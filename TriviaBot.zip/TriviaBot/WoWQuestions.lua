WOW_TRIVIA_QUESTIONS = {};
WOW_TRIVIA_ANSWERS1 = {};
WOW_TRIVIA_ANSWERS2 = {};
WOW_TRIVIA_ANSWERS3 = {};
WOW_TRIVIA_ANSWERS4 = {};
WOW_TRIVIA_ANSWERS5 = {};
WOW_TRIVIA_ANSWERS6 = {};
WOW_TRIVIA_ANSWERS7 = {};
WOW_TRIVIA_ANSWERS8 = {};

WOW_TRIVIA_QUESTIONS[1] = "Who is the third boss in Blackwing Lair?";
WOW_TRIVIA_ANSWERS1[1] = "Broodlord Lashlayer";
WOW_TRIVIA_ANSWERS2[1] = "Broodlord";

WOW_TRIVIA_QUESTIONS[2] = "What is the minimum level requirement for artisan skills? (1-60)";
WOW_TRIVIA_ANSWERS1[2] = "35";
WOW_TRIVIA_ANSWERS2[2] = "thirtyfive";
WOW_TRIVIA_ANSWERS3[2] = "thirty five";

WOW_TRIVIA_QUESTIONS[3] = "Which class can cast 'blessings'?";
WOW_TRIVIA_ANSWERS1[3] = "Paladins";
WOW_TRIVIA_ANSWERS2[3] = "Paladin";

WOW_TRIVIA_QUESTIONS[4] = "What is the zone north of Blasted Lands called? (full name)";
WOW_TRIVIA_ANSWERS1[4] = "Swamp of Sorrows";

WOW_TRIVIA_QUESTIONS[5] = "What is the busiest Alliance city?";
WOW_TRIVIA_ANSWERS1[5] = "Ironforge";
WOW_TRIVIA_ANSWERS2[5] = "IF";

WOW_TRIVIA_QUESTIONS[6] = "In which instance does General Drakkisath reside?";
WOW_TRIVIA_ANSWERS1[6] = "UBRS";
WOW_TRIVIA_ANSWERS2[6] = "Upper Blackrock Spire";

WOW_TRIVIA_QUESTIONS[7] = "What is Leeroy's surname?";
WOW_TRIVIA_ANSWERS1[7] = "Jenkins";

WOW_TRIVIA_QUESTIONS[8] = "What race has the 'Will of the Forsaken' racial ability?";
WOW_TRIVIA_ANSWERS1[8] = "Undead";
WOW_TRIVIA_ANSWERS2[8] = "Undeads";
WOW_TRIVIA_ANSWERS3[8] = "The Forsaken";
WOW_TRIVIA_ANSWERS4[8] = "Forsaken";

WOW_TRIVIA_QUESTIONS[9] = "What are low-leveled, buffed characters usually called?";
WOW_TRIVIA_ANSWERS1[9] = "Twinks";
WOW_TRIVIA_ANSWERS2[9] = "Twink";
WOW_TRIVIA_ANSWERS3[9] = "Twinked";

WOW_TRIVIA_QUESTIONS[10] = "Where does each class-specific tier 0 (ex. Lightforge) leggings drop?";
WOW_TRIVIA_ANSWERS1[10] = "Stratholme UD";
WOW_TRIVIA_ANSWERS2[10] = "Stratholme";
WOW_TRIVIA_ANSWERS3[10] = "strat";

WOW_TRIVIA_QUESTIONS[11] = "With whom must you reach exalted with to be able to buy 'The Unstoppable Force' (name one of the factions)?";
WOW_TRIVIA_ANSWERS1[11] = "stormpike";
WOW_TRIVIA_ANSWERS2[11] = "frostwolf";
WOW_TRIVIA_ANSWERS3[11] = "frostwolf clan";

WOW_TRIVIA_QUESTIONS[12] = "Who is the final boss in Molten Core?";
WOW_TRIVIA_ANSWERS1[12] = "Ragnaros";
WOW_TRIVIA_ANSWERS2[12] = "Ragnaros the Firelord";

WOW_TRIVIA_QUESTIONS[13] = "What does an orange-colored text on an item refer to?";
WOW_TRIVIA_ANSWERS1[13] = "Legendary Quality";
WOW_TRIVIA_ANSWERS2[13] = "legendary";

WOW_TRIVIA_QUESTIONS[14] = "What does a purple-colored text on an item refer to?";
WOW_TRIVIA_ANSWERS1[14] = "Epic Quality";
WOW_TRIVIA_ANSWERS2[14] = "epic";

WOW_TRIVIA_QUESTIONS[15] = "What does a blue-colored text on an item refer to?";
WOW_TRIVIA_ANSWERS1[15] = "Rare Quality";
WOW_TRIVIA_ANSWERS2[15] = "rare";

WOW_TRIVIA_QUESTIONS[16] = "What does a green-colored text on an item refer to?";
WOW_TRIVIA_ANSWERS1[16] = "Uncommon Quality";
WOW_TRIVIA_ANSWERS2[16] = "uncommon";

WOW_TRIVIA_QUESTIONS[17] = "Which of these end-game raiding instances is limited to 20 members? (UBRS, MC, AQ40, ZG, BWL";
WOW_TRIVIA_ANSWERS1[17] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[17] = "ZG";
WOW_TRIVIA_ANSWERS3[17] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[18] = "What is the lowest level requirement for an epic weapon?";
WOW_TRIVIA_ANSWERS1[18] = "35";
WOW_TRIVIA_ANSWERS2[18] = "thirty five";

WOW_TRIVIA_QUESTIONS[19] = "The Elements set corresponds to which class?";
WOW_TRIVIA_ANSWERS1[19] = "Shaman";
WOW_TRIVIA_ANSWERS2[19] = "Shammy";

WOW_TRIVIA_QUESTIONS[20] = "What is the tier 2 Priest set called?";
WOW_TRIVIA_ANSWERS1[20] = "Vestments of Transcendence";
WOW_TRIVIA_ANSWERS2[20] = "Transcendence";

WOW_TRIVIA_QUESTIONS[21] = "The Barrens was once a great forest under the protection of the Kaldorei's. (True/False)?";
WOW_TRIVIA_ANSWERS1[21] = "True";

WOW_TRIVIA_QUESTIONS[22] = "The three bugs in AQ40 are called Vem, Kri and ...?";
WOW_TRIVIA_ANSWERS1[22] = "Princess Yauj";
WOW_TRIVIA_ANSWERS2[22] = "Yauj";

WOW_TRIVIA_QUESTIONS[23] = "The abbreviation 'Org' refers to?";
WOW_TRIVIA_ANSWERS1[23] = "Orgrimmar";

WOW_TRIVIA_QUESTIONS[24] = "Duskbat Pelt drops in which zone?";
WOW_TRIVIA_ANSWERS1[24] = "Tirisfal Glades";
WOW_TRIVIA_ANSWERS2[24] = "Tirisfal";

WOW_TRIVIA_QUESTIONS[25] = "Lethtendris in Dire Maul is what race?";
WOW_TRIVIA_ANSWERS1[25] = "Blood Elf";

WOW_TRIVIA_QUESTIONS[26] = "Which of these classes cannot duel-wield? (Warrior, Paladin, Rogue)";
WOW_TRIVIA_ANSWERS1[26] = "Paladins";
WOW_TRIVIA_ANSWERS2[26] = "Paladin";

WOW_TRIVIA_QUESTIONS[27] = "In which major city can the NPC Renzik 'The Shiv' be found?";
WOW_TRIVIA_ANSWERS1[27] = "Stormwind";
WOW_TRIVIA_ANSWERS2[27] = "SW";

WOW_TRIVIA_QUESTIONS[28] = "Negolash is found wandering off which zone's coast?";
WOW_TRIVIA_ANSWERS1[28] = "Stranglethorn Vale";
WOW_TRIVIA_ANSWERS2[28] = "STV";

WOW_TRIVIA_QUESTIONS[29] = "Which class can cast 'Unending Breath'?";
WOW_TRIVIA_ANSWERS1[29] = "Warlocks";
WOW_TRIVIA_ANSWERS2[29] = "Warlock";

WOW_TRIVIA_QUESTIONS[30] = "Goblin Rocket Fuel can be used for Cooking. (True/False)?";
WOW_TRIVIA_ANSWERS1[30] = "true";

WOW_TRIVIA_QUESTIONS[31] = "For humans, the starting place is called?";
WOW_TRIVIA_ANSWERS1[31] = "Northshire Valley";
WOW_TRIVIA_ANSWERS2[31] = "northshire";
WOW_TRIVIA_ANSWERS3[31] = "northshire abbey";

WOW_TRIVIA_QUESTIONS[32] = "The King of Ironforge is called?";
WOW_TRIVIA_ANSWERS1[32] = "Magni Bronzebeard";
WOW_TRIVIA_ANSWERS2[32] = "bronzebeard";

WOW_TRIVIA_QUESTIONS[33] = "Using the Seal of Ascension in UBRS summons which Dragon?";
WOW_TRIVIA_ANSWERS1[33] = "Vaelastrasz";
WOW_TRIVIA_ANSWERS2[33] = "Vaelastrasz the Red";

WOW_TRIVIA_QUESTIONS[34] = "Which enchanting shard is the highest ingame at the moment?";
WOW_TRIVIA_ANSWERS1[34] = "Large Brilliant";
WOW_TRIVIA_ANSWERS2[34] = "Large Brilliant Shard";

WOW_TRIVIA_QUESTIONS[35] = "The cooldown on making Mooncloth is ____ days";
WOW_TRIVIA_ANSWERS1[35] = "Four";
WOW_TRIVIA_ANSWERS2[35] = "4";

WOW_TRIVIA_QUESTIONS[36] = "The Emerald Dragons are Ysondre, Emeriss, Taerar and _____?";
WOW_TRIVIA_ANSWERS1[36] = "Lethon";

WOW_TRIVIA_QUESTIONS[37] = "Wilddaddy!";
WOW_TRIVIA_ANSWERS1[37] = "Wilddaddy";

WOW_TRIVIA_QUESTIONS[38] = "Name a secondary trade skill.";
WOW_TRIVIA_ANSWERS1[38] = "First Aid";
WOW_TRIVIA_ANSWERS2[38] = "Fishing";
WOW_TRIVIA_ANSWERS3[38] = "Cooking";

WOW_TRIVIA_QUESTIONS[39] = "How much reputation does it take to get from revered to exalted?";
WOW_TRIVIA_ANSWERS1[39] = "21000";
WOW_TRIVIA_ANSWERS2[39] = "21k";
WOW_TRIVIA_ANSWERS3[39] = "21,000";

WOW_TRIVIA_QUESTIONS[40] = "To which zone can Druids teleport?";
WOW_TRIVIA_ANSWERS1[40] = "Moonglade";

WOW_TRIVIA_QUESTIONS[41] = "Which AQ40 boss drops the tanking trinket The Burrower's Shell?"
WOW_TRIVIA_ANSWERS1[41] = "Ouro";

WOW_TRIVIA_QUESTIONS[42] = "The enchant 'Enchant Chest - Major Mana' requires how many Lesser Eternal Essences?";
WOW_TRIVIA_ANSWERS1[42] = "Zero";
WOW_TRIVIA_ANSWERS2[42] = "0";

WOW_TRIVIA_QUESTIONS[43] = "The item 'Smite's Mighty Hammer' is what weapon-type?";
WOW_TRIVIA_ANSWERS1[43] = "Mace";
WOW_TRIVIA_ANSWERS2[43] = "a mace";

WOW_TRIVIA_QUESTIONS[44] = "_______ of Power consist of Zul'Gurub Coins, Bijous and Primal Hakkari items that can be obtained in Zul'Gurub.";
WOW_TRIVIA_ANSWERS1[44] = "Paragons";
WOW_TRIVIA_ANSWERS2[44] = "Paragon";

WOW_TRIVIA_QUESTIONS[45] = "The dungeon 'Maraudon' was released in which content patch?";
WOW_TRIVIA_ANSWERS1[45] = "1.2";

WOW_TRIVIA_QUESTIONS[46] = "In order to summon the Avatar of Hakkar in the Sunken Temple, you need 4x of what item?";
WOW_TRIVIA_ANSWERS1[46] = "Blood of Hakkar";
WOW_TRIVIA_ANSWERS2[46] = "blood";

WOW_TRIVIA_QUESTIONS[47] = "Reginald Windsor plays a part in what major Alliance quest chain?";
WOW_TRIVIA_ANSWERS1[47] = "Onyxia Key";
WOW_TRIVIA_ANSWERS2[47] = "Onyxia";
WOW_TRIVIA_ANSWERS3[47] = "Ony";

WOW_TRIVIA_QUESTIONS[48] = "Gnomes can purchase their mount just outside Ironforge, at _______'s Depot.";
WOW_TRIVIA_ANSWERS1[48] = "Steelgrill's Depot";
WOW_TRIVIA_ANSWERS2[48] = "Steelgrill";
WOW_TRIVIA_ANSWERS3[48] = "Steelgrill's";

WOW_TRIVIA_QUESTIONS[49] = "Cured Medium Hide can be created by leatherworkers of what skill level?";
WOW_TRIVIA_ANSWERS1[49] = "100";
WOW_TRIVIA_ANSWERS2[49] = "one hundred";

WOW_TRIVIA_QUESTIONS[50] = "Which class can cast Moonfire?";
WOW_TRIVIA_ANSWERS1[50] = "Druids";
WOW_TRIVIA_ANSWERS2[50] = "Druid";

WOW_TRIVIA_QUESTIONS[51] = "By how much does a Priest's Inner Focus spell increase crit chance?";
WOW_TRIVIA_ANSWERS1[51] = "25%";
WOW_TRIVIA_ANSWERS2[51] = "25";

WOW_TRIVIA_QUESTIONS[52] = "Which class has a talent tree called 'protection'?";
WOW_TRIVIA_ANSWERS1[52] = "Warriors";
WOW_TRIVIA_ANSWERS2[52] = "Warrior";
WOW_TRIVIA_ANSWERS3[52] = "Paladin";
WOW_TRIVIA_ANSWERS4[52] = "Paladins";

WOW_TRIVIA_QUESTIONS[53] = "The first boss in AQ40 is called?";
WOW_TRIVIA_ANSWERS1[53] = "The Prophet Skeram";
WOW_TRIVIA_ANSWERS2[53] = "Prophet Skeram";
WOW_TRIVIA_ANSWERS3[53] = "Skeram";

WOW_TRIVIA_QUESTIONS[54] = "Anubisath Defenders in AQ40 have 2 abilities they use close to death. Name one?";
WOW_TRIVIA_ANSWERS1[54] = "Enrage or Explode";
WOW_TRIVIA_ANSWERS2[54] = "Enrage";
WOW_TRIVIA_ANSWERS3[54] = "Explode";

WOW_TRIVIA_QUESTIONS[55] = "Blackwing Lair was released in which content patch?";
WOW_TRIVIA_ANSWERS1[55] = "1.6";

WOW_TRIVIA_QUESTIONS[56] = "To enter Blackwing Lair via the shortcut you need to touch an item called the _________?";
WOW_TRIVIA_ANSWERS1[56] = "Orb of Command";

WOW_TRIVIA_QUESTIONS[57] = "Name one of the flying Dragons of Blackwing Lair.";
WOW_TRIVIA_ANSWERS1[57] = "Ebonroc";
WOW_TRIVIA_ANSWERS2[57] = "Flamegor";
WOW_TRIVIA_ANSWERS3[57] = "Firemaw";
WOW_TRIVIA_ANSWERS4[57] = "Nefarian";

WOW_TRIVIA_QUESTIONS[58] = "Chromaggus's Brood Affliction: Blue is what kind of debuff type?";
WOW_TRIVIA_ANSWERS1[58] = "magic";

WOW_TRIVIA_QUESTIONS[59] = "The tier 2 shoulders drop from which boss?";
WOW_TRIVIA_ANSWERS1[59] = "Chromaggus";

WOW_TRIVIA_QUESTIONS[60] = "Acronyms: What does ZF stand for?";
WOW_TRIVIA_ANSWERS1[60] = "Zul'Farrak";
WOW_TRIVIA_ANSWERS2[60] = "zulfarrak";
WOW_TRIVIA_ANSWERS3[60] = "zul farrak";

WOW_TRIVIA_QUESTIONS[61] = "Acronyms: What does ZG stand for?";
WOW_TRIVIA_ANSWERS1[61] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[61] = "zulgurub";
WOW_TRIVIA_ANSWERS3[61] = "zul gurub";

WOW_TRIVIA_QUESTIONS[62] = "What being was supposedly created by the Old God, C'thun, as a mockery of life?";
WOW_TRIVIA_ANSWERS1[62] = "Ouro";
WOW_TRIVIA_ANSWERS2[62] = "Ouro the Sandworm";

WOW_TRIVIA_QUESTIONS[63] = "Acronyms: What does WTT stand for?";
WOW_TRIVIA_ANSWERS1[63] = "Want To Trade";

WOW_TRIVIA_QUESTIONS[64] = "Acronyms: What does NPC stand for?";
WOW_TRIVIA_ANSWERS1[64] = "Non-Player Character";
WOW_TRIVIA_ANSWERS2[64] = "Non Player Character";
WOW_TRIVIA_ANSWERS3[64] = "Non Playing Character";

WOW_TRIVIA_QUESTIONS[65] = "Acronyms: What does ML stand for?";
WOW_TRIVIA_ANSWERS1[65] = "Master Looter";
WOW_TRIVIA_ANSWERS2[65] = "Main Loot";
WOW_TRIVIA_ANSWERS3[65] = "Masterloot";
WOW_TRIVIA_ANSWERS4[65] = "Master Loot";

WOW_TRIVIA_QUESTIONS[66] = "Acronyms: What does DPS stand for?";
WOW_TRIVIA_ANSWERS1[66] = "damage per second";

WOW_TRIVIA_QUESTIONS[67] = "Acronyms: What does PoM stand for?";
WOW_TRIVIA_ANSWERS1[67] = "Presence of Mind";

WOW_TRIVIA_QUESTIONS[68] = "Completing the quest 'Imperial Qiraji Armaments' takes how many Elementium Ore's?";
WOW_TRIVIA_ANSWERS1[68] = "Three";
WOW_TRIVIA_ANSWERS2[68] = "3";

WOW_TRIVIA_QUESTIONS[69] = "The debuff 'Veil of Shadow' reduces healing by what percentage?";
WOW_TRIVIA_ANSWERS1[69] = "75";
WOW_TRIVIA_ANSWERS2[69] = "seventy-five";
WOW_TRIVIA_ANSWERS3[69] = "seventy five";
WOW_TRIVIA_ANSWERS4[69] = "seventyfive";

WOW_TRIVIA_QUESTIONS[70] = "Guess The Zone: A Desert Zone with a Goblin town in it.";
WOW_TRIVIA_ANSWERS1[70] = "Tanaris";

WOW_TRIVIA_QUESTIONS[71] = "Guess The Zone: A Tropical Zone, with lots of coastlines, and a Goblin Port.";
WOW_TRIVIA_ANSWERS1[71] = "STV";
WOW_TRIVIA_ANSWERS2[71] = "Stranglethorn Vale";

WOW_TRIVIA_QUESTIONS[72] = "Guess The Zone: Has volcanic terrain, and 'The Cauldron'.";
WOW_TRIVIA_ANSWERS1[72] = "Searing Gorge";

WOW_TRIVIA_QUESTIONS[73] = "Guess The Zone: A Tropical Zone, which has a dark portal, and a mountain you can parachute off.";
WOW_TRIVIA_ANSWERS1[73] = "Feralas";

WOW_TRIVIA_QUESTIONS[74] = "Guess The Zone: A Diseased wooded zone with special plants.";
WOW_TRIVIA_ANSWERS1[74] = "Felwood";

WOW_TRIVIA_QUESTIONS[75] = "Guess The Zone: A Winter Zone which has hot springs.";
WOW_TRIVIA_ANSWERS1[75] = "Winterspring";

WOW_TRIVIA_QUESTIONS[76] = "the PvP 'Grunts' rank are which rank?";
WOW_TRIVIA_ANSWERS1[76] = "Two";
WOW_TRIVIA_ANSWERS2[76] = "2";

WOW_TRIVIA_QUESTIONS[77] = "The Maker's Terrace can be found outside which instance?";
WOW_TRIVIA_ANSWERS1[77] = "Uldaman";
WOW_TRIVIA_ANSWERS2[77] = "Ulda";

WOW_TRIVIA_QUESTIONS[78] = "'Clam Chowder' grants a well fed buff with how much spirit and stamina?";
WOW_TRIVIA_ANSWERS1[78] = "Zero";
WOW_TRIVIA_ANSWERS2[78] = "0";

WOW_TRIVIA_QUESTIONS[79] = "'Tender Wolf Steak' grants a well fed buff with how much spirit and stamina?";
WOW_TRIVIA_ANSWERS1[79] = "Twelve";
WOW_TRIVIA_ANSWERS2[79] = "12";

WOW_TRIVIA_QUESTIONS[80] = "What is the cooldown of the 'Transmute: Arcanite' skill?";
WOW_TRIVIA_ANSWERS1[80] = "48 hours";
WOW_TRIVIA_ANSWERS2[80] = "2 days";
WOW_TRIVIA_ANSWERS3[80] = "two days";

WOW_TRIVIA_QUESTIONS[81] = "How many primary and secondary professions are there all together?";
WOW_TRIVIA_ANSWERS1[81] = "Twelve";
WOW_TRIVIA_ANSWERS2[81] = "12";

WOW_TRIVIA_QUESTIONS[82] = "How many copper bars are required to make 1x copper chain pants?";
WOW_TRIVIA_ANSWERS1[82] = "Four";
WOW_TRIVIA_ANSWERS2[82] = "4";

WOW_TRIVIA_QUESTIONS[83] = "How much does a linen bandage heal for (per second)?";
WOW_TRIVIA_ANSWERS1[83] = "Eleven";
WOW_TRIVIA_ANSWERS2[83] = "11";

WOW_TRIVIA_QUESTIONS[84] = "What is the only class totally devoid of healing effects?";
WOW_TRIVIA_ANSWERS1[84] = "Mage";
WOW_TRIVIA_ANSWERS2[84] = "Mages";

WOW_TRIVIA_QUESTIONS[85] = "Which Horde race cannot be a Shaman?";
WOW_TRIVIA_ANSWERS1[85] = "Undeads";
WOW_TRIVIA_ANSWERS2[85] = "Undead";

WOW_TRIVIA_QUESTIONS[86] = "The Valley Of Trials is the starting area for which races (name at least one)?";
WOW_TRIVIA_ANSWERS1[86] = "Orcs and Trolls";
WOW_TRIVIA_ANSWERS2[86] = "Orcs";
WOW_TRIVIA_ANSWERS3[86] = "Trolls";
WOW_TRIVIA_ANSWERS4[86] = "Troll";
WOW_TRIVIA_ANSWERS5[86] = "Orc";

WOW_TRIVIA_QUESTIONS[87] = "How many weapon types are there (like one-handed sword, two-handed sword, dagger etc.)?";
WOW_TRIVIA_ANSWERS1[87] = "Sixteen";
WOW_TRIVIA_ANSWERS2[87] = "16";

WOW_TRIVIA_QUESTIONS[88] = "What is the name of the zone that lies west of Tanaris?";
WOW_TRIVIA_ANSWERS1[88] = "Un'Goro Crater";
WOW_TRIVIA_ANSWERS2[88] = "Un'Goro";
WOW_TRIVIA_ANSWERS3[88] = "UnGoro";
WOW_TRIVIA_ANSWERS4[88] = "Un Goro";

WOW_TRIVIA_QUESTIONS[89] = "How many combinations of races(8) and classes(6) can be made?";
WOW_TRIVIA_ANSWERS1[89] = "Forty";
WOW_TRIVIA_ANSWERS2[89] = "40";

WOW_TRIVIA_QUESTIONS[90] = "What continent in Azeroth has two Horde capital cities?";
WOW_TRIVIA_ANSWERS1[90] = "Kalimdor";

WOW_TRIVIA_QUESTIONS[91] = "Attempting to swim the Great Sea will ultimatly lead to death by _____?";
WOW_TRIVIA_ANSWERS1[91] = "Fatigue";

WOW_TRIVIA_QUESTIONS[92] = "Name one of the continents in Azeroth that actually is ingame and accessible?";
WOW_TRIVIA_ANSWERS1[92] = "Eastern Kingdoms";
WOW_TRIVIA_ANSWERS2[92] = "Kalimdor";

WOW_TRIVIA_QUESTIONS[93] = "Who is the player who once got banned and is now back? Also everyone tends to hate him/her.";
WOW_TRIVIA_ANSWERS1[93] = "Flo";


WOW_TRIVIA_QUESTIONS[94] = "Essence of the Red in the Vaelastrasz encounter restores how much energy per second?";
WOW_TRIVIA_ANSWERS1[94] = "Fifty";
WOW_TRIVIA_ANSWERS2[94] = "50";

WOW_TRIVIA_QUESTIONS[95] = "The transport mechanism between the southern Barrens and Thousand Needles is called?";
WOW_TRIVIA_ANSWERS1[95] = "The Great Lift";
WOW_TRIVIA_ANSWERS2[95] = "great lift";

WOW_TRIVIA_QUESTIONS[96] = "'Skull Rock' is found in which zone?";
WOW_TRIVIA_ANSWERS1[96] = "Durotar";

WOW_TRIVIA_QUESTIONS[97] = "Sven and Lars can be found at which camp?";
WOW_TRIVIA_ANSWERS1[97] = "Rebel Camp";
WOW_TRIVIA_ANSWERS2[97] = "Rebel";

WOW_TRIVIA_QUESTIONS[98] = "Larion's companion in Un'Goro Crater is called?";
WOW_TRIVIA_ANSWERS1[98] = "Muigin";
WOW_TRIVIA_ANSWERS2[98] = "Muigi";

WOW_TRIVIA_QUESTIONS[99] = "Sten Stoutarm starts intrepid adventurers of which race(s) on their first quest?";
WOW_TRIVIA_ANSWERS1[99] = "Gnomes and dwarves";
WOW_TRIVIA_ANSWERS2[99] = "Gnomes";
WOW_TRIVIA_ANSWERS3[99] = "dwarves";

WOW_TRIVIA_QUESTIONS[100] = "The Icebane set grants resistence to which school of magic?";
WOW_TRIVIA_ANSWERS1[100] = "Frost";

WOW_TRIVIA_QUESTIONS[101] = "The 'Banner of Provocation' is used in which questline?";
WOW_TRIVIA_ANSWERS1[101] = "tier 0.5";
WOW_TRIVIA_ANSWERS2[101] = "t0.5";

WOW_TRIVIA_QUESTIONS[102] = "Sarltooth in the Wetlands is what type of beast?";
WOW_TRIVIA_ANSWERS1[102] = "Raptor";

WOW_TRIVIA_QUESTIONS[103] = "Light Feathers are used as a reagent by which class?";
WOW_TRIVIA_ANSWERS1[103] = "Mage and Priest";
WOW_TRIVIA_ANSWERS2[103] = "Mage";
WOW_TRIVIA_ANSWERS3[103] = "Priest";

WOW_TRIVIA_QUESTIONS[104] = "To throw a 'Rough Dynamite' requires what skill level in Engineering?";
WOW_TRIVIA_ANSWERS1[104] = "1";
WOW_TRIVIA_ANSWERS2[104] = "One";

WOW_TRIVIA_QUESTIONS[105] = "Jaina Proudmoore's father is called?";
WOW_TRIVIA_ANSWERS1[105] = "Daelin Proudmoore";
WOW_TRIVIA_ANSWERS2[105] = "Daelin";

WOW_TRIVIA_QUESTIONS[106] = "Cooking a 'Herb Baked Egg' requires which type of spice?";
WOW_TRIVIA_ANSWERS1[106] = "Mild Spices";
WOW_TRIVIA_ANSWERS2[106] = "mild";

WOW_TRIVIA_QUESTIONS[107] = "Huhuran's Stinger grants how much extra agility?";
WOW_TRIVIA_ANSWERS1[107] = "Eighteen";
WOW_TRIVIA_ANSWERS2[107] = "18";

WOW_TRIVIA_QUESTIONS[108] = "The 'Soulforge' set can only be used by which class?";
WOW_TRIVIA_ANSWERS1[108] = "Paladins";
WOW_TRIVIA_ANSWERS2[108] = "Paladin";

WOW_TRIVIA_QUESTIONS[109] = "The Twilight Vale can be found in which zone?";
WOW_TRIVIA_ANSWERS1[109] = "Darkshore";

WOW_TRIVIA_QUESTIONS[110] = "What is the duration on Prayer of Shadow Protection?";
WOW_TRIVIA_ANSWERS1[110] = "20 Minutes";
WOW_TRIVIA_ANSWERS2[110] = "20 min";
WOW_TRIVIA_ANSWERS3[110] = "20 mins";

WOW_TRIVIA_QUESTIONS[111] = "Who on the Emerald Dream Forums posts pictures of Asian Chicks?";
WOW_TRIVIA_ANSWERS1[111] = "Mizry";


WOW_TRIVIA_QUESTIONS[112] = "The Bramblewood set grants resistance to what?";
WOW_TRIVIA_ANSWERS1[112] = "Nature";
WOW_TRIVIA_ANSWERS2[112] = "NR";

WOW_TRIVIA_QUESTIONS[113] = "The Doom Touched Warriors are found in which instance?";
WOW_TRIVIA_ANSWERS1[113] = "Naxxramas";
WOW_TRIVIA_ANSWERS2[113] = "Naxx";

WOW_TRIVIA_QUESTIONS[114] = "What will undead NPC's not do?";
WOW_TRIVIA_ANSWERS1[114] = "Swim";
WOW_TRIVIA_ANSWERS2[114] = "swimming";

WOW_TRIVIA_QUESTIONS[115] = "What is the Wildbend River called further upstream?";
WOW_TRIVIA_ANSWERS1[115] = "Bloodvenom River";
WOW_TRIVIA_ANSWERS2[115] = "Bloodvenom";

WOW_TRIVIA_QUESTIONS[116] = "The NPC Donni Anthania sells which kind of non-combat pet?";
WOW_TRIVIA_ANSWERS1[116] = "cats";
WOW_TRIVIA_ANSWERS2[116] = "cat";

WOW_TRIVIA_QUESTIONS[117] = "What is the Rogue's tier 3 called?";
WOW_TRIVIA_ANSWERS1[117] = "Bonescythe Armor";
WOW_TRIVIA_ANSWERS2[117] = "Bonescythe";


WOW_TRIVIA_QUESTIONS[118] = "To get a pet chicken (Chicken Egg) players must complete which quest?";
WOW_TRIVIA_ANSWERS1[118] = "CLUCK!";
WOW_TRIVIA_ANSWERS2[118] = "cluck";

WOW_TRIVIA_QUESTIONS[119] = "Amberseal Keeper grants how much magical resistance to all?";
WOW_TRIVIA_ANSWERS1[119] = "Five";
WOW_TRIVIA_ANSWERS2[119] = "5";

WOW_TRIVIA_QUESTIONS[120] = "What is the biggest lake in Azeroth?";
WOW_TRIVIA_ANSWERS1[120] = "Lordamere Lake";
WOW_TRIVIA_ANSWERS2[120] = "Lordamere";

WOW_TRIVIA_QUESTIONS[121] = "Upon using an Orb of Deception, what race will a dwarf turn into?";
WOW_TRIVIA_ANSWERS1[121] = "Darkspear Troll";
WOW_TRIVIA_ANSWERS2[121] = "Troll";

WOW_TRIVIA_QUESTIONS[122] = "Who is the father of the dreaded Lord of Blackrock, Nefarian?";
WOW_TRIVIA_ANSWERS1[122] = "Neltharion";
WOW_TRIVIA_ANSWERS2[122] = "Deathwing";
WOW_TRIVIA_ANSWERS3[122] = "The Earth-warder";
WOW_TRIVIA_ANSWERS4[122] = "Neltharion the Earth-Warder";

WOW_TRIVIA_QUESTIONS[123] = "What is the name of the original World Tree?";
WOW_TRIVIA_ANSWERS1[123] = "Nordrassil";

WOW_TRIVIA_QUESTIONS[124] = "How many people does it take to perform a Ritual of Summoning?";
WOW_TRIVIA_ANSWERS1[124] = "Three";
WOW_TRIVIA_ANSWERS2[124] = "3";

WOW_TRIVIA_QUESTIONS[125] = "In which patch was the honor system implemented?";
WOW_TRIVIA_ANSWERS1[125] = "1.4";

WOW_TRIVIA_QUESTIONS[126] = "In which patch were the first battlegrounds added?";
WOW_TRIVIA_ANSWERS1[126] = "1.5";

WOW_TRIVIA_QUESTIONS[127] = "In which patch were weather effects implemented?";
WOW_TRIVIA_ANSWERS1[127] = "1.10";

WOW_TRIVIA_QUESTIONS[128] = "In which patch was the Druid talent review?";
WOW_TRIVIA_ANSWERS1[128] = "1.8";

WOW_TRIVIA_QUESTIONS[129] = "In which patch was the Mage talent review?";
WOW_TRIVIA_ANSWERS1[129] = "1.11";

WOW_TRIVIA_QUESTIONS[130] = "Which class(es) has a restoration talent tree? (name both or one of them)";
WOW_TRIVIA_ANSWERS1[130] = "Druid";
WOW_TRIVIA_ANSWERS2[130] = "Shaman";
WOW_TRIVIA_ANSWERS3[130] = "Shamans";
WOW_TRIVIA_ANSWERS4[130] = "Druids";
WOW_TRIVIA_ANSWERS5[130] = "Druid and Shaman";
WOW_TRIVIA_ANSWERS6[130] = "Druids and Shamans";
WOW_TRIVIA_ANSWERS7[130] = "Shaman and Druid";
WOW_TRIVIA_ANSWERS8[130] = "Shamans and Druids";

WOW_TRIVIA_QUESTIONS[131] = "To get 120 energy, Rogues must have 5 / 8 Nightslayer, and 31 points in which talent tree?";
WOW_TRIVIA_ANSWERS1[131] = "Assassination";

WOW_TRIVIA_QUESTIONS[132] = "Which racial skill breaks fear effects?";
WOW_TRIVIA_ANSWERS1[132] = "Will of the Forsaken";
WOW_TRIVIA_ANSWERS2[132] = "wotf";

WOW_TRIVIA_QUESTIONS[133] = "What are Mages also known as (especially before a raid)?";
WOW_TRIVIA_ANSWERS1[133] = "Vending Machine";
WOW_TRIVIA_ANSWERS2[133] = "vendor";
WOW_TRIVIA_ANSWERS3[133] = "water vendor";

WOW_TRIVIA_QUESTIONS[134] = "What is the duration of a Rogue's 5 point kidney shot? (__ sec)";
WOW_TRIVIA_ANSWERS1[134] = "6 seconds";
WOW_TRIVIA_ANSWERS2[134] = "6 secs";
WOW_TRIVIA_ANSWERS3[134] = "6 sec";
WOW_TRIVIA_ANSWERS4[134] = "6";
WOW_TRIVIA_ANSWERS5[134] = "six";

WOW_TRIVIA_QUESTIONS[135] = "What is the hardest race to target in a Battleground?";
WOW_TRIVIA_ANSWERS1[135] = "Gnome";
WOW_TRIVIA_ANSWERS2[135] = "Gnomes";

WOW_TRIVIA_QUESTIONS[136] = "What color does a Rogue have on CT_Raid?";
WOW_TRIVIA_ANSWERS1[136] = "Yellow";

WOW_TRIVIA_QUESTIONS[137] = "How many parts does the Temple of Ahn'Qiraj sets have? (hint: Tier 2.5)";
WOW_TRIVIA_ANSWERS1[137] = "Five";
WOW_TRIVIA_ANSWERS2[137] = "5";

WOW_TRIVIA_QUESTIONS[138] = "Which element slows Viscidus, and is needed in order to defeat him?";
WOW_TRIVIA_ANSWERS1[138] = "Frost";

WOW_TRIVIA_QUESTIONS[139] = "How many bosses can drop tier 2 gloves in Blackwing Lair?";
WOW_TRIVIA_ANSWERS1[139] = "Three";
WOW_TRIVIA_ANSWERS2[139] = "3";

WOW_TRIVIA_QUESTIONS[140] = "Who is known as 'The Ashbringer'?";
WOW_TRIVIA_ANSWERS1[140] = "Highlord Mograine";
WOW_TRIVIA_ANSWERS2[140] = "Mograine";

WOW_TRIVIA_QUESTIONS[141] = "Which drop from Hakkar allows you to get 3 different epic trinkets? (full name)";
WOW_TRIVIA_ANSWERS1[141] = "Heart of Hakkar";

WOW_TRIVIA_QUESTIONS[142] = "What level of reputation with Argent Dawn is needed in order to attune to Naxxramas?";
WOW_TRIVIA_ANSWERS1[142] = "Honored";

WOW_TRIVIA_QUESTIONS[143] = "What herb is required for all the Greater Protection potions?";
WOW_TRIVIA_ANSWERS1[143] = "Dreamfoil";

WOW_TRIVIA_QUESTIONS[144] = "Which instance is located in Silverpine Forest?";
WOW_TRIVIA_ANSWERS1[144] = "Shadowfang Keep";
WOW_TRIVIA_ANSWERS2[144] = "SFK";

WOW_TRIVIA_QUESTIONS[145] = "At what percentage of health does Princess Huhuran enrage?";
WOW_TRIVIA_ANSWERS1[145] = "30%";
WOW_TRIVIA_ANSWERS2[145] = "30";
WOW_TRIVIA_ANSWERS3[145] = "thirty";

WOW_TRIVIA_QUESTIONS[146] = "How much spellcrit does the 'Rallying Cry of the Dragonslayer' buff give?";
WOW_TRIVIA_ANSWERS1[146] = "10";
WOW_TRIVIA_ANSWERS2[146] = "10%";

WOW_TRIVIA_QUESTIONS[147] = "Which Naxxramas boss has two helpers called Stalagg and Fuegan?";
WOW_TRIVIA_ANSWERS1[147] = "Thaddius";

WOW_TRIVIA_QUESTIONS[148] = "Who drops the Hunter book 'Tranquilizing shot'?";
WOW_TRIVIA_ANSWERS1[148] = "Lucifron";

WOW_TRIVIA_QUESTIONS[149] = "Which class is considered the 'purest' of the healing classes?";
WOW_TRIVIA_ANSWERS1[149] = "Priest";

WOW_TRIVIA_QUESTIONS[150] = "How many tracks does the world of warcraft soundtrack have?";
WOW_TRIVIA_ANSWERS1[150] = "30";
WOW_TRIVIA_ANSWERS2[150] = "thirty";

WOW_TRIVIA_QUESTIONS[151] = "How much rage does the improved berserker rage talent (2/2) generate?";
WOW_TRIVIA_ANSWERS1[151] = "10";
WOW_TRIVIA_ANSWERS2[151] = "ten";

WOW_TRIVIA_QUESTIONS[152] = "How long does the unimproved Shield Wall last? ( ___ sec)";
WOW_TRIVIA_ANSWERS1[152] = "10 seconds";
WOW_TRIVIA_ANSWERS2[152] = "10";
WOW_TRIVIA_ANSWERS3[152] = "ten";
WOW_TRIVIA_ANSWERS4[152] = "ten secs";
WOW_TRIVIA_ANSWERS5[152] = "ten sec";
WOW_TRIVIA_ANSWERS6[152] = "10 sec";

WOW_TRIVIA_QUESTIONS[153] = "Who on Emerald Dream Forums Created Vanilla Guide?";
WOW_TRIVIA_ANSWERS1[153] = "mrmr";


WOW_TRIVIA_QUESTIONS[154] = "How much damage does each point of rage convert into on the last rank of Execute?";
WOW_TRIVIA_ANSWERS1[154] = "18";
WOW_TRIVIA_ANSWERS2[154] = "eighteen";

WOW_TRIVIA_QUESTIONS[155] = "Switching Stances constantly as a Warrior is called?";
WOW_TRIVIA_ANSWERS1[155] = "stance dance";
WOW_TRIVIA_ANSWERS2[155] = "stance dancing";
WOW_TRIVIA_ANSWERS3[155] = "stance-dancing";
WOW_TRIVIA_ANSWERS4[155] = "stance-dance";

WOW_TRIVIA_QUESTIONS[156] = "The last rank of Sunder Armor reduces armor by how much?";
WOW_TRIVIA_ANSWERS1[156] = "520";
WOW_TRIVIA_ANSWERS2[156] = "450";


WOW_TRIVIA_QUESTIONS[157] = "Piercing Howl reduces the movement speed of enemies by what percentage?";
WOW_TRIVIA_ANSWERS1[157] = "50%";
WOW_TRIVIA_ANSWERS2[157] = "50";
WOW_TRIVIA_ANSWERS3[157] = "fifty";

WOW_TRIVIA_QUESTIONS[158] = "Overpower can only be used after the target does what?";
WOW_TRIVIA_ANSWERS1[158] = "dodge";
WOW_TRIVIA_ANSWERS2[158] = "dodges";

WOW_TRIVIA_QUESTIONS[159] = "The talent Blood Craze can be found in which talent tree?";
WOW_TRIVIA_ANSWERS1[159] = "Fury";

WOW_TRIVIA_QUESTIONS[160] = "Rend (Rank 7) causes ___ damage over 21 secs.";
WOW_TRIVIA_ANSWERS1[160] = "147";
WOW_TRIVIA_ANSWERS2[160] = "One hundred fourty seven";

WOW_TRIVIA_QUESTIONS[161] = "Which Warrior ability reduces healing effects by 50%?";
WOW_TRIVIA_ANSWERS1[161] = "Mortal Strike";
WOW_TRIVIA_ANSWERS2[161] = "MS";

WOW_TRIVIA_QUESTIONS[162] = "Which sword was too powerful to be included in the game? (hint: Southpark)";
WOW_TRIVIA_ANSWERS1[162] = "The Sword of a Thousand Truths";
WOW_TRIVIA_ANSWERS2[162] = "sword of a thousand truths";
WOW_TRIVIA_ANSWERS3[162] = "sword of a 1000 truths";

WOW_TRIVIA_QUESTIONS[163] = "How much spell damage does the Zandalarian Hero Charm increase?";
WOW_TRIVIA_ANSWERS1[163] = "204";
WOW_TRIVIA_ANSWERS2[163] = "two hundred four";

WOW_TRIVIA_QUESTIONS[164] = "Which races can use a Mechanostrider Mount? (x and y)";
WOW_TRIVIA_ANSWERS1[164] = "dwarves and Gnomes";
WOW_TRIVIA_ANSWERS2[164] = "Dwarf and Gnome";
WOW_TRIVIA_ANSWERS3[164] = "Gnomes and dwarves";

WOW_TRIVIA_QUESTIONS[165] = "How long cooldown does the Zandalarian Hero Charm have?";
WOW_TRIVIA_ANSWERS1[165] = "2 minutes";
WOW_TRIVIA_ANSWERS2[165] = "2 min";
WOW_TRIVIA_ANSWERS3[165] = "2";
WOW_TRIVIA_ANSWERS4[165] = "2 mins";
WOW_TRIVIA_ANSWERS5[165] = "two minutes";
WOW_TRIVIA_ANSWERS6[165] = "two min";
WOW_TRIVIA_ANSWERS7[165] = "two";
WOW_TRIVIA_ANSWERS8[165] = "two mins";

WOW_TRIVIA_QUESTIONS[166] = "Who Drops Infernals at Crossroads on Emerald Dream?";
WOW_TRIVIA_ANSWERS1[166] = "Kray";


WOW_TRIVIA_QUESTIONS[167] = "What is Mages with talents mainly in Frost and Fire called?";
WOW_TRIVIA_ANSWERS1[167] = "Elemental";
WOW_TRIVIA_ANSWERS2[167] = "Elemental Mages";

WOW_TRIVIA_QUESTIONS[168] = "What two things can a Mage polymorph his foe into, besides a sheep?";
WOW_TRIVIA_ANSWERS1[168] = "Pig and Turtle";
WOW_TRIVIA_ANSWERS2[168] = "Turtle and Pig";
WOW_TRIVIA_ANSWERS3[168] = "Pig";
WOW_TRIVIA_ANSWERS4[168] = "Turtle";

WOW_TRIVIA_QUESTIONS[169] = "Which boss drops Ashkandi, greatsword of the Brotherhood?";
WOW_TRIVIA_ANSWERS1[169] = "Nefarian";

WOW_TRIVIA_QUESTIONS[170] = "What beast is Grimclaw, which patrols Darkshore?";
WOW_TRIVIA_ANSWERS1[170] = "Bear";
WOW_TRIVIA_ANSWERS2[170] = "Icebear";
WOW_TRIVIA_ANSWERS3[170] = "Ice-bear";

WOW_TRIVIA_QUESTIONS[171] = "How many people are there in a full party?";
WOW_TRIVIA_ANSWERS1[171] = "5";
WOW_TRIVIA_ANSWERS2[171] = "five";

WOW_TRIVIA_QUESTIONS[172] = "How many people are there in a full raid?";
WOW_TRIVIA_ANSWERS1[172] = "40";
WOW_TRIVIA_ANSWERS2[172] = "forty";

WOW_TRIVIA_QUESTIONS[173] = "Who can teach you how to use one handed swords in Stormwind?";
WOW_TRIVIA_ANSWERS1[173] = "Wu Ping";

WOW_TRIVIA_QUESTIONS[174] = "Curse of agony ticks every ___ seconds?";
WOW_TRIVIA_ANSWERS1[174] = "Two";
WOW_TRIVIA_ANSWERS2[174] = "2";

WOW_TRIVIA_QUESTIONS[175] = "Curse of doom ticks for how much base damage?";
WOW_TRIVIA_ANSWERS1[175] = "4200";
WOW_TRIVIA_ANSWERS2[175] = "four thousand two hundred";

WOW_TRIVIA_QUESTIONS[176] = "How many statues is there outside Stormwind?";
WOW_TRIVIA_ANSWERS1[176] = "6";
WOW_TRIVIA_ANSWERS2[176] = "Six";

WOW_TRIVIA_QUESTIONS[177] = "Where is the Valley of Heroes?";
WOW_TRIVIA_ANSWERS1[177] = "Stormwind";
WOW_TRIVIA_ANSWERS2[177] = "SW";

WOW_TRIVIA_QUESTIONS[178] = "Where is the Valley of Kings?";
WOW_TRIVIA_ANSWERS1[178] = "Loch Modan";

WOW_TRIVIA_QUESTIONS[179] = "Which class originally soloed Kazzak?";
WOW_TRIVIA_ANSWERS1[179] = "Paladin";
WOW_TRIVIA_ANSWERS2[179] = "Paladins";

WOW_TRIVIA_QUESTIONS[180] = "How many DoTs can a warlock have as abilities?";
WOW_TRIVIA_ANSWERS1[180] = "5";
WOW_TRIVIA_ANSWERS2[180] = "Five";

WOW_TRIVIA_QUESTIONS[181] = "What day did emerald dream open for play? (mm-dd-yyyy)";
WOW_TRIVIA_ANSWERS1[181] = "7-25-2013";

WOW_TRIVIA_QUESTIONS[182] = "What class besides a Warrior has a talent tree called protection?";
WOW_TRIVIA_ANSWERS1[182] = "Paladin";
WOW_TRIVIA_ANSWERS2[182] = "Paladins";

WOW_TRIVIA_QUESTIONS[183] = "Before the Paladin revamp, what was the top tier spell in the retribution tree of Paladins?";
WOW_TRIVIA_ANSWERS1[183] = "Blessing of Kings";
WOW_TRIVIA_ANSWERS2[183] = "BoK";

WOW_TRIVIA_QUESTIONS[184] = "How many capital cities is there ingame?";
WOW_TRIVIA_ANSWERS1[184] = "6";
WOW_TRIVIA_ANSWERS2[184] = "Six";

WOW_TRIVIA_QUESTIONS[185] = "On which boss in Naxxramas do you have to mind control a mob, but not use it for more than 5 seconds?";
WOW_TRIVIA_ANSWERS1[185] = "Grand widow faerlina";
WOW_TRIVIA_ANSWERS2[185] = "Faerlina";

WOW_TRIVIA_QUESTIONS[186] = "What is the Alliance equivelent to Will of the Forsaken? (gives a great advantage against a certain class)";
WOW_TRIVIA_ANSWERS1[186] = "perception";

WOW_TRIVIA_QUESTIONS[187] = "Who originally dropped the lightforge gauntlets?";
WOW_TRIVIA_ANSWERS1[187] = "Emperor Dagran Thaurissan";
WOW_TRIVIA_ANSWERS2[187] = "Dagran Thaurissan";

WOW_TRIVIA_QUESTIONS[188] = "In which zone does most blindweed grow?";
WOW_TRIVIA_ANSWERS1[188] = "Swamp of Sorrows";

WOW_TRIVIA_QUESTIONS[189] = "Which is the only zone where you can find gromsblood, mountain silversage and dreamfoil?";
WOW_TRIVIA_ANSWERS1[189] = "Felwood";

WOW_TRIVIA_QUESTIONS[190] = "Which flask provides players with an extra 1200 HP for 2 hours?";
WOW_TRIVIA_ANSWERS1[190] = "Flask of the Titans";
WOW_TRIVIA_ANSWERS2[190] = "titans";
WOW_TRIVIA_ANSWERS3[190] = "titan";

WOW_TRIVIA_QUESTIONS[191] = "Loatheb usually requires many Greater ______ Protection Potions.";
WOW_TRIVIA_ANSWERS1[191] = "Shadow";

WOW_TRIVIA_QUESTIONS[192] = "What is the name of the monument in Azshara that has been broken in half?";
WOW_TRIVIA_ANSWERS1[192] = "Ravencrest Monument";
WOW_TRIVIA_ANSWERS2[192] = "Ravencrest";

WOW_TRIVIA_QUESTIONS[193] = "What is the name of the last boss in Shadowfang Keep?";
WOW_TRIVIA_ANSWERS1[193] = "Arugal";
WOW_TRIVIA_ANSWERS2[193] = "Archmage Arugal";

WOW_TRIVIA_QUESTIONS[194] = "What is the ideal amount of Warriors for the 4 Horsemen fight in Naxxramas?";
WOW_TRIVIA_ANSWERS1[194] = "8";
WOW_TRIVIA_ANSWERS2[194] = "Eight";

WOW_TRIVIA_QUESTIONS[195] = "Blackwing Lair was introduced in which patch?";
WOW_TRIVIA_ANSWERS1[195] = "1.6";

WOW_TRIVIA_QUESTIONS[196] = "Gothik the Harvester in Naxxramas has how many waves of adds?";
WOW_TRIVIA_ANSWERS1[196] = "18";
WOW_TRIVIA_ANSWERS2[196] = "Eighteen";

WOW_TRIVIA_QUESTIONS[197] = "What trinket allows you to kill yourself when equipped?";
WOW_TRIVIA_ANSWERS1[197] = "Crystal of Zin-Malor";
WOW_TRIVIA_ANSWERS2[197] = "Zin-Malor";

WOW_TRIVIA_QUESTIONS[198] = "What is the color of the rarest AQ40 mount that drops from trash mobs?";
WOW_TRIVIA_ANSWERS1[198] = "red";

WOW_TRIVIA_QUESTIONS[199] = "What herb will sometimes spawn instead of grave moss in the SM graveyard?";
WOW_TRIVIA_ANSWERS1[199] = "Kingsblood";

WOW_TRIVIA_QUESTIONS[200] = "What is the name of the raiding instance in Netherstorm? (full name)";
WOW_TRIVIA_ANSWERS1[200] = "Tempest Keep";

WOW_TRIVIA_QUESTIONS[201] = "What debuff once allowed Horde players to attack NPCs of their own faction?";
WOW_TRIVIA_ANSWERS1[201] = "Mark of Shame";

WOW_TRIVIA_QUESTIONS[202] = "Who is the final boss you have to kill for the tier 0.5 series of quests?";
WOW_TRIVIA_ANSWERS1[202] = "Lord Valthalak";
WOW_TRIVIA_ANSWERS2[202] = "Valthalak";

WOW_TRIVIA_QUESTIONS[203] = "Greater Shadow Protection potions require one dreamfoil, one __________, and one crystal vial.";
WOW_TRIVIA_ANSWERS1[203] = "shadow oil";

WOW_TRIVIA_QUESTIONS[204] = "How long is the auto-release timer when you die outside of an instance?";
WOW_TRIVIA_ANSWERS1[204] = "6 minutes";
WOW_TRIVIA_ANSWERS2[204] = "6 min";
WOW_TRIVIA_ANSWERS3[204] = "6 mins";

WOW_TRIVIA_QUESTIONS[205] = "Name one of the two bosses you must kill during the Thaddius fight before you face Thaddius himself.";
WOW_TRIVIA_ANSWERS1[205] = "Stalagg";
WOW_TRIVIA_ANSWERS2[205] = "Feugen";

WOW_TRIVIA_QUESTIONS[206] = "The 'Fungal Bloom' debuff in the Loatheb fight gives how much bonus to crit chance?";
WOW_TRIVIA_ANSWERS1[206] = "60%";
WOW_TRIVIA_ANSWERS2[206] = "60";

WOW_TRIVIA_QUESTIONS[207] = "The Pools of Vision are found in what main city? (full name)";
WOW_TRIVIA_ANSWERS1[207] = "Thunder Bluff";

WOW_TRIVIA_QUESTIONS[208] = "Who Created this version TriviaBot?";
WOW_TRIVIA_ANSWERS1[208] = "Bennylava";

WOW_TRIVIA_QUESTIONS[209] = "Which zone do Druids gain a teleport to at level 10?";
WOW_TRIVIA_ANSWERS1[209] = "Moonglade";

WOW_TRIVIA_QUESTIONS[210] = "Flasks can be crafted in two instances. Name one?";
WOW_TRIVIA_ANSWERS1[210] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS2[210] = "Scholomance";

WOW_TRIVIA_QUESTIONS[211] = "What creature despawns at 20%, saying it is 'not his time yet'?";
WOW_TRIVIA_ANSWERS1[211] = "Anachronos";

WOW_TRIVIA_QUESTIONS[212] = "Which zone contains the original World Tree? (full name)";
WOW_TRIVIA_ANSWERS1[212] = "Mount Hyjal"

WOW_TRIVIA_QUESTIONS[213] = "What is the name of the elite Dragon who patrols the Blasted Lands?";
WOW_TRIVIA_ANSWERS1[213] = "Teremus the Devourer";
WOW_TRIVIA_ANSWERS2[213] = "Teremus";

WOW_TRIVIA_QUESTIONS[214] = "How many mini-bosses are there on the top-level of the Sunken Temple?";
WOW_TRIVIA_ANSWERS1[214] = "6";
WOW_TRIVIA_ANSWERS2[214] = "Six";

WOW_TRIVIA_QUESTIONS[215] = "What does Gluth eat to regain health?";
WOW_TRIVIA_ANSWERS1[215] = "Zombie Chow";
WOW_TRIVIA_ANSWERS2[215] = "zombies";
WOW_TRIVIA_ANSWERS3[215] = "zombie";

WOW_TRIVIA_QUESTIONS[216] = "Maexxna enrages at what health percentage?";
WOW_TRIVIA_ANSWERS1[216] = "30";
WOW_TRIVIA_ANSWERS2[216] = "30%";
WOW_TRIVIA_ANSWERS3[216] = "Thirty";

WOW_TRIVIA_QUESTIONS[217] = "Who is the most damaging boss in Naxxramas?";
WOW_TRIVIA_ANSWERS1[217] = "Instructor Razuvious";
WOW_TRIVIA_ANSWERS2[217] = "Razuvious";

WOW_TRIVIA_QUESTIONS[218] = "Which boss drops the tier 2 headpieces?";
WOW_TRIVIA_ANSWERS1[218] = "Onyxia";
WOW_TRIVIA_ANSWERS2[218] = "Ony";

WOW_TRIVIA_QUESTIONS[219] = "How many parts does the tier 3 armor set have?";
WOW_TRIVIA_ANSWERS1[219] = "9";
WOW_TRIVIA_ANSWERS2[219] = "Nine";

WOW_TRIVIA_QUESTIONS[220] = "The tunnel to Stonetalon Mountains from Ashenvale will deposit you near the road. (True/False)?";
WOW_TRIVIA_ANSWERS1[220] = "False";

WOW_TRIVIA_QUESTIONS[221] = "What is the second last boss in Molten Core?";
WOW_TRIVIA_ANSWERS1[221] = "Majordomo Executus";
WOW_TRIVIA_ANSWERS2[221] = "Majordomo";

WOW_TRIVIA_QUESTIONS[222] = "In the AQ War Effort, what item was required in the greatest number?";
WOW_TRIVIA_ANSWERS1[222] = "Linen bandages";

WOW_TRIVIA_QUESTIONS[223] = "What does Ragnaros summon when he submerges after 3 minutes of combat?";
WOW_TRIVIA_ANSWERS1[223] = "Sons of Flame";

WOW_TRIVIA_QUESTIONS[224] = "What Rogue leggings does Ragnaros drop?";
WOW_TRIVIA_ANSWERS1[224] = "Bloodfang Pants";
WOW_TRIVIA_ANSWERS2[224] = "Bloodfang";

WOW_TRIVIA_QUESTIONS[225] = "Who is the 'Dad' in the Bug Family in AQ40?";
WOW_TRIVIA_ANSWERS1[225] = "Lord Kri";
WOW_TRIVIA_ANSWERS2[225] = "Kri";

WOW_TRIVIA_QUESTIONS[226] = "When the game was released, the mobs of which zone had no loot?";
WOW_TRIVIA_ANSWERS1[226] = "Silithus";

WOW_TRIVIA_QUESTIONS[227] = "Which Blackwing Lair boss drops the tier 2 Bracers?";
WOW_TRIVIA_ANSWERS1[227] = "Razorgore the Untamed";
WOW_TRIVIA_ANSWERS2[227] = "Razorgore";

WOW_TRIVIA_QUESTIONS[228] = "What is the name of the bar in Blackrock Depths?";
WOW_TRIVIA_ANSWERS1[228] = "The Grim Guzzler";
WOW_TRIVIA_ANSWERS2[228] = "Grim Guzzler";

WOW_TRIVIA_QUESTIONS[229] = "How many bosses in AQ20 must be kited to kill them?";
WOW_TRIVIA_ANSWERS1[229] = "2";
WOW_TRIVIA_ANSWERS2[229] = "two";

WOW_TRIVIA_QUESTIONS[230] = "Who has the lowest health of all the bosses in Naxxramas?";
WOW_TRIVIA_ANSWERS1[230] = "Gothik the Harvester";
WOW_TRIVIA_ANSWERS2[230] = "Gothik";

WOW_TRIVIA_QUESTIONS[231] = "How many optional encounters does AQ40 have?";
WOW_TRIVIA_ANSWERS1[231] = "3";
WOW_TRIVIA_ANSWERS2[231] = "Three";

WOW_TRIVIA_QUESTIONS[232] = "The Gurubashi Arena event takes place at ____-hourly intervals?";
WOW_TRIVIA_ANSWERS1[232] = "3";
WOW_TRIVIA_ANSWERS2[232] = "three";

WOW_TRIVIA_QUESTIONS[233] = "In what patch were the 4 world Dragons introduced?";
WOW_TRIVIA_ANSWERS1[233] = "1.8";

WOW_TRIVIA_QUESTIONS[234] = "What is the lowest level instance in the game?";
WOW_TRIVIA_ANSWERS1[234] = "Ragefire Chasm";
WOW_TRIVIA_ANSWERS2[234] = "RFC";

WOW_TRIVIA_QUESTIONS[235] = "Who Made The In Game Joana's Atlas Guide?";
WOW_TRIVIA_ANSWERS1[235] = "Bennylava";
WOW_TRIVIA_ANSWERS2[235] = "Doctorbeefy";

WOW_TRIVIA_QUESTIONS[236] = "Which Alliance race has +15 engineering as racial passive?";
WOW_TRIVIA_ANSWERS1[236] = "Gnome";
WOW_TRIVIA_ANSWERS2[236] = "Gnomes";

WOW_TRIVIA_QUESTIONS[237] = "Acronyms: What does ATP stand for?";
WOW_TRIVIA_ANSWERS1[237] = "Attack Power";

WOW_TRIVIA_QUESTIONS[238] = "How many fears does the Warlock class have?";
WOW_TRIVIA_ANSWERS1[238] = "2";
WOW_TRIVIA_ANSWERS2[238] = "two";

WOW_TRIVIA_QUESTIONS[239] = "Druids can do Physical, Nature and ______ damage.";
WOW_TRIVIA_ANSWERS1[239] = "Arcane damage";
WOW_TRIVIA_ANSWERS2[239] = "arcane";

WOW_TRIVIA_QUESTIONS[240] = "What boss is a anagram for healbot?";
WOW_TRIVIA_ANSWERS1[240] = "Loatheb";

WOW_TRIVIA_QUESTIONS[241] = "How many PvP ranks exist in the honor system?";
WOW_TRIVIA_ANSWERS1[241] = "14";
WOW_TRIVIA_ANSWERS2[241] = "fourteen";

WOW_TRIVIA_QUESTIONS[242] = "At what PvP rank can you buy PvP mounts? (number)";
WOW_TRIVIA_ANSWERS1[242] = "11";
WOW_TRIVIA_ANSWERS2[242] = "eleven";

WOW_TRIVIA_QUESTIONS[243] = "Arcane Resilience will increase your armor by what % of your intellect?";
WOW_TRIVIA_ANSWERS1[243] = "50%";
WOW_TRIVIA_ANSWERS2[243] = "Fifty";
WOW_TRIVIA_ANSWERS3[243] = "50";

WOW_TRIVIA_QUESTIONS[244] = "What instance is sometimes called 'UD'?";
WOW_TRIVIA_ANSWERS1[244] = "Stratholme";
WOW_TRIVIA_ANSWERS2[244] = "Strat";

WOW_TRIVIA_QUESTIONS[245] = "Name a faction that is part of the Steamwheedle Cartel.";
WOW_TRIVIA_ANSWERS1[245] = "Booty Bay";
WOW_TRIVIA_ANSWERS2[245] = "Everlook";
WOW_TRIVIA_ANSWERS3[245] = "Ratchet";
WOW_TRIVIA_ANSWERS4[245] = "Gadgetztan";

WOW_TRIVIA_QUESTIONS[246] = "What race has the racial skill 'Diplomacy'?";
WOW_TRIVIA_ANSWERS1[246] = "Human";
WOW_TRIVIA_ANSWERS2[246] = "Humans";

WOW_TRIVIA_QUESTIONS[247] = "Blizzard will do up to 1472 damage over ___ seconds?";
WOW_TRIVIA_ANSWERS1[247] = "8";
WOW_TRIVIA_ANSWERS2[247] = "eight";

WOW_TRIVIA_QUESTIONS[248] = "Evocation has a ___ min cooldown?";
WOW_TRIVIA_ANSWERS1[248] = "8";
WOW_TRIVIA_ANSWERS2[248] = "eight";

WOW_TRIVIA_QUESTIONS[249] = "Mages can Polymorph you into a goat. (True/False)?";
WOW_TRIVIA_ANSWERS1[249] = "False";

WOW_TRIVIA_QUESTIONS[250] = "Which class can cast Fear?";
WOW_TRIVIA_ANSWERS1[250] = "Warlock";

WOW_TRIVIA_QUESTIONS[251] = "The  tier 3 Mage set is called?";
WOW_TRIVIA_ANSWERS1[251] = "Frostfire";

WOW_TRIVIA_QUESTIONS[252] = "Which is the most hated instance?";
WOW_TRIVIA_ANSWERS1[252] = "Gnomeregan";

WOW_TRIVIA_QUESTIONS[253] = "Acronyms: What does DKP stand for?";
WOW_TRIVIA_ANSWERS1[253] = "Dragon Kill Points";

WOW_TRIVIA_QUESTIONS[254] = "Who is being held captive by the Baron in Stratholme?";
WOW_TRIVIA_ANSWERS1[254] = "Ysida Harmon";
WOW_TRIVIA_ANSWERS2[254] = "Ysida";

WOW_TRIVIA_QUESTIONS[255] = "What epic sword set was 'Forged in the seething flames of hatred'?";
WOW_TRIVIA_ANSWERS1[255] = "The Twin blades of Hakkari";
WOW_TRIVIA_ANSWERS2[255] = "Twin blades of Hakkari";

WOW_TRIVIA_QUESTIONS[256] = "What is the name of the fruit vendor patrolling in Ironforge (The Mystic Ward)?";
WOW_TRIVIA_ANSWERS1[256] = "Bimble Longberry";
WOW_TRIVIA_ANSWERS2[256] = "Longberry";
WOW_TRIVIA_ANSWERS3[256] = "Bimble";

WOW_TRIVIA_QUESTIONS[257] = "What is the name of the food you get from the Mage spell 'Conjure food (Rank 1)'?";
WOW_TRIVIA_ANSWERS1[257] = "Muffin";
WOW_TRIVIA_ANSWERS2[257] = "Muffins";
WOW_TRIVIA_ANSWERS3[257] = "Conjured Muffins";
WOW_TRIVIA_ANSWERS4[257] = "Conjured Muffin";

WOW_TRIVIA_QUESTIONS[258] = "Humanoids can drop linen cloth from level _.";
WOW_TRIVIA_ANSWERS1[258] = "8";
WOW_TRIVIA_ANSWERS2[258] = "eight";

WOW_TRIVIA_QUESTIONS[259] = "One area in Silverpine Forest is called '______ Isle'.";
WOW_TRIVIA_ANSWERS1[259] = "Fenris";

WOW_TRIVIA_QUESTIONS[260] = "Where does most of the Blue Dragonflight reside?";
WOW_TRIVIA_ANSWERS1[260] = "Northrend";

WOW_TRIVIA_QUESTIONS[261] = "Where does most of the Black Dragonflight reside?";
WOW_TRIVIA_ANSWERS1[261] = "Blackrock Mountain";
WOW_TRIVIA_ANSWERS2[261] = "Blackrock Spire";
WOW_TRIVIA_ANSWERS3[261] = "Burning Steppes";

WOW_TRIVIA_QUESTIONS[262] = "Where does most of the Bronze Dragonflight reside?";
WOW_TRIVIA_ANSWERS1[262] = "Caverns of Time";
WOW_TRIVIA_ANSWERS2[262] = "Tanaris";

WOW_TRIVIA_QUESTIONS[263] = "Where does most of the Red Dragonflight reside?";
WOW_TRIVIA_ANSWERS1[263] = "Grim Batol";
WOW_TRIVIA_ANSWERS2[263] = "Wetlands";

WOW_TRIVIA_QUESTIONS[264] = "Where does most of the Green Dragonflight reside?";
WOW_TRIVIA_ANSWERS1[264] = "The Emerald Dream";
WOW_TRIVIA_ANSWERS2[264] = "Emerald Dream";
WOW_TRIVIA_ANSWERS3[264] = "Swamp of Sorrows";

WOW_TRIVIA_QUESTIONS[265] = "Who is the leader of the Bronze Dragonflight?";
WOW_TRIVIA_ANSWERS1[265] = "Nozdormu";
WOW_TRIVIA_ANSWERS2[265] = "Nozdormu the Timeless one";

WOW_TRIVIA_QUESTIONS[266] = "Who is the leader of the Green Dragonflight?";
WOW_TRIVIA_ANSWERS1[266] = "Ysera";
WOW_TRIVIA_ANSWERS2[266] = "Ysera the Dreamer";

WOW_TRIVIA_QUESTIONS[267] = "Who is the leader of the Red Dragonflight?";
WOW_TRIVIA_ANSWERS1[267] = "Alexstraza";
WOW_TRIVIA_ANSWERS2[267] = "Alexstrasza the Life-Binder"
WOW_TRIVIA_ANSWERS3[267] = "Alexstrasza the Life Binder";

WOW_TRIVIA_QUESTIONS[268] = "Who is the leader of the Blue Dragonflight?";
WOW_TRIVIA_ANSWERS1[268] = "Malygos";
WOW_TRIVIA_ANSWERS2[268] = "Malygos the Spell-Weaver";
WOW_TRIVIA_ANSWERS3[268] = "Malygos the Spell Weaver";

WOW_TRIVIA_QUESTIONS[269] = "Who is the leader of the Black Dragonflight?";
WOW_TRIVIA_ANSWERS1[269] = "Neltharion";
WOW_TRIVIA_ANSWERS2[269] = "Deathwing";
WOW_TRIVIA_ANSWERS3[269] = "Neltharion the Earth-Warder";
WOW_TRIVIA_ANSWERS4[269] = "Deathwing the Destroyer";

WOW_TRIVIA_QUESTIONS[270] = "The Black Dragonflight was originally which color, before becoming corrupted?";
WOW_TRIVIA_ANSWERS1[270] = "Brown";

WOW_TRIVIA_QUESTIONS[271] = "To where does the portals which the corrupted Emerald Dragons are guarding, lead?";
WOW_TRIVIA_ANSWERS1[271] = "The Emerald Dream";
WOW_TRIVIA_ANSWERS2[271] = "Emerald Dream";

WOW_TRIVIA_QUESTIONS[272] = "Name one of the two places where Eranikus can be found.";
WOW_TRIVIA_ANSWERS1[272] = "Sunken Temple or Moonglade";
WOW_TRIVIA_ANSWERS2[272] = "Sunken Temple";
WOW_TRIVIA_ANSWERS3[272] = "Moonglade";
WOW_TRIVIA_ANSWERS4[272] = "Moonglade or Sunken Temple";

WOW_TRIVIA_QUESTIONS[273] = "With the Genesis (t2.5) set bonus, what is the cooldown on Rebirth for Druids?";
WOW_TRIVIA_ANSWERS1[273] = "20 minutes";
WOW_TRIVIA_ANSWERS2[273] = "Twenty minutes";
WOW_TRIVIA_ANSWERS3[273] = "Twenty mins";

WOW_TRIVIA_QUESTIONS[274] = "The only non-combat pet with an effect on gameplay is the _____.";
WOW_TRIVIA_ANSWERS1[274] = "Disgusting Oozeling";

WOW_TRIVIA_QUESTIONS[275] = "What is the name of the mount you can obtain through the repeatable quests in Winterspring?";
WOW_TRIVIA_ANSWERS1[275] = "Reins of the Winterspring Frostsaber";
WOW_TRIVIA_ANSWERS2[275] = "Winterspring Frostsaber";

WOW_TRIVIA_QUESTIONS[276] = "Who Hosts http://www.feenixcensus.com/?";
WOW_TRIVIA_ANSWERS1[276] = "DotMatrix";

WOW_TRIVIA_QUESTIONS[277] = "Who is the mighty Warrior you must defeat in the Upper Blackrock Spire in order to obtain the tier 0 Warrior shoulders?";
WOW_TRIVIA_ANSWERS1[277] = "Rend";
WOW_TRIVIA_ANSWERS2[277] = "Rend Blackhand";
WOW_TRIVIA_ANSWERS3[277] = "Warchief Rend Blackhand";

WOW_TRIVIA_QUESTIONS[278] = "In the Upper Blackrock Spires is a giant hound named 'The ____'.";
WOW_TRIVIA_ANSWERS1[278] = "Beast";

WOW_TRIVIA_QUESTIONS[279] = "What dragon drops the tier 2 headpieces? (the full name)";
WOW_TRIVIA_ANSWERS1[279] = "Onyxia";

WOW_TRIVIA_QUESTIONS[280] = "How long does it take for a Rogues stealth to be ready after unstealthing (Without Talents)?";
WOW_TRIVIA_ANSWERS1[280] = "10 seconds";
WOW_TRIVIA_ANSWERS2[280] = "10 secs";
WOW_TRIVIA_ANSWERS3[280] = "10 sec";

WOW_TRIVIA_QUESTIONS[281] = "The cooldown for Goblin Jumper Cables is ____ minutes?";
WOW_TRIVIA_ANSWERS1[281] = "30";
WOW_TRIVIA_ANSWERS2[281] = "30 mins";
WOW_TRIVIA_ANSWERS3[281] = "30 minutes";
WOW_TRIVIA_ANSWERS4[281] = "30 min";

WOW_TRIVIA_QUESTIONS[282] = "Who does the trinket Warmth of Forgiveness drop off?";
WOW_TRIVIA_ANSWERS1[282] = "The Four Horsemen";
WOW_TRIVIA_ANSWERS2[282] = "Four Horsemen";

WOW_TRIVIA_QUESTIONS[283] = "What is the Hunter's tier 3 called?";
WOW_TRIVIA_ANSWERS1[283] = "Cryptstalker";

WOW_TRIVIA_QUESTIONS[284] = "What plate item collection from Naxxramas increases frost resistance?";
WOW_TRIVIA_ANSWERS1[284] = "Icebane";

WOW_TRIVIA_QUESTIONS[285] = "What level do you have to be to join /world?.";
WOW_TRIVIA_ANSWERS1[285] = "20";
WOW_TRIVIA_ANSWERS2[285] = "Twenty";

WOW_TRIVIA_QUESTIONS[286] = "What is the full name of the last boss in The Deadmines?";
WOW_TRIVIA_ANSWERS1[286] = "Edwin Van Cleef";

WOW_TRIVIA_QUESTIONS[287] = "What rare spawn in Stratholme drops Piccolo of the Flaming Fire?";
WOW_TRIVIA_ANSWERS1[287] = "Hearthsinger Forresten";
WOW_TRIVIA_ANSWERS2[287] = "Forresten";

WOW_TRIVIA_QUESTIONS[288] = "Where is the Dark Portal Located?";
WOW_TRIVIA_ANSWERS1[288] = "Blasted Lands";
WOW_TRIVIA_ANSWERS2[288] = "The Blasted Lands";

WOW_TRIVIA_QUESTIONS[289] = "Blizzard Entertainment is owned by which company?";
WOW_TRIVIA_ANSWERS1[289] = "Vivendi Universal Games";
WOW_TRIVIA_ANSWERS2[289] = "vivendi";

WOW_TRIVIA_QUESTIONS[290] = "What is the place called you submit feenix bugs to?";
WOW_TRIVIA_ANSWERS1[290] = "Issue Tracker";
WOW_TRIVIA_ANSWERS2[290] = "The Issue Tracker";
WOW_TRIVIA_ANSWERS3[290] = "Feenix Issue Tracker";
WOW_TRIVIA_ANSWERS4[290] = "Emerald Dream Issue Tracker";

WOW_TRIVIA_QUESTIONS[291] = "What is the undead's starting place called?";
WOW_TRIVIA_ANSWERS1[291] = "Deathknell";

WOW_TRIVIA_QUESTIONS[292] = "In which talent tree can the spell 'Dark Pact' be found?";
WOW_TRIVIA_ANSWERS1[292] = "Affliction";

WOW_TRIVIA_QUESTIONS[293] = "In which talent tree can the spell 'Soul Link' be found?";
WOW_TRIVIA_ANSWERS1[293] = "Demonology";

WOW_TRIVIA_QUESTIONS[294] = "What lvl of First Aid is required to learn Artisan First Aid?";
WOW_TRIVIA_ANSWERS1[294] = "225";

WOW_TRIVIA_QUESTIONS[295] = "Which class(es) can breathe under water infinitely?";
WOW_TRIVIA_ANSWERS1[295] = "Warlock";
WOW_TRIVIA_ANSWERS2[295] = "Shaman";
WOW_TRIVIA_ANSWERS3[295] = "Druid";

WOW_TRIVIA_QUESTIONS[296] = "In which zone can you find Donova Snowden";
WOW_TRIVIA_ANSWERS1[296] = "Winterspring";

WOW_TRIVIA_QUESTIONS[297] = "How many items is there in a tier 3 set?";
WOW_TRIVIA_ANSWERS1[297] = "9";
WOW_TRIVIA_ANSWERS2[297] = "Nine";

WOW_TRIVIA_QUESTIONS[298] = "What were the Blood Elves originally called?";
WOW_TRIVIA_ANSWERS1[298] = "high elfs";
WOW_TRIVIA_ANSWERS2[298] = "high elves";

WOW_TRIVIA_QUESTIONS[299] = "What race has Escape Artist as their racial?";
WOW_TRIVIA_ANSWERS1[299] = "Gnomes";
WOW_TRIVIA_ANSWERS2[299] = "Gnome";

WOW_TRIVIA_QUESTIONS[300] = "What is the Warlocks second pet called?";
WOW_TRIVIA_ANSWERS1[300] = "Voidwalker";
WOW_TRIVIA_ANSWERS2[300] = "vw";

WOW_TRIVIA_QUESTIONS[301] = "What is the highest rank of Fireball?";
WOW_TRIVIA_ANSWERS1[301] = "Rank 12";
WOW_TRIVIA_ANSWERS2[301] = "12";
WOW_TRIVIA_ANSWERS3[301] = "twelve";

WOW_TRIVIA_QUESTIONS[302] = "How much resources do you need to win an Arathi Basin match?";
WOW_TRIVIA_ANSWERS1[302] = "2000";
WOW_TRIVIA_ANSWERS2[302] = "two thousand";

WOW_TRIVIA_QUESTIONS[303] = "What type of resistance do you need for the Sapphiron encounter?";
WOW_TRIVIA_ANSWERS1[303] = "Frost";

WOW_TRIVIA_QUESTIONS[304] = "What kind of monster is Onyxia?";
WOW_TRIVIA_ANSWERS1[304] = "Dragon";
WOW_TRIVIA_ANSWERS2[304] = "Dragonkin";

WOW_TRIVIA_QUESTIONS[305] = "On which continent is Deadwind Pass found?";
WOW_TRIVIA_ANSWERS1[305] = "eastern kingdoms";

WOW_TRIVIA_QUESTIONS[306] = "What Guild on Emerald Dream talks the most crap?";
WOW_TRIVIA_ANSWERS1[306] = "Apathetic";

WOW_TRIVIA_QUESTIONS[307] = "What will Piccolo of the Flaming Fire make you do?";
WOW_TRIVIA_ANSWERS1[307] = "Dance";
WOW_TRIVIA_ANSWERS2[307] = "dancing";

WOW_TRIVIA_QUESTIONS[308] = "Which boss do you need to defeat in order to aquire 'Thunderfury, The Blessed Blade of the Windseeker', if you have the bindings?";
WOW_TRIVIA_ANSWERS1[308] = "Prince Thunderaan";
WOW_TRIVIA_ANSWERS2[308] = "thunderaan";

WOW_TRIVIA_QUESTIONS[309] = "Gnomes can be Druids. (True/False)??";
WOW_TRIVIA_ANSWERS1[309] = "False";

WOW_TRIVIA_QUESTIONS[310] = "What patch is Emerald Dream?";
WOW_TRIVIA_ANSWERS1[310] = "1.12.1";

WOW_TRIVIA_QUESTIONS[311] = "Name the crafted engineering item that only affects beasts";
WOW_TRIVIA_ANSWERS1[311] = "Flash Bomb";

WOW_TRIVIA_QUESTIONS[312] = "How many Elementium Ore does it take to make a bar?";
WOW_TRIVIA_ANSWERS1[312] = "One";
WOW_TRIVIA_ANSWERS2[312] = "1";

WOW_TRIVIA_QUESTIONS[313] = "The acronym 'WPL' refers to?";
WOW_TRIVIA_ANSWERS1[313] = "Western Plaguelands";

WOW_TRIVIA_QUESTIONS[314] = "What button do you spam to teabag someone?";
WOW_TRIVIA_ANSWERS1[314] = "x";

WOW_TRIVIA_QUESTIONS[315] = "What is the starting place for Orcs?";
WOW_TRIVIA_ANSWERS1[315] = "Valley of Trials";
WOW_TRIVIA_ANSWERS2[315] = "The Valley of Trials";

WOW_TRIVIA_QUESTIONS[316] = "How many servers does feenix have?";
WOW_TRIVIA_ANSWERS1[316] = "4";
WOW_TRIVIA_ANSWERS2[316] = "Four";

WOW_TRIVIA_QUESTIONS[317] = "In what zone is Razorfen Kraul in?";
WOW_TRIVIA_ANSWERS1[317] = "The Barrens";
WOW_TRIVIA_ANSWERS2[317] = "Barrens";

WOW_TRIVIA_QUESTIONS[318] = "Whats the command to tell a joke?";
WOW_TRIVIA_ANSWERS1[318] = " /silly";
WOW_TRIVIA_ANSWERS2[318] = "/silly";

WOW_TRIVIA_QUESTIONS[319] = "What does Benediction turn into?";
WOW_TRIVIA_ANSWERS1[319] = "Anathema";


WOW_TRIVIA_QUESTIONS[320] = "Emerald Dream has reached its player cap at least once?  ( True / False )";
WOW_TRIVIA_ANSWERS1[320] = "True";

WOW_TRIVIA_QUESTIONS[321] = "Emerald Dream Allows Donation. (True / False)";
WOW_TRIVIA_ANSWERS1[321] = "False";

WOW_TRIVIA_QUESTIONS[322] = "Who is the Root Administrator of Feenix?";
WOW_TRIVIA_ANSWERS1[322] = "Feenixes";

WOW_TRIVIA_QUESTIONS[323] = "What are the rates on emerald dream?";
WOW_TRIVIA_ANSWERS1[323] = "x1";
WOW_TRIVIA_ANSWERS2[323] = "x 1";
WOW_TRIVIA_ANSWERS3[323] = "Times 1";

WOW_TRIVIA_QUESTIONS[324] = "How many raids are currently released on Emerald Dream?";
WOW_TRIVIA_ANSWERS1[324] = "3";
WOW_TRIVIA_ANSWERS2[324] = "Three";

WOW_TRIVIA_QUESTIONS[325] = "What zone is ZF in?";
WOW_TRIVIA_ANSWERS1[325] = "Tanaris";


WOW_TRIVIA_QUESTIONS[326] = "What is the skill limit on proffesions?";
WOW_TRIVIA_ANSWERS1[326] = "300";
WOW_TRIVIA_ANSWERS2[326] = "Three hundred";

WOW_TRIVIA_QUESTIONS[327] = "Where is Caverns of Time?";
WOW_TRIVIA_ANSWERS1[327] = "Tanaris";

WOW_TRIVIA_QUESTIONS[328] = "How many dragon aspects were there before deathwing?";
WOW_TRIVIA_ANSWERS1[328] = "5";
WOW_TRIVIA_ANSWERS2[328] = "Five";


WOW_TRIVIA_QUESTIONS[329] = "Who's wife died in the barrens?";
WOW_TRIVIA_ANSWERS1[329] = "Mankrik";
WOW_TRIVIA_ANSWERS2[329] = "Mankriks";
WOW_TRIVIA_ANSWERS3[329] = "Mankrik's";

WOW_TRIVIA_QUESTIONS[330] = "In what zone is Molten Core?";
WOW_TRIVIA_ANSWERS1[330] = "Searing Gorge";
WOW_TRIVIA_ANSWERS2[330] = "Burning Steppes";

WOW_TRIVIA_QUESTIONS[331] = "In what zone is Zul'Gurub?";
WOW_TRIVIA_ANSWERS1[331] = "Stranglethorn Vale";
WOW_TRIVIA_ANSWERS2[331] = "STV";

WOW_TRIVIA_QUESTIONS[332] = "In what zone is Naxxramas?";
WOW_TRIVIA_ANSWERS1[332] = "Eastern Plaguelands";
WOW_TRIVIA_ANSWERS2[332] = "EPL";

WOW_TRIVIA_QUESTIONS[333] = "What was the last patch of vanilla called?";
WOW_TRIVIA_ANSWERS1[333] = "Before the Storm";

WOW_TRIVIA_QUESTIONS[334] = "What is the name of the popular auctioning addon?";
WOW_TRIVIA_ANSWERS1[334] = "Auctioneer";

WOW_TRIVIA_QUESTIONS[335] = "What was Thralls real name?";
WOW_TRIVIA_ANSWERS1[335] = "Go'el";
WOW_TRIVIA_ANSWERS2[335] = "Goel";

WOW_TRIVIA_QUESTIONS[336] = "What mob-type is the realm Daggerspine named after?";
WOW_TRIVIA_ANSWERS1[336] = "naga";
WOW_TRIVIA_ANSWERS2[336] = "nagas";

WOW_TRIVIA_QUESTIONS[337] = "Who was Thralls Slave Master?";
WOW_TRIVIA_ANSWERS1[337] = "Aedelas Blackmoore";
WOW_TRIVIA_ANSWERS2[337] = "Blackmoore";
WOW_TRIVIA_ANSWERS3[337] = "Lord Blackmoore";

WOW_TRIVIA_QUESTIONS[338] = "What Clan was Thralls Father the cheiftain of?";
WOW_TRIVIA_ANSWERS1[338] = "Frostwolf clan";
WOW_TRIVIA_ANSWERS2[338] = "The Frostwolf clan";
WOW_TRIVIA_ANSWERS3[338] = "Frostwolf";
WOW_TRIVIA_ANSWERS4[338] = "The Frostwolf";

WOW_TRIVIA_QUESTIONS[339] = "What Human helped Thrall escape slavery and paid for it with her life?";
WOW_TRIVIA_ANSWERS1[339] = "Taretha";

WOW_TRIVIA_QUESTIONS[340] = "WCRadio.com is a wow-radio that plays online shows every now and then. (True/False)?";
WOW_TRIVIA_ANSWERS1[340] = "True";

WOW_TRIVIA_QUESTIONS[341] = "What mob type is the realm Bloodfeather named after?";
WOW_TRIVIA_ANSWERS1[341] = "Harpies";
WOW_TRIVIA_ANSWERS2[341] = "Harpy";

WOW_TRIVIA_QUESTIONS[342] = "Al'Akir is a _________. (The race)";
WOW_TRIVIA_ANSWERS1[342] = "Elemental";

WOW_TRIVIA_QUESTIONS[343] = "Aszune was a woman that was turned into a statue of living stone by the Oracle. What race was she?";
WOW_TRIVIA_ANSWERS1[343] = "night elf";
WOW_TRIVIA_ANSWERS2[343] = "Kaldorei";

WOW_TRIVIA_QUESTIONS[344] = "What is the nathrezim race also known as?";
WOW_TRIVIA_ANSWERS1[344] = "Dreadlord";
WOW_TRIVIA_ANSWERS2[344] = "Dreadlords";

WOW_TRIVIA_QUESTIONS[345] = "What is Bladefist's first name?";
WOW_TRIVIA_ANSWERS1[345] = "Kargath";

WOW_TRIVIA_QUESTIONS[346] = "What is 'The Venture Co.' mostly made of?";
WOW_TRIVIA_ANSWERS1[346] = "Goblin";
WOW_TRIVIA_ANSWERS2[346] = "Goblins"; 

WOW_TRIVIA_QUESTIONS[347] = "Who became the first satyr?";
WOW_TRIVIA_ANSWERS1[347] = "Xavius";

WOW_TRIVIA_QUESTIONS[348] = "Where is Uldum located?";
WOW_TRIVIA_ANSWERS1[348] = "Tanaris";

WOW_TRIVIA_QUESTIONS[349] = "Who is C'thun?";
WOW_TRIVIA_ANSWERS1[349] = "Old God";
WOW_TRIVIA_ANSWERS2[349] = "an Old God";

WOW_TRIVIA_QUESTIONS[350] = "Who leads the orcish Dragonmaw clan?"
WOW_TRIVIA_ANSWERS1[350] = "Zuluhed the Whacked"
WOW_TRIVIA_ANSWERS2[350] = "Zuluhed";

WOW_TRIVIA_QUESTIONS[351] = "The acronym 'SW' refers to?";
WOW_TRIVIA_ANSWERS1[351] = "Stormwind";

WOW_TRIVIA_QUESTIONS[352] = "The acronym 'UC' refers to?";
WOW_TRIVIA_ANSWERS1[352] = "Undercity";

WOW_TRIVIA_QUESTIONS[353] = "The acronym 'SM' refers to?";
WOW_TRIVIA_ANSWERS1[353] = "Scarlet Monastery";

WOW_TRIVIA_QUESTIONS[354] = "The acronym 'RFD' refers to?";
WOW_TRIVIA_ANSWERS1[354] = "Razorfen downs";

WOW_TRIVIA_QUESTIONS[355] = "The abbreviation 'BFD' refers to?";
WOW_TRIVIA_ANSWERS1[355] = "Blackfathom Deeps";

WOW_TRIVIA_QUESTIONS[356] = "Anetheron is a lich. (True/False)?";
WOW_TRIVIA_ANSWERS1[356] = "False";

WOW_TRIVIA_QUESTIONS[357] = "What zone lies north of Ashenvale?";
WOW_TRIVIA_ANSWERS1[357] = "Felwood";

WOW_TRIVIA_QUESTIONS[358] = "The acronym 'WC' refers to (in wow)?";
WOW_TRIVIA_ANSWERS1[358] = "Wailing Caverns";

WOW_TRIVIA_QUESTIONS[359] = "The acronym 'RFK' refers to?";
WOW_TRIVIA_ANSWERS1[359] = "Razorfen Kraul";

WOW_TRIVIA_QUESTIONS[360] = "The acronym 'RFC' refers to?";
WOW_TRIVIA_ANSWERS1[360] = "Ragefire Chasm";

WOW_TRIVIA_QUESTIONS[361] = "The acronym 'PST' refers to?";
WOW_TRIVIA_ANSWERS1[361] = "Please send tell";

WOW_TRIVIA_QUESTIONS[362] = "The acronym 'Strat' refers to?";
WOW_TRIVIA_ANSWERS1[362] = "Stratholme";

WOW_TRIVIA_QUESTIONS[363] = "The acronym 'ST' refers to?";
WOW_TRIVIA_ANSWERS1[363] = "Sunken Temple";
WOW_TRIVIA_ANSWERS2[363] = "The Temple of Atal'hakkar";
WOW_TRIVIA_ANSWERS3[363] = "Temple of Atal'hakkar";

WOW_TRIVIA_QUESTIONS[364] = "The abbreviation 'Ony' refers to?";
WOW_TRIVIA_ANSWERS1[364] = "Onyxia";

WOW_TRIVIA_QUESTIONS[365] = "The acronym 'IF' refers to?";
WOW_TRIVIA_ANSWERS1[365] = "Ironforge";

WOW_TRIVIA_QUESTIONS[366] = "The abbreviation 'Uld' refers to?";
WOW_TRIVIA_ANSWERS1[366] = "Uldaman";

WOW_TRIVIA_QUESTIONS[367] = "The acronym 'UBRS' refers to?";
WOW_TRIVIA_ANSWERS1[367] = "Upper Blackrock Spire";

WOW_TRIVIA_QUESTIONS[368] = "The acronym 'BRS' refers to?";
WOW_TRIVIA_ANSWERS1[368] = "Blackrock Spire";

WOW_TRIVIA_QUESTIONS[369] = "The acronym 'LBRS' refers to?";
WOW_TRIVIA_ANSWERS1[369] = "Lower Blackrock Spire";

WOW_TRIVIA_QUESTIONS[370] = "The acronym 'DOT' refers to?";
WOW_TRIVIA_ANSWERS1[370] = "Damage over Time";

WOW_TRIVIA_QUESTIONS[371] = "The acronym 'HOT' refers to?";
WOW_TRIVIA_ANSWERS1[371] = "Healing over Time";

WOW_TRIVIA_QUESTIONS[372] = "The acronym 'WTB' refers to?";
WOW_TRIVIA_ANSWERS1[372] = "Want to buy";

WOW_TRIVIA_QUESTIONS[373] = "The acronym 'WTS' refers to?";
WOW_TRIVIA_ANSWERS1[373] = "Want to Sell";

WOW_TRIVIA_QUESTIONS[374] = "The acronym 'GZ' refers to? (not the city, the word)";
WOW_TRIVIA_ANSWERS1[374] = "Congratulations";

WOW_TRIVIA_QUESTIONS[375] = "The abbreviation 'Scholo' refers to?";
WOW_TRIVIA_ANSWERS1[375] = "Scholomance";

WOW_TRIVIA_QUESTIONS[376] = "The acronym 'XP' refers to?";
WOW_TRIVIA_ANSWERS1[376] = "Experience Point";
WOW_TRIVIA_ANSWERS2[376] = "Experience Points";

WOW_TRIVIA_QUESTIONS[377] = "The acronym 'DM' refers to what instance, in Feralas?";
WOW_TRIVIA_ANSWERS1[377] = "Dire Maul";

WOW_TRIVIA_QUESTIONS[378] = "The acronym 'DM' refers to what instance, in Westfall?";
WOW_TRIVIA_ANSWERS1[378] = "The Deadmines";
WOW_TRIVIA_ANSWERS2[378] = "Deadmines";

WOW_TRIVIA_QUESTIONS[379] = "The acronym 'AV' refers to?";
WOW_TRIVIA_ANSWERS1[379] = "Alterac valley";

WOW_TRIVIA_QUESTIONS[380] = "The acronym 'AB' refers to?";
WOW_TRIVIA_ANSWERS1[380] = "Arathi Basin";

WOW_TRIVIA_QUESTIONS[381] = "The acronym 'WSG' refers to?";
WOW_TRIVIA_ANSWERS1[381] = "Warsong Gulch";

WOW_TRIVIA_QUESTIONS[382] = "The acronym 'AOE' refers to?";
WOW_TRIVIA_ANSWERS1[382] = "Area of Effect";
WOW_TRIVIA_ANSWERS2[382] = "Area of Effects";

WOW_TRIVIA_QUESTIONS[383] = "The acronym 'LFM' refers to?";
WOW_TRIVIA_ANSWERS1[383] = "Looking for More";
WOW_TRIVIA_ANSWERS2[383] = "Looking for more people";

WOW_TRIVIA_QUESTIONS[384] = "The acronym 'LFG' refers to?";
WOW_TRIVIA_ANSWERS1[384] = "Looking for Group";

WOW_TRIVIA_QUESTIONS[385] = "The acronym 'Mara' refers to?";
WOW_TRIVIA_ANSWERS1[385] = "Maraudon";

WOW_TRIVIA_QUESTIONS[386] = "The acronym 'MT' refers to?";
WOW_TRIVIA_ANSWERS1[386] = "Main Tank";

WOW_TRIVIA_QUESTIONS[387] = "The acronym 'OT' refers to?";
WOW_TRIVIA_ANSWERS1[387] = "Off tank";

WOW_TRIVIA_QUESTIONS[388] = "The acronyms 'IRL/RL' refers to? (name one of them)";
WOW_TRIVIA_ANSWERS1[388] = "In real life";
WOW_TRIVIA_ANSWERS2[388] = "real life";

WOW_TRIVIA_QUESTIONS[389] = "The acronym 'GM' refers to? (name one of them)";
WOW_TRIVIA_ANSWERS1[389] = "Game Master";
WOW_TRIVIA_ANSWERS2[389] = "Guild Master";

WOW_TRIVIA_QUESTIONS[390] = "How Many Warcraft games came before WoW (Not including Expansions)?";
WOW_TRIVIA_ANSWERS1[390] = "3";
WOW_TRIVIA_ANSWERS1[390] = "Three";

WOW_TRIVIA_QUESTIONS[391] = "Who was the mysterious prophet?";
WOW_TRIVIA_ANSWERS1[391] = "Medivh";

WOW_TRIVIA_QUESTIONS[392] = "Who cast the blood curse on the orcs?";
WOW_TRIVIA_ANSWERS1[392] = "Mannoroth";

WOW_TRIVIA_QUESTIONS[393] = "Who is the leader of the burning legion?";
WOW_TRIVIA_ANSWERS1[393] = "Sargeras";
 

WOW_TRIVIA_QUESTIONS[394] = "When was the gate of AQ opened for the first time (MM-DD-YYYY)";
WOW_TRIVIA_ANSWERS1[394] = "01-23-2006";


WOW_TRIVIA_QUESTIONS[395] = "The acronym 'NE' refers to (not the direction, the race)?";
WOW_TRIVIA_ANSWERS1[395] = "night elf";

WOW_TRIVIA_QUESTIONS[396] = "What day was WoW Released in the US? (MM-DD-YYYY)";
WOW_TRIVIA_ANSWERS1[396] = "11-23-2004";

WOW_TRIVIA_QUESTIONS[397] = "The abbreviation 'Resto' refers to what? (hint: talent tree)";
WOW_TRIVIA_ANSWERS1[397] = "Restoration";

WOW_TRIVIA_QUESTIONS[398] = "The abbreviation 'Mats' refers to?";
WOW_TRIVIA_ANSWERS1[398] = "Materials";

WOW_TRIVIA_QUESTIONS[399] = "The acronym 'PUG' refers to?";
WOW_TRIVIA_ANSWERS1[399] = "pick up group";

WOW_TRIVIA_QUESTIONS[400] = "The acronym 'CC' refers to?";
WOW_TRIVIA_ANSWERS1[400] = "Crowd Control";

WOW_TRIVIA_QUESTIONS[401] = "The acronym 'AP' refers to?";
WOW_TRIVIA_ANSWERS1[401] = "Attack power";

WOW_TRIVIA_QUESTIONS[402] = "The acronym 'LOS' refers to?";
WOW_TRIVIA_ANSWERS1[402] = "line of sight";

WOW_TRIVIA_QUESTIONS[403] = "The acronym 'AQ20' refers to? (the full name)";
WOW_TRIVIA_ANSWERS1[403] = "Ruins of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[403] = "The Ruins of Ahn'Qiraj";

WOW_TRIVIA_QUESTIONS[404] = "The acronym 'AQ40' refers to? (the full name)";
WOW_TRIVIA_ANSWERS1[404] = "Temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[404] = "The Temple of Ahn'Qiraj";

WOW_TRIVIA_QUESTIONS[405] = "What day was WoW released in EU? (MM-DD-YYYY)";
WOW_TRIVIA_ANSWERS1[405] = "02-11-2005";


WOW_TRIVIA_QUESTIONS[406] = "The acronym 'BWL' refers to?";
WOW_TRIVIA_ANSWERS1[406] = "Blackwing Lair";

WOW_TRIVIA_QUESTIONS[407] = "Before patch 1.10 taurens had what ability?";
WOW_TRIVIA_ANSWERS1[407] = "Plainsrunning";

WOW_TRIVIA_QUESTIONS[408] = "The acronym 'EPL' refers to?";
WOW_TRIVIA_ANSWERS1[408] = "Eastern Plaguelands";

WOW_TRIVIA_QUESTIONS[409] = "Humans and Orcs were the first Races Blizzard created in game? (true / false)";
WOW_TRIVIA_ANSWERS1[409] = "True";

WOW_TRIVIA_QUESTIONS[410] = "Tauren is an anagram for?";
WOW_TRIVIA_ANSWERS1[410] = "Nature";

WOW_TRIVIA_QUESTIONS[411] = "At what level can you ride a mount?";
WOW_TRIVIA_ANSWERS1[411] = "40";

WOW_TRIVIA_QUESTIONS[412] = "If someone Muli-boxes on feenix servers what are they not allowed to do?";
WOW_TRIVIA_ANSWERS1[412] = "pvp";

WOW_TRIVIA_QUESTIONS[413] = "The drop chance for Baron Rivendare's mount is how much? (about, in percents)";
WOW_TRIVIA_ANSWERS1[413] = "0,01%";
WOW_TRIVIA_ANSWERS2[413] = "0.01%";
WOW_TRIVIA_ANSWERS3[413] = "0,01";
WOW_TRIVIA_ANSWERS4[413] = "0.01";

WOW_TRIVIA_QUESTIONS[414] = "Where is Maraudon?";
WOW_TRIVIA_ANSWERS1[414] = "Desolace";

WOW_TRIVIA_QUESTIONS[415] = "the Scourge was created by a being called ______________.";
WOW_TRIVIA_ANSWERS1[415] = "The Lich King";
WOW_TRIVIA_ANSWERS2[415] = "Lich King";

WOW_TRIVIA_QUESTIONS[416] = "The acronym 'DW' refers to?";
WOW_TRIVIA_ANSWERS1[416] = "Dual wield";

WOW_TRIVIA_QUESTIONS[417] = "The acronym 'HS' refers to?";
WOW_TRIVIA_ANSWERS1[417] = "Hearthstone";

WOW_TRIVIA_QUESTIONS[418] = "The acronym 'FR' refers to?";
WOW_TRIVIA_ANSWERS1[418] = "Fire resistance";

WOW_TRIVIA_QUESTIONS[419] = "The acronym 'NR' refers to?";
WOW_TRIVIA_ANSWERS1[419] = "Nature resistance";

WOW_TRIVIA_QUESTIONS[420] = "The acronym 'SR' refers to?";
WOW_TRIVIA_ANSWERS1[420] = "Shadow resistance";

WOW_TRIVIA_QUESTIONS[421] = "The acronym 'XR' refers to?";
WOW_TRIVIA_ANSWERS1[421] = "Crossroads";

WOW_TRIVIA_QUESTIONS[422] = "The acronym 'TM' refers to?";
WOW_TRIVIA_ANSWERS1[422] = "Tarren Mill";

WOW_TRIVIA_QUESTIONS[423] = "The acronym 'TB' refers to?";
WOW_TRIVIA_ANSWERS1[423] = "Thunder Bluff";

WOW_TRIVIA_QUESTIONS[424] = "The abbreviation 'Darn' refers to?";
WOW_TRIVIA_ANSWERS1[424] = "Darnassus";

WOW_TRIVIA_QUESTIONS[425] = "The acronym 'CoE' refers to?";
WOW_TRIVIA_ANSWERS1[425] = "Curse of Elements";
WOW_TRIVIA_ANSWERS2[425] = "Curse of the Elements";

WOW_TRIVIA_QUESTIONS[426] = "The acronym 'CoS' refers to?";
WOW_TRIVIA_ANSWERS1[426] = "Curse of Shadow";

WOW_TRIVIA_QUESTIONS[427] = "The acronym 'FW' refers to?";
WOW_TRIVIA_ANSWERS1[427] = "Fear ward";

WOW_TRIVIA_QUESTIONS[428] = "The acronym 'VW' refers to?";
WOW_TRIVIA_ANSWERS1[428] = "Voidwalker";

WOW_TRIVIA_QUESTIONS[429] = "What is the name of the capital city of the fallen nerubian empire?";
WOW_TRIVIA_ANSWERS1[429] = "Azjol-Nerub";

WOW_TRIVIA_QUESTIONS[430] = "What is the Boulderfist clan made of?";
WOW_TRIVIA_ANSWERS1[430] = "Ogres";
WOW_TRIVIA_ANSWERS2[430] = "Ogre";

WOW_TRIVIA_QUESTIONS[431] = "Keeper Remulos is the son of Cenarius. (True/False)?";
WOW_TRIVIA_ANSWERS1[431] = "True";

WOW_TRIVIA_QUESTIONS[432] = "Cenarius is a Demigod. (True/False)?";
WOW_TRIVIA_ANSWERS1[432] = "True";

WOW_TRIVIA_QUESTIONS[433] = "What is the name of the new World Tree?";
WOW_TRIVIA_ANSWERS1[433] = "Teldrassil";

WOW_TRIVIA_QUESTIONS[434] = "What is Deathwing also known as?";
WOW_TRIVIA_ANSWERS1[434] = "Neltharion";
WOW_TRIVIA_ANSWERS2[434] = "Neltharion the Earth Warder";
WOW_TRIVIA_ANSWERS3[434] = "Neltharion the Earth-Warder";

WOW_TRIVIA_QUESTIONS[435] = "The Bloodscalp tribe is what kind of trolls?";
WOW_TRIVIA_ANSWERS1[435] = "Jungle";
WOW_TRIVIA_ANSWERS2[435] = "Jungle Trolls";

WOW_TRIVIA_QUESTIONS[436] = "Who created the Twilight's Hammer?";
WOW_TRIVIA_ANSWERS1[436] = "Cho'gall";
WOW_TRIVIA_ANSWERS2[436] = "Chogall";

WOW_TRIVIA_QUESTIONS[437] = "Where does the Crushridge clan live?";
WOW_TRIVIA_ANSWERS1[437] = "Alterac";
WOW_TRIVIA_ANSWERS2[437] = "Alterac Mountains";

WOW_TRIVIA_QUESTIONS[438] = "Where can you find Chrommagus?";
WOW_TRIVIA_ANSWERS1[438] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS2[438] = "BWL";

WOW_TRIVIA_QUESTIONS[439] = "Dalaran is a city in the Hillsbrad Foothills. (True/False)?";
WOW_TRIVIA_ANSWERS1[439] = "True";

WOW_TRIVIA_QUESTIONS[440] = "What is 'Darrowmere'? (ex. a city)";
WOW_TRIVIA_ANSWERS1[440] = "Lake";
WOW_TRIVIA_ANSWERS2[440] = "A lake";

WOW_TRIVIA_QUESTIONS[441] = "Who founded Quel'thalas?";
WOW_TRIVIA_ANSWERS1[441] = "Dath'Remar";
WOW_TRIVIA_ANSWERS2[441] = "Dath Remar";
WOW_TRIVIA_ANSWERS3[441] = "Dath'Remar Sunstrider";
WOW_TRIVIA_ANSWERS4[441] = "Dath'Remar Sunstrider";

WOW_TRIVIA_QUESTIONS[442] = "What is the the name of the organization that is causing Stormwind major trouble? The organization has taken over nearly all of westfall.";
WOW_TRIVIA_ANSWERS1[442] = "Defias Brotherhood";
WOW_TRIVIA_ANSWERS2[442] = "The Defias Brotherhood";

WOW_TRIVIA_QUESTIONS[443] = "What race is Detheroc?";
WOW_TRIVIA_ANSWERS1[443] = "Dreadlord"
WOW_TRIVIA_ANSWERS2[443] = "Nathrezim";

WOW_TRIVIA_QUESTIONS[444] = "What is Doomhammer's first name?";
WOW_TRIVIA_ANSWERS1[444] = "Orgrim";

WOW_TRIVIA_QUESTIONS[445] = "Who is Thrall's mother?";
WOW_TRIVIA_ANSWERS1[445] = "Draka";

WOW_TRIVIA_QUESTIONS[446] = "What was Outland's true name, before it was sundered?";
WOW_TRIVIA_ANSWERS1[446] = "Draenor";

WOW_TRIVIA_QUESTIONS[447] = "Who is Thrall's advisor?";
WOW_TRIVIA_ANSWERS1[447] = "Eitrigg";

WOW_TRIVIA_QUESTIONS[448] = "Eastern Plaugelands is the place where the emerald dream is supposed to be accessable. (True/False)?";
WOW_TRIVIA_ANSWERS1[448] = "False";

WOW_TRIVIA_QUESTIONS[449] = "What is Eonar? (ex. a naga)";
WOW_TRIVIA_ANSWERS1[449] = "Titan";
WOW_TRIVIA_ANSWERS2[449] = "Vanir Titan";
WOW_TRIVIA_ANSWERS3[449] = "A titan";
WOW_TRIVIA_ANSWERS4[449] = "A Vanir Titan";

WOW_TRIVIA_QUESTIONS[450] = "Frostmourne is the Lich King's weapon. (True/False)?"
WOW_TRIVIA_ANSWERS1[450] = "True"

WOW_TRIVIA_QUESTIONS[451] = "The Firetree tribe, which is made of forest trolls, resides in?";
WOW_TRIVIA_ANSWERS1[451] = "UBRS";
WOW_TRIVIA_ANSWERS2[451] = "Upper Blackrock Spire";

WOW_TRIVIA_QUESTIONS[452] = "What rank was Garithos in the armies of Lordaeron before he was killed by Varimathras?";
WOW_TRIVIA_ANSWERS1[452] = "Grand Marshall";
WOW_TRIVIA_ANSWERS2[452] = "14"; -- Grand Marshal = 14

WOW_TRIVIA_QUESTIONS[453] = "Genjuros was the _______ of the blackrock clan before he died.";
WOW_TRIVIA_ANSWERS1[453] = "Blademaster";

WOW_TRIVIA_QUESTIONS[454] = "Gilneas is located in the _________ and is currently unaccessible. (hint: the continent)";
WOW_TRIVIA_ANSWERS1[454] = "Eastern kingdoms";

WOW_TRIVIA_QUESTIONS[455] = "Who is the leader of Gilneas?";
WOW_TRIVIA_ANSWERS1[455] = "Greymane";
WOW_TRIVIA_ANSWERS2[455] = "Genn Graymane";

WOW_TRIVIA_QUESTIONS[456] = "The Gurubashi empire is made of ogres. (True/False)?";
WOW_TRIVIA_ANSWERS1[456] = "False";

WOW_TRIVIA_QUESTIONS[457] = "What is Hakkar's fullname?";
WOW_TRIVIA_ANSWERS1[457] = "Hakkar the Soulflayer";

WOW_TRIVIA_QUESTIONS[458] = "What was Hellscream's first name?";
WOW_TRIVIA_ANSWERS1[458] = "Grom";

WOW_TRIVIA_QUESTIONS[459] = "Who lead the Warsong clan, before Thrall united all the orcs in Azeroth?";
WOW_TRIVIA_ANSWERS1[459] = "Grom Hellscream";

WOW_TRIVIA_QUESTIONS[460] = "What is the largest glacier on Azeroth?";
WOW_TRIVIA_ANSWERS1[460] = "Icecrown Glacier";
WOW_TRIVIA_ANSWERS2[460] = "The Icecrown glacier";
WOW_TRIVIA_ANSWERS3[460] = "The Icecrown";
WOW_TRIVIA_ANSWERS4[460] = "Icecrown";

WOW_TRIVIA_QUESTIONS[461] = "Who is Malfurion Stormrage's brother?";
WOW_TRIVIA_ANSWERS1[461] = "Illidan";
WOW_TRIVIA_ANSWERS2[461] = "Illidan Stormrage"

WOW_TRIVIA_QUESTIONS[462] = "Kel'Thuzad was killed by adventurers who entered Naxxramas. (True/False)?"; -- His phylatecary remains
WOW_TRIVIA_ANSWERS1[462] = "False";

WOW_TRIVIA_QUESTIONS[463] = "Kirin Tor is a crime syndicate currently located in Gilneas. (True/False)?";
WOW_TRIVIA_ANSWERS1[463] = "False";

WOW_TRIVIA_QUESTIONS[464] = "Rexxar is half orc, and half demon. (True/False)?";
WOW_TRIVIA_ANSWERS1[464] = "False";

WOW_TRIVIA_QUESTIONS[465] = "In the tauren mythology, Elune is known as Mu'sha and is the left eye of the ___________.";
WOW_TRIVIA_ANSWERS1[465] = "Earthmother";
WOW_TRIVIA_ANSWERS2[465] = "the Earthmother";

WOW_TRIVIA_QUESTIONS[466] = "Rexxar helped Thrall when he founded Durotar. (True/False)?";
WOW_TRIVIA_ANSWERS1[466] = "True";

WOW_TRIVIA_QUESTIONS[467] = "Who is known as 'the Lightbringer'?";
WOW_TRIVIA_ANSWERS1[467] = "Uther";

WOW_TRIVIA_QUESTIONS[468] = "Lethon was a Lieutenant of Ysera .(True/False)?";
WOW_TRIVIA_ANSWERS1[468] = "True";

WOW_TRIVIA_QUESTIONS[469] = "Lord Anduin Lothar was the last descendant of the ______ royal bloodline, and was known as the 'Lion of Azeroth'.";
WOW_TRIVIA_ANSWERS1[469] = "Arathi";

WOW_TRIVIA_QUESTIONS[470] = "The Maelstrom transformed some of the highborne's into naga's. (True/False)?";
WOW_TRIVIA_ANSWERS1[470] = "True";

WOW_TRIVIA_QUESTIONS[471] = "__________ is the father of Onyxia and Nefarian.";
WOW_TRIVIA_ANSWERS1[471] = "Deathwing";

WOW_TRIVIA_QUESTIONS[472] = "__________ was the father of Cenarius.";
WOW_TRIVIA_ANSWERS1[472] = "Malorne";

WOW_TRIVIA_QUESTIONS[473] = "Archimonde killed Cenarius father, Malorne, in the War of the Ancients. (True/False)?";
WOW_TRIVIA_ANSWERS1[473] = "True";

WOW_TRIVIA_QUESTIONS[474] = "What was Cenarius father, Malorne, also known as?";
WOW_TRIVIA_ANSWERS1[474] = "The white stag";

WOW_TRIVIA_QUESTIONS[475] = "The Earthen Ring is made of _________.";
WOW_TRIVIA_ANSWERS1[475] = "Shamans";

WOW_TRIVIA_QUESTIONS[476] = "What is Malygos the Blue aspect over?";
WOW_TRIVIA_ANSWERS1[476] = "Magic";

WOW_TRIVIA_QUESTIONS[477] = "_________ is the leader of the Blue Dragonflight.";
WOW_TRIVIA_ANSWERS1[477] = "Malygos";

WOW_TRIVIA_QUESTIONS[478] = "Mannoroth quickly became one of the favoured Generals of Archimonde and Kil'Jaeden. (True/False)";
WOW_TRIVIA_ANSWERS1[478] = "False";

WOW_TRIVIA_QUESTIONS[479] = "What was Mannoroth known as? (for ex. Archimonde the Defiler)";
WOW_TRIVIA_ANSWERS1[479] = "Mannoroth the Destructor";
WOW_TRIVIA_ANSWERS2[479] = "the Destructor";

WOW_TRIVIA_QUESTIONS[480] = "_________ opened the Dark Portal when he was possessed by Sargeras.";
WOW_TRIVIA_ANSWERS1[480] = "Medivh";

WOW_TRIVIA_QUESTIONS[481] = "_______ the Tidehunter was a Elemental Lieutenant of the Old Gods.";
WOW_TRIVIA_ANSWERS1[481] = "Neptulon";

WOW_TRIVIA_QUESTIONS[482] = "Ragnaros is a Elemental lieutenant of the Old Gods. (True/False)?";
WOW_TRIVIA_ANSWERS1[482] = "True";

WOW_TRIVIA_QUESTIONS[483] = "Ner'zhul was known as the elder _________ of the orcs, before he was transformed into the Lich King.";
WOW_TRIVIA_ANSWERS1[483] = "shaman";

WOW_TRIVIA_QUESTIONS[484] = "___________ is a male Aesir Titan. Master of the arcane magic, knowledge, secrets, and mysteries.";
WOW_TRIVIA_ANSWERS1[484] = "Norgannon";

WOW_TRIVIA_QUESTIONS[485] = "Lord ______ of Alterac betrayed the Alliance and attempted to assasinate lord Uther.";
WOW_TRIVIA_ANSWERS1[485] = "Perenolde";
WOW_TRIVIA_ANSWERS2[485] = "Aieden Perenolde";

WOW_TRIVIA_QUESTIONS[486] = "The Quel'dorei is a term meaning ________ in Thalassian.";
WOW_TRIVIA_ANSWERS1[486] = "high elves";
WOW_TRIVIA_ANSWERS2[486] = "high elfs";

WOW_TRIVIA_QUESTIONS[487] = "Lord Kur'talos ________ was the master of the Black Rook Hold.";
WOW_TRIVIA_ANSWERS1[487] = "ravencrest";

WOW_TRIVIA_QUESTIONS[488] = "________ was the leader of the Darkspear tribe before he was killed by murlocs. A troll village in Durotar is named after him.";
WOW_TRIVIA_ANSWERS1[488] = "Sen'jin";
WOW_TRIVIA_ANSWERS2[488] = "Senjin";

WOW_TRIVIA_QUESTIONS[489] = "The Shadow Councill has their base in Hillsbrad Foothills, in the mountains close to Alterac. (True/False)?";
WOW_TRIVIA_ANSWERS1[489] = "False";

WOW_TRIVIA_QUESTIONS[490] = "What is the name of the Archbishop who created the Paladin order of the Silver Hand, together with Uther.";
WOW_TRIVIA_ANSWERS1[490] = "Alonsus Faol";
WOW_TRIVIA_ANSWERS2[490] = "Archbishop Alonsus Faol";

WOW_TRIVIA_QUESTIONS[491] = "The domain of air is called The _______ on the Elemental Plane.";
WOW_TRIVIA_ANSWERS1[491] = "Skywall";

WOW_TRIVIA_QUESTIONS[492] = "The domain of earth is called _______ on the Elemental Plane.";
WOW_TRIVIA_ANSWERS1[492] = "Deephome";

WOW_TRIVIA_QUESTIONS[493] = "The domain of fire is called The ________ on the Elemental Plane.";
WOW_TRIVIA_ANSWERS1[493] = "Firelands";

WOW_TRIVIA_QUESTIONS[494] = "The domain of water is called The ___________ on the Elemental Plane.";
WOW_TRIVIA_ANSWERS1[494] = "Abyssal Maw";

WOW_TRIVIA_QUESTIONS[495] = "The ____________ Cartel is the largest and most successful of the Goblin Cartels in Undermine.";
WOW_TRIVIA_ANSWERS1[495] = "Steamwheedle";

WOW_TRIVIA_QUESTIONS[496] = "_______________ the naga tribe, is currently dwelling in the northern Darkshore. (hint: This is also a realm name, in both the EU and the US)";
WOW_TRIVIA_ANSWERS1[496] = "Stormscale";

WOW_TRIVIA_QUESTIONS[497] = "The 'Wailing Caverns is in the ___________.";
WOW_TRIVIA_ANSWERS1[497] = "barrens";


WOW_TRIVIA_QUESTIONS[498] = "Where can you find Garr?";
WOW_TRIVIA_ANSWERS1[498] = "Molten Core";
WOW_TRIVIA_ANSWERS2[498] = "MC";

WOW_TRIVIA_QUESTIONS[499] = "Where can you find Baron Geddon?";
WOW_TRIVIA_ANSWERS1[499] = "Molten Core";
WOW_TRIVIA_ANSWERS2[499] = "MC";

WOW_TRIVIA_QUESTIONS[500] = "Agamaggan was an immortal giant _____ which legend say was among the first living creatures to roam Azeroth.";
WOW_TRIVIA_ANSWERS1[500] = "Boar";

WOW_TRIVIA_QUESTIONS[501] = "Broodlord Lashlayer resides in ____________?";
WOW_TRIVIA_ANSWERS1[501] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS1[501] = "BWL";

WOW_TRIVIA_QUESTIONS[502] = "Mal'ganis was killed alongside with a large portion of the Scourge that thought they had achieved victory. (True/False)?";
WOW_TRIVIA_ANSWERS1[502] = "False";

WOW_TRIVIA_QUESTIONS[503] = "The Lich King is controlled by Kil'Jaeden. (True/False)?";
WOW_TRIVIA_ANSWERS1[503] = "false";

WOW_TRIVIA_QUESTIONS[504] = "The Lich King and Arthas were fused into a single entity. (True/False)?";
WOW_TRIVIA_ANSWERS1[504] = "True";

WOW_TRIVIA_QUESTIONS[505] = "Suramar was a keldorei city, which was destroyed by the _____________ during the War of the Ancients.";
WOW_TRIVIA_ANSWERS1[505] = "Burning Legion";

WOW_TRIVIA_QUESTIONS[506] = "The World of Warcraft official soundtrack is only availible if you purchased the Collector's edition. (True/False)?";
WOW_TRIVIA_ANSWERS1[506] = "False";

WOW_TRIVIA_QUESTIONS[507] = "Lord Kazzak spwans in what area?";
WOW_TRIVIA_ANSWERS1[507] = "Blasted Lands";
WOW_TRIVIA_ANSWERS2[507] = "The Blasted Lands";

WOW_TRIVIA_QUESTIONS[508] = "Azuregos spawns in what area?";
WOW_TRIVIA_ANSWERS1[508] = "Azshara";

WOW_TRIVIA_QUESTIONS[509] = "Doom Lord Kazzak is the third boss in Naxx. (True/False)?";
WOW_TRIVIA_ANSWERS1[509] = "False";

WOW_TRIVIA_QUESTIONS[510] = "What is the name of the populare addon which has a database of every thing you have picked, since you had the addon?";
WOW_TRIVIA_ANSWERS1[510] = "Gatherer";

WOW_TRIVIA_QUESTIONS[510] = "What is the name of the populare addon which has a database of every thing you have picked, since you had the addon?";
WOW_TRIVIA_ANSWERS1[510] = "Gatherer";

WOW_TRIVIA_QUESTIONS[511] = "Guess the Zone: This zone is very nature-looking, filled with wild beasts and famous for its fishing contest.";
WOW_TRIVIA_ANSWERS1[511] = "STV";
WOW_TRIVIA_ANSWERS2[511] = "Stranglethorn Vale";
WOW_TRIVIA_ANSWERS3[511] = "Stranglethorn";

WOW_TRIVIA_QUESTIONS[512] = "The zone north of Azshara is known as ______________.";
WOW_TRIVIA_ANSWERS1[512] = "Winterspring";

WOW_TRIVIA_QUESTIONS[513] = "The shattered floating remnants of the red world is also known as __________.";
WOW_TRIVIA_ANSWERS1[513] = "Outland";
WOW_TRIVIA_ANSWERS3[513] = "The Outland";

WOW_TRIVIA_QUESTIONS[514] = "World of Warcraft has a total of _____ million subscribers at the moment.";
WOW_TRIVIA_ANSWERS1[514] = "9";
WOW_TRIVIA_ANSWERS2[514] = "nine";

WOW_TRIVIA_QUESTIONS[515] = "Guess the Zone: This zone is a giant farm land, and is nearly controlled solely by the Defias Brotherhood.";
WOW_TRIVIA_ANSWERS1[515] = "Westfall";

WOW_TRIVIA_QUESTIONS[516] = "Guess the Zone: Son of Arugal patrols the zone.";
WOW_TRIVIA_ANSWERS1[516] = "Silverpine forest";

WOW_TRIVIA_QUESTIONS[517] = "Guess the Zone: The starting land of Dwarves and Gnomes.";
WOW_TRIVIA_ANSWERS1[517] = "Dun Morogh";
WOW_TRIVIA_ANSWERS2[517] = "Dun morogh";

WOW_TRIVIA_QUESTIONS[518] = "Guess the Zone: Violet Tragan plant and objective of Sprinkle's Secret Ingredient grows in this zone.";
WOW_TRIVIA_ANSWERS1[518] = "The Hinterlands";
WOW_TRIVIA_ANSWERS2[518] = "Hinterlands";

WOW_TRIVIA_QUESTIONS[519] = "Guess the Zone: This zone contains Irontree Woods and Emerald Sanctuary.";
WOW_TRIVIA_ANSWERS1[519] = "Felwood";

WOW_TRIVIA_QUESTIONS[520] = "Guess the Zone: The first time you will probably meet the crocodils if you are Orc. This zone is rich with copper ore.";
WOW_TRIVIA_ANSWERS1[520] = "Durotar";

WOW_TRIVIA_QUESTIONS[521] = "Guess the Zone: Guess it!.";
WOW_TRIVIA_ANSWERS1[521] = "WPL";
WOW_TRIVIA_ANSWERS2[521] = "Western Plaguelands";

WOW_TRIVIA_QUESTIONS[522] = "Guess the Zone: It is a PvP zone. It is the place of battle between Stormpike and Frostwolf clan.";
WOW_TRIVIA_ANSWERS1[522] = "Alterav Valley";
WOW_TRIVIA_ANSWERS1[522] = "AV";

WOW_TRIVIA_QUESTIONS[523] = "Guess the Zone: 'This zone is a grim spectacle of arena fights. Only the winner may take the chest.";
WOW_TRIVIA_ANSWERS1[523] = "STV";
WOW_TRIVIA_ANSWERS2[523] = "Stranglethorn";
WOW_TRIVIA_ANSWERS2[523] = "Stranglethorn Vale";

WOW_TRIVIA_QUESTIONS[524] = "Guess the Zone: Felguards, infernal's and other demonic beings ravages this zone. You can encounter the Shadow Councill here.";
WOW_TRIVIA_ANSWERS1[524] = "Shadowmoon";
WOW_TRIVIA_ANSWERS2[524] = "Shadowmoon valley";

WOW_TRIVIA_QUESTIONS[525] = "Guess the Zone: Before TBC came out, this zone featured the populare stat potions, the ones which gives the player +25 to a stat. With the recent development with the guardian and battle elixirs, these potions is not used anymore.";
WOW_TRIVIA_ANSWERS1[525] = "Blasted Lands";

WOW_TRIVIA_QUESTIONS[526] = "Guess the Zone: This zone was originally the Black Morass, but has changed name since then, due to the changes in the environment. This zone features a dragon which drops spheres, which in turn can be turned in for loot.";
WOW_TRIVIA_ANSWERS1[526] = "Blasted Lands";

WOW_TRIVIA_QUESTIONS[527] = "Guess the Zone: This zone is located north of the Redridge Mountains, and features the two first 40man instances ever created by Blizzard.";
WOW_TRIVIA_ANSWERS1[527] = "Burning Steppes";

WOW_TRIVIA_QUESTIONS[528] = "Guess the Zone: This zone features the Altar of Storms. This zone has plenty of dragon whelps and ogres. Herbers can find dreamfoil and black lotuses here.";
WOW_TRIVIA_ANSWERS1[528] = "Burning Steppes";

WOW_TRIVIA_QUESTIONS[529] = "Guess the Zone: Timbermaw Hold connects Winterspring, Felwood and ___________";
WOW_TRIVIA_ANSWERS1[529] = "Moonglade";

WOW_TRIVIA_QUESTIONS[530] = "Guess the Zone: The town in this zone is speculated to be Sunnyglade, but later renamed due to the events that has transpired in this zone. This zone features the Scourge, and a lot of worgens.";
WOW_TRIVIA_ANSWERS1[530] = "Duskwood";

WOW_TRIVIA_QUESTIONS[531] = "Guess the Zone: This zone is 'famous' for the rumored 'Schythe of Elune'. The zone features an emerald dream portal, and is one of the four zones where the Emerald Dragons spawns in. (One in each of the four zones)";
WOW_TRIVIA_ANSWERS1[531] = "Duskwood";

WOW_TRIVIA_QUESTIONS[532] = "Guess the Zone: This zone contains the Tower of Azora, and the Westbrook Garrison. The zone's inhabitants are mainly gnolls, bandits, and murlocs.";
WOW_TRIVIA_ANSWERS1[532] = "Elwynn Forest";
WOW_TRIVIA_ANSWERS2[532] = "Elwynn";

WOW_TRIVIA_QUESTIONS[533] = "Guess the Zone: This zone contains the capital city of one of the Alliance races. The zone features no instances, but has a famous gnoll named.. Hogger!";
WOW_TRIVIA_ANSWERS1[533] = "Elwynn Forest";
WOW_TRIVIA_ANSWERS2[533] = "Elwynn";

WOW_TRIVIA_QUESTIONS[534] = "Guess the Zone: This zone features the quest 'Hillary's necklace'. The zone's inhabitants are mostly orcs and gnolls. The alliance town in this region lies on the shores of Lake Everstill.";
WOW_TRIVIA_ANSWERS1[534] = "Redridge Mountains";
WOW_TRIVIA_ANSWERS2[534] = "Redridge";

WOW_TRIVIA_QUESTIONS[535] = "Guess the Zone: The Tower of Ilgalar is here, though it is currently controlled by the evil Mage, Morganth. Gnolls and spiders are just a small part of the many local inhabitants of the zone.";
WOW_TRIVIA_ANSWERS1[535] = "Redridge Mountains";
WOW_TRIVIA_ANSWERS2[535] = "Redridge";

WOW_TRIVIA_QUESTIONS[536] = "Guess the Zone: This zone was the primary center of the Gurubashi Empire, a long time ago. The zone is known to be a paradise for gankers. A lot of beasts live here.";
WOW_TRIVIA_ANSWERS1[536] = "Stranglethorn Vale";
WOW_TRIVIA_ANSWERS2[536] = "STV";

WOW_TRIVIA_QUESTIONS[537] = "Where is Rexxar, in Azeroth?";
WOW_TRIVIA_ANSWERS1[537] = "Desolace";

WOW_TRIVIA_QUESTIONS[538] = "Guess the Zone: This zone features the 'Tiny Emerald Whelpling' pet. There is only one instance in this zone. This zone is actually quite similar to Black Morass.";
WOW_TRIVIA_ANSWERS1[538] = "Swamp of Sorrows";

WOW_TRIVIA_QUESTIONS[539] = "Guess the Zone: Murlocs, crocolisks, spiders and lost one's occupies this zone. You can find much blindweed and goldthorn here, and therefor is a populare spot to grind the mats for arcane elixirs.";
WOW_TRIVIA_ANSWERS1[539] = "Swamp of Sorrows";

WOW_TRIVIA_QUESTIONS[540] = "Guess the Zone: The zone lies south of Darkshore, and is the ancestral homeland of the night elves. They still remain in control of several holdings throughout the zone, such as Maestra's Post, and the Shrine of Aessina.";
WOW_TRIVIA_ANSWERS1[540] = "Ashenvale";

WOW_TRIVIA_QUESTIONS[541] = "Guess the Zone: The Furbolgs, and satyrs are some of the local inhabitants of this zone. It was a populare world pvp zone before the expansion came out. This zone also features an Emerald Dream portal.";
WOW_TRIVIA_ANSWERS1[541] = "Ashenvale";

WOW_TRIVIA_QUESTIONS[542] = "Guess the Zone: Nagas, ghosts, and satyrs are some of the local inhabitants in this zone. The zone was named after the former kaldorei Queen, which is now the leader of the naga's.";
WOW_TRIVIA_ANSWERS1[542] = "Azshara";

WOW_TRIVIA_QUESTIONS[543] = "Guess the Zone: One of the best zones for farming Dreamfoil and Mountain Silversage. This zone also features the Hydraxian Waterlords faction. The zone is also known to be one of best-looking zones in World of Warcraft.";
WOW_TRIVIA_ANSWERS1[543] = "Azshara"

WOW_TRIVIA_QUESTIONS[544] = "Guess the Zone: Great battle took place in this Zone. The World Tree grows there.";
WOW_TRIVIA_ANSWERS1[544] = "Hyal";
WOW_TRIVIA_ANSWERS2[544] = "Mount Hyal";

WOW_TRIVIA_QUESTIONS[545] = "Guess the Zone: Several large kaldorei cities once stood in this zone. This zone has one instance, and is mostly about corrupted Druids. A quest chain in this zone wants you to hunt raptors all over the place becuase they stole some silver.";
WOW_TRIVIA_ANSWERS1[545] = "Barrens";
WOW_TRIVIA_ANSWERS2[545] = "The Barrens";

WOW_TRIVIA_QUESTIONS[546] = "Guess the Zone: The zone has some well known area's, such as the Fray Island, the Stagnant Oasis, and the Fields of Giants. This zone also features a lot of 'hunting' quests.";
WOW_TRIVIA_ANSWERS1[546] = "Barrens";
WOW_TRIVIA_ANSWERS2[546] = "The Barrens";

WOW_TRIVIA_QUESTIONS[547] = "Emerald dream question: Which class call was (is) bugged on Nefarian encounter?";
WOW_TRIVIA_ANSWERS1[547] = "Shaman";
WOW_TRIVIA_ANSWERS2[547] = "Shammy";

WOW_TRIVIA_QUESTIONS[548] = "Emerald dream question: There are several Horde guilds that have killed all the bosses in Blackwing Lair. But one guild has exploited Chrommagus fight when they progressed trough the dungeon. Which one?";
WOW_TRIVIA_ANSWERS1[548] = "Apathetic";

WOW_TRIVIA_QUESTIONS[549] = "Guess the Zone: The night elfs controls this zone. The night elf sentinels patrols the road from Auberdine in this zone till Ashenvale to the south. A quest-chain here is to free the furbolgs from a satyr's corruption.";
WOW_TRIVIA_ANSWERS1[549] = "Darkshore";

WOW_TRIVIA_QUESTIONS[550] = "Guess the Zone: The Twilight Hammer has plenty of people in this zone. The Cult of the Dark strand also operates here. An Old God is rumored to have fallen in the Master's Glaive area of this zone. Onu refers to it as a 'Old God of the earth'.";
WOW_TRIVIA_ANSWERS1[550] = "Darkshore";

WOW_TRIVIA_QUESTIONS[551] = "Guess the Zone: This zone has been savaged by centaur's seaseless aggressions. The Kolkar, the Gelkis, the Magram, and the Maraudine centaurs fight each other as much as they do against the Horde and the Alliance of this zone.";
WOW_TRIVIA_ANSWERS1[551] = "Desolace";

WOW_TRIVIA_QUESTIONS[552] = "Guess the Zone: The Burning Blade's in this zone increases the risk of a region-wide demonic infestation, due to all the demonic beings they have summoned. The naga presence in the northwest of this zone also causes concern.";
WOW_TRIVIA_ANSWERS1[552] = "Desolace";

WOW_TRIVIA_QUESTIONS[553] = "Guess the Zone: This zone is named after Thrall's father, to honor him. The inhabitants of this zone is mostly harpies, makruras, quillboars, and tigers.";
WOW_TRIVIA_ANSWERS1[553] = "Durotar";

WOW_TRIVIA_QUESTIONS[554] = "Guess the Zone: This place contains the stonemaul ogres. One of the famous characters in this zone is Jaina Proudmoore. The zone contains creatures such as nagas, turtles, crocolisks, and spiders.";
WOW_TRIVIA_ANSWERS1[554] = "Dustwallow marsh";

WOW_TRIVIA_QUESTIONS[555] = "Guess the Zone: Sharks, dragonspawns, and raptors are some of the local inhabitants of this zone. This zone features a very popular pre-tbc instance, and the end boss of this instance has been 2manned.";
WOW_TRIVIA_ANSWERS1[555] = "Dustwallow marsh";

WOW_TRIVIA_QUESTIONS[556] = "Guess the Zone: Lord Illidan Stormrage obtained the skull of gul'dan here. This place is known for its corruption, which were caused by the Burning Legion. The Shadow Councill has a base of operations in this zone.";
WOW_TRIVIA_ANSWERS1[556] = "Felwood";

WOW_TRIVIA_QUESTIONS[557] = "Guess the Zone: This is the best zone to gather gromsblood in. You can also find lots of dreamfoil, and plaguebloom here. Some gold farmers farmed the angerclaw bears in this zone for money, pre-tbc due to their quick respawn.";
WOW_TRIVIA_ANSWERS1[557] = "Felwood";

WOW_TRIVIA_QUESTIONS[558] = "Guess the Zone: This zone holds many ancient ruins. The zone is famous for its ancient night elf city, which is now a instance. The zone is also one of the four locations which contain an emerald portal.";
WOW_TRIVIA_ANSWERS1[558] = "Feralas";

WOW_TRIVIA_QUESTIONS[559] = "Guess the Zone: Faeri dragons, and gnolls are two of the local inhabitants in this zone. The endgame guilds used to grind the raw meat of the Chimaeras in this zone in order to make the famous food, Dirge's Kickin' Chimaerok Chops.";
WOW_TRIVIA_ANSWERS1[559] = "Feralas";

WOW_TRIVIA_QUESTIONS[560] = "Guess the Zone: This zone contains the old world tree, and is currently unaccessible without special means.";
WOW_TRIVIA_ANSWERS1[560] = "Mount Hyjal";

WOW_TRIVIA_QUESTIONS[561] = "Guess the Zone: This zone is a haven for Druids and is the home of the Cenarion Circle. The conflict between the Alliance and the Horde is not tolerated by the protectors of this zone. This zone also features Omen during the Lunar Festival.";
WOW_TRIVIA_ANSWERS1[561] = "Moonglade";

WOW_TRIVIA_QUESTIONS[562] = "Guess the Zone: This zone is known for its nature-loving tribe people. This zone features a huge variety of animals. The Venture Co and the dwarves has intruded into this zone.";
WOW_TRIVIA_ANSWERS1[562] = "Mulgore";

WOW_TRIVIA_QUESTIONS[563] = "Guess the Zone: This zone contains the Bael'Dun Digsite, where dwarves scour the mountains for traces of their shrouded ancestry. Peacebloom and silverleaf is the local herbs around here. There is plenty of harpies in this zone.";
WOW_TRIVIA_ANSWERS1[563] = "Mulgore";

WOW_TRIVIA_QUESTIONS[564] = "Guess the Zone: This zone contains two high-end instances and was the location of a server wide event, more commonly known as the AQ War Effort. This zone also features extremely many insects.";
WOW_TRIVIA_ANSWERS1[564] = "Silithus";

WOW_TRIVIA_QUESTIONS[565] = "Guess the Zone: The wildlife here are mostly insects, snakes, and spiders. This zone has a world pvp event, and had many populare grinding places pre-tbc. The Cenarion Cirlce defends the local town here.";
WOW_TRIVIA_ANSWERS1[565] = "Silithus";

WOW_TRIVIA_QUESTIONS[566] = "Guess the Zone: This zone has huge problems with 'The Venture Co', who is trying to harvest the local forest here for profit. The Alliance can get here via the Talondeep Path.";
WOW_TRIVIA_ANSWERS1[566] = "Stonetalon Mountains";

WOW_TRIVIA_QUESTIONS[567] = "Guess the Zone: The inhabitants here are mostly harpies, goblins and fire elementals. You can mainly find copper veins here as a miner, with some occasional tin veins. One of the quests in this zone wants you to kill Besseleth, a huge spider.";
WOW_TRIVIA_ANSWERS1[567]= "Stonetalon Mountains";

WOW_TRIVIA_QUESTIONS[568] = "Guess the Zone: This zone contains one of the most liked mid level instances. This zone also contains a unaccessible location known as Uldum (very similar to Uldaman).";
WOW_TRIVIA_ANSWERS1[568] = "Tanaris";

WOW_TRIVIA_QUESTIONS[569] = "Guess the Zone: Furbolgs, grells, and nightsabers are some of the local inhabitants. This place is a nightmare for miners and for the Horde, as it's a hard zone to reach. This place is also the starting zone for one of the Alliance races.";
WOW_TRIVIA_ANSWERS1[569] = "Teldrassil";

WOW_TRIVIA_QUESTIONS[570] = "Guess the Zone: Dolanaar, and Starbreeze Village are some of the villages in this zone. You can find up to swiftthistle here as a herbalist, but not even one copper vein here as miner.";
WOW_TRIVIA_ANSWERS1[570] = "Teldrassil";

WOW_TRIVIA_QUESTIONS[571] = "Guess the Zone: A area in this zone is just as dangerous as Stranglethorn Vale, in terms of ganking, if not even more. Both the Alliance and the Horde goes here. This zone contains silithids, water elementals, turtles and wyverns.";
WOW_TRIVIA_ANSWERS1[571] = "Thousand Needles";

WOW_TRIVIA_QUESTIONS[572] = "Guess the Zone: Kobolds, earth elementals, carrion birds and wind serpents live here. The zone also features the Grimtotem clan. Tanaris lies north of this zone.";
WOW_TRIVIA_ANSWERS1[572] = "Thousand Needles";

WOW_TRIVIA_QUESTIONS[573] = "Guess the Zone: 'The night elf army was pushed back to this location. Something here prevented the Qiraji from being able to take the land. I do not quite understand this word but i belive it to mean 'God Lands'.'";
WOW_TRIVIA_ANSWERS1[573] = "Un'Goro";
WOW_TRIVIA_ANSWERS2[573] = "Un'Goro Crater";

WOW_TRIVIA_QUESTIONS[574] = "Guess the Zone: Dreamfoil, and mountain silersage can be gathered here, as a herbalist. The fire elementals in this region is a popular grinding place for fire essences. Stegodons, gorillas, and bloodpetals are some of the local inhabitants.";
WOW_TRIVIA_ANSWERS1[574] = "Un'Goro";
WOW_TRIVIA_ANSWERS2[574] = "Un'Goro Crater";

WOW_TRIVIA_QUESTIONS[575] = "Guess the Zone: Both the Steamwheedle Cartel and the night elfs has established a base in this region. The zone is rich on thorium veins for miners. The zone has quite a wildlife aswell, with its blue dragons, bears, and owls.";
WOW_TRIVIA_ANSWERS1[575] = "Winterspring";

WOW_TRIVIA_QUESTIONS[576] = "Guess the Zone: The Eye of Shadow was grinded quite often in this zone, before the expansion came. As Alliance you can obtain the 'Reins of the Winterspring Frostsaber' in this zone.";
WOW_TRIVIA_ANSWERS1[576] = "Winterspring";

WOW_TRIVIA_QUESTIONS[577] = "At what level can you become an artisan skinner?";
WOW_TRIVIA_ANSWERS1[577] = "35";

WOW_TRIVIA_QUESTIONS[578] = "The epic frost resistance gear for Warriors is called _________. Guilds usually create them for Naxxramas.";
WOW_TRIVIA_ANSWERS1[578] = "Icebane";

WOW_TRIVIA_QUESTIONS[579] = "How many people can you enter Zul'Gurub with?";
WOW_TRIVIA_ANSWERS1[579] = "20";

WOW_TRIVIA_QUESTIONS[580] = "How many people can you enter Lower Blackrock Spire with?";
WOW_TRIVIA_ANSWERS1[580] = "10";
WOW_TRIVIA_ANSWERS2[580] = "ten";

WOW_TRIVIA_QUESTIONS[581] = "The famous '______ on a stick' is widely known by nearly everyone in World of Warcaft.";
WOW_TRIVIA_ANSWERS1[581] = "Carrot";

WOW_TRIVIA_QUESTIONS[582] = "The uncommon trinket that is obtainable by doing quests with the Badlands, is called '________ Stopwatch'.";
WOW_TRIVIA_ANSWERS1[582] = "Nifty";

WOW_TRIVIA_QUESTIONS[583] = "Where can you find Lucifron?";
WOW_TRIVIA_ANSWERS1[583] = "Molten Core";
WOW_TRIVIA_ANSWERS2[583] = "MC";

WOW_TRIVIA_QUESTIONS[584] = "Where can you find Magmadar?";
WOW_TRIVIA_ANSWERS1[584] = "Molten Core";
WOW_TRIVIA_ANSWERS2[584] = "MC";

WOW_TRIVIA_QUESTIONS[585] = "Where can you find Gehennas?";
WOW_TRIVIA_ANSWERS1[585] = "Molten Core";
WOW_TRIVIA_ANSWERS2[585] = "MC";

WOW_TRIVIA_QUESTIONS[586] = "Where is 'Edge of Madness'?";
WOW_TRIVIA_ANSWERS1[586] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[586] = "ZG";
WOW_TRIVIA_ANSWERS3[586] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[587] = "Where can you find Shazzrah?";
WOW_TRIVIA_ANSWERS1[587] = "Molten Core";
WOW_TRIVIA_ANSWERS2[587] = "MC";

WOW_TRIVIA_QUESTIONS[588] = "Where can you find Golemagg the Incinerator?";
WOW_TRIVIA_ANSWERS1[588] = "Molten Core";
WOW_TRIVIA_ANSWERS2[588] = "MC";

WOW_TRIVIA_QUESTIONS[589] = "Where can you find Sulfuron Harbringer?";
WOW_TRIVIA_ANSWERS1[589] = "Molten Core";
WOW_TRIVIA_ANSWERS2[589] = "MC";

WOW_TRIVIA_QUESTIONS[590] = "Where can you find Majordomo Executus?";
WOW_TRIVIA_ANSWERS1[590] = "Molten Core";
WOW_TRIVIA_ANSWERS2[590] = "MC";

WOW_TRIVIA_QUESTIONS[591] = "Where can you find the Old God's Lieutenant, Ragnaros?";
WOW_TRIVIA_ANSWERS1[591] = "Molten Core";
WOW_TRIVIA_ANSWERS2[591] = "MC";

WOW_TRIVIA_QUESTIONS[592] = "Where can you find Bloodlord Mandokir?";
WOW_TRIVIA_ANSWERS1[592] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[592] = "ZG";
WOW_TRIVIA_ANSWERS3[592] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[593] = "Where can you find Gahz'ranka?";
WOW_TRIVIA_ANSWERS1[593] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[593] = "ZG";
WOW_TRIVIA_ANSWERS3[593] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[594] = "Where can you find Thekal?";
WOW_TRIVIA_ANSWERS1[594] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[594] = "ZG";
WOW_TRIVIA_ANSWERS3[594] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[595] = "Where can you find Venoxis?";
WOW_TRIVIA_ANSWERS1[595] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[595] = "ZG";
WOW_TRIVIA_ANSWERS3[595] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[596] = "Where can you find High Priestess Arlokk?";
WOW_TRIVIA_ANSWERS1[596] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[596] = "ZG";
WOW_TRIVIA_ANSWERS3[596] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[597] = "Where can you find Jeklik?";
WOW_TRIVIA_ANSWERS1[597] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[597] = "ZG";
WOW_TRIVIA_ANSWERS3[597] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[598] = "Where can you find Mar'li?";
WOW_TRIVIA_ANSWERS1[598] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[598] = "ZG";
WOW_TRIVIA_ANSWERS3[598] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[599] = "Where can you find Jin'do the Hexxer?";
WOW_TRIVIA_ANSWERS1[599] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[599] = "ZG";
WOW_TRIVIA_ANSWERS3[599] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[600] = "Where can you find Hakkar the Soulflayer?";
WOW_TRIVIA_ANSWERS1[600] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[600] = "ZG";
WOW_TRIVIA_ANSWERS3[600] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[601] = "Where can you find Gri'lek?"
WOW_TRIVIA_ANSWERS1[601] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[601] = "ZG";
WOW_TRIVIA_ANSWERS3[601] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[602] = "Where can you find Hazza'rah?"
WOW_TRIVIA_ANSWERS1[602] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[602] = "ZG";
WOW_TRIVIA_ANSWERS3[602] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[603] = "Where can you find Wushoolay?"
WOW_TRIVIA_ANSWERS1[603] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[603] = "ZG";
WOW_TRIVIA_ANSWERS3[603] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[604] = "At what level can you learn your first tallent point?";
WOW_TRIVIA_ANSWERS1[604] = "10";
WOW_TRIVIA_ANSWERS2[604] = "Ten";

WOW_TRIVIA_QUESTIONS[605] = "Where can you find Razorgore the Untamed?";
WOW_TRIVIA_ANSWERS1[605] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS2[605] = "BWL";

WOW_TRIVIA_QUESTIONS[606] = "Where can you find Vaelastrasz the Corrupt?";
WOW_TRIVIA_ANSWERS1[606] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS2[606] = "BWL";

WOW_TRIVIA_QUESTIONS[607] = "Where can you find Firemaw?";
WOW_TRIVIA_ANSWERS1[607] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS2[607] = "BWL";

WOW_TRIVIA_QUESTIONS[608] = "Where can you find Ebonroc?";
WOW_TRIVIA_ANSWERS1[608] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS2[608] = "BWL";

WOW_TRIVIA_QUESTIONS[609] = "Where can you find Flamegor?";
WOW_TRIVIA_ANSWERS1[609] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS2[609] = "BWL";

WOW_TRIVIA_QUESTIONS[610] = "Where can you find Nefarian?";
WOW_TRIVIA_ANSWERS1[610] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS2[610] = "BWL";

WOW_TRIVIA_QUESTIONS[611] = "Where can you find Master Elemental Shaper Krixix?";
WOW_TRIVIA_ANSWERS1[611] = "Blackwing Lair";
WOW_TRIVIA_ANSWERS2[611] = "BWL";

WOW_TRIVIA_QUESTIONS[612] = "In what zone lies The Ruins of Ahn'Qiraj?";
WOW_TRIVIA_ANSWERS1[612] = "Silithus";

WOW_TRIVIA_QUESTIONS[613] = "In what zone lies The Temple of Ahn'Qiraj?";
WOW_TRIVIA_ANSWERS1[613] = "Silithus";

WOW_TRIVIA_QUESTIONS[614] = "In what zone lies Blackwing Lair?";
WOW_TRIVIA_ANSWERS1[614] = "Searing Gorge";
WOW_TRIVIA_ANSWERS2[614] = "Burning steppes";

WOW_TRIVIA_QUESTIONS[615] = "Where can you find The Prophet Skeram?";
WOW_TRIVIA_ANSWERS1[615] = "The temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[615] = "AQ40";
WOW_TRIVIA_ANSWERS3[615] = "AQ 40";

WOW_TRIVIA_QUESTIONS[616] = "Where can you find the 'Bug Family' (Kri, Yauj, Vem)?";
WOW_TRIVIA_ANSWERS1[616]= "The temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[616] = "AQ40";
WOW_TRIVIA_ANSWERS3[616] = "AQ 40";

WOW_TRIVIA_QUESTIONS[617] = "Where can you find Battleguard Sartura?";
WOW_TRIVIA_ANSWERS1[617]= "The temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[617] = "AQ40";
WOW_TRIVIA_ANSWERS3[617] = "AQ 40";

WOW_TRIVIA_QUESTIONS[618] = "Where can you find Fankriss the Unyielding?";
WOW_TRIVIA_ANSWERS1[618]= "The temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[618] = "AQ40";
WOW_TRIVIA_ANSWERS3[618] = "AQ 40";

WOW_TRIVIA_QUESTIONS[619] = "Where can you find Viscidus?";
WOW_TRIVIA_ANSWERS1[619]= "The temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[619] = "AQ40";
WOW_TRIVIA_ANSWERS3[619] = "AQ 40";

WOW_TRIVIA_QUESTIONS[620] = "Where can you find Princess Huhuran?";
WOW_TRIVIA_ANSWERS1[620]= "The temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[620] = "AQ40";
WOW_TRIVIA_ANSWERS3[620] = "AQ 40";

WOW_TRIVIA_QUESTIONS[621] = "Where can you find the Twin Emperors?";
WOW_TRIVIA_ANSWERS1[621]= "The temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[621] = "AQ40";
WOW_TRIVIA_ANSWERS3[621] = "AQ 40";

WOW_TRIVIA_QUESTIONS[622] = "Who is the brother of Vek'nilash?";
WOW_TRIVIA_ANSWERS1[622] = "Vek'lor";

WOW_TRIVIA_QUESTIONS[623] = "Who is the brother of Vek'lor?";
WOW_TRIVIA_ANSWERS1[623] = "Vek'nilash";

WOW_TRIVIA_QUESTIONS[624] = "Where can you find Ouro?";
WOW_TRIVIA_ANSWERS1[624]= "The temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[624] = "AQ40";
WOW_TRIVIA_ANSWERS3[624] = "AQ 40";

WOW_TRIVIA_QUESTIONS[625] = "Where can you find C'thun?";
WOW_TRIVIA_ANSWERS1[625]= "The temple of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[625] = "AQ40";
WOW_TRIVIA_ANSWERS3[625] = "AQ 40";

WOW_TRIVIA_QUESTIONS[626] = "The war between the Qiraji and the rest of kalimdor was called 'The war of the ______ ______'.";
WOW_TRIVIA_ANSWERS1[626] = "Shifting sands";

WOW_TRIVIA_QUESTIONS[627] = "Where can you find Ayamiss the Hunter?";
WOW_TRIVIA_ANSWERS1[627] = "Ruins of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[627] = "AQ20";
WOW_TRIVIA_ANSWERS3[627] = "AQ 20";

WOW_TRIVIA_QUESTIONS[628] = "Where can you find Buru the Gorger?";
WOW_TRIVIA_ANSWERS1[628] = "Ruins of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[628] = "AQ20";
WOW_TRIVIA_ANSWERS3[628] = "AQ 20";

WOW_TRIVIA_QUESTIONS[629] = "Where can you find General Rajaxx?";
WOW_TRIVIA_ANSWERS1[629] = "Ruins of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[629] = "AQ20";
WOW_TRIVIA_ANSWERS3[629] = "AQ 20";

WOW_TRIVIA_QUESTIONS[630] = "Where can you find Kurinaxx?";
WOW_TRIVIA_ANSWERS1[630] = "Ruins of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[630] = "AQ20";
WOW_TRIVIA_ANSWERS3[630] = "AQ 20";

WOW_TRIVIA_QUESTIONS[631] = "Where can you find Moam?";
WOW_TRIVIA_ANSWERS1[631] = "Ruins of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[631] = "AQ20";
WOW_TRIVIA_ANSWERS3[631] = "AQ 20";

WOW_TRIVIA_QUESTIONS[632] = "Where can you find Ossirian the Unscarred?";
WOW_TRIVIA_ANSWERS1[632] = "Ruins of Ahn'Qiraj";
WOW_TRIVIA_ANSWERS2[632] = "AQ20";
WOW_TRIVIA_ANSWERS3[632] = "AQ 20";

WOW_TRIVIA_QUESTIONS[633] = "In what content patch was Ahn'Qiraj released?";
WOW_TRIVIA_ANSWERS1[633] = "1.9";

WOW_TRIVIA_QUESTIONS[634] = "Northrend will certainly feature 'The Venture Co'. (True/False)?";
WOW_TRIVIA_ANSWERS1[634] = "true";

WOW_TRIVIA_QUESTIONS[635] = "In what content patch was Naxxramas released?";
WOW_TRIVIA_ANSWERS1[635] = "1.11";

WOW_TRIVIA_QUESTIONS[636] = "Where can you find Anub'Rekhan?";
WOW_TRIVIA_ANSWERS1[636] = "Naxx";
WOW_TRIVIA_ANSWERS2[636] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[637] = "Where can you find Grand Widow Faerlina?";
WOW_TRIVIA_ANSWERS1[637] = "Naxx";
WOW_TRIVIA_ANSWERS2[637] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[638] = "Where can you find Mr.Bigglesworth?";
WOW_TRIVIA_ANSWERS1[638] = "Naxx";
WOW_TRIVIA_ANSWERS2[638] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[639] = "Where can you find Maexxna?";
WOW_TRIVIA_ANSWERS1[639] = "Naxx";
WOW_TRIVIA_ANSWERS2[639] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[640] = "Where can you find Noth?";
WOW_TRIVIA_ANSWERS1[640] = "Naxx";
WOW_TRIVIA_ANSWERS2[640] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[641] = "Where can you find Heigan?";
WOW_TRIVIA_ANSWERS1[641] = "Naxx";
WOW_TRIVIA_ANSWERS2[641] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[642] = "Where can you find Loatheb?";
WOW_TRIVIA_ANSWERS1[642] = "Naxx";
WOW_TRIVIA_ANSWERS2[642] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[643] = "Where can you find Razuvious?";
WOW_TRIVIA_ANSWERS1[643] = "Naxx";
WOW_TRIVIA_ANSWERS2[643] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[644] = "Where can you find Gothik?";
WOW_TRIVIA_ANSWERS1[644] = "Naxx";
WOW_TRIVIA_ANSWERS2[644] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[645] = "Where can you find The Four Horsemen?";
WOW_TRIVIA_ANSWERS1[645] = "Naxx";
WOW_TRIVIA_ANSWERS2[645] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[646] = "Where can you find Patchwerk?";
WOW_TRIVIA_ANSWERS1[646] = "Naxx";
WOW_TRIVIA_ANSWERS2[646] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[647] = "Where can you find Grobbulus?";
WOW_TRIVIA_ANSWERS1[647] = "Naxx";
WOW_TRIVIA_ANSWERS2[647] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[648] = "Where can you find Gluth?";
WOW_TRIVIA_ANSWERS1[648] = "Naxx";
WOW_TRIVIA_ANSWERS2[648] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[649] = "Where can you find Thaddius?";
WOW_TRIVIA_ANSWERS1[649] = "Naxx";
WOW_TRIVIA_ANSWERS2[649] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[650] = "Where can you find Sapphiron?";
WOW_TRIVIA_ANSWERS1[650] = "Naxx";
WOW_TRIVIA_ANSWERS2[650] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[651] = "Where can you find Kel'Thuzad?";
WOW_TRIVIA_ANSWERS1[651] = "Naxx";
WOW_TRIVIA_ANSWERS2[651] = "Naxxramas";

WOW_TRIVIA_QUESTIONS[652] = "Who is Highlord Mograine's son?";
WOW_TRIVIA_ANSWERS1[652] = "Renault";
WOW_TRIVIA_ANSWERS2[652] = "Renault Mograine";

WOW_TRIVIA_QUESTIONS[653] = "There is a NPC in Stranglethorn Vale which starts several quests for both Horde and Alliance. His encampement is also infamous for ganking. His name is ______ Nesingwary";
WOW_TRIVIA_ANSWERS1[653] = "Hemet";

WOW_TRIVIA_QUESTIONS[654] = "A pirates name from Booty Bay starting quest Cracking Maury's Foot, also known as Sea Wolf is ______";
WOW_TRIVIA_ANSWERS1[654] = "MacKinley";

WOW_TRIVIA_QUESTIONS[655] = "A popular shirt Sleeveles T-Shirt drops in ________. (name the zone)?";
WOW_TRIVIA_ANSWERS1[655] = "AV";
WOW_TRIVIA_ANSWERS2[655] = "Alterac Valley";

WOW_TRIVIA_QUESTIONS[656] = "How many cities in Azeroth are a part of Steamwheedle Cartel?";
WOW_TRIVIA_ANSWERS1[656] = "4";
WOW_TRIVIA_ANSWERS2[656] = "four";

WOW_TRIVIA_QUESTIONS[657] = "The night elves were once called the ________.";
WOW_TRIVIA_ANSWERS1[657] = "Kaldorei";

WOW_TRIVIA_QUESTIONS[658] = "Some of the kaldorei's were transformed into naga's during the accident with the ____________________";
WOW_TRIVIA_ANSWERS1[658] = "well of eternity";

WOW_TRIVIA_QUESTIONS[659] = "The Well of Eternity left a permanent storm known as 'The __________'.";
WOW_TRIVIA_ANSWERS1[659] = "Maelstrom";

WOW_TRIVIA_QUESTIONS[660] = "The makrura is rumored to have a city named _______.";
WOW_TRIVIA_ANSWERS1[660] = "Mak'aru";

WOW_TRIVIA_QUESTIONS[661] = "The  _______ speaks in nerglish and are a race of humanoid lobsters who are constantly in war with the naga.";
WOW_TRIVIA_ANSWERS1[661] = "Makrura";

WOW_TRIVIA_QUESTIONS[662] = "It is rumored that ______ are the offsprings of gronns.";
WOW_TRIVIA_ANSWERS1[662] = "Ogre";
WOW_TRIVIA_ANSWERS2[662] = "Ogres";

WOW_TRIVIA_QUESTIONS[663] = "What is the name of the radio who produces shows such as 'EPIC', 'Blue plz', 'vendor trash', and others?";
WOW_TRIVIA_ANSWERS1[663] = "wcradio";
WOW_TRIVIA_ANSWERS2[663] = "wowradio";

WOW_TRIVIA_QUESTIONS[664] = "______ did the world first on Azgalor the pitlord.";
WOW_TRIVIA_ANSWERS1[664] = "Curse";

WOW_TRIVIA_QUESTIONS[665] = "What is the name of the guild which did the world first on Nefarian? (hint: Something that happens quite often in guilds is the guildname of this guild)";
WOW_TRIVIA_ANSWERS1[665] = "Drama";

WOW_TRIVIA_QUESTIONS[666] = "Death & Taxes did the world first on _______ in Karazhan.";
WOW_TRIVIA_ANSWERS1[666] = "Nightbane";

WOW_TRIVIA_QUESTIONS[667] = "Ascent did the world first on __________.";
WOW_TRIVIA_ANSWERS1[667] = "Ragnaros";

WOW_TRIVIA_QUESTIONS[668] = "What guild did the world first on Kel'Thuzad?";
WOW_TRIVIA_ANSWERS1[668] = "Nihilum";

WOW_TRIVIA_QUESTIONS[669] = "What guild did the world first on The Four Horsemen?";
WOW_TRIVIA_ANSWERS1[669] = "Deathandtaxes";
WOW_TRIVIA_ANSWERS2[669] = "Death & Taxes";
WOW_TRIVIA_ANSWERS3[669] = "Death&Taxes";

WOW_TRIVIA_QUESTIONS[670] = "If you go where you are not supposed to (like, Mount Hyjal, which is not finished) you get a debuff called _______________ which teleports you away.";
WOW_TRIVIA_ANSWERS1[670] = "no mans land";
WOW_TRIVIA_ANSWERS2[670] = "no man's land";

WOW_TRIVIA_QUESTIONS[671] = "There is ______ holiday events in world of warcraft.";
WOW_TRIVIA_ANSWERS1[671] = "ten";
WOW_TRIVIA_ANSWERS2[671] = "10";

WOW_TRIVIA_QUESTIONS[672] = "What is the name of the player which got to 1-60 in 4 days and 20 hours before TBC came, and made a guide about it?";
WOW_TRIVIA_ANSWERS1[672] = "Joana";

WOW_TRIVIA_QUESTIONS[673] = "What is the name of the player who is famous for his leveling guides? (from 20-60 on both factions)";
WOW_TRIVIA_ANSWERS1[673] = "Jame";

WOW_TRIVIA_QUESTIONS[674] = "How many characters can you have per realm?";
WOW_TRIVIA_ANSWERS1[674] = "ten";
WOW_TRIVIA_ANSWERS2[674] = "10";

WOW_TRIVIA_QUESTIONS[675] = "Ciq";
WOW_TRIVIA_ANSWERS1[675] = "Ciq";

WOW_TRIVIA_QUESTIONS[676] = "The dwarves capital city is called?";
WOW_TRIVIA_ANSWERS1[676] = "Ironforge";
WOW_TRIVIA_ANSWERS2[676] = "IF";

WOW_TRIVIA_QUESTIONS[677] = "How many troll empires has been known to exists?";
WOW_TRIVIA_ANSWERS1[677] = "three";
WOW_TRIVIA_ANSWERS2[677] = "3";

WOW_TRIVIA_QUESTIONS[678] = "How many troll tribes is known to exists?";
WOW_TRIVIA_ANSWERS1[678] = "18";
WOW_TRIVIA_ANSWERS2[678] = "eighteen";

WOW_TRIVIA_QUESTIONS[679] = "Name the dungeon where you can complete Molten Core prequest.";
WOW_TRIVIA_ANSWERS1[679] = "BRD";
WOW_TRIVIA_ANSWERS2[679] = "Blackrock Depths";

WOW_TRIVIA_QUESTIONS[680] = "When does the Harvest Festival start, in September?";
WOW_TRIVIA_ANSWERS1[680] = "September 24th";
WOW_TRIVIA_ANSWERS2[680] = "24th september";
WOW_TRIVIA_ANSWERS3[680] = "24th";
WOW_TRIVIA_ANSWERS4[680] = "24";

WOW_TRIVIA_QUESTIONS[681] = "When does the Feast of Winter Veil start, in December?";
WOW_TRIVIA_ANSWERS1[681] = "December 22th";
WOW_TRIVIA_ANSWERS2[681] = "22th December";
WOW_TRIVIA_ANSWERS3[681] = "22th";
WOW_TRIVIA_ANSWERS4[681] = "22";

WOW_TRIVIA_QUESTIONS[682] = "When does the Lunar Festival start, in February?";
WOW_TRIVIA_ANSWERS1[682] = "February 16th";
WOW_TRIVIA_ANSWERS2[682] = "16th February";
WOW_TRIVIA_ANSWERS3[682] = "16th";
WOW_TRIVIA_ANSWERS4[682] = "16";

WOW_TRIVIA_QUESTIONS[683] = "When does 'Love is in the Air' start, in February?";
WOW_TRIVIA_ANSWERS1[683] = "February 11th";
WOW_TRIVIA_ANSWERS2[683] = "11th February";
WOW_TRIVIA_ANSWERS3[683] = "11th";
WOW_TRIVIA_ANSWERS4[683] = "11";

WOW_TRIVIA_QUESTIONS[684] = "When does Noblegarden start, in April?";
WOW_TRIVIA_ANSWERS1[684] = "April 15th";
WOW_TRIVIA_ANSWERS2[684] = "15th April";
WOW_TRIVIA_ANSWERS3[684] = "15th";
WOW_TRIVIA_ANSWERS4[684] = "15";

WOW_TRIVIA_QUESTIONS[685] = "When does the Children's Week start, in May?";
WOW_TRIVIA_ANSWERS1[685] = "May 22th";
WOW_TRIVIA_ANSWERS2[685] = "22th May";
WOW_TRIVIA_ANSWERS3[685] = "22th";
WOW_TRIVIA_ANSWERS4[685] = "22";

WOW_TRIVIA_QUESTIONS[685] = "When does the Midsummer Fire Festival start, in June?";
WOW_TRIVIA_ANSWERS1[685] = "June 21th";
WOW_TRIVIA_ANSWERS2[685] = "21th June";
WOW_TRIVIA_ANSWERS3[685] = "21th";
WOW_TRIVIA_ANSWERS4[685] = "21";

WOW_TRIVIA_QUESTIONS[686] = "Guess the Zone: This zone has lava elementals, spiders, and incendosaurs as its inhabitants. One of the quests in this zone is called 'What the Flux?'.";
WOW_TRIVIA_ANSWERS1[686] = "Searing Gorge";

WOW_TRIVIA_QUESTIONS[687] = "Guess the Zone: 'Here, young orcs, tauren, and trolls study Shamanism, Hunting, and the Ways of the Warrior'.";
WOW_TRIVIA_ANSWERS1[687] = "Durotar";

WOW_TRIVIA_QUESTIONS[688] = "When does Hallow's End start, in october?";
WOW_TRIVIA_ANSWERS1[688] = "18";
WOW_TRIVIA_ANSWERS2[688] = "eighteenth";
WOW_TRIVIA_ANSWERS3[688] = "18th";

WOW_TRIVIA_QUESTIONS[689] = "Where can you find Renataki?"
WOW_TRIVIA_ANSWERS1[689] = "Zul'Gurub";
WOW_TRIVIA_ANSWERS2[689] = "ZG";
WOW_TRIVIA_ANSWERS3[689] = "Zul Gurub";

WOW_TRIVIA_QUESTIONS[690] = "What is Cenarius?";
WOW_TRIVIA_ANSWERS1[690] = "A demigod";
WOW_TRIVIA_ANSWERS2[690] = "Demigod";
WOW_TRIVIA_ANSWERS3[690] = "A demi-god";

WOW_TRIVIA_QUESTIONS[691] = "What is the naga's also known as? (like, Archimonde the Defiler)";
WOW_TRIVIA_ANSWERS1[691] = "The terror of the tides";
WOW_TRIVIA_ANSWERS2[691] = "Terror of the tides";
WOW_TRIVIA_ANSWERS3[691] = "The naga, Terror of the Tides";

WOW_TRIVIA_QUESTIONS[692] = "A race of humanoid spiders, is also known as the __________.";
WOW_TRIVIA_ANSWERS1[692] = "Nerubians";

-- Naxxrammas

WOW_TRIVIA_QUESTIONS[693] = "Naxxrammas was once an ancient ________ ziggurat, before it was pulled free from the ground by agents of the Lich King. It served as Kel'Thuzad's base of operations as he spread the plague. It's the home of Kel'Thuzad.";
WOW_TRIVIA_ANSWERS1[693] = "nerubian";

WOW_TRIVIA_QUESTIONS[694] = "What is the name of the legendary caster staff, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[694] = "Atiesh, Greatstaff of the Guardian";
WOW_TRIVIA_ANSWERS2[694] = "Atiesh";

WOW_TRIVIA_QUESTIONS[695] = "Kel'Thuzad was formerly a sorcerer of ________.";
WOW_TRIVIA_ANSWERS1[695] = "Dalaran";

WOW_TRIVIA_QUESTIONS[696] = "No one have yet entered __________ and lived to tell the tale. (hint: The Dread Citadel)";
WOW_TRIVIA_ANSWERS1[696] = "Naxxrammas";
WOW_TRIVIA_ANSWERS2[696] = "Naxx";

WOW_TRIVIA_QUESTIONS[697] = "To enter Naxxramas you need to go into an open _________ in the middle of Plaguewood, which lies in the Eastern Plaguelands. From there you teleport yourself to Naxxramas, by standing on the main floor.";
WOW_TRIVIA_ANSWERS1[697] = "ziggurat";

WOW_TRIVIA_QUESTIONS[698] = "Naxxramas will be retuned for level 80. (True/False)?";
WOW_TRIVIA_ANSWERS1[698] = "true";

WOW_TRIVIA_QUESTIONS[699] = "Naxxramas has how many wings?";
WOW_TRIVIA_ANSWERS1[699] = "4";
WOW_TRIVIA_ANSWERS2[699] = "four";
WOW_TRIVIA_ANSWERS3[699] = "four wings";
WOW_TRIVIA_ANSWERS4[699] = "4 wings";

WOW_TRIVIA_QUESTIONS[700] = "Who is the last boss of the Spider Wing in Naxxramas?";
WOW_TRIVIA_ANSWERS1[700] = "Maexxna";

WOW_TRIVIA_QUESTIONS[701] = "Who is the last boss of the Plague Wing in Naxxramas?";
WOW_TRIVIA_ANSWERS1[701] = "Loatheb";

WOW_TRIVIA_QUESTIONS[702] = "What is the last bosses of the Deathknight wing called, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[702] = "The Four Horsemen";

WOW_TRIVIA_QUESTIONS[703] = "Who is the last boss of the Abomination Wing in Naxxramas?";
WOW_TRIVIA_ANSWERS1[703] = "Thaddius";

WOW_TRIVIA_QUESTIONS[704] = "There is a night elf highborne inside Naxxramas, called _________ Tarsis Kir-Moldir.";
WOW_TRIVIA_ANSWERS1[704] = "Archmage";

WOW_TRIVIA_QUESTIONS[705] = "What is the cat inside Naxxramas called? if you kill it, Kel'Thuzad will curse you and you're raid.";
WOW_TRIVIA_ANSWERS1[705] = "Bigglesworth";
WOW_TRIVIA_ANSWERS2[705] = "Mr. Bigglesworth";

WOW_TRIVIA_QUESTIONS[706] = "Players will need resistance in every element in order to complete Naxxramas. (True/False)?";
WOW_TRIVIA_ANSWERS1[706] = "false"; -- You dont _need_ nature resistance, or fire resistance (not sure about fire though) and perhaps arcane

WOW_TRIVIA_QUESTIONS[707] = "You need to clear every wing before you can enter ________ Lair, in Naxxramas.";
WOW_TRIVIA_ANSWERS1[707] = "Frostwyrm";

WOW_TRIVIA_QUESTIONS[708] = "What dungeon tier drops in Naxxramas?";
WOW_TRIVIA_ANSWERS1[708] = "Tier 3";

WOW_TRIVIA_QUESTIONS[709] = "What can you find on the walls of each boss chamber and varius other places, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[709] = "Frozen Runes";
WOW_TRIVIA_ANSWERS2[709] = "Frozen Rune's";

WOW_TRIVIA_QUESTIONS[710] = "Defrosting a frozen rune in Naxxramas with 'Word of _______' yields around 3 to 6 tradeable frozen runes. They can be used as a Greater Frost Protection Potion, or to craft epic frost resistance gear.";
WOW_TRIVIA_ANSWERS1[710] = "Thawing";

WOW_TRIVIA_QUESTIONS[711] = "You dont generally use the frozen rune's from Naxxramas, as it is considered too expensive. Instead, most guilds use them to create the epic _____ resistance gear for classes, which is needed for Sapphiron in Naxxramas.";
WOW_TRIVIA_ANSWERS1[711] = "frost";

WOW_TRIVIA_QUESTIONS[712] = "The epic frost resistance collection for Rogues is called _______. Guilds usually create them for Naxxramas.";
WOW_TRIVIA_ANSWERS1[712] = "polar";

WOW_TRIVIA_QUESTIONS[713] = "The epic frost resistance collection for Hunters is called ____________. Guilds usually create them for Naxxramas.";
WOW_TRIVIA_ANSWERS1[713] = "Icy Scale";

WOW_TRIVIA_QUESTIONS[714] = "The epic frost resistance collection for Mages, Priests, Warlocks is called __________. Guilds usually create them for Naxxramas.";
WOW_TRIVIA_ANSWERS1[714] = "Glacial";

WOW_TRIVIA_QUESTIONS[715] = "What boss is considered to be the easiest, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[715] = "Instructor Razuvious";
WOW_TRIVIA_ANSWERS2[715] = "Razuvious";

WOW_TRIVIA_QUESTIONS[716] = "What boss in Naxxramas is considered a very hard 'gear check'?";
WOW_TRIVIA_ANSWERS1[716] = "Patchwerk";

WOW_TRIVIA_QUESTIONS[717] = "What boss is considered to be the second hardest in Naxxramas?";
WOW_TRIVIA_ANSWERS1[717] = "The Four Horsemen";

WOW_TRIVIA_QUESTIONS[718] = "What boss is considered to be the hardest of all in Naxxramas?";
WOW_TRIVIA_ANSWERS1[718] = "Kel'Thuzad";

WOW_TRIVIA_QUESTIONS[719] = "In what instance except Naxxramas, can Kel'Thuzad be found?";
WOW_TRIVIA_ANSWERS1[719] = "Escape from Durnholde Keep";
WOW_TRIVIA_ANSWERS2[719] = "Durnholde";
WOW_TRIVIA_ANSWERS3[719] = "Escape from Durnholde";
WOW_TRIVIA_ANSWERS4[719] = "Old hillsbrad";
WOW_TRIVIA_ANSWERS5[719] = "Old hillsbrad foothills";

WOW_TRIVIA_QUESTIONS[720] = "In order to fight Sapphiron, you need to ring a bell inside Naxxramas. (True/False)?";
WOW_TRIVIA_ANSWERS1[720] = "false";

WOW_TRIVIA_QUESTIONS[721] = "What resistance do you need 150-200 of, in order to kill Sapphiron in Naxxramas? (atleast it was so, pre-bc)";
WOW_TRIVIA_ANSWERS1[721] = "frost";

WOW_TRIVIA_QUESTIONS[722] = "Ronin was married to what race?";
WOW_TRIVIA_ANSWERS1[722] = "Night Elf"; 
WOW_TRIVIA_ANSWERS2[722] = "NE"; 

WOW_TRIVIA_QUESTIONS[723] = "What is the name of the boss which is considered 'free loot' by many people?";
WOW_TRIVIA_ANSWERS1[723] = "Grobbulus";

WOW_TRIVIA_QUESTIONS[724] = "_____________ in Naxxramas you need to kite, in order to defeat him. He is known to get bugged sometimes.";
WOW_TRIVIA_ANSWERS1[724] = "Anub'Rekhan";

WOW_TRIVIA_QUESTIONS[725] = "What is the mobs that spawns during the Anub'Rekhan fight called? (hint: the huge spiders, which you need to offtank and kill before you can countinue to DPS Anub'Rekhan)";
WOW_TRIVIA_ANSWERS1[725] = "Crypt Guards";
WOW_TRIVIA_ANSWERS2[725] = "Crypt Guard";

WOW_TRIVIA_QUESTIONS[726] = "What raiding instance is considered to be the 'best' ever created by Blizzard, atleast of the 40man instances?";
WOW_TRIVIA_ANSWERS1[726] = "Naxxramas";
WOW_TRIVIA_ANSWERS2[726] = "Naxx";

WOW_TRIVIA_QUESTIONS[727] = "What boss in Naxxramas casts Locust Swarm, the deadly 1200 dmg / 2sec dot which the tank must avoid at any cost?";
WOW_TRIVIA_ANSWERS1[727] = "Anub'Rekhan";

WOW_TRIVIA_QUESTIONS[728] = "What boss in Naxxramas can create Corpse Scarabs from the remains of dead Crypt Guards and dead players? (hint: These scarabs can never be allowed to hit the MT, due to the 'daze' effect which is devestating)";
WOW_TRIVIA_ANSWERS1[728] = "Anub'Rekhan";

WOW_TRIVIA_QUESTIONS[729] = "Quote: I hear little hearts beating. Yesss... beating faster now. Soon the beating will stop.";
WOW_TRIVIA_ANSWERS1[729] = "Anub'Rekhan";

WOW_TRIVIA_QUESTIONS[730] = "What boss casts Poison Bolt Volley in Naxxramas?";
WOW_TRIVIA_ANSWERS1[730] = "Grand Widow Faerlina";
WOW_TRIVIA_ANSWERS2[730] = "Faerlina";

WOW_TRIVIA_QUESTIONS[731] = "What boss has worshippers as adds in Naxxramas?";
WOW_TRIVIA_ANSWERS1[731] = "Grand Widow Faerlina";
WOW_TRIVIA_ANSWERS2[731] = "Faerlina";

WOW_TRIVIA_QUESTIONS[732] = "Quote: Your old lives, your mortal desires, mean nothing. You are acolytes of the master now, and you will serve the cause without question! The greatest glory is to die in the master's service!";
WOW_TRIVIA_ANSWERS1[732] = "Grand Widow Faerlina";
WOW_TRIVIA_ANSWERS2[732] = "Faerlina";

WOW_TRIVIA_QUESTIONS[733] = "What boss will 'cocoon' players, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[733] = "Maexxna";

WOW_TRIVIA_QUESTIONS[734] = "What boss casts Web Sprays, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[734] = "Maexxna";

WOW_TRIVIA_QUESTIONS[735] = "What boss in Naxxramas drops the Wraith blade, a caster sword?";
WOW_TRIVIA_ANSWERS1[735] = "Maexxna";

WOW_TRIVIA_QUESTIONS[736] = "What boss drops the epic T3 hands, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[736] = "Maexxna";

WOW_TRIVIA_QUESTIONS[737] = "Noth the Plaguebringer were once a notable wizard and ________ of Dalaran. (hint: proffesion in wow)";
WOW_TRIVIA_ANSWERS1[737] = "alchemist";

WOW_TRIVIA_QUESTIONS[738] = "Kel'Thuzad froze ______________________'s heart in Naxxramas with cold magic, so that he would not have any feelings. This was needed, because of his guilt. He is now more undead then human.";
WOW_TRIVIA_ANSWERS1[738] = "Noth the Plaguebringer";
WOW_TRIVIA_ANSWERS2[738] = "Noth";

WOW_TRIVIA_QUESTIONS[739] = "What boss in Naxxramas casts Curse of the Plaguebringer, which must be decursed at all costs, otherwise the raid will most probably wipe?";
WOW_TRIVIA_ANSWERS1[739] = "Noth the Plaguebringer";
WOW_TRIVIA_ANSWERS2[739] = "Noth";

WOW_TRIVIA_QUESTIONS[740] = "Quote: Rise my soldiers! Rise, and fight once more!";
WOW_TRIVIA_ANSWERS1[740] = "Noth the Plaguebringer";
WOW_TRIVIA_ANSWERS2[740] = "Noth";

WOW_TRIVIA_QUESTIONS[741] = "Quote: Glory to the master!";
WOW_TRIVIA_ANSWERS1[741] = "Noth the Plaguebringer";
WOW_TRIVIA_ANSWERS2[741] = "Noth";

WOW_TRIVIA_QUESTIONS[742] = "What boss requires you to essentially 'dance' to avoid dying in Naxxramas?";
WOW_TRIVIA_ANSWERS1[742] = "Heigan the Unclean";
WOW_TRIVIA_ANSWERS2[742] = "Heigan";

WOW_TRIVIA_QUESTIONS[743] = "What boss in Naxxramas teleports three people to a tunnel occasionally?";
WOW_TRIVIA_ANSWERS1[743] = "Heigan the Unclean";
WOW_TRIVIA_ANSWERS2[743] = "Heigan";

WOW_TRIVIA_QUESTIONS[744] = "Quote: Close your eyes.. sleep";
WOW_TRIVIA_ANSWERS1[744] = "Heigan the Unclean";
WOW_TRIVIA_ANSWERS2[744] = "Heigan"

WOW_TRIVIA_QUESTIONS[745] = "Quote: The end is upon you.";
WOW_TRIVIA_ANSWERS1[745] = "Heigan the Unclean";
WOW_TRIVIA_ANSWERS2[745] = "Heigan";

WOW_TRIVIA_QUESTIONS[746] = "What boss in Naxxramas requires very good individual coordination from everyone?";
WOW_TRIVIA_ANSWERS1[746] = "Heigan the Unclean";
WOW_TRIVIA_ANSWERS2[746] = "Heigan";

WOW_TRIVIA_QUESTIONS[747] = "What boss in Naxxramas requires 3x Greater Shadow Protection Potions?";
WOW_TRIVIA_ANSWERS1[747] = "Loatheb";

WOW_TRIVIA_QUESTIONS[748] = "What boss casts Corrupted Mind, which makes you able to only cast one healing spell per minute, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[748] = "Loatheb";

WOW_TRIVIA_QUESTIONS[749] = "What boss spawns spores, which upon killing grants five players the fungal bloom debuff? (increases you're crit and hit, and causes you to make no threat)";
WOW_TRIVIA_ANSWERS1[749] = "Loatheb";

WOW_TRIVIA_QUESTIONS[750] = "What boss in Naxxramas casts Unbalancing Strike, which need to be taken by one of his adds?";
WOW_TRIVIA_ANSWERS1[750] = "Instructor Razuvious";
WOW_TRIVIA_ANSWERS2[750] = "Razuvious";

WOW_TRIVIA_QUESTIONS[751] = "What boss in Naxxramas casts Disrupting Shout, which reduces the mana of everyone it hits by up to 4000 and deals twice the mana burned this way in damage?";
WOW_TRIVIA_ANSWERS1[751] = "Instructor Razuvious";
WOW_TRIVIA_ANSWERS2[751] = "Razuvious";

WOW_TRIVIA_QUESTIONS[752] = "Quote: The time for practice is over! Show me what you've learned!";
WOW_TRIVIA_ANSWERS1[752] = "Instructor Razuvious";
WOW_TRIVIA_ANSWERS2[752] = "Razuvious";

WOW_TRIVIA_QUESTIONS[753] = "Quote: Show me what you've got!";
WOW_TRIVIA_ANSWERS1[753] = "Instructor Razuvious";
WOW_TRIVIA_ANSWERS2[753] = "Razuvious";

WOW_TRIVIA_QUESTIONS[754] = "Quote: An honorable... death..";
WOW_TRIVIA_ANSWERS1[754] = "Instructor Razuvious";
WOW_TRIVIA_ANSWERS2[754] = "Razuvious";

WOW_TRIVIA_QUESTIONS[755] = "The bosses in Naxxramas can sometimes drop ______ of Atiesh. Sapphiron and Kel'Thuzad will never drop one, though.";
WOW_TRIVIA_ANSWERS1[755] = "Splinter";

WOW_TRIVIA_QUESTIONS[756] = "What boss in Naxxramas looks nearly identical to Heigan the Unclean?";
WOW_TRIVIA_ANSWERS1[756] = "Gothik the Harvester";
WOW_TRIVIA_ANSWERS2[756] = "Gothik";

WOW_TRIVIA_QUESTIONS[757] = "What boss in Naxxramas will have you kill Spectral Trainee's, Unrelenting Riders and other undeads, before you can face him?";
WOW_TRIVIA_ANSWERS1[757] = "Gothik the Harvester";
WOW_TRIVIA_ANSWERS2[757] = "Gothik";

WOW_TRIVIA_QUESTIONS[758] = "What boss in Naxxramas will casts Harvest Soul sometimes on the tank, which reduces stats by 10% and is stackable?";
WOW_TRIVIA_ANSWERS1[758] = "Gothik the Harvester";
WOW_TRIVIA_ANSWERS2[758] = "Gothik";

WOW_TRIVIA_QUESTIONS[759] = "Quote: Foolishly you have sought your own demise. Brazenly you have disregarded powers beyond your understanding. You have fought hard to invade the realm of the harvester. Now there is only one way out - to walk the lonely path of the damned.";
WOW_TRIVIA_ANSWERS1[759] = "Gothik the Harvester";
WOW_TRIVIA_ANSWERS2[759] = "Gothik";

WOW_TRIVIA_QUESTIONS[760] = "Quote: I have waited long enough! Now, you face the harvester of souls!";
WOW_TRIVIA_ANSWERS1[760] = "Gothik the Harvester";
WOW_TRIVIA_ANSWERS2[760] = "Gothik";

WOW_TRIVIA_QUESTIONS[761] = "The Four Horsemen are Highlord Mograine, Thane Korth'azz, Lady Blaumeux, and Sir _______. They are in service of the powerful lich, Kel'Thuzad.";
WOW_TRIVIA_ANSWERS1[761] = "Zeliek";

WOW_TRIVIA_QUESTIONS[762] = "Highlord Mograine's special ability in Naxxramas, is the _____________. It deals 2160-2640 frontload damage and a 4800/8 sec damage DoT. It is identical to Ragnaros's Elemental Fire, and can be mitigated by fire resist.";
WOW_TRIVIA_ANSWERS1[762] = "Righteous Fire";

WOW_TRIVIA_QUESTIONS[763] = "Thane Korth'azz's special ability in Naxxrams, is the ________. It deals roughly 14250-15750~ fire damage, which is shared between all people within 8 yards from where the meteor landed.";
WOW_TRIVIA_ANSWERS1[763] = "Meteor";

WOW_TRIVIA_QUESTIONS[764] = "Sir Zeliek's special ability is called ______________. It will chain around everyone within 5 yards of the last hitted target, so it's important too not get to close. It wont loop however, but it deals twice the damage each hit.";
WOW_TRIVIA_ANSWERS1[764] = "Holy Wrath";

WOW_TRIVIA_QUESTIONS[765] = "Lady Blaumeux's special ability in Naxxramas, is the ____________. It will summon an area of damage that deals shadow damage if you step into it. It has a small radius however, only 5~ yards. It lasts for 1 minute and 30 seconds.";
WOW_TRIVIA_ANSWERS1[765] = "Void Zone";

WOW_TRIVIA_QUESTIONS[766] = "Who drops the Ashbringer, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[766] = "Highlord Mograine";

WOW_TRIVIA_QUESTIONS[767] = "You need to tank each of the horsemen seperately, in Naxxramas. (True/False)?";
WOW_TRIVIA_ANSWERS1[767] = "True";

WOW_TRIVIA_QUESTIONS[768] = "Quote: Life is meaningless. It is in death that we are truly tested.";
WOW_TRIVIA_ANSWERS1[768] = "Highlord Mograine";
WOW_TRIVIA_ANSWERS2[768] = "Mograine";

WOW_TRIVIA_QUESTIONS[769] = "Quote: The first kill goes to me! Anyone care to wager?";
WOW_TRIVIA_ANSWERS1[769] = "Lady Blaumeux";
WOW_TRIVIA_ANSWERS2[769] = "Blaumeux";

WOW_TRIVIA_QUESTIONS[770] = "Quote: I'm gonna enjoy killin' these slack-jawed daffodils!";
WOW_TRIVIA_ANSWERS1[770] = "Thane Korth'azz";
WOW_TRIVIA_ANSWERS2[770] = "Thane Korthazz";

WOW_TRIVIA_QUESTIONS[771] = "Quote: Do not continue! Turn back while there's still time!";
WOW_TRIVIA_ANSWERS1[771] = "Sir Zeliek";
WOW_TRIVIA_ANSWERS2[771] = "Zeliek";

WOW_TRIVIA_QUESTIONS[772] = "This boss in Naxxramas is a major difficulty for healers especially. The healing needs to be perfect for this boss, and the same with the DPS. This boss is the first boss of the Abonimation Wing.";
WOW_TRIVIA_ANSWERS1[772] = "Patchwerk";

WOW_TRIVIA_QUESTIONS[773] = "If this boss in Naxxramas enters a berserker rage, then the raid will have around 12 seconds max to kill him, before they are all dead.";
WOW_TRIVIA_ANSWERS1[773] = "Patchwerk";

WOW_TRIVIA_QUESTIONS[774] = "This boss in Naxxramas is known for its difficulty. This boss is probably the hardest of the first ones in each wing. His special ability 'Hateful Strike', can be devestating for the MT. This encounter is hard for every class.";
WOW_TRIVIA_ANSWERS1[774] = "Patchwerk";

WOW_TRIVIA_QUESTIONS[775] = "Patchwerk is an aggro-sensitive encounter. (True/False)?";
WOW_TRIVIA_ANSWERS1[775] = "false";

WOW_TRIVIA_QUESTIONS[776] = "Quote: No more play?";
WOW_TRIVIA_ANSWERS1[776] = "Patchwerk";

WOW_TRIVIA_QUESTIONS[777] = "Quote: _______ want to play.";
WOW_TRIVIA_ANSWERS1[777] = "Patchwerk";

WOW_TRIVIA_QUESTIONS[778] = "Quote: Kel'Thuzad make _______ his avatar of war!";
WOW_TRIVIA_ANSWERS1[778] = "Patchwerk";

WOW_TRIVIA_QUESTIONS[779] = "Quote: What happened to... Patch...";
WOW_TRIVIA_ANSWERS1[779] = "Patchwerk";

WOW_TRIVIA_QUESTIONS[780] = "Grobbulus and _________ drops the tier 3 shoulders.";
WOW_TRIVIA_ANSWERS1[780] = "Patchwerk";

WOW_TRIVIA_QUESTIONS[781] = "____________ in Naxxramas emits poision clouds which is 10 yards wide and deals a heavy ammount of nature damage if you stand in it. The MT for this boss needs to move steadily but slowly, to avoid them.";
WOW_TRIVIA_ANSWERS1[781] = "Grobbulus";

WOW_TRIVIA_QUESTIONS[782] = "What boss in Naxxramas is required to be ranged down, whilsts the meele deals with the slimes from this boss, when they spawn? (the meele players also helps out with the ranged dps, when there are no slimes up)";
WOW_TRIVIA_ANSWERS1[782] = "Grobbulus";

WOW_TRIVIA_QUESTIONS[783] = "What boss in Naxxramas drops The End of Dreams, a mace for druids?";
WOW_TRIVIA_ANSWERS1[783] = "Grobbulus";

WOW_TRIVIA_QUESTIONS[784] = "What boss in Naxxramas has a ability called 'Decimate', which is needed in order to kill him?";
WOW_TRIVIA_ANSWERS1[784] = "Gluth";

WOW_TRIVIA_QUESTIONS[785] = "What boss spawns a zombie every 10 seconds, which you need to kite for 105 seconds, together with the others that will spawn in that time?";
WOW_TRIVIA_ANSWERS1[785] = "Gluth";

WOW_TRIVIA_QUESTIONS[786] = "What boss has Enrage, Mortal Wound, Frenzy, Decimate, Terrifying Roar, and Devour Zombie as abilities, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[786] = "Gluth";

WOW_TRIVIA_QUESTIONS[787] = "This boss will 'polarize' a raid group, making 50% negativily charged and 50% positively charged. They need to be seperated as fast as possible, otherwise they will deal 2k nature damage to all opposite-charged players within 10 yards.";
WOW_TRIVIA_ANSWERS1[787] = "Thaddius";

WOW_TRIVIA_QUESTIONS[788] = "If no one is in meele range of this boss, in Naxxramas, this boss will throw 'Ball Lightning' on players, dealing around 8k nature damage on every throw.";
WOW_TRIVIA_ANSWERS1[788] = "Thaddius";

WOW_TRIVIA_QUESTIONS[789] = "Only by splitting the raid in half can this boss in Naxxramas be killed. Some exceptions can probably be made, but not more then some few.";
WOW_TRIVIA_ANSWERS1[789] = "Thaddius";

WOW_TRIVIA_QUESTIONS[790] = "Quote: You are too late... I... must... OBEY!";
WOW_TRIVIA_ANSWERS1[790] = "Thaddius";

WOW_TRIVIA_QUESTIONS[791] = "Quote: Now YOU feel pain!";
WOW_TRIVIA_ANSWERS1[791] = "Thaddius";

WOW_TRIVIA_QUESTIONS[792] = "Quote: You die now!";
WOW_TRIVIA_ANSWERS1[792] = "Thaddius";

WOW_TRIVIA_QUESTIONS[793] = "What boss in Naxxramas drops the tier 3 headpieces?";
WOW_TRIVIA_ANSWERS1[793] = "Thaddius";

WOW_TRIVIA_QUESTIONS[794] = "What boss in Naxxramas casts Frost Breath? The boss will take a deep breath sometimes and breathe a cloud of frost which will slowly fall to the ground and explode, dealing 75k-125k when it touches it, in a 70 yard radius.";
WOW_TRIVIA_ANSWERS1[794] = "Sapphiron";

WOW_TRIVIA_QUESTIONS[795] = "On which boss in Naxxramas do you need to stay behind iceblocked individuals, to avoid dying?";
WOW_TRIVIA_ANSWERS1[795] = "Sapphiron";

WOW_TRIVIA_QUESTIONS[796] = "Sapphiron in Naxxramas was originally a blue dragon that was protecting Northrend, untill he was killed by _________ and his forces. He was resurrected as a undead shortly after, by Arthas.";
WOW_TRIVIA_ANSWERS1[796] = "Arthas";

WOW_TRIVIA_QUESTIONS[797] = "What boss drops 'The Face of Death', the best tanking shield availible pre-bc, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[797] = "Sapphiron";

WOW_TRIVIA_QUESTIONS[798] = "Kel'Thuzad is immune to frost attacks. (True/False)?";
WOW_TRIVIA_ANSWERS1[798] = "false";

WOW_TRIVIA_QUESTIONS[799] = "The Four Horsemen drops the _______ of T3.";
WOW_TRIVIA_ANSWERS1[799] = "chests";

WOW_TRIVIA_QUESTIONS[800] = "Where can you find Carrion Spinners?";
WOW_TRIVIA_ANSWERS1[800] = "Naxxramas";
WOW_TRIVIA_ANSWERS2[800] = "Naxx";

WOW_TRIVIA_QUESTIONS[801] = "Quote: Do not rejoice... your victory is a hollow one... for I shall return with powers beyond your imagining!";
WOW_TRIVIA_ANSWERS1[801] = "Kel'Thuzad";

WOW_TRIVIA_QUESTIONS[802] = "Quote: The dark void awaits you!";
WOW_TRIVIA_ANSWERS1[802] = "Kel'Thuzad";

WOW_TRIVIA_QUESTIONS[803] = "Quote: Very well... warriors of the frozen wastes, rise up, I command you to fight, kill, and die for your master. Let none survive...";
WOW_TRIVIA_ANSWERS1[803] = "The lich king";
WOW_TRIVIA_ANSWERS2[803] = "Lich king";

WOW_TRIVIA_QUESTIONS[804] = "Quote: Fools, you think yourselves triumphant? You have only taken one step closer to the abyss!";
WOW_TRIVIA_ANSWERS1[804] = "Kel'Thuzad";

WOW_TRIVIA_QUESTIONS[805] = "What boss drops the rings of T3?";
WOW_TRIVIA_ANSWERS1[805] = "Kel'Thuzad";

WOW_TRIVIA_QUESTIONS[806] = "What boss in Naxxramas drops Fists of the Unrelenting, a Fury Warrior gauntlet?";
WOW_TRIVIA_ANSWERS1[806] = "Sapphiron";

WOW_TRIVIA_QUESTIONS[807] = "On stage three of this boss, this boss will summon five Guardians of Icecrown. They are tough and everytime they switch target, they gain a +15% more damage and +10% size buff. These buffs stacks, and remains throughout the encounter.";
WOW_TRIVIA_ANSWERS1[807] = "Kel'Thuzad";

WOW_TRIVIA_QUESTIONS[808] = "Who drops 'Might of Menethil', in Naxxramas?";
WOW_TRIVIA_ANSWERS1[808] = "Kel'Thuzad";

WOW_TRIVIA_QUESTIONS[809] = "You can find Archmage Tarsis Kir-Moldir in his tower, in Azshara. (True/False)?";
WOW_TRIVIA_ANSWERS1[809] = "false";

WOW_TRIVIA_QUESTIONS[810] = "Quote: The end is upon you!";
WOW_TRIVIA_ANSWERS1[810] = "Kel'Thuzad";

WOW_TRIVIA_QUESTIONS[811] = "What is the Warrior's tier 3 called?";
WOW_TRIVIA_ANSWERS1[811] = "Dreadnaught";

WOW_TRIVIA_QUESTIONS[812] = "What is the Mage's tier 3 called?";
WOW_TRIVIA_ANSWERS1[812] = "Frostfire Regalia";
WOW_TRIVIA_ANSWERS2[812] = "Frostfire";

WOW_TRIVIA_QUESTIONS[813] = "What is the Priest's tier 3 called?";
WOW_TRIVIA_ANSWERS1[813] = "Vestments of Faith";

WOW_TRIVIA_QUESTIONS[814] = "What is the Warlock's tier 3 called?";
WOW_TRIVIA_ANSWERS1[814] = "Plagueheart Raiment";
WOW_TRIVIA_ANSWERS2[814] = "Plagueheart";

WOW_TRIVIA_QUESTIONS[815] = "What is the Shaman's tier 3 called?";
WOW_TRIVIA_ANSWERS1[815] = "The Earthshatterer";
WOW_TRIVIA_ANSWERS2[815] = "Earthshatterer";

WOW_TRIVIA_QUESTIONS[816] = "What is the Paladin's tier 3 called?";
WOW_TRIVIA_ANSWERS1[816] = "Redemption Armor";
WOW_TRIVIA_ANSWERS2[816] = "Redemption";

WOW_TRIVIA_QUESTIONS[817] = "What is the Druid's tier 3 called?";
WOW_TRIVIA_ANSWERS1[817] = "Dreamwalker Raiment"
WOW_TRIVIA_ANSWERS2[817] = "Dreamwalker";

WOW_TRIVIA_QUESTIONS[818] = "Who drops the 'Misplaced Servo Arm' in Naxxramas? (hint: a term used a lot in instances)";
WOW_TRIVIA_ANSWERS1[818] = "trash mobs";
WOW_TRIVIA_ANSWERS2[818] = "trash";

WOW_TRIVIA_QUESTIONS[819] = "Which bosses in Naxxramas drops the T3 feets? (name both, or one of them)";
WOW_TRIVIA_ANSWERS1[819] = "Razuvious and Gothik";
WOW_TRIVIA_ANSWERS2[819] = "Instructor Razuvious and Gothik the Harvester";
WOW_TRIVIA_ANSWERS3[819] = "Gothik and Razuvious";
WOW_TRIVIA_ANSWERS4[819] = "Gothik the Harvester and Instructor Razuvious";
WOW_TRIVIA_ANSWERS5[819] = "Gothik";
WOW_TRIVIA_ANSWERS6[819] = "Gothik the Harvester";
WOW_TRIVIA_ANSWERS7[819] = "Instructor Razuvious";
WOW_TRIVIA_ANSWERS8[819] = "Razuvious";

WOW_TRIVIA_QUESTIONS[820] = "What boss drops the T3 leggings, in Naxxramas?";
WOW_TRIVIA_ANSWERS1[820] = "Loatheb";

WOW_TRIVIA_QUESTIONS[821] = "Which bosses in Naxxramas drops the T3 waist? (name both, or one of them)";
WOW_TRIVIA_ANSWERS1[821] = "Noth and Heigan";
WOW_TRIVIA_ANSWERS2[821] = "Noth the Plaguebringer and Heigan the Unclean";
WOW_TRIVIA_ANSWERS3[821] = "Heigan and Noth";
WOW_TRIVIA_ANSWERS4[821] = "Heigan the Unclean and Noth the Plaguebringer";
WOW_TRIVIA_ANSWERS5[821] = "Noth";
WOW_TRIVIA_ANSWERS6[821] = "Heigan";
WOW_TRIVIA_ANSWERS7[821] = "Noth the Plaguebringer";
WOW_TRIVIA_ANSWERS8[821] = "Heigan the Unclean";

WOW_TRIVIA_QUESTIONS[822] = "What boss in Naxxramas drops the T3 headpieces?";
WOW_TRIVIA_ANSWERS1[822] = "Thaddius";

WOW_TRIVIA_QUESTIONS[823] = "What boss in Naxxramas can drop the Feet/Waist/Shoulder/Wrist of T3?";
WOW_TRIVIA_ANSWERS1[823] = "Gluth";

WOW_TRIVIA_QUESTIONS[824] = "Which bosses in Naxxramas drops the T3 shoulders? (name both)";
WOW_TRIVIA_ANSWERS1[824] = "Patchwerk and Grobbulus";
WOW_TRIVIA_ANSWERS2[824] = "Grobbulus and Patchwerk";

WOW_TRIVIA_QUESTIONS[825] = "Quote: Your fate is sealed!";
WOW_TRIVIA_ANSWERS1[825] = "The Twin Emperors";
WOW_TRIVIA_ANSWERS2[825] = "Twin Emperors";

WOW_TRIVIA_QUESTIONS[826] = "Quote: Your friends will abandon you.";
WOW_TRIVIA_ANSWERS1[826] = "C'thun";
WOW_TRIVIA_ANSWERS2[826] = "Cthun";

WOW_TRIVIA_QUESTIONS[827] = "Quote: Your heart will explode.";
WOW_TRIVIA_ANSWERS1[827] = "C'thun";
WOW_TRIVIA_ANSWERS2[827] = "Cthun";

WOW_TRIVIA_QUESTIONS[828] = "Quote: Death is close.";
WOW_TRIVIA_ANSWERS1[828] = "C'thun";
WOW_TRIVIA_ANSWERS2[828] = "Cthun";

WOW_TRIVIA_QUESTIONS[829] = "Where do you train tailoring at 200?";
WOW_TRIVIA_ANSWERS1[829] = "TM";
WOW_TRIVIA_ANSWERS2[829] = "Tarren Mill";