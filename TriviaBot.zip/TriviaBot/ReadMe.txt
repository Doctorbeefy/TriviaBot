Bennylava's TriviaBot v1.0

Trivia is a fun trivia bot which gives you something to do while you are doing things such as Grinding or just idling at home while others want to have some fun.


This new version features a interface, which was made by Bennylava.
Fixed the 720 questions. Made 290 new questions. 


/trivia channel [ PARTY | RAID | GUILD | <custom channel> ] - Sets the trivia channel.
/trivia start	- Starts the trivia game.
/trivia stop 	- Stops the current game.
/trivia skip 	- Skips the current question.
/trivia shuffle - Reshuffles the questions (restarts from beginning)
/trivia clear   - Clears the scores.
/trivia qlist [wow|normal] -  Select the question list.
/trivia help    - In-game help display

Included Questions:
Normal (2632 questions)
WoW (1010 questions)

Originally made by Guri of Trollbane.
Now devloped and created by Bennylava.