NORMAL_TRIVIA_QUESTIONS = {};
NORMAL_TRIVIA_ANSWERS1 = {};
NORMAL_TRIVIA_ANSWERS2 = {};
NORMAL_TRIVIA_ANSWERS3 = {};

NORMAL_TRIVIA_QUESTIONS[1] = "(Arts&Entertainment): Who was the youngest person to win an acting Oscar?";
NORMAL_TRIVIA_ANSWERS1[1] = "Tatum O'Neal at age 10";
NORMAL_TRIVIA_ANSWERS2[1] = "Tatum O'Neal";

NORMAL_TRIVIA_QUESTIONS[2] = "(Arts&Entertainment): What did the Scarecrow want from the Wizard of Oz?";
NORMAL_TRIVIA_ANSWERS1[2] = "A brain";
NORMAL_TRIVIA_ANSWERS2[2] = "brain";

NORMAL_TRIVIA_QUESTIONS[3] = "(Arts&Entertainment): What is Keanu Reeves character's Real name in \"The Matrix\" (1999)?";
NORMAL_TRIVIA_ANSWERS1[3] = "Thomas Anderson";
NORMAL_TRIVIA_ANSWERS2[3] = "Tom Anderson";

NORMAL_TRIVIA_QUESTIONS[4] = "(Arts&Entertainment): What is Keanu Reeve's hacker name in the movie, \"The Matrix\" (1999)?";
NORMAL_TRIVIA_ANSWERS1[4] = "Neo";

NORMAL_TRIVIA_QUESTIONS[5] = "(Arts&Entertainment): Who is the voice of Darth Vader in \"Star Wars\"?";
NORMAL_TRIVIA_ANSWERS1[5] = "James Earl Jones";

NORMAL_TRIVIA_QUESTIONS[6] = "(Arts&Entertainment): What is the name of Han Solo's ship in \"Star Wars\"?";
NORMAL_TRIVIA_ANSWERS1[6] = "The Millennium Falcon";
NORMAL_TRIVIA_ANSWERS2[6] = "millennium falcon";
NORMAL_TRIVIA_ANSWERS3[6] = "millenium falcon";

NORMAL_TRIVIA_QUESTIONS[7] = "(Arts&Entertainment): What kind of car was used as a time machine in the \"Back To The Future\" movies?";
NORMAL_TRIVIA_ANSWERS1[7] = "A DeLoren";
NORMAL_TRIVIA_ANSWERS2[7] = "deloren";

NORMAL_TRIVIA_QUESTIONS[8] = "(Arts&Entertainment): What is the name of the sequel to \"101 Dalmations\"?";
NORMAL_TRIVIA_ANSWERS1[8] = "102 Dalmations";

NORMAL_TRIVIA_QUESTIONS[9] = "(Arts&Entertainment): What was Indiana Jones's real first name?";
NORMAL_TRIVIA_ANSWERS1[9] = "Henry";

NORMAL_TRIVIA_QUESTIONS[10] = "(Arts&Entertainment): What actor starred in both \"Funny Girl\" and \"Lawrence Of Arabia\"?";
NORMAL_TRIVIA_ANSWERS1[10] = "Omar Sharif";
NORMAL_TRIVIA_ANSWERS2[10] = "Sharif";

NORMAL_TRIVIA_QUESTIONS[11] = "(Arts&Entertainment): What Academy Award winning actor is Angelina Jolie's father?";
NORMAL_TRIVIA_ANSWERS1[11] = "Jon Voight";
NORMAL_TRIVIA_ANSWERS2[11] = "voight";

NORMAL_TRIVIA_QUESTIONS[12] = "(Arts&Entertainment): Who is famous for saying 'I'll be back'?";
NORMAL_TRIVIA_ANSWERS1[12] = "Arnold Schwarzenegger";
NORMAL_TRIVIA_ANSWERS2[12] = "Arnold";

NORMAL_TRIVIA_QUESTIONS[13] = "(Arts&Entertainment): Who is famous for saying 'Make my day'?";
NORMAL_TRIVIA_ANSWERS1[13] = "Clint Eastwood";
NORMAL_TRIVIA_ANSWERS2[13] = "eastwood";

NORMAL_TRIVIA_QUESTIONS[14] = "(Arts&Entertainment): Who played the voice of the baby in \"Look Who's Talking\" (1989)?";
NORMAL_TRIVIA_ANSWERS1[14] = "Bruce Willis";
NORMAL_TRIVIA_ANSWERS2[14] = "willis";

NORMAL_TRIVIA_QUESTIONS[15] = "(Arts&Entertainment): What name is Lazlo Loewenstein  better know as?";
NORMAL_TRIVIA_ANSWERS1[15] = "Peter Lorre";
NORMAL_TRIVIA_ANSWERS2[15] = "Lorre";

NORMAL_TRIVIA_QUESTIONS[16] = "(Arts&Entertainment): Lucille LeSueur was the real name of what legendary Hollywood actress?";
NORMAL_TRIVIA_ANSWERS1[16] = "Joan Crawford";
NORMAL_TRIVIA_ANSWERS2[16] = "crawford";

NORMAL_TRIVIA_QUESTIONS[17] = "(Arts&Entertainment): Caryn Johnson is the birth name of what famous comic and actress?";
NORMAL_TRIVIA_ANSWERS1[17] = "Whoopi Goldberg";
NORMAL_TRIVIA_ANSWERS2[17] = "Whoopi";
NORMAL_TRIVIA_ANSWERS3[17] = "Goldburg";

NORMAL_TRIVIA_QUESTIONS[18] = "(Arts&Entertainment): In what movie did we first hear 'May the force be with you'?";
NORMAL_TRIVIA_ANSWERS1[18] = "Star Wars";

NORMAL_TRIVIA_QUESTIONS[19] = "(Arts&Entertainment): In what movie did Tom Cruise play a vampire?";
NORMAL_TRIVIA_ANSWERS1[19] = "Interview With The Vampire";

NORMAL_TRIVIA_QUESTIONS[20] = "(Arts&Entertainment): Who played Dr. Frankenstein in \"Young Frankenstein\"?";
NORMAL_TRIVIA_ANSWERS1[20] = "Gene Wilder";
NORMAL_TRIVIA_ANSWERS2[20] = "Wilder";

NORMAL_TRIVIA_QUESTIONS[21] = "(Arts&Entertainment): Who played the monster in \"Young Frankenstein\"?";
NORMAL_TRIVIA_ANSWERS1[21] = "Peter Boyle";
NORMAL_TRIVIA_ANSWERS2[21] = "boyle";

NORMAL_TRIVIA_QUESTIONS[22] = "(Geography): What is the highest mountain in the world?";
NORMAL_TRIVIA_ANSWERS1[22] = "Mt. Everest in Nepal and Tibet at 29,028 feet";
NORMAL_TRIVIA_ANSWERS2[22] = "Mt. Everest";
NORMAL_TRIVIA_ANSWERS3[22] = "Everest";

NORMAL_TRIVIA_QUESTIONS[23] = "(United States): In what year did Alaska become a state?";
NORMAL_TRIVIA_ANSWERS1[23] = "1959 as the 49th state";
NORMAL_TRIVIA_ANSWERS2[23] = "1959";

NORMAL_TRIVIA_QUESTIONS[24] = "(Geography): What is the largest 'lake' in the world?";
NORMAL_TRIVIA_ANSWERS1[24] = "The Caspian Sea";
NORMAL_TRIVIA_ANSWERS2[24] = "Caspian";

NORMAL_TRIVIA_QUESTIONS[25] = "(Geography): What is the largest lake in North America?";
NORMAL_TRIVIA_ANSWERS1[25] = "Lake Superior";

NORMAL_TRIVIA_QUESTIONS[26] = "(United States): What year did women win the right to vote in national elections in the U.S.?";
NORMAL_TRIVIA_ANSWERS1[26] = "August 18, 1920";
NORMAL_TRIVIA_ANSWERS2[26] = "1920";

NORMAL_TRIVIA_QUESTIONS[27] = "(Science&Nature): How many tentacles does an octopus have?";
NORMAL_TRIVIA_ANSWERS1[27] = "8";
NORMAL_TRIVIA_ANSWERS2[27] = "eight";

NORMAL_TRIVIA_QUESTIONS[28] = "(Science&Nature): How many legs does a spider have?";
NORMAL_TRIVIA_ANSWERS1[28] = "8";
NORMAL_TRIVIA_ANSWERS2[28] = "eight";

NORMAL_TRIVIA_QUESTIONS[29] = "(Science&Nature): About how fast can a dragonfly fly; 10, 20, 30 or 40 miles per hour?";
NORMAL_TRIVIA_ANSWERS1[29] = "30 miles per hour";
NORMAL_TRIVIA_ANSWERS2[29] = "30";

NORMAL_TRIVIA_QUESTIONS[30] = "(United States): In what city did Rosa Parks first take a stand against \"Jim Crow\" laws by refusing to stand?";
NORMAL_TRIVIA_ANSWERS1[30] = "Montgomery, Alabama, December 1, 1955";
NORMAL_TRIVIA_ANSWERS2[30] = "Montgomery";

NORMAL_TRIVIA_QUESTIONS[31] = "(Geography): Where is the Weddell Sea?";
NORMAL_TRIVIA_ANSWERS1[31] = "Antartica";

NORMAL_TRIVIA_QUESTIONS[32] = "(Geography): What is the longest river in the world?";
NORMAL_TRIVIA_ANSWERS1[32] = "The Nile at 4,160 miles";
NORMAL_TRIVIA_ANSWERS2[32] = "nile";

NORMAL_TRIVIA_QUESTIONS[33] = "(Geography): What is the largest lake in Africa?";
NORMAL_TRIVIA_ANSWERS1[33] = "Lake Victoria at 28,820 square miles";
NORMAL_TRIVIA_ANSWERS2[33] = "Lake Victoria";
NORMAL_TRIVIA_ANSWERS3[33] = "Victoria";

NORMAL_TRIVIA_QUESTIONS[34] = "(Geography): What do Istanbul, Constantinople, and Byzantium have in common?";
NORMAL_TRIVIA_ANSWERS1[34] = "They are all historical names for the same place";
NORMAL_TRIVIA_ANSWERS2[34] = "same place";
NORMAL_TRIVIA_ANSWERS3[34] = "same city";

NORMAL_TRIVIA_QUESTIONS[35] = "(Sports&Leisure): Who fought in the boxing match called 'The Thrilla in Manila'?";
NORMAL_TRIVIA_ANSWERS1[35] = "Muhammad Ali and Joe Frazier (Ali won)";
NORMAL_TRIVIA_ANSWERS2[35] = "Ali and Frazier";
NORMAL_TRIVIA_ANSWERS3[35] = "Ali & Frazier";

NORMAL_TRIVIA_QUESTIONS[36] = "(History): In what year was the Magna Carta signed?";
NORMAL_TRIVIA_ANSWERS1[36] = "1215";

NORMAL_TRIVIA_QUESTIONS[37] = "(History): What 2 countries fought the Hundred Years War?";
NORMAL_TRIVIA_ANSWERS1[37] = "France and England from 1334 to 1453";
NORMAL_TRIVIA_ANSWERS2[37] = "France and England";
NORMAL_TRIVIA_ANSWERS3[37] = "France & England";

NORMAL_TRIVIA_QUESTIONS[38] = "(Arts&Entertainment): How are the Bee Gees related?";
NORMAL_TRIVIA_ANSWERS1[38] = "They are brothers";
NORMAL_TRIVIA_ANSWERS2[38] = "brothers";

NORMAL_TRIVIA_QUESTIONS[39] = "(Sports&Leisure): Where was the game of golf invented?";
NORMAL_TRIVIA_ANSWERS1[39] = "Scotland";

NORMAL_TRIVIA_QUESTIONS[40] = "(History): Who was the first 'elected' President of Russia?";
NORMAL_TRIVIA_ANSWERS1[40] = "Boris Yeltsin";
NORMAL_TRIVIA_ANSWERS2[40] = "Yeltsin";

NORMAL_TRIVIA_QUESTIONS[41] = "(Geography): What is the highest waterfall in the world?";
NORMAL_TRIVIA_ANSWERS1[41] = "Angel Falls in Venezuela at 3,212 feet";
NORMAL_TRIVIA_ANSWERS2[41] = "Angel Falls";

NORMAL_TRIVIA_QUESTIONS[42] = "(Geography): What is the world's largest desert?";
NORMAL_TRIVIA_ANSWERS1[42] = "The Sahara at 3,500,000 square miles";
NORMAL_TRIVIA_ANSWERS2[42] = "Sahara";

NORMAL_TRIVIA_QUESTIONS[43] = "(United States): What U.S. city is also called 'The Windy City'?";
NORMAL_TRIVIA_ANSWERS1[43] = "Chicago";

NORMAL_TRIVIA_QUESTIONS[44] = "(Science&Nature): How far can a skunk spray; 5, 10 or 15 feet?";
NORMAL_TRIVIA_ANSWERS1[44] = "up to 10 feet";
NORMAL_TRIVIA_ANSWERS2[44] = "10";

NORMAL_TRIVIA_QUESTIONS[45] = "(Geography): What is the highest mountain in Africa?";
NORMAL_TRIVIA_ANSWERS1[45] = "Mt. Kilimanjaro at 19,340 feet";
NORMAL_TRIVIA_ANSWERS2[45] = "Kilimanjaro";

NORMAL_TRIVIA_QUESTIONS[46] = "(Science&Nature): Who invented the computer mouse?";
NORMAL_TRIVIA_ANSWERS1[46] = "Douglas C. Engelbart in 1968 but it wasn't popularized until Apple used it in 1984";
NORMAL_TRIVIA_ANSWERS2[46] = "Engelbart";

NORMAL_TRIVIA_QUESTIONS[47] = "(Science&Nature): How many bones are there in the adult human body?";
NORMAL_TRIVIA_ANSWERS1[47] = "206";

NORMAL_TRIVIA_QUESTIONS[48] = "(Geography): What is the narrow sea between the Arabian Peninsula and Africa called?";
NORMAL_TRIVIA_ANSWERS1[48] = "The Red Sea";
NORMAL_TRIVIA_ANSWERS2[48] = "Red Sea";

NORMAL_TRIVIA_QUESTIONS[49] = "(Mythology): What is the name of the Greek wine god?";
NORMAL_TRIVIA_ANSWERS1[49] = "Dionysus (also called Bacchus)";
NORMAL_TRIVIA_ANSWERS2[49] = "Bacchus";
NORMAL_TRIVIA_ANSWERS3[49] = "Dionysus";

NORMAL_TRIVIA_QUESTIONS[50] = "(Literature): What is the name of the bad guy in Peter Pan?";
NORMAL_TRIVIA_ANSWERS1[50] = "Captain Hook";
NORMAL_TRIVIA_ANSWERS2[50] = "Hook";

NORMAL_TRIVIA_QUESTIONS[51] = "(Geography): What is the southern most capital city in the world?";
NORMAL_TRIVIA_ANSWERS1[51] = "Wellington, capital of New Zealand";
NORMAL_TRIVIA_ANSWERS2[51] = "Wellington";
NORMAL_TRIVIA_ANSWERS3[51] = "Welington";

NORMAL_TRIVIA_QUESTIONS[52] = "(United States): Who is the only U.S. President who was never married?";
NORMAL_TRIVIA_ANSWERS1[52] = "James Buchanan";
NORMAL_TRIVIA_ANSWERS2[52] = "Buchanan";

NORMAL_TRIVIA_QUESTIONS[53] = "(Literature): What is the river named most often in the Bible?";
NORMAL_TRIVIA_ANSWERS1[53] = "Jordan";

NORMAL_TRIVIA_QUESTIONS[54] = "(Language): What is the Scottish word for lake?";
NORMAL_TRIVIA_ANSWERS1[54] = "Loch";

NORMAL_TRIVIA_QUESTIONS[55] = "(Arts&Entertainmen): Who was the singer who made the video THRILLER?";
NORMAL_TRIVIA_ANSWERS1[55] = "Michael Jackson";
NORMAL_TRIVIA_ANSWERS2[55] = "Michel Jackson";

NORMAL_TRIVIA_QUESTIONS[56] = "(Arts&Entertainment): Which actor entered a Charlie Chaplin look alike contest and came in third?";
NORMAL_TRIVIA_ANSWERS1[56] = "Charlie Chaplin";

NORMAL_TRIVIA_QUESTIONS[57] = "(Geography): Which animal are the Canary Islands named after?";
NORMAL_TRIVIA_ANSWERS1[57] = "Dog (Canine, the birds were named for the islands)";
NORMAL_TRIVIA_ANSWERS2[57] = "dog";

NORMAL_TRIVIA_QUESTIONS[58] = "(Science&Nature): Which planet is closest to the sun?";
NORMAL_TRIVIA_ANSWERS1[58] = "Mercury";

NORMAL_TRIVIA_QUESTIONS[59] = "(Science&Nature): How many moons does Mars have?";
NORMAL_TRIVIA_ANSWERS1[59] = "2 moons, Phobos and Deimos";
NORMAL_TRIVIA_ANSWERS2[59] = "2";
NORMAL_TRIVIA_ANSWERS3[59] = "two";

NORMAL_TRIVIA_QUESTIONS[60] = "(Geography): What is the lowest point on land in the world?";
NORMAL_TRIVIA_ANSWERS1[60] = "The Dead Sea in Israel and Jordan at 1,312 feet below sea level";
NORMAL_TRIVIA_ANSWERS2[60] = "Dead Sea";

NORMAL_TRIVIA_QUESTIONS[61] = "(History): When did World War II begin?";
NORMAL_TRIVIA_ANSWERS1[61] = "September 1, 1939 when German troops crossed into Poland";
NORMAL_TRIVIA_ANSWERS2[61] = "1939";

NORMAL_TRIVIA_QUESTIONS[62] = "(History): When did the U.S. enter World War II?";
NORMAL_TRIVIA_ANSWERS1[62] = "December 1941";
NORMAL_TRIVIA_ANSWERS2[62] = "1941";

NORMAL_TRIVIA_QUESTIONS[63] = "(Literature): Where were the words \"The truth shall make you free\" first written?";
NORMAL_TRIVIA_ANSWERS1[63] = "The Bible, John 8:32";
NORMAL_TRIVIA_ANSWERS2[63] = "Bible";

NORMAL_TRIVIA_QUESTIONS[64] = "(History): What year did the Russian revolution take place?";
NORMAL_TRIVIA_ANSWERS1[64] = "1917 (the Russian civil war lasted from 1918-1921)";
NORMAL_TRIVIA_ANSWERS2[64] = "1917";

NORMAL_TRIVIA_QUESTIONS[65] = "(History): What year did the Titanic sink?";
NORMAL_TRIVIA_ANSWERS1[65] = "1912";

NORMAL_TRIVIA_QUESTIONS[66] = "(History): Who was the first person in space?";
NORMAL_TRIVIA_ANSWERS1[66] = "Yuri Gagarin in 1961";
NORMAL_TRIVIA_ANSWERS2[66] = "Gargarin";
NORMAL_TRIVIA_ANSWERS3[66] = "Yuri";

NORMAL_TRIVIA_QUESTIONS[67] = "(History): Who was the first person to set foot on the moon?";
NORMAL_TRIVIA_ANSWERS1[67] = "Neil Armstrong in 1969";
NORMAL_TRIVIA_ANSWERS2[67] = "Armstrong";

NORMAL_TRIVIA_QUESTIONS[68] = "(Science&Nature): What year was a sheep named Dolly created by cloning?";
NORMAL_TRIVIA_ANSWERS1[68] = "1997";

NORMAL_TRIVIA_QUESTIONS[69] = "(History): What year saw the break up of the USSR?";
NORMAL_TRIVIA_ANSWERS1[69] = "1991";

NORMAL_TRIVIA_QUESTIONS[70] = "(Sports&Leisure): Where were the 2000 Olympics held?";
NORMAL_TRIVIA_ANSWERS1[70] = "Sydney, Australia";
NORMAL_TRIVIA_ANSWERS2[70] = "Sydney";
NORMAL_TRIVIA_ANSWERS3[70] = "Australia";

NORMAL_TRIVIA_QUESTIONS[71] = "(History): What year was the Commonwealth of Australia established?";
NORMAL_TRIVIA_ANSWERS1[71] = "1901";

NORMAL_TRIVIA_QUESTIONS[72] = "(Literature): What did Sir Galahad search for?";
NORMAL_TRIVIA_ANSWERS1[72] = "The Holy Grail";
NORMAL_TRIVIA_ANSWERS2[72] = "holy grail";

NORMAL_TRIVIA_QUESTIONS[73] = "(Geography): What is the Spanish name for the South American capital which means 'good air'?";
NORMAL_TRIVIA_ANSWERS1[73] = "Buenos Aires";

NORMAL_TRIVIA_QUESTIONS[74] = "(Geography): What is the capital of Ecuador?";
NORMAL_TRIVIA_ANSWERS1[74] = "Quito";

NORMAL_TRIVIA_QUESTIONS[75] = "(Geography): What is the capital of Somalia?";
NORMAL_TRIVIA_ANSWERS1[75] = "Mogadishu";

NORMAL_TRIVIA_QUESTIONS[76] = "(Language): What is the meaning of the French word estragon?";
NORMAL_TRIVIA_ANSWERS1[76] = "Tarragon (the spice)";
NORMAL_TRIVIA_ANSWERS2[76] = "tarragon";
NORMAL_TRIVIA_ANSWERS3[76] = "taragon";

NORMAL_TRIVIA_QUESTIONS[77] = "(Geography): What is the capital of Hungary?";
NORMAL_TRIVIA_ANSWERS1[77] = "Budapest";

NORMAL_TRIVIA_QUESTIONS[78] = "(Arts&Entertainment): What name is Annie Mae Bullock better know as?";
NORMAL_TRIVIA_ANSWERS1[78] = "Tina Turner";

NORMAL_TRIVIA_QUESTIONS[79] = "(Arts&Entertainment): What name is Paul Hewson better know as?";
NORMAL_TRIVIA_ANSWERS1[79] = "Bono, from the group called U2";
NORMAL_TRIVIA_ANSWERS2[79] = "bono";

NORMAL_TRIVIA_QUESTIONS[80] = "(Geography): What middle eastern state was founded in 1948?";
NORMAL_TRIVIA_ANSWERS1[80] = "Israel";

NORMAL_TRIVIA_QUESTIONS[81] = "(Language): What does the Russian word buran mean?";
NORMAL_TRIVIA_ANSWERS1[81] = "Blizzard";

NORMAL_TRIVIA_QUESTIONS[82] = "(Arts&Entertainment): How many members in the guy group N'SYNC? ";
NORMAL_TRIVIA_ANSWERS1[82] = "5";
NORMAL_TRIVIA_ANSWERS2[82] = "five";

NORMAL_TRIVIA_QUESTIONS[83] = "(Arts&Entertainment): Name one of the 3 members of N'SYNC whose names start with the letter \"J\".";
NORMAL_TRIVIA_ANSWERS1[83] = "Joey, JC or Justin";
NORMAL_TRIVIA_ANSWERS2[83] = "Joey";
NORMAL_TRIVIA_ANSWERS3[83] = "JC";

NORMAL_TRIVIA_QUESTIONS[84] = "(Arts&Entertainnment): Name one of the 2 members of N'SYNC whose names do NOT start with the letter \"J\".";
NORMAL_TRIVIA_ANSWERS1[84] = "Chris and Lance";
NORMAL_TRIVIA_ANSWERS2[84] = "Chris";
NORMAL_TRIVIA_ANSWERS3[84] = "Lance";

NORMAL_TRIVIA_QUESTIONS[85] = "(Arts&Entertainment): What year was the movie Ben Hur with Charlton Heston made?";
NORMAL_TRIVIA_ANSWERS1[85] = "1959";

NORMAL_TRIVIA_QUESTIONS[86] = "(Arts&Entertainment): Who played Captain Queeg in \"The Caine Mutiny\"?";
NORMAL_TRIVIA_ANSWERS1[86] = "Humphrey Bogart";
NORMAL_TRIVIA_ANSWERS2[86] = "Bogart";

NORMAL_TRIVIA_QUESTIONS[87] = "(Arts&Entertainment): Who played Maggie in \"Cat On A Hot Tin Roof\" with Paul Newman?";
NORMAL_TRIVIA_ANSWERS1[87] = "Elizabeth Taylor";
NORMAL_TRIVIA_ANSWERS2[87] = "Taylor";

NORMAL_TRIVIA_QUESTIONS[88] = "(Language): What is a Wyvern?";
NORMAL_TRIVIA_ANSWERS1[88] = "A type of dragon";
NORMAL_TRIVIA_ANSWERS2[88] = "dragon";

NORMAL_TRIVIA_QUESTIONS[89] = "(United States): When were PopTarts invented?";
NORMAL_TRIVIA_ANSWERS1[89] = "1964";

NORMAL_TRIVIA_QUESTIONS[90] = "(Geography): What African country is only 8 miles from Spain?";
NORMAL_TRIVIA_ANSWERS1[90] = "Morocco";

NORMAL_TRIVIA_QUESTIONS[91] = "(Language): What African language do Boers speak?";
NORMAL_TRIVIA_ANSWERS1[91] = "Afrikaans";

NORMAL_TRIVIA_QUESTIONS[92] = "(History): Which people created the sundial?";
NORMAL_TRIVIA_ANSWERS1[92] = "The Egyptians in 2400 B.C.";
NORMAL_TRIVIA_ANSWERS2[92] = "Egyptians";

NORMAL_TRIVIA_QUESTIONS[93] = "(Mythology): Who did Paris, the ruler of Troy, select as the most beautiful goddess?";
NORMAL_TRIVIA_ANSWERS1[93] = "Aphrodite";

NORMAL_TRIVIA_QUESTIONS[94] = "(Science&Nature): What are Pyxis, Puppis, and Pavo?";
NORMAL_TRIVIA_ANSWERS1[94] = "Constellations in the southern sky";
NORMAL_TRIVIA_ANSWERS2[94] = "constellations";

NORMAL_TRIVIA_QUESTIONS[95] = "(United States): How many deserts are in or extend into the United States?";
NORMAL_TRIVIA_ANSWERS1[95] = "5";
NORMAL_TRIVIA_ANSWERS2[95] = "five";

NORMAL_TRIVIA_QUESTIONS[96] = "(Geography): Name the 500,000 square mile desert that Mongolia and China share.";
NORMAL_TRIVIA_ANSWERS1[96] = "Gobi";

NORMAL_TRIVIA_QUESTIONS[97] = "(Computers): What is the type of computer virus that is named after a device of trickery used in a famous mythological war?";
NORMAL_TRIVIA_ANSWERS1[97] = "Trojan Horse";
NORMAL_TRIVIA_ANSWERS2[97] = "trojan";

NORMAL_TRIVIA_QUESTIONS[98] = "(Computers): When was the World Wide Web developed?";
NORMAL_TRIVIA_ANSWERS1[98] = "1990";

NORMAL_TRIVIA_QUESTIONS[99] = "(Computers): What is the name of the group that developed the World Wide Web?";
NORMAL_TRIVIA_ANSWERS1[99] = "European Center for Nuclear Research";

NORMAL_TRIVIA_QUESTIONS[100] = "(Computers): In what Swiss city was the World Wide Web first developed?";
NORMAL_TRIVIA_ANSWERS1[100] = "Geneva, Switzerland";
NORMAL_TRIVIA_ANSWERS2[100] = "Geneva";

NORMAL_TRIVIA_QUESTIONS[101] = "(True&False): Goat's milk is used more widely throughout the world than cows milk.";
NORMAL_TRIVIA_ANSWERS1[101] = "True";

NORMAL_TRIVIA_QUESTIONS[102] = "(Numbers): How many U.S. state capitals are named after presidents?";
NORMAL_TRIVIA_ANSWERS1[102] = "4";
NORMAL_TRIVIA_ANSWERS2[102] = "four";

NORMAL_TRIVIA_QUESTIONS[103] = "(Colors): \"I'm Dreaming of a _____ Christmas.\"";
NORMAL_TRIVIA_ANSWERS1[103] = "white";

NORMAL_TRIVIA_QUESTIONS[104] = "(Sports&Leisure): What member of the British royal family competed in the 1976 Summer Olympics?";
NORMAL_TRIVIA_ANSWERS1[104] = "Princess Anne";

NORMAL_TRIVIA_QUESTIONS[105] = "(Colors): What color are the Majestic mountains in \"America the Beautiful\"?";
NORMAL_TRIVIA_ANSWERS1[105] = "Purple";

NORMAL_TRIVIA_QUESTIONS[106] = "(True&False): If one part of a parallel circuit is broken, the circuit continues to function.";
NORMAL_TRIVIA_ANSWERS1[106] = "true";

NORMAL_TRIVIA_QUESTIONS[107] = "(Miscellaneous): World War 2 ended in 194_.";
NORMAL_TRIVIA_ANSWERS1[107] = "5";
NORMAL_TRIVIA_ANSWERS2[107] = "five";

NORMAL_TRIVIA_QUESTIONS[108] = "(Art&Literature): Who made his debut in Action Comics No.1?";
NORMAL_TRIVIA_ANSWERS1[108] = "Superman";

NORMAL_TRIVIA_QUESTIONS[109] = "(Colors): What color is the center stripe on the American flag?";
NORMAL_TRIVIA_ANSWERS1[109] = "Red";

NORMAL_TRIVIA_QUESTIONS[110] = "(Miscellaneous): Potato chips were invented by a chef in Louisiana in 1865.";
NORMAL_TRIVIA_ANSWERS1[110] = "True";

NORMAL_TRIVIA_QUESTIONS[111] = "(Colors): What two colors are found on the flags of ALL Central American nations?";
NORMAL_TRIVIA_ANSWERS1[111] = "blue and white";
NORMAL_TRIVIA_ANSWERS2[111] = "white and blue";
NORMAL_TRIVIA_ANSWERS3[111] = "blue&white";

NORMAL_TRIVIA_QUESTIONS[112] = "(Geography): What state capital is 10 miles from Princeton University?";
NORMAL_TRIVIA_ANSWERS1[112] = "Trenton";

NORMAL_TRIVIA_QUESTIONS[113] = "(True&False): You can only see a rainbow if you are not facing the sun.";
NORMAL_TRIVIA_ANSWERS1[113] = "True";

NORMAL_TRIVIA_QUESTIONS[114] = "(Numbers): How many of the seven dwarf's names do not end with \"y\"?";
NORMAL_TRIVIA_ANSWERS1[114] = "2";
NORMAL_TRIVIA_ANSWERS2[114] = "two";

NORMAL_TRIVIA_QUESTIONS[115] = "(Numbers): How many faces on a dreydel?";
NORMAL_TRIVIA_ANSWERS1[115] = "7";
NORMAL_TRIVIA_ANSWERS2[115] = "seven";

NORMAL_TRIVIA_QUESTIONS[116] = "(Colors): ______stone National Park has 120 named geysers.";
NORMAL_TRIVIA_ANSWERS1[116] = "Yellow";

NORMAL_TRIVIA_QUESTIONS[117] = "(Science&Nature): What was the Bridge of San Luis Rey made of?";
NORMAL_TRIVIA_ANSWERS1[117] = "rope";

NORMAL_TRIVIA_QUESTIONS[118] = "(History): What country did Lord Haw Haw broadcast propaganda for in World War 2?";
NORMAL_TRIVIA_ANSWERS1[118] = "Denmark";

NORMAL_TRIVIA_QUESTIONS[119] = "(Colors): What color did most beatniks wear exclusively?";
NORMAL_TRIVIA_ANSWERS1[119] = "Black";

NORMAL_TRIVIA_QUESTIONS[120] = "(Numbers): How many planets are between Earth and the sun?";
NORMAL_TRIVIA_ANSWERS1[120] = "2";
NORMAL_TRIVIA_ANSWERS2[120] = "two";

NORMAL_TRIVIA_QUESTIONS[121] = "(Miscellaneous): Wall Streeters called October 29, 1929_____ Tuesday. ";
NORMAL_TRIVIA_ANSWERS1[121] = "black";

NORMAL_TRIVIA_QUESTIONS[122] = "(Entertainment): How many times did Bing Crosby and Bob Hope hit the road films?";
NORMAL_TRIVIA_ANSWERS1[122] = "7";
NORMAL_TRIVIA_ANSWERS2[122] = "seven";

NORMAL_TRIVIA_QUESTIONS[123] = "(Colors): \"Ho,ho,ho\"is heard in the valley of the Jolly _____ Giant.";
NORMAL_TRIVIA_ANSWERS1[123] = "Green";

NORMAL_TRIVIA_QUESTIONS[124] = "(Colors): What are the New York Yankees two team colors?";
NORMAL_TRIVIA_ANSWERS1[124] = "Black and White";
NORMAL_TRIVIA_ANSWERS2[124] = "White and Black";
NORMAL_TRIVIA_ANSWERS3[124] = "Black&White";

NORMAL_TRIVIA_QUESTIONS[125] = "(Art&Literature): What country was the setting of You Only Live Twice?";
NORMAL_TRIVIA_ANSWERS1[125] = "Japan";

NORMAL_TRIVIA_QUESTIONS[126] = "(Numbers): How many axles does an 18-wheeler have?";
NORMAL_TRIVIA_ANSWERS1[126] = "5";
NORMAL_TRIVIA_ANSWERS2[126] = "five";

NORMAL_TRIVIA_QUESTIONS[127] = "(Geography): What does the River Seine empty into?";
NORMAL_TRIVIA_ANSWERS1[127] = "The English Channel";
NORMAL_TRIVIA_ANSWERS2[127] = "English Channel";

NORMAL_TRIVIA_QUESTIONS[128] = "(History): Who was the first U.S. Billionaire?";
NORMAL_TRIVIA_ANSWERS1[128] = "John D. Rockefeller";
NORMAL_TRIVIA_ANSWERS2[128] = "Rockefeller";
NORMAL_TRIVIA_ANSWERS3[128] = "Rockafeller";

NORMAL_TRIVIA_QUESTIONS[129] = "(Colors): Rhapsody in ____ was a loose biographical film of George Gershwin.";
NORMAL_TRIVIA_ANSWERS1[129] = "Blue";

NORMAL_TRIVIA_QUESTIONS[130] = "(Geography): What country covers an entire continent?";
NORMAL_TRIVIA_ANSWERS1[130] = "Australia";

NORMAL_TRIVIA_QUESTIONS[131] = "(Horror Roles): Who was the '50's horror film hostess that also appeared in \"Plan 9 from Outer Space\"?";
NORMAL_TRIVIA_ANSWERS1[131] = "Vampira";

NORMAL_TRIVIA_QUESTIONS[132] = "(Monsters): What was the only thing that Beetlejuice was afraid of?";
NORMAL_TRIVIA_ANSWERS1[132] = "sand worms";
NORMAL_TRIVIA_ANSWERS2[132] = "sand worm";

NORMAL_TRIVIA_QUESTIONS[133] = "(Characters): What was the name of the Addams Family butler?";
NORMAL_TRIVIA_ANSWERS1[133] = "Lurch";
NORMAL_TRIVIA_ANSWERS2[133] = "lerch";

NORMAL_TRIVIA_QUESTIONS[134] = "(Horror Roles): Which actress played the mother of \"Rosemary's Baby\"?";
NORMAL_TRIVIA_ANSWERS1[134] = "Mia Farrow";
NORMAL_TRIVIA_ANSWERS2[134] = "farrow";

NORMAL_TRIVIA_QUESTIONS[135] = "(General Knowledge): What finally destroyed the aliens in \"War of the Worlds\"?";
NORMAL_TRIVIA_ANSWERS1[135] = "germs";
NORMAL_TRIVIA_ANSWERS2[135] = "bacteria";

NORMAL_TRIVIA_QUESTIONS[136] = "(Horror Roles): What young actor was eaten by a bed in \"Nightmare on Elm Street\"?";
NORMAL_TRIVIA_ANSWERS1[136] = "Johnny Depp";
NORMAL_TRIVIA_ANSWERS2[136] = "depp";

NORMAL_TRIVIA_QUESTIONS[137] = "(General Knowledge): What was the town of Blair in \"The Blair Witch Project\" renamed as?";
NORMAL_TRIVIA_ANSWERS1[137] = "Burkittsville";

NORMAL_TRIVIA_QUESTIONS[138] = "(Horror Roles): Who played the title role in \"Carrie\"?";
NORMAL_TRIVIA_ANSWERS1[138] = "Sissy Spacek";
NORMAL_TRIVIA_ANSWERS2[138] = "spacek";

NORMAL_TRIVIA_QUESTIONS[139] = "(Monsters): What was the name of Godzilla's (movie) son?";
NORMAL_TRIVIA_ANSWERS1[139] = "Minya";

NORMAL_TRIVIA_QUESTIONS[140] = "(Characters): What was Lon Chaney Jr's human name in \"The Wolfman\"?";
NORMAL_TRIVIA_ANSWERS1[140] = "Larry Talbot";
NORMAL_TRIVIA_ANSWERS2[140] = "talbot";
NORMAL_TRIVIA_ANSWERS3[140] = "tallbot";

NORMAL_TRIVIA_QUESTIONS[141] = "(General Knowledge): Who wrote the novel, \"Jaws\"?";
NORMAL_TRIVIA_ANSWERS1[141] = "Peter Benchley";
NORMAL_TRIVIA_ANSWERS2[141] = "benchley";

NORMAL_TRIVIA_QUESTIONS[142] = "(Horror Roles): Which actor has played Dracula in more films than anyone else?";
NORMAL_TRIVIA_ANSWERS1[142] = "Christopher Lee";
NORMAL_TRIVIA_ANSWERS2[142] = "chris lee";

NORMAL_TRIVIA_QUESTIONS[143] = "(Complete The Quote): Complete this quote: \"Soylent Green is...\"";
NORMAL_TRIVIA_ANSWERS1[143] = "people";

NORMAL_TRIVIA_QUESTIONS[144] = "(Characters): What was the name of the villian in 1921's \"Nosferatu\"?";
NORMAL_TRIVIA_ANSWERS1[144] = "Count Orlock";
NORMAL_TRIVIA_ANSWERS2[144] = "orlock";

NORMAL_TRIVIA_QUESTIONS[145] = "(General Knowledge): To what was Dracula referring to as \"children of the night\"?";
NORMAL_TRIVIA_ANSWERS1[145] = "wolves";

NORMAL_TRIVIA_QUESTIONS[146] = "(Horror Roles): Which actor played Count Alucard in 1943's \"Son of Dracula\"?";
NORMAL_TRIVIA_ANSWERS1[146] = "Lon Chaney Jr";
NORMAL_TRIVIA_ANSWERS2[146] = "lon chaney junior";
NORMAL_TRIVIA_ANSWERS3[146] = "chaney jr";

NORMAL_TRIVIA_QUESTIONS[147] = "(Characters): In the 1931 film, \"Frankenstein\", what was the doctor's first name?";
NORMAL_TRIVIA_ANSWERS1[147] = "Henry";

NORMAL_TRIVIA_QUESTIONS[148] = "(Monsters): The monsters in the film, \"Them\", were giant, what?";
NORMAL_TRIVIA_ANSWERS1[148] = "ants";

NORMAL_TRIVIA_QUESTIONS[149] = "(General Knowledge): What type of bat is most often used in horror films?";
NORMAL_TRIVIA_ANSWERS1[149] = "flying fox";

NORMAL_TRIVIA_QUESTIONS[150] = "(Horror Roles): Who played Herman on the original \"The Munsters\" television series?";
NORMAL_TRIVIA_ANSWERS1[150] = "Fred Gwynne";
NORMAL_TRIVIA_ANSWERS2[150] = "guinn";
NORMAL_TRIVIA_ANSWERS3[150] = "gwynne";

NORMAL_TRIVIA_QUESTIONS[151] = "(Characters): What was the name of the antichrist character in the \"Omen\" trilogy?";
NORMAL_TRIVIA_ANSWERS1[151] = "Damien";
NORMAL_TRIVIA_ANSWERS2[151] = "damian";

NORMAL_TRIVIA_QUESTIONS[152] = "(Complete The Quote): Complete this quote: \"It's alive!...\"";
NORMAL_TRIVIA_ANSWERS1[152] = "it's alive";

NORMAL_TRIVIA_QUESTIONS[153] = "(General Knowledge): Who was billed as the \"Man of 1000 Faces\"?";
NORMAL_TRIVIA_ANSWERS1[153] = "Lon Chaney";
NORMAL_TRIVIA_ANSWERS2[153] = "chaney";

NORMAL_TRIVIA_QUESTIONS[154] = "(Horror Roles): Which television star played the title role in 1957's \"I was a Teenage Werewolf\"?";
NORMAL_TRIVIA_ANSWERS1[154] = "Michael Landon";
NORMAL_TRIVIA_ANSWERS2[154] = "landon";

NORMAL_TRIVIA_QUESTIONS[155] = "(Characters): What was the title character's name in 1925's \"The Phantom of the Opera\"?";
NORMAL_TRIVIA_ANSWERS1[155] = "Eric";
NORMAL_TRIVIA_ANSWERS2[155] = "erik";

NORMAL_TRIVIA_QUESTIONS[156] = "(General Knowledge): What was Bela Lugosi's real name?";
NORMAL_TRIVIA_ANSWERS1[156] = "Bela Blasko";
NORMAL_TRIVIA_ANSWERS2[156] = "blasko";

NORMAL_TRIVIA_QUESTIONS[157] = "(Horror Roles): Who played the masochistic dental patient in the 1986 remake of \"The Little Shop of Horrors\"?";
NORMAL_TRIVIA_ANSWERS1[157] = "Bill Murray";
NORMAL_TRIVIA_ANSWERS2[157] = "murray";
NORMAL_TRIVIA_ANSWERS3[157] = "murrey";

NORMAL_TRIVIA_QUESTIONS[158] = "(General Knowledge): What actress played in the movies \"Firestarter\" and \"E.T.\"?";
NORMAL_TRIVIA_ANSWERS1[158] = "Drew Barrymore";
NORMAL_TRIVIA_ANSWERS2[158] = "barrymore";

NORMAL_TRIVIA_QUESTIONS[159] = "(Monsters): In \"King Kong vs. Godzilla\", who won?";
NORMAL_TRIVIA_ANSWERS1[159] = "neither";
NORMAL_TRIVIA_ANSWERS2[159] = "no one";
NORMAL_TRIVIA_ANSWERS3[159] = "nobody";

NORMAL_TRIVIA_QUESTIONS[160] = "(Horror Roles): Who played Jamie Lee Curtis' \"Psycho\" mother in \"Halloween H20\"?";
NORMAL_TRIVIA_ANSWERS1[160] = "Janet Leigh";
NORMAL_TRIVIA_ANSWERS2[160] = "leigh";

NORMAL_TRIVIA_QUESTIONS[161] = "(Characters): What was the name of the hero (Bruce Campbell) in the \"The Evil Dead\" trilogy?";
NORMAL_TRIVIA_ANSWERS1[161] = "Ash";

NORMAL_TRIVIA_QUESTIONS[162] = "(General Knowledge): What was Norman Bates' hobby in \"Psycho\"?";
NORMAL_TRIVIA_ANSWERS1[162] = "taxidermy";
NORMAL_TRIVIA_ANSWERS2[162] = "taxadermy";

NORMAL_TRIVIA_QUESTIONS[163] = "(Complete The Quote): Complete this quote from the monster in Frankenstein: \"Fire...\"";
NORMAL_TRIVIA_ANSWERS1[163] = "bad!";
NORMAL_TRIVIA_ANSWERS2[163] = "bad";

NORMAL_TRIVIA_QUESTIONS[164] = "(Monsters): In \"From Dusk Til Dawn\", the \"heroes\" stumble into a nightclub full of what?";
NORMAL_TRIVIA_ANSWERS1[164] = "vampires";

NORMAL_TRIVIA_QUESTIONS[165] = "(Characters): What role did Christopher Lee play in Hammer's \"The Curse of Frankenstein\"?";
NORMAL_TRIVIA_ANSWERS1[165] = "monster";

NORMAL_TRIVIA_QUESTIONS[166] = "(General Knowledge): In what city does the interview in \"Interview with the Vampire\" take place?";
NORMAL_TRIVIA_ANSWERS1[166] = "San Fransisco";
NORMAL_TRIVIA_ANSWERS2[166] = "san fran";

NORMAL_TRIVIA_QUESTIONS[167] = "(Horror Roles): What television star played the title role in 1985's \"Teen Wolf\"?";
NORMAL_TRIVIA_ANSWERS1[167] = "Michael J. Fox";
NORMAL_TRIVIA_ANSWERS2[167] = "Michael Fox";
NORMAL_TRIVIA_ANSWERS3[167] = "fox";

NORMAL_TRIVIA_QUESTIONS[168] = "(Characters): What character did Vincent Price play in \"Abbott and Costello meet Frankenstein\"?";
NORMAL_TRIVIA_ANSWERS1[168] = "invisible man";
NORMAL_TRIVIA_ANSWERS2[168] = "invisable man";

NORMAL_TRIVIA_QUESTIONS[169] = "(General Knowledge): What was \"The Munsters\"'s street address?";
NORMAL_TRIVIA_ANSWERS1[169] = "1313 Mockingbird Lane";

NORMAL_TRIVIA_QUESTIONS[170] = "(Horror Roles): Who played Dracula in \"Love at First Bite\"?";
NORMAL_TRIVIA_ANSWERS1[170] = "George Hamilton";
NORMAL_TRIVIA_ANSWERS2[170] = "hamilton";

NORMAL_TRIVIA_QUESTIONS[171] = "(Monsters): What was the name of the clown in Stephen King's \"IT\"?";
NORMAL_TRIVIA_ANSWERS1[171] = "pennywise";
NORMAL_TRIVIA_ANSWERS2[171] = "penny wise";

NORMAL_TRIVIA_QUESTIONS[172] = "(Characters): What was the name of the scientist that accidentally had his dna mixed with that of a fly in the 1986 remake of \"The Fly\"?";
NORMAL_TRIVIA_ANSWERS1[172] = "Seth Brundle";
NORMAL_TRIVIA_ANSWERS2[172] = "brundle";

NORMAL_TRIVIA_QUESTIONS[173] = "(Complete The Quote): Complete this quote: \"Enter freely, of your own will, and leave some of the...\"";
NORMAL_TRIVIA_ANSWERS1[173] = "happiness you bring";

NORMAL_TRIVIA_QUESTIONS[174] = "(General Knowledge): Michael Myers' mask in \"Halloween\" was made from the novelty Halloween mask of what well-known actor?";
NORMAL_TRIVIA_ANSWERS1[174] = "William Shatner";
NORMAL_TRIVIA_ANSWERS2[174] = "Shatner";
NORMAL_TRIVIA_ANSWERS3[174] = "schatner";

NORMAL_TRIVIA_QUESTIONS[175] = "(Horror Roles): Who played the title character in the \"Leprechaun\" series?";
NORMAL_TRIVIA_ANSWERS1[175] = "Warwick Davis";
NORMAL_TRIVIA_ANSWERS2[175] = "davis";

NORMAL_TRIVIA_QUESTIONS[176] = "(Characters): What was the name of the \"faithful handyman\" in \"The Rocky Horror Picture Show\"?";
NORMAL_TRIVIA_ANSWERS1[176] = "Riff Raff";
NORMAL_TRIVIA_ANSWERS2[176] = "riffraff";

NORMAL_TRIVIA_QUESTIONS[177] = "(General Knowledge): How many blades were on Freddy Kruger's glove?";
NORMAL_TRIVIA_ANSWERS1[177] = "4";
NORMAL_TRIVIA_ANSWERS2[177] = "four";

NORMAL_TRIVIA_QUESTIONS[178] = "(Horror Roles): Who played the title character in 1921's \"Nosferatu\". (hint: the name was later used for one of the villians in \"Batman Returns\")";
NORMAL_TRIVIA_ANSWERS1[178] = "Max Shreck";
NORMAL_TRIVIA_ANSWERS2[178] = "shreck";

NORMAL_TRIVIA_QUESTIONS[179] = "(General Knowledge): Who was unsuccessfully sued by \"Vampira\" for character copyright infringement?";
NORMAL_TRIVIA_ANSWERS1[179] = "Elvira";

NORMAL_TRIVIA_QUESTIONS[180] = "(General Knowledge): What was the last movie that Bela Lugosi appeared in?";
NORMAL_TRIVIA_ANSWERS1[180] = "Plan 9 from Outer Space";

NORMAL_TRIVIA_QUESTIONS[181] = "(BlackHistory): In 1957 President Eisenhower sent federal troops to intervene for 9 black students trying to enter Central High School for classes in what city?";
NORMAL_TRIVIA_ANSWERS1[181] = "Little Rock, Arkansas";
NORMAL_TRIVIA_ANSWERS2[181] = "Little Rock";

NORMAL_TRIVIA_QUESTIONS[182] = "(BlackHistory): Who was the Alabama govenor that physically blocked 2 black students from registering for classes at the University of Alabama in 1963?";
NORMAL_TRIVIA_ANSWERS1[182] = "George Wallace";
NORMAL_TRIVIA_ANSWERS2[182] = "Wallace";

NORMAL_TRIVIA_QUESTIONS[183] = "(BlackHistory): Generally considered the mother of the Civil Rights Movement, in 1955 this courageous lady refused to give up her seat on a bus to a white man in Montgomery, Alabama. ";
NORMAL_TRIVIA_ANSWERS1[183] = "Rosa Parks";

NORMAL_TRIVIA_QUESTIONS[184] = "(BlackHistory): Sent out by the Congress of Racial Equality in 1961, these student volunteers went on bus trips to test the new laws prohibiting segregation in interstate travel facilities. What were they called?";
NORMAL_TRIVIA_ANSWERS1[184] = "Freedom Riders";

NORMAL_TRIVIA_QUESTIONS[185] = "(BlackHistory): In August, 1963, Martin Luther King, Jr. gave a speech to 250,000 listeners in front of the Lincoln Memorial. What title is this speech commonly know by? ";
NORMAL_TRIVIA_ANSWERS1[185] = "I Have A Dream";

NORMAL_TRIVIA_QUESTIONS[186] = "(BlackHistory): In what year did President Lyndon Johnson sign the Civil Rights Act making segregation in public facilities and discrimination in employment illegal?";
NORMAL_TRIVIA_ANSWERS1[186] = "1964";
NORMAL_TRIVIA_ANSWERS2[186] = "nineteen sixty-four";

NORMAL_TRIVIA_QUESTIONS[187] = "(BlackHistory): A peacful march from Selma to Montgomery, Alabama in support of voting rights for Blacks was blocked by police using tear gas, whips and clubs. The media dubbed this incident with what title?";
NORMAL_TRIVIA_ANSWERS1[187] = "Bloody Sunday";

NORMAL_TRIVIA_QUESTIONS[188] = "(BlackHistory): The Reverend Martin Luther King, Jr., at age 39, was shot in Memphis, Tennessee in what month and year?";
NORMAL_TRIVIA_ANSWERS1[188] = "April 1968";

NORMAL_TRIVIA_QUESTIONS[189] = "(BlackHistory): What Amendment to the Constitution, made into law on February 3, 1870, granted Black Americans the right to vote?";
NORMAL_TRIVIA_ANSWERS1[189] = "15th";
NORMAL_TRIVIA_ANSWERS2[189] = "15";
NORMAL_TRIVIA_ANSWERS3[189] = "fifteenth";

NORMAL_TRIVIA_QUESTIONS[190] = "(BlackHistory): Noted Black American intellectual and civil rights activist W.E.B. DuBois was a founding member of which organization in 1909?";
NORMAL_TRIVIA_ANSWERS1[190] = "National Association for the Advancement of Colored People";
NORMAL_TRIVIA_ANSWERS2[190] = "NAACP";

NORMAL_TRIVIA_QUESTIONS[191] = "(BlackHistory): Who was propelled to national prominence as a leader of the civil rights movement when he led a boycott against Montgomery's segregated city bus lines?";
NORMAL_TRIVIA_ANSWERS1[191] = "Martin Luther King, Jr.";
NORMAL_TRIVIA_ANSWERS2[191] = "Martin Luther King";
NORMAL_TRIVIA_ANSWERS3[191] = "King";

NORMAL_TRIVIA_QUESTIONS[192] = "(BlackHistory): What coveted award did Martin Luther King, Jr. receive in 1964 for his philosophy of nonviolent resistance?";
NORMAL_TRIVIA_ANSWERS1[192] = "Nobel Peace Prize";
NORMAL_TRIVIA_ANSWERS2[192] = "Nobel";

NORMAL_TRIVIA_QUESTIONS[193] = "(BlackHistory): Who was the first Black American to win an Academy Award?";
NORMAL_TRIVIA_ANSWERS1[193] = "Hattie McDaniel";
NORMAL_TRIVIA_ANSWERS2[193] = "McDaniel";

NORMAL_TRIVIA_QUESTIONS[194] = "(BlackHistory): The Harlem Renaissance, a period of artistic flowering among Black American writers and artists that was centered in Harlem, occurred roughly during which decade?";
NORMAL_TRIVIA_ANSWERS1[194] = "1920s";
NORMAL_TRIVIA_ANSWERS2[194] = "1920";
NORMAL_TRIVIA_ANSWERS3[194] = "nineteen twenties";

NORMAL_TRIVIA_QUESTIONS[195] = "(BlackHistory): Which Black American entertainer was the first to star in his own television series?";
NORMAL_TRIVIA_ANSWERS1[195] = "Nat King Cole";
NORMAL_TRIVIA_ANSWERS2[195] = "Cole";

NORMAL_TRIVIA_QUESTIONS[196] = "(BlackHistory): Credited with breaking the \"color barrier\" in baseball by becoming the first Black American to play in the major leagues, Jackie Robinson played for which team?";
NORMAL_TRIVIA_ANSWERS1[196] = "Brooklyn Dodgers";
NORMAL_TRIVIA_ANSWERS2[196] = "Dodgers";

NORMAL_TRIVIA_QUESTIONS[197] = "(BlackHistory): Who was the first player from the Negro Leagues to be elected to Baseball's Hall of Fame?";
NORMAL_TRIVIA_ANSWERS1[197] = "Leroy Robert \"Satchel\" Paige";
NORMAL_TRIVIA_ANSWERS2[197] = "Satchel";
NORMAL_TRIVIA_ANSWERS3[197] = "Paige";

NORMAL_TRIVIA_QUESTIONS[198] = "(Geography): Which mountains is the range where vicunas live?";
NORMAL_TRIVIA_ANSWERS1[198] = "The Andes";
NORMAL_TRIVIA_ANSWERS2[198] = "Andes";

NORMAL_TRIVIA_QUESTIONS[199] = "(History): Who was the first woman to win a Nobel Prize?";
NORMAL_TRIVIA_ANSWERS1[199] = "Marie Curie";
NORMAL_TRIVIA_ANSWERS2[199] = "Madam Curie";
NORMAL_TRIVIA_ANSWERS3[199] = "Madame Curie";

NORMAL_TRIVIA_QUESTIONS[200] = "(Literature): Who wrote LES MISERABLES?";
NORMAL_TRIVIA_ANSWERS1[200] = "Victor Hugo";
NORMAL_TRIVIA_ANSWERS2[200] = "Hugo";

NORMAL_TRIVIA_QUESTIONS[201] = "(Literature): Who wrote PETER PAN?";
NORMAL_TRIVIA_ANSWERS1[201] = "J. M. Barrie";
NORMAL_TRIVIA_ANSWERS2[201] = "Barrie";

NORMAL_TRIVIA_QUESTIONS[202] = "(History): Who was Israel's first prime minister?";
NORMAL_TRIVIA_ANSWERS1[202] = "David Ben-Gurion";
NORMAL_TRIVIA_ANSWERS2[202] = "Ben-Gurion";
NORMAL_TRIVIA_ANSWERS3[202] = "Ben Gurion";

NORMAL_TRIVIA_QUESTIONS[203] = "(Literature): What was the pen name of Charles Dodgson?";
NORMAL_TRIVIA_ANSWERS1[203] = "Lewis Carroll";
NORMAL_TRIVIA_ANSWERS2[203] = "Carroll";

NORMAL_TRIVIA_QUESTIONS[204] = "(TheWorld): Who is the current leader of Cuba?";
NORMAL_TRIVIA_ANSWERS1[204] = "Fidel Castro";
NORMAL_TRIVIA_ANSWERS2[204] = "Castro";

NORMAL_TRIVIA_QUESTIONS[205] = "(Literature): Who wrote DON QUIXOTE?";
NORMAL_TRIVIA_ANSWERS1[205] = "Miguel de Cervantes";
NORMAL_TRIVIA_ANSWERS2[205] = "de Cervantes";
NORMAL_TRIVIA_ANSWERS3[205] = "Cervantes";

NORMAL_TRIVIA_QUESTIONS[206] = "(History): Who lead the Indians at the battle of Little Bighorn?";
NORMAL_TRIVIA_ANSWERS1[206] = "Chief Sitting Bull";
NORMAL_TRIVIA_ANSWERS2[206] = "Sitting Bull";

NORMAL_TRIVIA_QUESTIONS[207] = "(History): Who took his army over the Alps in 221 B.C.?";
NORMAL_TRIVIA_ANSWERS1[207] = "Hannibal";

NORMAL_TRIVIA_QUESTIONS[208] = "(Literature): Who wrote WINNIE THE POOH?";
NORMAL_TRIVIA_ANSWERS1[208] = "A. A. Milne";
NORMAL_TRIVIA_ANSWERS2[208] = "A.A. Milne";
NORMAL_TRIVIA_ANSWERS3[208] = "Milne";

NORMAL_TRIVIA_QUESTIONS[209] = "(History): Who \"fiddled\" while Rome burned?";
NORMAL_TRIVIA_ANSWERS1[209] = "Nero";

NORMAL_TRIVIA_QUESTIONS[210] = "(Literature): Who wrote the novel NINETEEN EIGHTY-FOUR?";
NORMAL_TRIVIA_ANSWERS1[210] = "George Orwell";
NORMAL_TRIVIA_ANSWERS2[210] = "Orwell";

NORMAL_TRIVIA_QUESTIONS[211] = "(Science&Nature): What is Wilhelm Rontgen known for discovering?";
NORMAL_TRIVIA_ANSWERS1[211] = "X-rays";
NORMAL_TRIVIA_ANSWERS2[211] = "x rays";

NORMAL_TRIVIA_QUESTIONS[212] = "(History): In 1483 Torquemada was placed in charge of what?";
NORMAL_TRIVIA_ANSWERS1[212] = "The Spanish Inquistion";
NORMAL_TRIVIA_ANSWERS2[212] = "The Inquisition";

NORMAL_TRIVIA_QUESTIONS[213] = "(Geography): Panama was originally a province of what country?";
NORMAL_TRIVIA_ANSWERS1[213] = "Columbia";

NORMAL_TRIVIA_QUESTIONS[214] = "(History): In what year did the Bahamas become a formal British colony?";
NORMAL_TRIVIA_ANSWERS1[214] = "1783";

NORMAL_TRIVIA_QUESTIONS[215] = "(History): When did the Bahamas become independant?";
NORMAL_TRIVIA_ANSWERS1[215] = "July 10, 1973";
NORMAL_TRIVIA_ANSWERS2[215] = "1973";

NORMAL_TRIVIA_QUESTIONS[216] = "(Geography): What is the capital of Brazil?";
NORMAL_TRIVIA_ANSWERS1[216] = "Brasilia";

NORMAL_TRIVIA_QUESTIONS[217] = "(History): What country is Europe's oldest kingdom?";
NORMAL_TRIVIA_ANSWERS1[217] = "Denmark";

NORMAL_TRIVIA_QUESTIONS[218] = "(History): In what year did East and West Germany re-unite?";
NORMAL_TRIVIA_ANSWERS1[218] = "1990";

NORMAL_TRIVIA_QUESTIONS[219] = "(Holidays): When is Bastille Day celebrated?";
NORMAL_TRIVIA_ANSWERS1[219] = "July 14 (1789)";
NORMAL_TRIVIA_ANSWERS2[219] = "July 14";

NORMAL_TRIVIA_QUESTIONS[220] = "(History): What country has the Grimaldi family ruled since the 13th century?";
NORMAL_TRIVIA_ANSWERS1[220] = "Monaco";

NORMAL_TRIVIA_QUESTIONS[221] = "(TheWorld): Which country has the only flag which is NOT rectangular or square?";
NORMAL_TRIVIA_ANSWERS1[221] = "Nepal (it has 2 connected triangles";
NORMAL_TRIVIA_ANSWERS2[221] = "Nepal";

NORMAL_TRIVIA_QUESTIONS[222] = "(TheWorld): How many stars are there on the Austrailian flag?";
NORMAL_TRIVIA_ANSWERS1[222] = "6 (5 for the Southern Cross and 1 Commonwealth star)";
NORMAL_TRIVIA_ANSWERS2[222] = "6";
NORMAL_TRIVIA_ANSWERS3[222] = "six";

NORMAL_TRIVIA_QUESTIONS[223] = "(UnitedStates): What state is the Mayo Clinic located in?";
NORMAL_TRIVIA_ANSWERS1[223] = "Minnesota, USA";
NORMAL_TRIVIA_ANSWERS2[223] = "Minnesota";

NORMAL_TRIVIA_QUESTIONS[224] = "(Arts&Entertainment): Barry Humphries is better known under what name?";
NORMAL_TRIVIA_ANSWERS1[224] = "Dame Edna";

NORMAL_TRIVIA_QUESTIONS[225] = "(Science&Nature): In the sequence 2, 3, 5, 7, 11, 13, what number comes next?";
NORMAL_TRIVIA_ANSWERS1[225] = "17";
NORMAL_TRIVIA_ANSWERS2[225] = "seventeen";

NORMAL_TRIVIA_QUESTIONS[226] = "(UnitedStates): Who was the first woman Supreme Court Justice in the U.S.?";
NORMAL_TRIVIA_ANSWERS1[226] = "Sandra Day O'Connor";
NORMAL_TRIVIA_ANSWERS2[226] = "O'Connor";

NORMAL_TRIVIA_QUESTIONS[227] = "(History): Who was the first person to reach the South Pole?";
NORMAL_TRIVIA_ANSWERS1[227] = "Roald Amundsen (on Dec 13, 1911)";
NORMAL_TRIVIA_ANSWERS2[227] = "Amundsen";

NORMAL_TRIVIA_QUESTIONS[228] = "(History): When did Henry VIII rule?";
NORMAL_TRIVIA_ANSWERS1[228] = "1509 - 1547";

NORMAL_TRIVIA_QUESTIONS[229] = "(History): Which family ruled Russia from 1613 to 1917?";
NORMAL_TRIVIA_ANSWERS1[229] = "Romanov";

NORMAL_TRIVIA_QUESTIONS[230] = "(Arts&Entertainment): What are the names of Donald Duck's nephews?";
NORMAL_TRIVIA_ANSWERS1[230] = "Huey, Dewey, and Louie";
NORMAL_TRIVIA_ANSWERS2[230] = "Huey Dewey Louie";

NORMAL_TRIVIA_QUESTIONS[231] = "(Science&Nature): How many of our years does it take for Pluto to circle the sun once?";
NORMAL_TRIVIA_ANSWERS1[231] = "248 earth years";
NORMAL_TRIVIA_ANSWERS2[231] = "248";
NORMAL_TRIVIA_ANSWERS3[231] = "two hundred forty-eight";

NORMAL_TRIVIA_QUESTIONS[232] = "(TheWorld): What is the capital of Nova Scotia, Canada?";
NORMAL_TRIVIA_ANSWERS1[232] = "Halifax";

NORMAL_TRIVIA_QUESTIONS[233] = "(Science&Nature): Which animal kills more people per year, world wide, than any other?";
NORMAL_TRIVIA_ANSWERS1[233] = "snakes";

NORMAL_TRIVIA_QUESTIONS[234] = "(UnitedStates): What year was the first U.S. census taken?";
NORMAL_TRIVIA_ANSWERS1[234] = "1790";

NORMAL_TRIVIA_QUESTIONS[235] = "(TheWorld): Which country uses a Tugrik for money?";
NORMAL_TRIVIA_ANSWERS1[235] = "Mongolia";

NORMAL_TRIVIA_QUESTIONS[236] = "(TheWorld): In which country is Pashto and Dari spoken?";
NORMAL_TRIVIA_ANSWERS1[236] = "Afghanistan";

NORMAL_TRIVIA_QUESTIONS[237] = "(TheWorld): Which country uses a Yen for money?";
NORMAL_TRIVIA_ANSWERS1[237] = "Japan";

NORMAL_TRIVIA_QUESTIONS[238] = "(Arts&Entertainment): Which singer's fans are called Parrot Heads?";
NORMAL_TRIVIA_ANSWERS1[238] = "Jimmy Buffett";
NORMAL_TRIVIA_ANSWERS2[238] = "Buffett";

NORMAL_TRIVIA_QUESTIONS[239] = "(Literature): In the book and movie titled FAIL SAFE which two cities are bombed?";
NORMAL_TRIVIA_ANSWERS1[239] = "Moscow and New York";
NORMAL_TRIVIA_ANSWERS2[239] = "Moscow & New York";
NORMAL_TRIVIA_ANSWERS3[239] = "New York and Moscow";

NORMAL_TRIVIA_QUESTIONS[240] = "(World): What country was hit by a devastating earthquake on August 17, 1999, killing at least 16,000 people?";
NORMAL_TRIVIA_ANSWERS1[240] = "Turkey";

NORMAL_TRIVIA_QUESTIONS[241] = "(Science&Nature): What caused West Virginia and portions of 5 other states to be declared disaster areas in the summer of 1999?";
NORMAL_TRIVIA_ANSWERS1[241] = "drought";

NORMAL_TRIVIA_QUESTIONS[242] = "(Science&Nature): The oldest person to ever travel through space landed at Cape Canaveral Nov 7th, 1998 after a 10 day mission. Who was this person?";
NORMAL_TRIVIA_ANSWERS1[242] = "John Glenn";
NORMAL_TRIVIA_ANSWERS2[242] = "Glenn";

NORMAL_TRIVIA_QUESTIONS[243] = "(UnitedStates): For the 3rd time in less than 2 months, what did the Federal Reserve Board announce on November 17, 1998?";
NORMAL_TRIVIA_ANSWERS1[243] = "A cut in interest rates";
NORMAL_TRIVIA_ANSWERS2[243] = "lowered interest rates";
NORMAL_TRIVIA_ANSWERS3[243] = "cut interest";

NORMAL_TRIVIA_QUESTIONS[244] = "(World): On Nov 15, 1998 bombers were called back from an aerial assault on what country after it again conceeded to allow inspections by the UN Special Commission?";
NORMAL_TRIVIA_ANSWERS1[244] = "Iraq";

NORMAL_TRIVIA_QUESTIONS[245] = "(World): Attempts to register what political party in China have caused harassment of it's supporters by Chinese authorities?";
NORMAL_TRIVIA_ANSWERS1[245] = "China Democratic Party";

NORMAL_TRIVIA_QUESTIONS[246] = "(Nature&Science): What plowed through Central America in late October 1998 causing wide-spread devastation?";
NORMAL_TRIVIA_ANSWERS1[246] = "Hurricane Mitch";
NORMAL_TRIVIA_ANSWERS2[246] = "Mitch";

NORMAL_TRIVIA_QUESTIONS[247] = "(World): What 2 oil-industry giants announced plans to merge on December 1, 1998?";
NORMAL_TRIVIA_ANSWERS1[247] = "Mobil and Exxon";
NORMAL_TRIVIA_ANSWERS2[247] = "Exxon and Mobil";

NORMAL_TRIVIA_QUESTIONS[248] = "(World): Ceeded to the United States by the 1898 Treaty of Paris, what country's people were given the opportunity to express their preference as to the country's future political status on December 13, 1998?";
NORMAL_TRIVIA_ANSWERS1[248] = "Puerto Rico";

NORMAL_TRIVIA_QUESTIONS[249] = "(History): What do Nara, Fujiwara and Edo have in common?";
NORMAL_TRIVIA_ANSWERS1[249] = "They are all Japanese historical periods";
NORMAL_TRIVIA_ANSWERS2[249] = "Japan historical periods";
NORMAL_TRIVIA_ANSWERS3[249] = "historical eras";

NORMAL_TRIVIA_QUESTIONS[250] = "(History): In what year did Napoleon abdicate the throne of France?";
NORMAL_TRIVIA_ANSWERS1[250] = "1814";

NORMAL_TRIVIA_QUESTIONS[251] = "(Computers): What was the most visited website in 1999?";
NORMAL_TRIVIA_ANSWERS1[251] = "www.yahoo.com";
NORMAL_TRIVIA_ANSWERS2[251] = "yahoo";

NORMAL_TRIVIA_QUESTIONS[252] = "(World): In what country would you find Seikan; the world's longest railroad tunnel?";
NORMAL_TRIVIA_ANSWERS1[252] = "Japan";

NORMAL_TRIVIA_QUESTIONS[253] = "(World): What country is the Aswan High Dam in?";
NORMAL_TRIVIA_ANSWERS1[253] = "Egypt";

NORMAL_TRIVIA_QUESTIONS[254] = "(Geography): Which country is also a continent?";
NORMAL_TRIVIA_ANSWERS1[254] = "Australia";

NORMAL_TRIVIA_QUESTIONS[255] = "(History): True or false:  French was never the official language of England.";
NORMAL_TRIVIA_ANSWERS1[255] = "False. French was the official language for over 600 years.";
NORMAL_TRIVIA_ANSWERS2[255] = "False";

NORMAL_TRIVIA_QUESTIONS[256] = "(UnitedStates): Which is the only state that grows coffee?";
NORMAL_TRIVIA_ANSWERS1[256] = "Hawaii";

NORMAL_TRIVIA_QUESTIONS[257] = "(Science&Nature): True or False:  10 percent of professional boxers have suffered brain damage.";
NORMAL_TRIVIA_ANSWERS1[257] = "False, over 80% have suffered brain damage";
NORMAL_TRIVIA_ANSWERS2[257] = "false";

NORMAL_TRIVIA_QUESTIONS[258] = "(Geography): Which well-known Russian city has seen it's name changed 3 times since it was founded in 1703 by Peter the Great?";
NORMAL_TRIVIA_ANSWERS1[258] = "St. Petersburg, Russia";
NORMAL_TRIVIA_ANSWERS2[258] = "St. Petersburg";
NORMAL_TRIVIA_ANSWERS3[258] = "St. Petersberg";

NORMAL_TRIVIA_QUESTIONS[259] = "(Arts&Entertainment): Of the 7 dwarfs in 'Snow White and The Seven Dwarfs', which one is the only beardless one?";
NORMAL_TRIVIA_ANSWERS1[259] = "Dopey";

NORMAL_TRIVIA_QUESTIONS[260] = "(Language): True or false:  The word 'karate' means 'empty hand'.";
NORMAL_TRIVIA_ANSWERS1[260] = "True";

NORMAL_TRIVIA_QUESTIONS[261] = "(Geography): Which country is the world's leading importer of iron ore?";
NORMAL_TRIVIA_ANSWERS1[261] = "Japan";

NORMAL_TRIVIA_QUESTIONS[262] = "(History): What year was the Republic of Israel established, 1933, 1948, 1957 or 1966?";
NORMAL_TRIVIA_ANSWERS1[262] = "1948";

NORMAL_TRIVIA_QUESTIONS[263] = "(Geography): How many cities in the world boast populations in excess of 1 million people; over 50, over 200, over 300 or over 400?";
NORMAL_TRIVIA_ANSWERS1[263] = "over 300";
NORMAL_TRIVIA_ANSWERS2[263] = "over three hundred";
NORMAL_TRIVIA_ANSWERS3[263] = "300";

NORMAL_TRIVIA_QUESTIONS[264] = "(Mythology): Who was the Greek goddess of victory?";
NORMAL_TRIVIA_ANSWERS1[264] = "Nike";

NORMAL_TRIVIA_QUESTIONS[265] = "(UnitedStates): What city is the oldest one in the United States?";
NORMAL_TRIVIA_ANSWERS1[265] = "St. Augustine, Florida";
NORMAL_TRIVIA_ANSWERS2[265] = "St. Augustine";
NORMAL_TRIVIA_ANSWERS3[265] = "Saint Augustine";

NORMAL_TRIVIA_QUESTIONS[266] = "(Science&Nature): What continent is the only one on Earth that has no reptiles or snakes?";
NORMAL_TRIVIA_ANSWERS1[266] = "Antarctica";

NORMAL_TRIVIA_QUESTIONS[267] = "(Science&Nature): What breed of dog bites more humans than any other breed?";
NORMAL_TRIVIA_ANSWERS1[267] = "German Shepherds";
NORMAL_TRIVIA_ANSWERS2[267] = "german sheperd";
NORMAL_TRIVIA_ANSWERS3[267] = "german shepard";

NORMAL_TRIVIA_QUESTIONS[268] = "(Science&Nature): True or false:  Adolescent male crickets can chirp.";
NORMAL_TRIVIA_ANSWERS1[268] = "False";

NORMAL_TRIVIA_QUESTIONS[269] = "(Science&Nature): The blood of mammals is red.  What color is a lobster's blood?";
NORMAL_TRIVIA_ANSWERS1[269] = "blue";

NORMAL_TRIVIA_QUESTIONS[270] = "(Arts&Entertainment): What cartoon character says \"DOH\"?";
NORMAL_TRIVIA_ANSWERS1[270] = "Homer Simpson";
NORMAL_TRIVIA_ANSWERS2[270] = "Homer";

NORMAL_TRIVIA_QUESTIONS[271] = "(Arts&Entertainment): True or false:  In the movie, 'The Wizard Of Oz', Dorothy's 3 companions were looking for a heart, a brain and a glass slipper.";
NORMAL_TRIVIA_ANSWERS1[271] = "False";

NORMAL_TRIVIA_QUESTIONS[272] = "(Languages): What is the world's most widely spoken language?";
NORMAL_TRIVIA_ANSWERS1[272] = "the Mandarin dialect of Chinese";
NORMAL_TRIVIA_ANSWERS2[272] = "Chinese";
NORMAL_TRIVIA_ANSWERS3[272] = "Mandarin";

NORMAL_TRIVIA_QUESTIONS[273] = "(Geography): Which large, well-known Central American city is sinking at the rate of 6 to 8 inches per year?";
NORMAL_TRIVIA_ANSWERS1[273] = "Mexico City";

NORMAL_TRIVIA_QUESTIONS[274] = "(Science&Nature): If offered a new pen to write with, what will 97% of people do with it?";
NORMAL_TRIVIA_ANSWERS1[274] = "write their own name";
NORMAL_TRIVIA_ANSWERS2[274] = "write name";
NORMAL_TRIVIA_ANSWERS3[274] = "write their name0";

NORMAL_TRIVIA_QUESTIONS[275] = "(Science&Nature): The average person has a vocabulary of 1,000 to 2,000, 3,000 to 4,000, or 5,000 to 6,000 words?";
NORMAL_TRIVIA_ANSWERS1[275] = "5,000 to 6,000";
NORMAL_TRIVIA_ANSWERS2[275] = "five thousand to six thousand";
NORMAL_TRIVIA_ANSWERS3[275] = " 5 to 6 thousand";

NORMAL_TRIVIA_QUESTIONS[276] = "(Geography): Which one of Earth's oceans is mostly covered by solid ice, ice floes and icebergs?";
NORMAL_TRIVIA_ANSWERS1[276] = "Arctic Ocean";
NORMAL_TRIVIA_ANSWERS2[276] = "Arctic";

NORMAL_TRIVIA_QUESTIONS[277] = "(Science&Nature): About how many feet of earth could an ambitious mole tunnel through in one day; 20 feet, 100 feet, 200 feet or 300 feet?";
NORMAL_TRIVIA_ANSWERS1[277] = "300 feet";
NORMAL_TRIVIA_ANSWERS2[277] = "300";
NORMAL_TRIVIA_ANSWERS3[277] = "three hundred";

NORMAL_TRIVIA_QUESTIONS[278] = "(Science&Nature): The blood of mammals is red.  What color is insect's blood?";
NORMAL_TRIVIA_ANSWERS1[278] = "yellow";

NORMAL_TRIVIA_QUESTIONS[279] = "(Science&Nature): What does a speleologist study?";
NORMAL_TRIVIA_ANSWERS1[279] = "studies caves";
NORMAL_TRIVIA_ANSWERS2[279] = "caves";
NORMAL_TRIVIA_ANSWERS3[279] = "cave";

NORMAL_TRIVIA_QUESTIONS[280] = "(UnitedStates): Which product is more money spent on per year, baby food or pet food?";
NORMAL_TRIVIA_ANSWERS1[280] = "pet food";
NORMAL_TRIVIA_ANSWERS2[280] = "pet";

NORMAL_TRIVIA_QUESTIONS[281] = "(Geography): Can you name the largest island in the world?";
NORMAL_TRIVIA_ANSWERS1[281] = "Greenland, at 840,000 square miles";
NORMAL_TRIVIA_ANSWERS2[281] = "greenland";

NORMAL_TRIVIA_QUESTIONS[282] = "(Geography): True or false:  In Paraguay dueling is still legal as long as both parties are registered blood donors.";
NORMAL_TRIVIA_ANSWERS1[282] = "True";

NORMAL_TRIVIA_QUESTIONS[283] = "(Geography): What city in the world was the first one to reach the population of 1 million people?";
NORMAL_TRIVIA_ANSWERS1[283] = "Rome, Italy in 133 B.C.";
NORMAL_TRIVIA_ANSWERS2[283] = "Rome";

NORMAL_TRIVIA_QUESTIONS[284] = "(Geography): True or false:  Michigan's Great Lakes are the largest group of freshwater lakes in the world.";
NORMAL_TRIVIA_ANSWERS1[284] = "True";

NORMAL_TRIVIA_QUESTIONS[285] = "(History): To date, who has been the only American president to win non-consecutive terms to the White House?";
NORMAL_TRIVIA_ANSWERS1[285] = "President Grover Cleveland";
NORMAL_TRIVIA_ANSWERS2[285] = "Cleveland";

NORMAL_TRIVIA_QUESTIONS[286] = "(UnitedStates): In area, which city is larger, Los Angeles, California or Juneau, Alaska?";
NORMAL_TRIVIA_ANSWERS1[286] = "Juneau, Alaska";
NORMAL_TRIVIA_ANSWERS2[286] = "Juneau";

NORMAL_TRIVIA_QUESTIONS[287] = "(Science&Nature): How much of the world's population is left-handed, 5 percent, 10 percent, 15 percent or 20 percent?";
NORMAL_TRIVIA_ANSWERS1[287] = "10 percent";
NORMAL_TRIVIA_ANSWERS2[287] = "ten percent";
NORMAL_TRIVIA_ANSWERS3[287] = "10%";

NORMAL_TRIVIA_QUESTIONS[288] = "(Science&Nature): How many times a day does an average adult person laugh, 10 times, 15 times, 20 times or 25 times?";
NORMAL_TRIVIA_ANSWERS1[288] = "15 times";
NORMAL_TRIVIA_ANSWERS2[288] = "15";

NORMAL_TRIVIA_QUESTIONS[289] = "(Science&Nature): What insect is known for being a carrier of malaria, encephalitis, yellow fever and dengue fever?";
NORMAL_TRIVIA_ANSWERS1[289] = "mosquitos";
NORMAL_TRIVIA_ANSWERS2[289] = "mosquito";

NORMAL_TRIVIA_QUESTIONS[290] = "(Science&Nature): Which part of your body accounts for one quarter of the bones your body contains?";
NORMAL_TRIVIA_ANSWERS1[290] = "your feet";
NORMAL_TRIVIA_ANSWERS2[290] = "feet";
NORMAL_TRIVIA_ANSWERS3[290] = "foot";

NORMAL_TRIVIA_QUESTIONS[291] = "(Science&Nature): What does a person with hexidectylism have?";
NORMAL_TRIVIA_ANSWERS1[291] = "six fingers or six toes";
NORMAL_TRIVIA_ANSWERS2[291] = "6 fingers";
NORMAL_TRIVIA_ANSWERS3[291] = "6 toes";

NORMAL_TRIVIA_QUESTIONS[292] = "(Geography): What country's name is a Native American Indian word meaning 'Big Village'?";
NORMAL_TRIVIA_ANSWERS1[292] = "Canada";

NORMAL_TRIVIA_QUESTIONS[293] = "(Geography): Over which waterfall does the most water flow over per year?";
NORMAL_TRIVIA_ANSWERS1[293] = "Niagara Falls";
NORMAL_TRIVIA_ANSWERS2[293] = "Niagara";

NORMAL_TRIVIA_QUESTIONS[294] = "(Geography): Which large island is 3 times the size of Texas?";
NORMAL_TRIVIA_ANSWERS1[294] = "Greenland";

NORMAL_TRIVIA_QUESTIONS[295] = "(Geography): Which county in Great Britain is the only one that has 2 coasts?";
NORMAL_TRIVIA_ANSWERS1[295] = "Devon";

NORMAL_TRIVIA_QUESTIONS[296] = "(Geography): Which ocean is the smallest and shallowest?";
NORMAL_TRIVIA_ANSWERS1[296] = "Artic Ocean";
NORMAL_TRIVIA_ANSWERS2[296] = "Artic";

NORMAL_TRIVIA_QUESTIONS[297] = "(Geography): Which ocean is saltier, the Pacific or the Atlantic?";
NORMAL_TRIVIA_ANSWERS1[297] = "Atlantic Ocean";
NORMAL_TRIVIA_ANSWERS2[297] = "Atlantic";

NORMAL_TRIVIA_QUESTIONS[298] = "(Geography): What name was the city of St. Petersburg, Russia given in 1914 because Russian leaders thought it's name sounded too German?";
NORMAL_TRIVIA_ANSWERS1[298] = "Petrograd";

NORMAL_TRIVIA_QUESTIONS[299] = "(Geography): What name was the city of St. Petersburg, Russia given in 1924 to honor the founder of the Soviet Union?";
NORMAL_TRIVIA_ANSWERS1[299] = "Petrograd";

NORMAL_TRIVIA_QUESTIONS[300] = "(Geography): What country's national flag is flown differently depending on if the country is at war or at peace?";
NORMAL_TRIVIA_ANSWERS1[300] = "Philippines";
NORMAL_TRIVIA_ANSWERS2[300] = "Phillipine";
NORMAL_TRIVIA_ANSWERS3[300] = "Phillipines";

NORMAL_TRIVIA_QUESTIONS[301] = "(Geography): What is the highest mountain range in the world?";
NORMAL_TRIVIA_ANSWERS1[301] = "The Himilayas";
NORMAL_TRIVIA_ANSWERS2[301] = "himilayas";
NORMAL_TRIVIA_ANSWERS3[301] = "himilayan";

NORMAL_TRIVIA_QUESTIONS[302] = "(Geography): What body of water does the river Danube empty into?";
NORMAL_TRIVIA_ANSWERS1[302] = "The Black Sea";
NORMAL_TRIVIA_ANSWERS2[302] = "black sea";

NORMAL_TRIVIA_QUESTIONS[303] = "(Geography): Rome was originally built on how many hills?";
NORMAL_TRIVIA_ANSWERS1[303] = "seven";
NORMAL_TRIVIA_ANSWERS2[303] = "7";

NORMAL_TRIVIA_QUESTIONS[304] = "(Geography): What group of islands boasts the 'wettest spot on Earth' because of the rainfall there?";
NORMAL_TRIVIA_ANSWERS1[304] = "The Hawaiian Islands";
NORMAL_TRIVIA_ANSWERS2[304] = "Hawaii";
NORMAL_TRIVIA_ANSWERS3[304] = "Hawaiian";

NORMAL_TRIVIA_QUESTIONS[305] = "(Geography): Name the world's smallest independant state.";
NORMAL_TRIVIA_ANSWERS1[305] = "Vatican City";
NORMAL_TRIVIA_ANSWERS2[305] = "the Vatican";
NORMAL_TRIVIA_ANSWERS3[305] = "Vatican";

NORMAL_TRIVIA_QUESTIONS[306] = "(History): What is the name of the largest building from ancient Rome that survives intact?";
NORMAL_TRIVIA_ANSWERS1[306] = "The Pantheon";
NORMAL_TRIVIA_ANSWERS2[306] = "pantheon";

NORMAL_TRIVIA_QUESTIONS[307] = "(Literature): Who or what was the only one to recognize Odysseus when he arrived home after an absence of 20 years?";
NORMAL_TRIVIA_ANSWERS1[307] = "his dog, Argus";
NORMAL_TRIVIA_ANSWERS2[307] = "his dog";
NORMAL_TRIVIA_ANSWERS3[307] = "dog";

NORMAL_TRIVIA_QUESTIONS[308] = "(Literature): What famous ancient Greek author wrote about the epic journey of Odysseus?";
NORMAL_TRIVIA_ANSWERS1[308] = "Homer";

NORMAL_TRIVIA_QUESTIONS[309] = "(UnitedStates): Which US state has 8 national park sites?";
NORMAL_TRIVIA_ANSWERS1[309] = "Alaska";

NORMAL_TRIVIA_QUESTIONS[310] = "(UnitedStates): Which is larger, the island of Manhattan in New York or Disney World in Orlando, Florida?";
NORMAL_TRIVIA_ANSWERS1[310] = "Disney World in Orlando, Florida";
NORMAL_TRIVIA_ANSWERS2[310] = "Disney World";

NORMAL_TRIVIA_QUESTIONS[311] = "(UnitedStates): Which state is the only one whose name has only one syllable?";
NORMAL_TRIVIA_ANSWERS1[311] = "Maine";

NORMAL_TRIVIA_QUESTIONS[312] = "(UnitedStates): Which of Michigan's 'Great Lakes' lies entirely inside the United States?";
NORMAL_TRIVIA_ANSWERS1[312] = "Lake Michigan";

NORMAL_TRIVIA_QUESTIONS[313] = "(UnitedStates): What is the most important inland waterway in North America?";
NORMAL_TRIVIA_ANSWERS1[313] = "The Great Lakes";
NORMAL_TRIVIA_ANSWERS2[313] = "Great Lakes";

NORMAL_TRIVIA_QUESTIONS[314] = "(Science&Nature): A zebra is which:  black with white stripes or white with black stripes?";
NORMAL_TRIVIA_ANSWERS1[314] = "white with black stripes";
NORMAL_TRIVIA_ANSWERS2[314] = "white with black";
NORMAL_TRIVIA_ANSWERS3[314] = "black on white";

NORMAL_TRIVIA_QUESTIONS[315] = "(Science&Nature): What animal produces the loudest sound of any animal on Earth?";
NORMAL_TRIVIA_ANSWERS1[315] = "the blue whale can whistle at 188 decibels";
NORMAL_TRIVIA_ANSWERS2[315] = "blue whale";

NORMAL_TRIVIA_QUESTIONS[316] = "(Science&Nature): Which animal, cat or dog, has the most vocal sounds?";
NORMAL_TRIVIA_ANSWERS1[316] = "Cats, with over 100";
NORMAL_TRIVIA_ANSWERS2[316] = "cats";

NORMAL_TRIVIA_QUESTIONS[317] = "(Science&Nature): What gossamer-winged insect is the fastest flying of all the insects?";
NORMAL_TRIVIA_ANSWERS1[317] = "Dragonflies";
NORMAL_TRIVIA_ANSWERS2[317] = "dragonfly";

NORMAL_TRIVIA_QUESTIONS[318] = "(Science&Nature): How many worker bees would have to spend their lifetime to produce 1 teaspoon of honey?";
NORMAL_TRIVIA_ANSWERS1[318] = "12";
NORMAL_TRIVIA_ANSWERS2[318] = "twelve";

NORMAL_TRIVIA_QUESTIONS[319] = "(Science&Nature): Which do mosquitos prefer, brunettes or blonds?";
NORMAL_TRIVIA_ANSWERS1[319] = "blonds";

NORMAL_TRIVIA_QUESTIONS[320] = "(Science&Nature): Which do mosquitos prefer, children or adults?";
NORMAL_TRIVIA_ANSWERS1[320] = "children";

NORMAL_TRIVIA_QUESTIONS[321] = "(Science&Nature): What part of the mosquito does citronella bother the most?";
NORMAL_TRIVIA_ANSWERS1[321] = "their feet";
NORMAL_TRIVIA_ANSWERS2[321] = "feet";

NORMAL_TRIVIA_QUESTIONS[322] = "(Science&Nature): Herbivorous means only plants are eaten for food.  What word means anything is eaten for food?";
NORMAL_TRIVIA_ANSWERS1[322] = "omnivorous";

NORMAL_TRIVIA_QUESTIONS[323] = "(Science&Nature): What is the world's largest living bird?";
NORMAL_TRIVIA_ANSWERS1[323] = "adult male ostrich";
NORMAL_TRIVIA_ANSWERS2[323] = "ostrich";

NORMAL_TRIVIA_QUESTIONS[324] = "(Sports&Leisure*G*): What profession is troubled by the most workplace violence?";
NORMAL_TRIVIA_ANSWERS1[324] = "Police officers";
NORMAL_TRIVIA_ANSWERS2[324] = "police";
NORMAL_TRIVIA_ANSWERS3[324] = "policemen";

NORMAL_TRIVIA_QUESTIONS[325] = "(Music): How did Kurt Cobain announce The Meat Puppets on Nirvana's \"Unplugged in New York?";
NORMAL_TRIVIA_ANSWERS1[325] = "Thing 1 and Thing 2";
NORMAL_TRIVIA_ANSWERS2[325] = "thing1 and thing2";
NORMAL_TRIVIA_ANSWERS3[325] = "thing1 thing2";

NORMAL_TRIVIA_QUESTIONS[326] = "(Music): Who were the guest artists in Nirvana's \"Unplugged in New York?";
NORMAL_TRIVIA_ANSWERS1[326] = "The Meat Puppets";

NORMAL_TRIVIA_QUESTIONS[327] = "(People&Places): What are the 3 best-known western personages in China?";
NORMAL_TRIVIA_ANSWERS1[327] = "Jesus Christ, Richard Nixon and Elvis Presley";
NORMAL_TRIVIA_ANSWERS2[327] = "Jesus";
NORMAL_TRIVIA_ANSWERS3[327] = "Nixon";

NORMAL_TRIVIA_QUESTIONS[328] = "(History): What was the name of the B-29 bomber that dropped the Atom Bomb on Nagasaki?";
NORMAL_TRIVIA_ANSWERS1[328] = "Bock's Car";

NORMAL_TRIVIA_QUESTIONS[329] = "(Science&Nature): Which takes more muscles to do, frowning or smiling?";
NORMAL_TRIVIA_ANSWERS1[329] = "frowning";
NORMAL_TRIVIA_ANSWERS2[329] = "frown";

NORMAL_TRIVIA_QUESTIONS[330] = "(Science&Nature): What is the body's largest internal organ?";
NORMAL_TRIVIA_ANSWERS1[330] = "small intestine";

NORMAL_TRIVIA_QUESTIONS[331] = "(Language): What do you study if you are studying entomology?";
NORMAL_TRIVIA_ANSWERS1[331] = "entomology is the study of insects";
NORMAL_TRIVIA_ANSWERS2[331] = "insects";
NORMAL_TRIVIA_ANSWERS3[331] = "insect";

NORMAL_TRIVIA_QUESTIONS[332] = "(Language): If you study etymology, what are you studying?";
NORMAL_TRIVIA_ANSWERS1[332] = "word origins";
NORMAL_TRIVIA_ANSWERS2[332] = "where words come from";
NORMAL_TRIVIA_ANSWERS3[332] = "words";

NORMAL_TRIVIA_QUESTIONS[333] = "(Geography): Name one of the \"Great Lakes\" that surround Michigan.";
NORMAL_TRIVIA_ANSWERS1[333] = "Michigan, Huron, Erie or Superior";
NORMAL_TRIVIA_ANSWERS2[333] = "Michigan";
NORMAL_TRIVIA_ANSWERS3[333] = "Huron";

NORMAL_TRIVIA_QUESTIONS[334] = "(Geography): Which sea lies along the western side of Holland (the Netherlands)?";
NORMAL_TRIVIA_ANSWERS1[334] = "North Sea";

NORMAL_TRIVIA_QUESTIONS[335] = "(Geography): What country lies along the western side of Spain?";
NORMAL_TRIVIA_ANSWERS1[335] = "Portugal";

NORMAL_TRIVIA_QUESTIONS[336] = "(Literature): Who said: \"Fie Fi Fo Fum, I smell the blood of an Englishman\"?";
NORMAL_TRIVIA_ANSWERS1[336] = "the giant in \"Jack In The Beanstalk\"";
NORMAL_TRIVIA_ANSWERS2[336] = "the giant";
NORMAL_TRIVIA_ANSWERS3[336] = "giant";

NORMAL_TRIVIA_QUESTIONS[337] = "(Weights&Measures): In kilograms, how much does one litre of water weigh?";
NORMAL_TRIVIA_ANSWERS1[337] = "1 Kg";
NORMAL_TRIVIA_ANSWERS2[337] = "one kilogram";
NORMAL_TRIVIA_ANSWERS3[337] = "1KG";

NORMAL_TRIVIA_QUESTIONS[338] = "(Arts&Entertainment): What Lewis Carroll work offers this bit of whimsy: \"All mimsy were the borogoves, and the mome raths outgrabe\"?";
NORMAL_TRIVIA_ANSWERS1[338] = "Alice's Adventures in Wonderland";
NORMAL_TRIVIA_ANSWERS2[338] = "Alice in wonderland";

NORMAL_TRIVIA_QUESTIONS[339] = "(Sports&Leisure): How many of every 10 baseball players who sign pro contracts never play in a major league game?";
NORMAL_TRIVIA_ANSWERS1[339] = "Nine";
NORMAL_TRIVIA_ANSWERS2[339] = "9";

NORMAL_TRIVIA_QUESTIONS[340] = "(Science&Nature): Which of the big, jungle cats is the only cat to be social rather than solitary?";
NORMAL_TRIVIA_ANSWERS1[340] = "The lion";

NORMAL_TRIVIA_QUESTIONS[341] = "(Science&Nature): What type of nucleic acid carries hereditary information from generation to generation?";
NORMAL_TRIVIA_ANSWERS1[341] = "Deoxyribonucleic acid or DNA";
NORMAL_TRIVIA_ANSWERS2[341] = "DNA";

NORMAL_TRIVIA_QUESTIONS[342] = "(Science&Nature): What substance is the largest single preventable cause of death?";
NORMAL_TRIVIA_ANSWERS1[342] = "Tobacco";

NORMAL_TRIVIA_QUESTIONS[343] = "(Science&Nature): What movie had Michael Keaton playing a character loosely named after a huge star in the constellation of Orion?";
NORMAL_TRIVIA_ANSWERS1[343] = "Beetlejuice";
NORMAL_TRIVIA_ANSWERS2[343] = "Betelguese";

NORMAL_TRIVIA_QUESTIONS[344] = "(History): What form of ancient writing was finally deciphered with the help of a chunk of basalt known as the Rosetta Stone?";
NORMAL_TRIVIA_ANSWERS1[344] = "Hieroglyphics";
NORMAL_TRIVIA_ANSWERS2[344] = "hirogliphics";

NORMAL_TRIVIA_QUESTIONS[345] = "(History): What country did Hitler's troops invade, kicking off World War II?";
NORMAL_TRIVIA_ANSWERS1[345] = "Poland";

NORMAL_TRIVIA_QUESTIONS[346] = "(Science&Nature): What do American parents of infants dump 17 billion of each year?";
NORMAL_TRIVIA_ANSWERS1[346] = "Disposable diapers";
NORMAL_TRIVIA_ANSWERS2[346] = "diapers";

NORMAL_TRIVIA_QUESTIONS[347] = "(People&Places): What state's license plates began saying 'Famous Potatoes' in 1957?";
NORMAL_TRIVIA_ANSWERS1[347] = "Idaho's";
NORMAL_TRIVIA_ANSWERS2[347] = "idaho";

NORMAL_TRIVIA_QUESTIONS[348] = "(Science&Nature): What's an organism made from the genetic material of another commonly called?";
NORMAL_TRIVIA_ANSWERS1[348] = "A clone";

NORMAL_TRIVIA_QUESTIONS[349] = "(People&Places): What tropical U.S. state has chosen the yellow hibiscus as it's state flower?";
NORMAL_TRIVIA_ANSWERS1[349] = "Hawaii";

NORMAL_TRIVIA_QUESTIONS[350] = "(People&Places): What European country contains Transylvania, commonly considered to be the home of \"Count Dracula\"?";
NORMAL_TRIVIA_ANSWERS1[350] = "Romania";

NORMAL_TRIVIA_QUESTIONS[351] = "(Science&Nature): How many bones does a shark have?";
NORMAL_TRIVIA_ANSWERS1[351] = "Zero";
NORMAL_TRIVIA_ANSWERS2[351] = "0";

NORMAL_TRIVIA_QUESTIONS[352] = "(Science&Nature): What does the male Emperor Penguine balance atop his feet for two months while its mate feeds?";
NORMAL_TRIVIA_ANSWERS1[352] = "An egg";

NORMAL_TRIVIA_QUESTIONS[353] = "(Science&Nature): What tracking device was the Stealth bomber designed to evade?";
NORMAL_TRIVIA_ANSWERS1[353] = "Radar";

NORMAL_TRIVIA_QUESTIONS[354] = "(Science&Nature): What's the heaviest naturally-occurring element?";
NORMAL_TRIVIA_ANSWERS1[354] = "Uranium";

NORMAL_TRIVIA_QUESTIONS[355] = "(Science&Nature): Which of the 9 planets in our solar system is blue and white when seen from outer space?";
NORMAL_TRIVIA_ANSWERS1[355] = "Earth";

NORMAL_TRIVIA_QUESTIONS[356] = "(Literature): What poet immortalized a famous silversmith's midnight ride to warn that the British were coming?";
NORMAL_TRIVIA_ANSWERS1[356] = "Henry Wadsworth Longfellow";
NORMAL_TRIVIA_ANSWERS2[356] = "longfellow";

NORMAL_TRIVIA_QUESTIONS[357] = "(People&Places): Who was the first pilot to take off solo in New York and land in Paris?";
NORMAL_TRIVIA_ANSWERS1[357] = "Charles Lindbergh";
NORMAL_TRIVIA_ANSWERS2[357] = "lindbergh";

NORMAL_TRIVIA_QUESTIONS[358] = "(Science&Nature): How many buffalo/bison roamed North America in 1492 - 600,000, 6 million or 60 million?";
NORMAL_TRIVIA_ANSWERS1[358] = "60 million";
NORMAL_TRIVIA_ANSWERS2[358] = "Sixty million";
NORMAL_TRIVIA_ANSWERS3[358] = "60,000,000";

NORMAL_TRIVIA_QUESTIONS[359] = "(History): Name 1 of the 2 U.S. presidents that were assassinated while in office other than Lincoln or Kennedy?";
NORMAL_TRIVIA_ANSWERS1[359] = "James Garfield";
NORMAL_TRIVIA_ANSWERS2[359] = "William McKinley";
NORMAL_TRIVIA_ANSWERS3[359] = "garfield";

NORMAL_TRIVIA_QUESTIONS[360] = "(People&Places): What U.S. state adopted a cactus blossom as its state flower?";
NORMAL_TRIVIA_ANSWERS1[360] = "Arizona";

NORMAL_TRIVIA_QUESTIONS[361] = "(World): Which president watched the most movies in his first year at the White House?";
NORMAL_TRIVIA_ANSWERS1[361] = "Bill Clinton";
NORMAL_TRIVIA_ANSWERS2[361] = "Clinton";

NORMAL_TRIVIA_QUESTIONS[362] = "(People&Places): What city rings in the new year with a descending ball or apple?";
NORMAL_TRIVIA_ANSWERS1[362] = "New York";

NORMAL_TRIVIA_QUESTIONS[363] = "(Science&Nature): What's the term for a device that uses the sun and horizon to determine location?";
NORMAL_TRIVIA_ANSWERS1[363] = "Sextant";

NORMAL_TRIVIA_QUESTIONS[364] = "(Sports&Leisure): What chess piece is second in strength only to the queen?";
NORMAL_TRIVIA_ANSWERS1[364] = "Rook";
NORMAL_TRIVIA_ANSWERS2[364] = "castle";

NORMAL_TRIVIA_QUESTIONS[365] = "(People&Places): What fort's 1814 bombardment inspired Francis Scott Key to pen the USA's anthem's lyrics?";
NORMAL_TRIVIA_ANSWERS1[365] = "Fort McHenry's";
NORMAL_TRIVIA_ANSWERS2[365] = "mchenry";

NORMAL_TRIVIA_QUESTIONS[366] = "(Science&Nature): What bird in the heron family is named for the long feathers, or \"aigrettes,\" grown by the male during mating season?";
NORMAL_TRIVIA_ANSWERS1[366] = "An egret";
NORMAL_TRIVIA_ANSWERS2[366] = "egret";

NORMAL_TRIVIA_QUESTIONS[367] = "(Science&Nature): What number is indicated by this symbol in the Greek numeral system? VII";
NORMAL_TRIVIA_ANSWERS1[367] = "Seven";
NORMAL_TRIVIA_ANSWERS2[367] = "7";

NORMAL_TRIVIA_QUESTIONS[368] = "(History): Whose signature on the USA's \"Declaration Of Independance\" is legible from the farthest distance?";
NORMAL_TRIVIA_ANSWERS1[368] = "John Hancock's";
NORMAL_TRIVIA_ANSWERS2[368] = "hancock";

NORMAL_TRIVIA_QUESTIONS[369] = "(History): What was the first U.S. battle cry of World War II?";
NORMAL_TRIVIA_ANSWERS1[369] = "Remember Pearl Harbor!";

NORMAL_TRIVIA_QUESTIONS[370] = "(People&Places): What's the first foreign country you'd reach by traveling due south from Detroit's City Airport?";
NORMAL_TRIVIA_ANSWERS1[370] = "Canada";

NORMAL_TRIVIA_QUESTIONS[371] = "(People&Places): What country found wooden shoes to be no match for German jackboots in 1940?";
NORMAL_TRIVIA_ANSWERS1[371] = "The Netherlands";
NORMAL_TRIVIA_ANSWERS2[371] = "Holland";

NORMAL_TRIVIA_QUESTIONS[372] = "(Arts&Entertainment): What six words does 007 say when introducing himself?";
NORMAL_TRIVIA_ANSWERS1[372] = "The name is Bond, James Bond";
NORMAL_TRIVIA_ANSWERS2[372] = "the name is bond james bond";

NORMAL_TRIVIA_QUESTIONS[373] = "(Science&Nature): What does the acronym \"WYSIWYG\" stand for?";
NORMAL_TRIVIA_ANSWERS1[373] = "What you see is what you get";

NORMAL_TRIVIA_QUESTIONS[374] = "(Science&Nature): What type of engineering sees organisms have their DNA altered to produce new substances?";
NORMAL_TRIVIA_ANSWERS1[374] = "Genetic engineering";
NORMAL_TRIVIA_ANSWERS2[374] = "genetic";

NORMAL_TRIVIA_QUESTIONS[375] = "(Science&Nature): What Intel chip is the successor to the 80286, 80386 and 80486?";
NORMAL_TRIVIA_ANSWERS1[375] = "The Pentium";
NORMAL_TRIVIA_ANSWERS2[375] = "pentium";

NORMAL_TRIVIA_QUESTIONS[376] = "(Science&Nature): What planet did the U.S. \"Viking I\" send surface images of, starting in 1976?";
NORMAL_TRIVIA_ANSWERS1[376] = "Mars";

NORMAL_TRIVIA_QUESTIONS[377] = "(People&Places): What continent boasts Angel Falls, the tallest in the world?";
NORMAL_TRIVIA_ANSWERS1[377] = "South America";

NORMAL_TRIVIA_QUESTIONS[378] = "(Science&Nature): What is the only mammal that can fly, and not simply glide?";
NORMAL_TRIVIA_ANSWERS1[378] = "The bat";
NORMAL_TRIVIA_ANSWERS2[378] = "bat";

NORMAL_TRIVIA_QUESTIONS[379] = "(History): What was the name of the B-29 that dropped the bomb on Hiroshima?";
NORMAL_TRIVIA_ANSWERS1[379] = "Enola Gay";

NORMAL_TRIVIA_QUESTIONS[380] = "(People&Places): What's the name of the stately stone gate in the center of Berlin?";
NORMAL_TRIVIA_ANSWERS1[380] = "The Brandenburg Gate";
NORMAL_TRIVIA_ANSWERS2[380] = "brandenberg";
NORMAL_TRIVIA_ANSWERS3[380] = "brandenburg";

NORMAL_TRIVIA_QUESTIONS[381] = "(Science&Nature): What invention did the most to discourage the practice of letter writing?";
NORMAL_TRIVIA_ANSWERS1[381] = "The telephone";
NORMAL_TRIVIA_ANSWERS2[381] = "telephone";

NORMAL_TRIVIA_QUESTIONS[382] = "(Science&Nature): What country was proud to see Marc Garneau as it's first astronaut 1984?";
NORMAL_TRIVIA_ANSWERS1[382] = "Canada";

NORMAL_TRIVIA_QUESTIONS[383] = "(Science&Nature): What industry, according to Melvin Belli, \"has conspired to catch you, hold you and kill you\"?";
NORMAL_TRIVIA_ANSWERS1[383] = "The tobacco industry";

NORMAL_TRIVIA_QUESTIONS[384] = "(People&Places): What British political party made Margaret Thatcher its first female leader?";
NORMAL_TRIVIA_ANSWERS1[384] = "The Conservative (Tory) Party";
NORMAL_TRIVIA_ANSWERS2[384] = "conservative";
NORMAL_TRIVIA_ANSWERS3[384] = "tory";

NORMAL_TRIVIA_QUESTIONS[385] = "(Science&Nature): Which can last longer without water, a camel or a rat?";
NORMAL_TRIVIA_ANSWERS1[385] = "a rat";
NORMAL_TRIVIA_ANSWERS2[385] = "rat";

NORMAL_TRIVIA_QUESTIONS[386] = "(Science&Nature): Which is bigger, an ostrich's eye or it's brain?";
NORMAL_TRIVIA_ANSWERS1[386] = "it's eye";
NORMAL_TRIVIA_ANSWERS2[386] = "eye";

NORMAL_TRIVIA_QUESTIONS[387] = "(Science&Nature): How many eyelids does a camel's eye have?";
NORMAL_TRIVIA_ANSWERS1[387] = "3";
NORMAL_TRIVIA_ANSWERS2[387] = "three";

NORMAL_TRIVIA_QUESTIONS[388] = "(Science&Nature): True or false:  Snakes are immune to their own poison.";
NORMAL_TRIVIA_ANSWERS1[388] = "true";

NORMAL_TRIVIA_QUESTIONS[389] = "(Science&Nature): Which insect is responsible for the most human deaths world-wide?";
NORMAL_TRIVIA_ANSWERS1[389] = "mosquito";
NORMAL_TRIVIA_ANSWERS2[389] = "mousquito";

NORMAL_TRIVIA_QUESTIONS[390] = "(Science&Nature): True or false:  The bones of a pidgeon weigh less than it's feathers.";
NORMAL_TRIVIA_ANSWERS1[390] = "true";

NORMAL_TRIVIA_QUESTIONS[391] = "(Science&Nature): What bird is the only bird in the world that can fly backwards?";
NORMAL_TRIVIA_ANSWERS1[391] = "the hummingbird";

NORMAL_TRIVIA_QUESTIONS[392] = "(Science&Nature): Name the national bird of New Zealand?";
NORMAL_TRIVIA_ANSWERS1[392] = "the Kiwi";
NORMAL_TRIVIA_ANSWERS2[392] = "kiwi";

NORMAL_TRIVIA_QUESTIONS[393] = "(Science&Nature): What is the most common mammal in the United States?";
NORMAL_TRIVIA_ANSWERS1[393] = "the mouse";
NORMAL_TRIVIA_ANSWERS2[393] = "mouse";

NORMAL_TRIVIA_QUESTIONS[394] = "(Science&Nature): The poison-arrow frog has enough poison to kill how many people; 10, 500, 1,200 or 2,200?";
NORMAL_TRIVIA_ANSWERS1[394] = "2,200";
NORMAL_TRIVIA_ANSWERS2[394] = "1,200";
NORMAL_TRIVIA_ANSWERS3[394] = "500";

NORMAL_TRIVIA_QUESTIONS[395] = "(Science&Nature): Whose venom is more potent, a rattlesnake's or a female black widow spider's?";
NORMAL_TRIVIA_ANSWERS1[395] = "the female black widow spider's";
NORMAL_TRIVIA_ANSWERS2[395] = "black widow's";
NORMAL_TRIVIA_ANSWERS3[395] = "black widow";

NORMAL_TRIVIA_QUESTIONS[396] = "(Science&Nature): What is the world's largest mammal?";
NORMAL_TRIVIA_ANSWERS1[396] = "the blue whale";
NORMAL_TRIVIA_ANSWERS2[396] = "blue whale";

NORMAL_TRIVIA_QUESTIONS[397] = "(Science&Nature): Of the approximately 2,600 different species of frogs, what is the only continent that they don't live on?";
NORMAL_TRIVIA_ANSWERS1[397] = "Antartica";

NORMAL_TRIVIA_QUESTIONS[398] = "(People&Places): What well-known ancient site in England is 1,500 years older then the Colosseum in Rome?";
NORMAL_TRIVIA_ANSWERS1[398] = "Stonehenge";

NORMAL_TRIVIA_QUESTIONS[399] = "(People&Places): How tall is the Eiffel Tower; 583 feet, 196 feet, 984 feet or 721 feet?";
NORMAL_TRIVIA_ANSWERS1[399] = "984 feet high";
NORMAL_TRIVIA_ANSWERS2[399] = "nine hundred eighty-four";
NORMAL_TRIVIA_ANSWERS3[399] = "984";

NORMAL_TRIVIA_QUESTIONS[400] = "(History): Who did Cleopatra wed after frustrating marriages with her two younger brothers?";
NORMAL_TRIVIA_ANSWERS1[400] = "Marc Antony";

NORMAL_TRIVIA_QUESTIONS[401] = "(Arts&Entertainment): What does \"dormez-vous\" mean?";
NORMAL_TRIVIA_ANSWERS1[401] = "Are you sleeping?";
NORMAL_TRIVIA_ANSWERS2[401] = "are you sleeping";

NORMAL_TRIVIA_QUESTIONS[402] = "(People&Places): What name did Mohammed A. Salameh use when he rented the van that carried the bomb that blew up the World Trade Center in New York City?";
NORMAL_TRIVIA_ANSWERS1[402] = "Mohammed A. Salameh";

NORMAL_TRIVIA_QUESTIONS[403] = "(Arts&Entertainment): What name did gangsta' rapper, Snoop Dogg, give his platinum debut album?";
NORMAL_TRIVIA_ANSWERS1[403] = "Doggystyle";
NORMAL_TRIVIA_ANSWERS2[403] = "doggy style";

NORMAL_TRIVIA_QUESTIONS[404] = "(Arts&Entertainment): What Spike Lee movie title was uttered in Congress 67 times in the six months after its release?";
NORMAL_TRIVIA_ANSWERS1[404] = "Do the Right Thing";

NORMAL_TRIVIA_QUESTIONS[405] = "(People&Places): What building did a wayward B-25 smack the 78th floor of in 1945?";
NORMAL_TRIVIA_ANSWERS1[405] = "The Empire State Building";

NORMAL_TRIVIA_QUESTIONS[406] = "(Science&Nature): What's the fastest man can run - 18, 28 or 38 miles per hour?";
NORMAL_TRIVIA_ANSWERS1[406] = "Twenty-eight miles per hour";
NORMAL_TRIVIA_ANSWERS2[406] = "28";
NORMAL_TRIVIA_ANSWERS3[406] = "28 miles per hour";

NORMAL_TRIVIA_QUESTIONS[407] = "(History): What war cost an average of one billion dollars a day?";
NORMAL_TRIVIA_ANSWERS1[407] = "The Persian Gulf War";
NORMAL_TRIVIA_ANSWERS2[407] = "desert storm";
NORMAL_TRIVIA_ANSWERS3[407] = "gulf war";

NORMAL_TRIVIA_QUESTIONS[408] = "(Science&Nature): What invention rendered the short-lived Pony Express delivery service unnecessary?";
NORMAL_TRIVIA_ANSWERS1[408] = "The telegraph";
NORMAL_TRIVIA_ANSWERS2[408] = "telegrams";

NORMAL_TRIVIA_QUESTIONS[409] = "(Sports&Leisure): Who, with Emil Gagnan, invented the gear that allows scuba diving to flourish as a sport?";
NORMAL_TRIVIA_ANSWERS1[409] = "Jacques Cousteau";
NORMAL_TRIVIA_ANSWERS2[409] = "costeau";

NORMAL_TRIVIA_QUESTIONS[410] = "(Arts&Entertainment): What \"pet\" came with an owner's manual that said it could learn to \"play dead\" with no training?";
NORMAL_TRIVIA_ANSWERS1[410] = "The Pet Rock";
NORMAL_TRIVIA_ANSWERS2[410] = "pet rock";
NORMAL_TRIVIA_ANSWERS3[410] = "rock";

NORMAL_TRIVIA_QUESTIONS[411] = "(History): True or false:  The Jordanian city, Amman, was once called Philadelphia.";
NORMAL_TRIVIA_ANSWERS1[411] = "True";

NORMAL_TRIVIA_QUESTIONS[412] = "(PresidentsDay): Abraham Lincoln, America's first President, began serving his 1st term in office in what year?";
NORMAL_TRIVIA_ANSWERS1[412] = "1861";

NORMAL_TRIVIA_QUESTIONS[413] = "(PresidentsDay): Abraham Lincoln was born in Hardin County, KY (now Larue Co.) in what year?";
NORMAL_TRIVIA_ANSWERS1[413] = "1809";

NORMAL_TRIVIA_QUESTIONS[414] = "(PresidentsDay): In what year was Lincoln elected to the Illinois state legislature.";
NORMAL_TRIVIA_ANSWERS1[414] = "1834";

NORMAL_TRIVIA_QUESTIONS[415] = "(PresidentsDay): Which president said \"A house divided against itself cannot stand\"? ";
NORMAL_TRIVIA_ANSWERS1[415] = "Lincoln";

NORMAL_TRIVIA_QUESTIONS[416] = "(PresidentsDay): In May, 1860 Abraham Lincoln was nominated for President by which political party?";
NORMAL_TRIVIA_ANSWERS1[416] = "Republican";

NORMAL_TRIVIA_QUESTIONS[417] = "(PresidentsDay): On Election Day, November 6, 1860, with Lincoln the decisive winner, how many states had started proceedings to seceed from the Union?";
NORMAL_TRIVIA_ANSWERS1[417] = "Seven";
NORMAL_TRIVIA_ANSWERS2[417] = "7";

NORMAL_TRIVIA_QUESTIONS[418] = "(PresidentsDay): What famous speech of Lincoln's started with the words, \"Fourscore and seven years ago\"?";
NORMAL_TRIVIA_ANSWERS1[418] = "Gettysburg Address (Nov. 19, 1863)";
NORMAL_TRIVIA_ANSWERS2[418] = "Gettysburg Address";

NORMAL_TRIVIA_QUESTIONS[419] = "(PresidentsDay): What was the intent of  Lincoln's Emancipation Proclamation of 1863?";
NORMAL_TRIVIA_ANSWERS1[419] = "to abolish slavery";
NORMAL_TRIVIA_ANSWERS2[419] = "set slaves free";
NORMAL_TRIVIA_ANSWERS3[419] = "free slaves";

NORMAL_TRIVIA_QUESTIONS[420] = "(PresidentsDay): April 14, 1865, while attending a play at Ford's Theater, Abraham Lincoln was shot. What city was Ford's Theater in?";
NORMAL_TRIVIA_ANSWERS1[420] = "Washington DC";
NORMAL_TRIVIA_ANSWERS2[420] = "Washington";

NORMAL_TRIVIA_QUESTIONS[421] = "(PresidentsDay): Who became Lincoln's wife in 1842 and gave him four sons?";
NORMAL_TRIVIA_ANSWERS1[421] = "Mary Todd Lincoln (1818-82)";
NORMAL_TRIVIA_ANSWERS2[421] = "Mary Lincoln";

NORMAL_TRIVIA_QUESTIONS[422] = "(PresidentsDay): How tall was Abraham Lincoln?";
NORMAL_TRIVIA_ANSWERS1[422] = "6' 4\"";
NORMAL_TRIVIA_ANSWERS2[422] = "six feet, four inches";

NORMAL_TRIVIA_QUESTIONS[423] = "(PresidentsDay): What monument was built and designed by American architect, Henry Bacon?";
NORMAL_TRIVIA_ANSWERS1[423] = "the Lincoln Memorial in Washington DC";
NORMAL_TRIVIA_ANSWERS2[423] = "Lincoln Monument";
NORMAL_TRIVIA_ANSWERS3[423] = "Lincoln Memorial";

NORMAL_TRIVIA_QUESTIONS[424] = "(PresidentsDay): Where is Abraham Lincoln buried? ";
NORMAL_TRIVIA_ANSWERS1[424] = "Oak Ridge Cemetery, Springfield, Illinois";
NORMAL_TRIVIA_ANSWERS2[424] = "Springfield";

NORMAL_TRIVIA_QUESTIONS[425] = "(PresidentsDay): What runs under the Hudson River between NY & NJ?";
NORMAL_TRIVIA_ANSWERS1[425] = "Lincoln Tunnel";

NORMAL_TRIVIA_QUESTIONS[426] = "(PresidentsDay): Lincoln, Nebraska was initially know by what name before it was renamed when it became the state capitol in 1867?";
NORMAL_TRIVIA_ANSWERS1[426] = "Lancaster";

NORMAL_TRIVIA_QUESTIONS[427] = "(PresidentsDay): Martin Luther King, Jr. delivered his famous \"I Have A Dream\" speech in front of what memorial. on August 28, 1963?";
NORMAL_TRIVIA_ANSWERS1[427] = "Lincoln Memorial";
NORMAL_TRIVIA_ANSWERS2[427] = "Lincoln Monument";
NORMAL_TRIVIA_ANSWERS3[427] = "Lincoln";

NORMAL_TRIVIA_QUESTIONS[428] = "(PresidentsDay): Where was George Washington born?";
NORMAL_TRIVIA_ANSWERS1[428] = "Westmoreland County, VA";
NORMAL_TRIVIA_ANSWERS2[428] = "Westmoreland County";

NORMAL_TRIVIA_QUESTIONS[429] = "(PresidentsDay): When is George Washington's birth date?";
NORMAL_TRIVIA_ANSWERS1[429] = "February 22, 1732";
NORMAL_TRIVIA_ANSWERS2[429] = "feb 22, 1732";

NORMAL_TRIVIA_QUESTIONS[430] = "(PresidentsDay): In 1755 a young George Washington became the commander in chief of what state's militia?";
NORMAL_TRIVIA_ANSWERS1[430] = "Virginia";

NORMAL_TRIVIA_QUESTIONS[431] = "(PresidentsDay): In 1758 Washington got married to young widow with 2 young children. What was her name?";
NORMAL_TRIVIA_ANSWERS1[431] = "Martha Dandridge Custis";
NORMAL_TRIVIA_ANSWERS2[431] = "Martha Custis";

NORMAL_TRIVIA_QUESTIONS[432] = "(PresidentsDay): When did the morale-boosting event of Washington crossing the Delaware River & defeating the British at Trenton & Princeton, NJ occur?";
NORMAL_TRIVIA_ANSWERS1[432] = "Christmas night 1776";
NORMAL_TRIVIA_ANSWERS2[432] = "christmas 1776";
NORMAL_TRIVIA_ANSWERS3[432] = "Dec 25, 1776";

NORMAL_TRIVIA_QUESTIONS[433] = "(PresidentsDay): The bitter winter of 1777-78 found the Continental Army, led by George Washington camped where? ";
NORMAL_TRIVIA_ANSWERS1[433] = "Valley Forge, PA";
NORMAL_TRIVIA_ANSWERS2[433] = "Valley Forge";

NORMAL_TRIVIA_QUESTIONS[434] = "(PresidentsDay): What is the name of George Washington's estate, located in Fairfax County, VA?";
NORMAL_TRIVIA_ANSWERS1[434] = "Mount Vernon";

NORMAL_TRIVIA_QUESTIONS[435] = "(PresidentsDay): Washington was called out of retirement to preside at the Constitutional Convention held in what city?";
NORMAL_TRIVIA_ANSWERS1[435] = "Philadelphia (1787)";
NORMAL_TRIVIA_ANSWERS2[435] = "Philadelphia";

NORMAL_TRIVIA_QUESTIONS[436] = "(PresidentsDay): How old was George Washington when he was chosen as President on April 30, 1789?";
NORMAL_TRIVIA_ANSWERS1[436] = "57";
NORMAL_TRIVIA_ANSWERS2[436] = "fifty-seven";

NORMAL_TRIVIA_QUESTIONS[437] = "(PresidentsDay): How many years did Washington serve as President of the United States of America?";
NORMAL_TRIVIA_ANSWERS1[437] = "8 (1789-1797)";
NORMAL_TRIVIA_ANSWERS2[437] = "eight";
NORMAL_TRIVIA_ANSWERS3[437] = "8";

NORMAL_TRIVIA_QUESTIONS[438] = "(PresidentsDay): Standing on the balcony of Federal Hall, Washington took the oath of office as the 1st President of the United States on April 30, 1789 in what city?";
NORMAL_TRIVIA_ANSWERS1[438] = "New York City";
NORMAL_TRIVIA_ANSWERS2[438] = "New York";

NORMAL_TRIVIA_QUESTIONS[439] = "(PresidentsDay): On July 4, 1848, the cornerstone of the Washington Monument was laid with same trowel Washington used to lay cornerstone of what other, well-known Washington DC building?  ";
NORMAL_TRIVIA_ANSWERS1[439] = "US Capitol Building (1793)";
NORMAL_TRIVIA_ANSWERS2[439] = "capital building";
NORMAL_TRIVIA_ANSWERS3[439] = "capitol building";

NORMAL_TRIVIA_QUESTIONS[440] = "(PresidentsDay):  In 1871 two cities were consolidated with Washington County to become Washington DC.  Name one of them.";
NORMAL_TRIVIA_ANSWERS1[440] = "Georgetown";
NORMAL_TRIVIA_ANSWERS2[440] = "Washington";

NORMAL_TRIVIA_QUESTIONS[441] = "(PresidentsDay): Washington D.C. is located at the confluence of the Potomac river and what other river?";
NORMAL_TRIVIA_ANSWERS1[441] = "Anacostia";

NORMAL_TRIVIA_QUESTIONS[442] = "(PresidentsDay): Washington DC was laid out by a French architect.  What was his name?";
NORMAL_TRIVIA_ANSWERS1[442] = "Pierre Charles L'Enfant (1791)";
NORMAL_TRIVIA_ANSWERS2[442] = "L'Enfant";

NORMAL_TRIVIA_QUESTIONS[443] = "(TravelTrivia): To visit the 2nd largest country in South America you would have to go to what country?";
NORMAL_TRIVIA_ANSWERS1[443] = "Argentina";
NORMAL_TRIVIA_ANSWERS2[443] = "argentina";
NORMAL_TRIVIA_ANSWERS3[443] = "argentena";

NORMAL_TRIVIA_QUESTIONS[444] = "(TravelTrivia): What city in Mexico's Baja California state is just across the border from San Diego?";
NORMAL_TRIVIA_ANSWERS1[444] = "Tijuana";
NORMAL_TRIVIA_ANSWERS2[444] = "tiajuana";
NORMAL_TRIVIA_ANSWERS3[444] = "tijuana";

NORMAL_TRIVIA_QUESTIONS[445] = "(TravelTrivia): Although Bern is the capital of Switzerland, what city would you go to if you wanted to visit Switzerland's largest city?";
NORMAL_TRIVIA_ANSWERS1[445] = "Zurich";
NORMAL_TRIVIA_ANSWERS2[445] = "zurick";

NORMAL_TRIVIA_QUESTIONS[446] = "(TravelTrivia): What German city might you go for an all-beef pattie?";
NORMAL_TRIVIA_ANSWERS1[446] = "Hamburg, Germany";
NORMAL_TRIVIA_ANSWERS2[446] = "Hamburg";

NORMAL_TRIVIA_QUESTIONS[447] = "(TravelTrivia): What U.S. river is known as \"The Big Muddy\"?";
NORMAL_TRIVIA_ANSWERS1[447] = "Mississippi";
NORMAL_TRIVIA_ANSWERS2[447] = "mississippi river";

NORMAL_TRIVIA_QUESTIONS[448] = "(TravelTrivia): Who's buried in Grant's tomb?";
NORMAL_TRIVIA_ANSWERS1[448] = "Grant";
NORMAL_TRIVIA_ANSWERS2[448] = "ulysses s grant";
NORMAL_TRIVIA_ANSWERS3[448] = "president grant";

NORMAL_TRIVIA_QUESTIONS[449] = "(TravelTrivia): The Nile is the longest river in the world but what river carries the most water everyday?";
NORMAL_TRIVIA_ANSWERS1[449] = "Amazon";
NORMAL_TRIVIA_ANSWERS2[449] = "amazon river";

NORMAL_TRIVIA_QUESTIONS[450] = "(TravelTrivia): What region in southwestern China was once ruled by the Dalai Lama?";
NORMAL_TRIVIA_ANSWERS1[450] = "Tibet";

NORMAL_TRIVIA_QUESTIONS[451] = "(TravelTrivia): What commercial and industrial center is the capital of Germany's Bavaria state?";
NORMAL_TRIVIA_ANSWERS1[451] = "Munich";
NORMAL_TRIVIA_ANSWERS2[451] = "Munich, Germany";

NORMAL_TRIVIA_QUESTIONS[452] = "(TravelTrivia): Extending from the Arctic Tundra to the desert north of the Caspian Sea, what mountains separate Europe and Asia?";
NORMAL_TRIVIA_ANSWERS1[452] = "the Urals";
NORMAL_TRIVIA_ANSWERS2[452] = "Ural";
NORMAL_TRIVIA_ANSWERS3[452] = "the Ural Mountains";

NORMAL_TRIVIA_QUESTIONS[453] = "(TravelTrivia): All English monarchs since William the Conqueror have been crowned in the same church located in London. What church is it?";
NORMAL_TRIVIA_ANSWERS1[453] = "Westminster Abbey";
NORMAL_TRIVIA_ANSWERS2[453] = "wesminster abby";
NORMAL_TRIVIA_ANSWERS3[453] = "westminster abby";

NORMAL_TRIVIA_QUESTIONS[454] = "(TravelTrivia): What is the largest Portugeuse speaking country in the world?";
NORMAL_TRIVIA_ANSWERS1[454] = "Brazil";

NORMAL_TRIVIA_QUESTIONS[455] = "(TravelTrivia): What do we now call the country that was once known as Siam?";
NORMAL_TRIVIA_ANSWERS1[455] = "Thailand";
NORMAL_TRIVIA_ANSWERS2[455] = "Thiland";

NORMAL_TRIVIA_QUESTIONS[456] = "(TravelTrivia): Uganda can't boast an ocean shore but it does reside on what Lake?";
NORMAL_TRIVIA_ANSWERS1[456] = "Lake Victoria";
NORMAL_TRIVIA_ANSWERS2[456] = "Lac victoria";
NORMAL_TRIVIA_ANSWERS3[456] = "Victoria";

NORMAL_TRIVIA_QUESTIONS[457] = "(TravelTrivia): From what famous European city does the country of Venezuela get its name?";
NORMAL_TRIVIA_ANSWERS1[457] = "Venice";
NORMAL_TRIVIA_ANSWERS2[457] = "Venice, Italy";

NORMAL_TRIVIA_QUESTIONS[458] = "(TravelTrivia): You are standing on a bridge over the river Seine looking at Notre Dame cathedral. Another church in this city is the church of Sacre Coeur. Where are you?";
NORMAL_TRIVIA_ANSWERS1[458] = "Paris";
NORMAL_TRIVIA_ANSWERS2[458] = "paris, france";

NORMAL_TRIVIA_QUESTIONS[459] = "(TravelTrivia): If you going to visit Taj Mahal, Towers of Silence and Golconda, what country will you travel to?";
NORMAL_TRIVIA_ANSWERS1[459] = "India";

NORMAL_TRIVIA_QUESTIONS[460] = "(TravelTrivia): What color is the circle on the Japanese flag?";
NORMAL_TRIVIA_ANSWERS1[460] = "red";

NORMAL_TRIVIA_QUESTIONS[461] = "(TravelTrivia): What city is the capital of Bolivia?";
NORMAL_TRIVIA_ANSWERS1[461] = "Sucre";

NORMAL_TRIVIA_QUESTIONS[462] = "(TravelTrivia): In Italy, a man may be arrested for wearing a what?";
NORMAL_TRIVIA_ANSWERS1[462] = "skirt";
NORMAL_TRIVIA_ANSWERS2[462] = "dress";

NORMAL_TRIVIA_QUESTIONS[463] = "(TravelTrivia): What is the capital of Australia?";
NORMAL_TRIVIA_ANSWERS1[463] = "Canberra";
NORMAL_TRIVIA_ANSWERS2[463] = "Canbera";

NORMAL_TRIVIA_QUESTIONS[464] = "(TravelTrivia): What city is home to the Alamo?";
NORMAL_TRIVIA_ANSWERS1[464] = "San Antonio";
NORMAL_TRIVIA_ANSWERS2[464] = "san antone";

NORMAL_TRIVIA_QUESTIONS[465] = "(TravelTrivia): Which English city is known for its association with Robin Hood and Sherwood Forest?";
NORMAL_TRIVIA_ANSWERS1[465] = "Nottingham";
NORMAL_TRIVIA_ANSWERS2[465] = "notingham";

NORMAL_TRIVIA_QUESTIONS[466] = "(TravelTrivia): What Hungarian capital is split by the Danube river?";
NORMAL_TRIVIA_ANSWERS1[466] = "Budapest";

NORMAL_TRIVIA_QUESTIONS[467] = "(TravelTrivia): What country has a 14:1 sheep to human ratio?";
NORMAL_TRIVIA_ANSWERS1[467] = "New Zealand";
NORMAL_TRIVIA_ANSWERS2[467] = "new zealand";

NORMAL_TRIVIA_QUESTIONS[468] = "(TravelTrivia): Which of the following is not a Greek island? Korfu, Crete, Corsica or Kos?";
NORMAL_TRIVIA_ANSWERS1[468] = "Corsica";

NORMAL_TRIVIA_QUESTIONS[469] = "(TravelTrivia): What city is known as \"The Big Apple\"?";
NORMAL_TRIVIA_ANSWERS1[469] = "New York";
NORMAL_TRIVIA_ANSWERS2[469] = "New York City";

NORMAL_TRIVIA_QUESTIONS[470] = "(TravelTrivia): If you were visiting Reykjavik what country would you be in?";
NORMAL_TRIVIA_ANSWERS1[470] = "Iceland";

NORMAL_TRIVIA_QUESTIONS[471] = "(TravelTrivia): What is the largest Japanese speaking country?";
NORMAL_TRIVIA_ANSWERS1[471] = "Japan";

NORMAL_TRIVIA_QUESTIONS[472] = "(TravelTrivia): In what USA state is the Petrified Forest located?";
NORMAL_TRIVIA_ANSWERS1[472] = "Arizona";

NORMAL_TRIVIA_QUESTIONS[473] = "(TravelTrivia): Where would you go to see a tower that leans?";
NORMAL_TRIVIA_ANSWERS1[473] = "Pisa, Italy";
NORMAL_TRIVIA_ANSWERS2[473] = "pisa";

NORMAL_TRIVIA_QUESTIONS[474] = "(TravelTrivia): The most populated country in western Europe is?";
NORMAL_TRIVIA_ANSWERS1[474] = "Germany";

NORMAL_TRIVIA_QUESTIONS[475] = "(TravelTrivia): The pyramids in Egypt are located nearest to what city?";
NORMAL_TRIVIA_ANSWERS1[475] = "Giza";

NORMAL_TRIVIA_QUESTIONS[476] = "(TravelTrivia): In Thailand, it is illegal to leave your house if you are not wearing what?";
NORMAL_TRIVIA_ANSWERS1[476] = "underwear";
NORMAL_TRIVIA_ANSWERS2[476] = "panties";
NORMAL_TRIVIA_ANSWERS3[476] = "skivvies";

NORMAL_TRIVIA_QUESTIONS[477] = "(TravelTrivia): In Switzerland, it is illegal to do this after 10PM if you live in an Apartment?";
NORMAL_TRIVIA_ANSWERS1[477] = "flush the toilet";
NORMAL_TRIVIA_ANSWERS2[477] = "flush";

NORMAL_TRIVIA_QUESTIONS[478] = "(TravelTrivia): What state is known for Mackinac Island Fudge?";
NORMAL_TRIVIA_ANSWERS1[478] = "Michigan";

NORMAL_TRIVIA_QUESTIONS[479] = "(TravelTrivia): Whose statue is in Trafalgar Square?";
NORMAL_TRIVIA_ANSWERS1[479] = "Lord Nelson";
NORMAL_TRIVIA_ANSWERS2[479] = "lord nelsons";

NORMAL_TRIVIA_QUESTIONS[480] = "(Valentines): Saint Valentine was beheaded by which Roman Emperor for marrying  couples during wartime and interfering with the Emperor's war recruitment?";
NORMAL_TRIVIA_ANSWERS1[480] = "Claudius";

NORMAL_TRIVIA_QUESTIONS[481] = "(Valentines): Which Catholic pope declared February 14th as St. Valentine's Day around 496 A.D?";
NORMAL_TRIVIA_ANSWERS1[481] = "Pope Gelasius";
NORMAL_TRIVIA_ANSWERS2[481] = "Gelasius";

NORMAL_TRIVIA_QUESTIONS[482] = "(Valentines): The \"christian\" church may have decided to celebrate Saint Valentine's feast day in the middle of February in an effort to 'christianize' celebrations of which pagan, Roman festival?";
NORMAL_TRIVIA_ANSWERS1[482] = "Lupercalia";

NORMAL_TRIVIA_QUESTIONS[483] = "(Valentines): The oldest known valentine still in existence today was a poem written in 1415 by Charles, Duke of Orleans to his wife and can be found in a library in what country?";
NORMAL_TRIVIA_ANSWERS1[483] = "British Library in London, England";
NORMAL_TRIVIA_ANSWERS2[483] = "England";
NORMAL_TRIVIA_ANSWERS3[483] = "United Kingdom";

NORMAL_TRIVIA_QUESTIONS[484] = "(Valentines): Which English king hired a writer named John Lydgate to compose a Valentine note to Catherine of Valois?";
NORMAL_TRIVIA_ANSWERS1[484] = "King Henry V";
NORMAL_TRIVIA_ANSWERS2[484] = "Henry V";
NORMAL_TRIVIA_ANSWERS3[484] = "Henry the 5th";

NORMAL_TRIVIA_QUESTIONS[485] = "(Valentines): In which century did Valentine's Day begin to be popularly celebrated in Great Britain?";
NORMAL_TRIVIA_ANSWERS1[485] = "17th";
NORMAL_TRIVIA_ANSWERS2[485] = "seventeenth";

NORMAL_TRIVIA_QUESTIONS[486] = "(Valentines): By the end of which century did printed Valentine's Day cards began to replace written Valentine love letters due to improvements in printing technology? ";
NORMAL_TRIVIA_ANSWERS1[486] = "17th";
NORMAL_TRIVIA_ANSWERS2[486] = "seventeenth";

NORMAL_TRIVIA_QUESTIONS[487] = "(Valentines):  Esther A. Howland began to sell the first mass-produced Valentines in America during which decade?";
NORMAL_TRIVIA_ANSWERS1[487] = "In the 1840s";
NORMAL_TRIVIA_ANSWERS2[487] = "1840";

NORMAL_TRIVIA_QUESTIONS[488] = "(Valentines): What female, American entrepreneur perfected the assembly line method of card design in 1848? ";
NORMAL_TRIVIA_ANSWERS1[488] = "Esther Howland";
NORMAL_TRIVIA_ANSWERS2[488] = "Esther A. Howland";

NORMAL_TRIVIA_QUESTIONS[489] = "(Valentines): Approximately what percent of all Valentines are purchased by women? ";
NORMAL_TRIVIA_ANSWERS1[489] = "85%";
NORMAL_TRIVIA_ANSWERS2[489] = "85";
NORMAL_TRIVIA_ANSWERS3[489] = "85 percent";

NORMAL_TRIVIA_QUESTIONS[490] = "(Valentines): Cupid, a well-known Valentine's Day symbol, is known for making people fall in love.  What mortal maiden did Cupid fall in love with? ";
NORMAL_TRIVIA_ANSWERS1[490] = "Psyche";

NORMAL_TRIVIA_QUESTIONS[491] = "(Valentines): Theorem or Poonah valentines; a style that came from the Orient; uses what \"device\" to achieve their designs?";
NORMAL_TRIVIA_ANSWERS1[491] = "stencils";
NORMAL_TRIVIA_ANSWERS2[491] = "stencil";

NORMAL_TRIVIA_QUESTIONS[492] = "(Valentines): What style of script, originated during the Middle Ages and was widely used in manuscripts, do Fraktur valentines use?";
NORMAL_TRIVIA_ANSWERS1[492] = "ornamental or illuminated lettering";
NORMAL_TRIVIA_ANSWERS2[492] = "illuminated";
NORMAL_TRIVIA_ANSWERS3[492] = "ornimental";

NORMAL_TRIVIA_QUESTIONS[493] = "(Valentines): Fancy valentines were made with real lace and ribbons. When was paper lace introduced? ";
NORMAL_TRIVIA_ANSWERS1[493] = "mid 1800's";
NORMAL_TRIVIA_ANSWERS2[493] = "1800";

NORMAL_TRIVIA_QUESTIONS[494] = "(Valentines): As far back as the Middle Ages, lovers said or sang their valentines. When did written valentines began to appear? ";
NORMAL_TRIVIA_ANSWERS1[494] = "1400";

NORMAL_TRIVIA_QUESTIONS[495] = "(Valentines): According to the Chinese lunar calendar, Chinese Valentine's Day (Qi Qiao Jie) falls on what number day of what number month?";
NORMAL_TRIVIA_ANSWERS1[495] = "7th day of the 7th month (August by the Gregorian calendar)";
NORMAL_TRIVIA_ANSWERS2[495] = "7th day of the 7th month";
NORMAL_TRIVIA_ANSWERS3[495] = "7";

NORMAL_TRIVIA_QUESTIONS[496] = "(Valentines): Which Lord Protector of England, during the early 1600's, declared Valentines immoral and had them banned? ";
NORMAL_TRIVIA_ANSWERS1[496] = "Oliver Cromwell";
NORMAL_TRIVIA_ANSWERS2[496] = "Cromwell";

NORMAL_TRIVIA_QUESTIONS[497] = "(Valentines):  The rose is a symbol Valentine's Day and is also the ancient, sacred symbol of the Greek Goddess of Love.  What is the goddess' name?";
NORMAL_TRIVIA_ANSWERS1[497] = "Aphrodite";

NORMAL_TRIVIA_QUESTIONS[498] = "(Valentines): Hearts, the symbol of love, were thought by the Romans to contain what part of the human \"psyche\"? ";
NORMAL_TRIVIA_ANSWERS1[498] = "the soul";
NORMAL_TRIVIA_ANSWERS2[498] = "soul";

NORMAL_TRIVIA_QUESTIONS[499] = "(Valentines): A white dove, also a symbol of Valentine's Day, symbolizes what?";
NORMAL_TRIVIA_ANSWERS1[499] = "good luck";

NORMAL_TRIVIA_QUESTIONS[500] = "(Valentines): What country had the tradition that the first young man seen by a girl on the morning of Valentine's day became her boyfriend?";
NORMAL_TRIVIA_ANSWERS1[500] = "France";

NORMAL_TRIVIA_QUESTIONS[501] = "(Valentines): According to a 17th century custom, children get candy or money for singing songs on Valentine's Day in which country? ";
NORMAL_TRIVIA_ANSWERS1[501] = "British Isles";
NORMAL_TRIVIA_ANSWERS2[501] = "England";
NORMAL_TRIVIA_ANSWERS3[501] = "United Kingdom";

NORMAL_TRIVIA_QUESTIONS[502] = "(Valentines): In England special Valentine buns are baked with raisins and caraway seeds and filled with what?";
NORMAL_TRIVIA_ANSWERS1[502] = "plum filling";
NORMAL_TRIVIA_ANSWERS2[502] = "plum";

NORMAL_TRIVIA_QUESTIONS[503] = "(Valentines): In Scotland what Valentine gift is given that's made of ribbon or paper? ";
NORMAL_TRIVIA_ANSWERS1[503] = "Lover's Knot";
NORMAL_TRIVIA_ANSWERS2[503] = "lovers knot";

NORMAL_TRIVIA_QUESTIONS[504] = "(Valentines):  In what coutry are carved, wooden, \"love\" spoons given as gifts on February 14th?";
NORMAL_TRIVIA_ANSWERS1[504] = "Wales";

NORMAL_TRIVIA_QUESTIONS[505] = "(Valentines): Women plant onions in pots on Valentine's Day. Each onion is given a man's name and put near the fireplace. The first onion to sprout will be the intended. What country is this a tradition in? ";
NORMAL_TRIVIA_ANSWERS1[505] = "Germany";

NORMAL_TRIVIA_QUESTIONS[506] = "(Valentines): Cupid is the most famous of Valentine symbols and that boy, armed with bow and arrows, is known as a mischievious, winged child.  What do his arrows signify?";
NORMAL_TRIVIA_ANSWERS1[506] = "desire and love";
NORMAL_TRIVIA_ANSWERS2[506] = "desire";
NORMAL_TRIVIA_ANSWERS3[506] = "love";

NORMAL_TRIVIA_QUESTIONS[507] = "(Valentines): Ich liebe Dich means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[507] = "German";

NORMAL_TRIVIA_QUESTIONS[508] = "(Valentines): Je t'aime means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[508] = "French";

NORMAL_TRIVIA_QUESTIONS[509] = "(Valentines): Ti amo means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[509] = "Italian";

NORMAL_TRIVIA_QUESTIONS[510] = "(Valentines): Te quiero means  \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[510] = "Spanish";

NORMAL_TRIVIA_QUESTIONS[511] = "(Valentines): Eg elskar deg means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[511] = "Norwegian";

NORMAL_TRIVIA_QUESTIONS[512] = "(Valentines): Kimi o ai shiteru means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[512] = "Japanese";

NORMAL_TRIVIA_QUESTIONS[513] = "(Valentines): Moi oiy neya means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[513] = "Cantonese";

NORMAL_TRIVIA_QUESTIONS[514] = "(Valentines): Szeretlek! means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[514] = "Hungarian";

NORMAL_TRIVIA_QUESTIONS[515] = "(Valentines): S'ayapo! means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[515] = "Greek";

NORMAL_TRIVIA_QUESTIONS[516] = "(Valentines): Ik hou van je! means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[516] = "Dutch";

NORMAL_TRIVIA_QUESTIONS[517] = "(Valentines): t'a gr'a agam dhuit! means \"I love you\" in what language?";
NORMAL_TRIVIA_ANSWERS1[517] = "Irish";

NORMAL_TRIVIA_QUESTIONS[518] = "(Valentines): St. Valentine became the patron saint of  --- what? ";
NORMAL_TRIVIA_ANSWERS1[518] = "lovers";

NORMAL_TRIVIA_QUESTIONS[519] = "(Valentines): What well-named town in Colorado does a large post office business around February 14? ";
NORMAL_TRIVIA_ANSWERS1[519] = "Loveland";

NORMAL_TRIVIA_QUESTIONS[520] = "(Valentines): In what country is it only the women who buy gifts for the men for Valentine's Day? ";
NORMAL_TRIVIA_ANSWERS1[520] = "Japan";

NORMAL_TRIVIA_QUESTIONS[521] = "(Valentines): In 1537, which British king declared, by Royal Charter, that February 14 was \"Saint Valentine's Day\"?";
NORMAL_TRIVIA_ANSWERS1[521] = "King Henry the Eighth";
NORMAL_TRIVIA_ANSWERS2[521] = "Henry VIII";
NORMAL_TRIVIA_ANSWERS3[521] = "Henry the 8th";

NORMAL_TRIVIA_QUESTIONS[522] = "(Literature): What did they use for croquet mallets in Wonderland?";
NORMAL_TRIVIA_ANSWERS1[522] = "Flamingoes";
NORMAL_TRIVIA_ANSWERS2[522] = "flamingos";

NORMAL_TRIVIA_QUESTIONS[523] = "(Science & Nature): What two gases are used in a welding torch?";
NORMAL_TRIVIA_ANSWERS1[523] = "Oxygen and Acetylene";
NORMAL_TRIVIA_ANSWERS2[523] = "oxygen";
NORMAL_TRIVIA_ANSWERS3[523] = "acetylene";

NORMAL_TRIVIA_QUESTIONS[524] = "(Science & Nature): What is the closest star to the Earth?";
NORMAL_TRIVIA_ANSWERS1[524] = "The sun";
NORMAL_TRIVIA_ANSWERS2[524] = "sun";

NORMAL_TRIVIA_QUESTIONS[525] = "(History): What weapon was instrumental in the English victory at the Battle of Crecy?";
NORMAL_TRIVIA_ANSWERS1[525] = "Longbow";
NORMAL_TRIVIA_ANSWERS2[525] = "long bow";

NORMAL_TRIVIA_QUESTIONS[526] = "(Science & Nature): What poison is derived from the plant, foxglove?";
NORMAL_TRIVIA_ANSWERS1[526] = "Digitalis";

NORMAL_TRIVIA_QUESTIONS[527] = "(Entertainment): What is the appropriate response to the Vulcan salutation, \"Live long and prosper\"?";
NORMAL_TRIVIA_ANSWERS1[527] = "Peace and long life";

NORMAL_TRIVIA_QUESTIONS[528] = "(Science & Nature): What magical object did ancient alchemysts believe could turn lead into gold?";
NORMAL_TRIVIA_ANSWERS1[528] = "lodestone";
NORMAL_TRIVIA_ANSWERS2[528] = "lode stone";

NORMAL_TRIVIA_QUESTIONS[529] = "(Science & Nature): Name the process by which oxygen and hydrogen can be created from water.";
NORMAL_TRIVIA_ANSWERS1[529] = "electrolysis";

NORMAL_TRIVIA_QUESTIONS[530] = "(Art & Literature): In JRR Tolkien's mythos, what island sank beneath the sea?";
NORMAL_TRIVIA_ANSWERS1[530] = "Numenor (Akallabeth,Atalante)";
NORMAL_TRIVIA_ANSWERS2[530] = "Numenor";
NORMAL_TRIVIA_ANSWERS3[530] = "Akallabeth";

NORMAL_TRIVIA_QUESTIONS[531] = "(Art & Literature): What was the name of the giant whirlpool that Odysseus faced?";
NORMAL_TRIVIA_ANSWERS1[531] = "Charybdis";

NORMAL_TRIVIA_QUESTIONS[532] = "(History): Name the string of fortifications the French built in 1929 to defend against German invasion.";
NORMAL_TRIVIA_ANSWERS1[532] = "Maginot Line";
NORMAL_TRIVIA_ANSWERS2[532] = "Maginot";

NORMAL_TRIVIA_QUESTIONS[533] = "(Science & Nature): What does a sphygmomanometer measure?";
NORMAL_TRIVIA_ANSWERS1[533] = "Blood pressure";

NORMAL_TRIVIA_QUESTIONS[534] = "(Art & Literature): Which Indian goddess was known as \"the Black Mother\"?";
NORMAL_TRIVIA_ANSWERS1[534] = "Kali";

NORMAL_TRIVIA_QUESTIONS[535] = "(Pop Culture): What popular 60's mini-monster character did hot-rodder \"Big Daddy\" Ed Roth create?";
NORMAL_TRIVIA_ANSWERS1[535] = "Rat-fink";
NORMAL_TRIVIA_ANSWERS2[535] = "ratfink";
NORMAL_TRIVIA_ANSWERS3[535] = "rat fink";

NORMAL_TRIVIA_QUESTIONS[536] = "(Science & Nature): When measuring acidity and alkalinity, what does \"pH\" stand for?";
NORMAL_TRIVIA_ANSWERS1[536] = "per hydroxide";

NORMAL_TRIVIA_QUESTIONS[537] = "(Art & Literature): What kind of sword slew Lewis Carrol's Jaberwocky?";
NORMAL_TRIVIA_ANSWERS1[537] = "Vorpal";

NORMAL_TRIVIA_QUESTIONS[538] = "(History): Who was the pilot of the U2 spy-plane shot down and captured by the Soviets on May 1, 1960?";
NORMAL_TRIVIA_ANSWERS1[538] = "Gary Francis Powers";
NORMAL_TRIVIA_ANSWERS2[538] = "Powers";
NORMAL_TRIVIA_ANSWERS3[538] = "Gary Powers";

NORMAL_TRIVIA_QUESTIONS[539] = "(Science & Nature): Which poison smells like almonds?";
NORMAL_TRIVIA_ANSWERS1[539] = "Cyanide";

NORMAL_TRIVIA_QUESTIONS[540] = "(History): What was Buddha's name before his enlightenment?";
NORMAL_TRIVIA_ANSWERS1[540] = "Sidhartha";
NORMAL_TRIVIA_ANSWERS2[540] = "Siddhartha";
NORMAL_TRIVIA_ANSWERS3[540] = "Sidharta";

NORMAL_TRIVIA_QUESTIONS[541] = "(Pop Culture): What popular toy consisting of two plastic balls attached to each other by a string were banned in 1972?";
NORMAL_TRIVIA_ANSWERS1[541] = "Klackers";
NORMAL_TRIVIA_ANSWERS2[541] = "Clackers";
NORMAL_TRIVIA_ANSWERS3[541] = "Whackers";

NORMAL_TRIVIA_QUESTIONS[542] = "(Art & Literature): Which Aztec god was known as the \"Plumed Serpent\"?";
NORMAL_TRIVIA_ANSWERS1[542] = "Quetzalcoatl";

NORMAL_TRIVIA_QUESTIONS[543] = "(Art & Literature): In Arthurian legend, which knight threw Excalibur back into the lake?";
NORMAL_TRIVIA_ANSWERS1[543] = "Bedevere";

NORMAL_TRIVIA_QUESTIONS[544] = "(History):  Who assassinated the Austrian Archduke, Francis Ferdinand?";
NORMAL_TRIVIA_ANSWERS1[544] = "Gavrilo Princip";
NORMAL_TRIVIA_ANSWERS2[544] = "Princip";

NORMAL_TRIVIA_QUESTIONS[545] = "(Science & Nature): What visionary inventor created the AC induction motor and caused an earthquake in New York while experimenting with high voltage?";
NORMAL_TRIVIA_ANSWERS1[545] = "Nikolai Tesla";
NORMAL_TRIVIA_ANSWERS2[545] = "Tesla";

NORMAL_TRIVIA_QUESTIONS[546] = "(Art & Literature): What manner of creature was Medusa?";
NORMAL_TRIVIA_ANSWERS1[546] = "Gorgon";

NORMAL_TRIVIA_QUESTIONS[547] = "(Pop Culture): What did the band Jefferson Airplane change their name to?";
NORMAL_TRIVIA_ANSWERS1[547] = "Jefferson Starship";

NORMAL_TRIVIA_QUESTIONS[548] = "(Art & Literature): What was Sherlock Holmes' brother's name?";
NORMAL_TRIVIA_ANSWERS1[548] = "Mycroft Holmes";
NORMAL_TRIVIA_ANSWERS2[548] = "Mycroft";

NORMAL_TRIVIA_QUESTIONS[549] = "(Entertainment): Name the specific part of the ship that HAL told Dave Bowman and Frank Poole was about to fail.";
NORMAL_TRIVIA_ANSWERS1[549] = "AE-35 unit";
NORMAL_TRIVIA_ANSWERS2[549] = "AE35 unit";

NORMAL_TRIVIA_QUESTIONS[550] = "(Good To Know): What dog breed bites people more often than any other?";
NORMAL_TRIVIA_ANSWERS1[550] = "German Shepherd";

NORMAL_TRIVIA_QUESTIONS[551] = "(Art & Literature): Zeus created warriors called Myrmidons out of what creatures?";
NORMAL_TRIVIA_ANSWERS1[551] = "Ants";
NORMAL_TRIVIA_ANSWERS2[551] = "Ant";

NORMAL_TRIVIA_QUESTIONS[552] = "(Art & Literature): What was Odysseus' dog's name?";
NORMAL_TRIVIA_ANSWERS1[552] = "Argo";

NORMAL_TRIVIA_QUESTIONS[553] = "(History): Name the largest airplane ever built?";
NORMAL_TRIVIA_ANSWERS1[553] = "Spruce Goose";

NORMAL_TRIVIA_QUESTIONS[554] = "(Science & Nature): What rock floats in water?";
NORMAL_TRIVIA_ANSWERS1[554] = "Pumice";

NORMAL_TRIVIA_QUESTIONS[555] = "(Art & Literature): Name 1 of the 4 Horsemen of the Apocalypse.";
NORMAL_TRIVIA_ANSWERS1[555] = "War, Pestilence, Famine and Death";
NORMAL_TRIVIA_ANSWERS2[555] = "War";
NORMAL_TRIVIA_ANSWERS3[555] = "Pestilence";

NORMAL_TRIVIA_QUESTIONS[556] = "(Entertainment): Vulcan blood is based on what metal?";
NORMAL_TRIVIA_ANSWERS1[556] = "Copper";

NORMAL_TRIVIA_QUESTIONS[557] = "(Art & Literature): What famous British novel begins with the line: \"It was a cold day in April, and the clocks were striking thirteen\"?";
NORMAL_TRIVIA_ANSWERS1[557] = "1984";

NORMAL_TRIVIA_QUESTIONS[558] = "(Art & Literature): According to Douglas Adams' Hitchhiker's Guide To The Galaxy, who designed Norway?";
NORMAL_TRIVIA_ANSWERS1[558] = "Slartibartfast";

NORMAL_TRIVIA_QUESTIONS[559] = "(History): What Kenyan secret terrorist organization revolted against British colonists in 1952?";
NORMAL_TRIVIA_ANSWERS1[559] = "Mau Mau";

NORMAL_TRIVIA_QUESTIONS[560] = "(Sciece & Nature): What is the most abundant metal in the Earth's crust?";
NORMAL_TRIVIA_ANSWERS1[560] = "Aluminum";

NORMAL_TRIVIA_QUESTIONS[561] = "(Art & Literature): In Norse mythology, what was the Twilight of the Gods called?";
NORMAL_TRIVIA_ANSWERS1[561] = "Ragnarok";

NORMAL_TRIVIA_QUESTIONS[562] = "(Entertainment): Name Quickdraw McGraw's sidekick.";
NORMAL_TRIVIA_ANSWERS1[562] = "Baba Looey";

NORMAL_TRIVIA_QUESTIONS[563] = "(History): What was the name of the battle in which Hannibal was defeated?";
NORMAL_TRIVIA_ANSWERS1[563] = "Zama";

NORMAL_TRIVIA_QUESTIONS[564] = "(Art & Literature): James Bond creator Ian Fleming wrote what famous children's story, later made into a movie?";
NORMAL_TRIVIA_ANSWERS1[564] = "Chitty Chitty Bang Bang";
NORMAL_TRIVIA_ANSWERS2[564] = "Chitty";
NORMAL_TRIVIA_ANSWERS3[564] = "Bang Bang";

NORMAL_TRIVIA_QUESTIONS[565] = "(History): One of the 7 Wonders of the ancient world was a giant bronze statue, what was it called?";
NORMAL_TRIVIA_ANSWERS1[565] = "Colossus of Rhodes";
NORMAL_TRIVIA_ANSWERS2[565] = "Colossus";
NORMAL_TRIVIA_ANSWERS3[565] = "Rhodes";

NORMAL_TRIVIA_QUESTIONS[566] = "(Art & Literature): In Norse mythology, the icy underworld was called?";
NORMAL_TRIVIA_ANSWERS1[566] = "Niflheim";
NORMAL_TRIVIA_ANSWERS2[566] = "Niflhel";

NORMAL_TRIVIA_QUESTIONS[567] = "(Entertainment): What song did the fictitious Dr. Chandra teach his famous computer HAL 9000 to sing?";
NORMAL_TRIVIA_ANSWERS1[567] = "Bicycle Built For Two";
NORMAL_TRIVIA_ANSWERS2[567] = "Bicycle";

NORMAL_TRIVIA_QUESTIONS[568] = "(Science & Nature): What is the name given to the change in pitch accompanied by an approaching or receeding sound source?";
NORMAL_TRIVIA_ANSWERS1[568] = "Doppler Effect";
NORMAL_TRIVIA_ANSWERS2[568] = "Doppler";

NORMAL_TRIVIA_QUESTIONS[569] = "(Art & Literature): Name 1 of Dumas' 3 musketeers.";
NORMAL_TRIVIA_ANSWERS1[569] = "Porthos, Athos and Aramis";
NORMAL_TRIVIA_ANSWERS2[569] = "Porthos";
NORMAL_TRIVIA_ANSWERS3[569] = "Athos";

NORMAL_TRIVIA_QUESTIONS[570] = "(Good To Know): What is the only man-made feature visible from space?";
NORMAL_TRIVIA_ANSWERS1[570] = "Great Wall of China";
NORMAL_TRIVIA_ANSWERS2[570] = "Great Wall";

NORMAL_TRIVIA_QUESTIONS[571] = "(Art & Literature): The classical medical symbol of two serpents wrapped around a staff is called a what?";
NORMAL_TRIVIA_ANSWERS1[571] = "Caduceus";

NORMAL_TRIVIA_QUESTIONS[572] = "(Art & Literature): Which Roman god had two faces?";
NORMAL_TRIVIA_ANSWERS1[572] = "Janus";

NORMAL_TRIVIA_QUESTIONS[573] = "(Entertainment): What was Dr. Who's phone booth called?";
NORMAL_TRIVIA_ANSWERS1[573] = "Tardis";

NORMAL_TRIVIA_QUESTIONS[574] = "(Entertainment): What words is the acronym HAL in the famous computer's name derived from?";
NORMAL_TRIVIA_ANSWERS1[574] = "Heuristically programmed ALgorithmic computer";
NORMAL_TRIVIA_ANSWERS2[574] = "Heuristically";
NORMAL_TRIVIA_ANSWERS3[574] = "ALgorithmic";

NORMAL_TRIVIA_QUESTIONS[575] = "(Art & Literature): Name Captain Nemo's submarine?";
NORMAL_TRIVIA_ANSWERS1[575] = "Nautilus";

NORMAL_TRIVIA_QUESTIONS[576] = "(History): In what ancient city did Alexander the Great die?";
NORMAL_TRIVIA_ANSWERS1[576] = "Babylon";

NORMAL_TRIVIA_QUESTIONS[577] = "(Science & Nature): What is the underside of a horse's hoove called?";
NORMAL_TRIVIA_ANSWERS1[577] = "Frog";

NORMAL_TRIVIA_QUESTIONS[578] = "(Art & Literature): In JRR Tolkien's Lord of the Rings, 3 wizards are mentioned by name: Gandalf, Saruman, and who? ";
NORMAL_TRIVIA_ANSWERS1[578] = "Radagast";

NORMAL_TRIVIA_QUESTIONS[579] = "(History): Which god was a favourite of the Roman legions, who sacrificed a bull to him in secret rituals?";
NORMAL_TRIVIA_ANSWERS1[579] = "Mithras";

NORMAL_TRIVIA_QUESTIONS[580] = "(Entertainment): Who dances the waltz in Mr. Kite's show?";
NORMAL_TRIVIA_ANSWERS1[580] = "Henry the Horse";
NORMAL_TRIVIA_ANSWERS2[580] = "Henry";

NORMAL_TRIVIA_QUESTIONS[581] = "(History): The ancient Egyptians used what substance as the earliest know contraceptive?";
NORMAL_TRIVIA_ANSWERS1[581] = "Crocodile dung";

NORMAL_TRIVIA_QUESTIONS[582] = "(Lord Of The Rings): What sort of trees flanked the West-door of Moria?";
NORMAL_TRIVIA_ANSWERS1[582] = "holly";

NORMAL_TRIVIA_QUESTIONS[583] = "(Lord Of The Rings): What was the Sindarin name for the black crows of Fangorn and Dunland?";
NORMAL_TRIVIA_ANSWERS1[583] = "crebain";

NORMAL_TRIVIA_QUESTIONS[584] = "(Lord Of The Rings): What was the false name adopted by Frodo when he set out for Rivendell?";
NORMAL_TRIVIA_ANSWERS1[584] = "Mr. Underhill";
NORMAL_TRIVIA_ANSWERS2[584] = "underhill";

NORMAL_TRIVIA_QUESTIONS[585] = "(Lord Of The Rings): What was Gandalf most famous for in the Shire?";
NORMAL_TRIVIA_ANSWERS1[585] = "fireworks";

NORMAL_TRIVIA_QUESTIONS[586] = "(Lord Of The Rings): Which of the 3 Elven-rings did Gandalf possess?";
NORMAL_TRIVIA_ANSWERS1[586] = "Narya";

NORMAL_TRIVIA_QUESTIONS[587] = "(Lord Of The Rings): Who, in legend, sailed with a Silmaril on his brow?";
NORMAL_TRIVIA_ANSWERS1[587] = "Earendil";

NORMAL_TRIVIA_QUESTIONS[588] = "(Lord Of The Rings): What underground halls were known as the Thousand Caves?";
NORMAL_TRIVIA_ANSWERS1[588] = "Menegroth";

NORMAL_TRIVIA_QUESTIONS[589] = "(Lord Of The Rings): What name did the Elves give to the wooden tree-platforms in Lothlorien?";
NORMAL_TRIVIA_ANSWERS1[589] = "talan";

NORMAL_TRIVIA_QUESTIONS[590] = "(Lord Of The Rings): In Middle Earth mythology, what island sank beneath the sea?";
NORMAL_TRIVIA_ANSWERS1[590] = "Numenor";
NORMAL_TRIVIA_ANSWERS2[590] = "Akallabeth";
NORMAL_TRIVIA_ANSWERS3[590] = "Atalante";

NORMAL_TRIVIA_QUESTIONS[591] = "(Lord Of The Rings): What did Boromir advise the Fellowship to take with them to the Redhorn Gate?";
NORMAL_TRIVIA_ANSWERS1[591] = "firewood";
NORMAL_TRIVIA_ANSWERS2[591] = "wood";

NORMAL_TRIVIA_QUESTIONS[592] = "(Lord Of The Rings): Who killed Saruman?";
NORMAL_TRIVIA_ANSWERS1[592] = "Grima Wormtongue";
NORMAL_TRIVIA_ANSWERS2[592] = "Wormtongue";

NORMAL_TRIVIA_QUESTIONS[593] = "(Lord Of The Rings): According to legend, who cut the One Ring from Sauron's hand?";
NORMAL_TRIVIA_ANSWERS1[593] = "Isildur";

NORMAL_TRIVIA_QUESTIONS[594] = "(Lord Of The Rings): What type of Orcs acted as elite warriors and commanders in the War of the Ring?";
NORMAL_TRIVIA_ANSWERS1[594] = "Uruk-hai";
NORMAL_TRIVIA_ANSWERS2[594] = "Uruk hai";

NORMAL_TRIVIA_QUESTIONS[595] = "(Lord Of The Rings): Which city was the original capital of Gondor?";
NORMAL_TRIVIA_ANSWERS1[595] = "Osgiliath";

NORMAL_TRIVIA_QUESTIONS[596] = "(Lord Of The Rings): Who had to be blindfolded before he was allowed to enter Lothlorien?";
NORMAL_TRIVIA_ANSWERS1[596] = "Gimli";

NORMAL_TRIVIA_QUESTIONS[597] = "(Lord Of The Rings): To what race of creatures did Gollum belong?";
NORMAL_TRIVIA_ANSWERS1[597] = "Hobbits";
NORMAL_TRIVIA_ANSWERS2[597] = "Hobbit";

NORMAL_TRIVIA_QUESTIONS[598] = "(Lord Of The Rings): What was Gollum's birth name?";
NORMAL_TRIVIA_ANSWERS1[598] = "Smeagol";

NORMAL_TRIVIA_QUESTIONS[599] = "(Lord Of The Rings): What was one of Sam's nicknames for Gollum?";
NORMAL_TRIVIA_ANSWERS1[599] = "Slinker or Stinker";
NORMAL_TRIVIA_ANSWERS2[599] = "Slinker";
NORMAL_TRIVIA_ANSWERS3[599] = "Stinker";

NORMAL_TRIVIA_QUESTIONS[600] = "(Lord Of The Rings): What tasted like dust and ashes to Gollum?";
NORMAL_TRIVIA_ANSWERS1[600] = "elven waybread (lembas)";
NORMAL_TRIVIA_ANSWERS2[600] = "lembas";
NORMAL_TRIVIA_ANSWERS3[600] = "waybread";

NORMAL_TRIVIA_QUESTIONS[601] = "(Lord Of The Rings): What was Aragorn's sword called?";
NORMAL_TRIVIA_ANSWERS1[601] = "Anduril";

NORMAL_TRIVIA_QUESTIONS[602] = "(Lord Of The Rings): What was the Sindarin name for the herb, kingsfoil?";
NORMAL_TRIVIA_ANSWERS1[602] = "athelas";

NORMAL_TRIVIA_QUESTIONS[603] = "(Lord Of The Rings): Who gave Aragorn an emerald brooch, for which he was nicknamed, Elfstone?";
NORMAL_TRIVIA_ANSWERS1[603] = "Galadriel";

NORMAL_TRIVIA_QUESTIONS[604] = "(Lord Of The Rings): Where was the \"Last Homely House\"?";
NORMAL_TRIVIA_ANSWERS1[604] = "Rivendell";

NORMAL_TRIVIA_QUESTIONS[605] = "(Lord Of The Rings): What was the Sindarin name for Weather Top?";
NORMAL_TRIVIA_ANSWERS1[605] = "Amon Sul";

NORMAL_TRIVIA_QUESTIONS[606] = "(Lord Of The Rings): What did Ghan-buri-Ghan call the Orcs?";
NORMAL_TRIVIA_ANSWERS1[606] = "gorgun";

NORMAL_TRIVIA_QUESTIONS[607] = "(Lord Of The Rings): What word opened the West-door of Moria?";
NORMAL_TRIVIA_ANSWERS1[607] = "mellon (friend)";
NORMAL_TRIVIA_ANSWERS2[607] = "mellon";
NORMAL_TRIVIA_ANSWERS3[607] = "friend";

NORMAL_TRIVIA_QUESTIONS[608] = "(Lord Of The Rings): What did Denethor hold in his hands as he died on the funeral pyre?";
NORMAL_TRIVIA_ANSWERS1[608] = "palantir the seeing stone";
NORMAL_TRIVIA_ANSWERS2[608] = "palantir";
NORMAL_TRIVIA_ANSWERS3[608] = "seeing stone";

NORMAL_TRIVIA_QUESTIONS[609] = "(Lord Of The Rings): What crop was Farmer Maggot famous for?";
NORMAL_TRIVIA_ANSWERS1[609] = "mushrooms";

NORMAL_TRIVIA_QUESTIONS[610] = "(Lord Of The Rings): What was the Elvish name for Saruman, meaning \"Man of Skill\"?";
NORMAL_TRIVIA_ANSWERS1[610] = "Curunir";

NORMAL_TRIVIA_QUESTIONS[611] = "(Lord Of The Rings): What color was Orc skin?";
NORMAL_TRIVIA_ANSWERS1[611] = "black";
NORMAL_TRIVIA_ANSWERS2[611] = "sallow";

NORMAL_TRIVIA_QUESTIONS[612] = "(Lord Of The Rings): In which tower was the Master-stone of the palantiri kept?";
NORMAL_TRIVIA_ANSWERS1[612] = "Cirith Ungol";

NORMAL_TRIVIA_QUESTIONS[613] = "(Lord Of The Rings):  What did Pippin drop as a sign to any rescuers while he was a prisoner of the Orc band?";
NORMAL_TRIVIA_ANSWERS1[613] = "brooch";

NORMAL_TRIVIA_QUESTIONS[614] = "(Lord Of The Rings): What region did Elessar give to the Shire?";
NORMAL_TRIVIA_ANSWERS1[614] = "Westmarch";

NORMAL_TRIVIA_QUESTIONS[615] = "(Lord Of The Rings): What was the name of Pippin's only child?";
NORMAL_TRIVIA_ANSWERS1[615] = "Faramir";

NORMAL_TRIVIA_QUESTIONS[616] = "(Lord Of The Rings): What was Durin's Bane?";
NORMAL_TRIVIA_ANSWERS1[616] = "Balrog";

NORMAL_TRIVIA_QUESTIONS[617] = "(Lord Of The Rings): Who attempted to recolonize Moria?";
NORMAL_TRIVIA_ANSWERS1[617] = "Balin";

NORMAL_TRIVIA_QUESTIONS[618] = "(Lord Of The Rings): What precious metal did the Dwarves most covet?";
NORMAL_TRIVIA_ANSWERS1[618] = "mithril";

NORMAL_TRIVIA_QUESTIONS[619] = "(Lord Of The Rings): What was the Dwarven name for Moria?";
NORMAL_TRIVIA_ANSWERS1[619] = "Khazad-dum";

NORMAL_TRIVIA_QUESTIONS[620] = "(Lord Of The Rings): What were the RingWraiths called in the Black Speech?";
NORMAL_TRIVIA_ANSWERS1[620] = "Numenor";

NORMAL_TRIVIA_QUESTIONS[621] = "(Lord Of The Rings): Who slew the Lord of the Nazgul?";
NORMAL_TRIVIA_ANSWERS1[621] = "Eowyn";

NORMAL_TRIVIA_QUESTIONS[622] = "(Lord Of The Rings): What was the Lord of the Nazgul called in ancient times?";
NORMAL_TRIVIA_ANSWERS1[622] = "Witch-king of Angmar";
NORMAL_TRIVIA_ANSWERS2[622] = "Angmar";

NORMAL_TRIVIA_QUESTIONS[623] = "(Lord Of The Rings): What was Rivendell called in Sindarin?";
NORMAL_TRIVIA_ANSWERS1[623] = "Imladris";

NORMAL_TRIVIA_QUESTIONS[624] = "(Lord Of The Rings): Which of the Three Elven rings did Elrond possess?";
NORMAL_TRIVIA_ANSWERS1[624] = "Vilya";

NORMAL_TRIVIA_QUESTIONS[625] = "(Lord Of The Rings): Deagol found the One Ring in which river?";
NORMAL_TRIVIA_ANSWERS1[625] = "Anduin";

NORMAL_TRIVIA_QUESTIONS[626] = "(Lord Of The Rings): What was the Elven name of Gandalf's sword?";
NORMAL_TRIVIA_ANSWERS1[626] = "Glamdring";

NORMAL_TRIVIA_QUESTIONS[627] = "(Lord Of The Rings): What does the name \"Glamdring\" mean?";
NORMAL_TRIVIA_ANSWERS1[627] = "foe-hammer";
NORMAL_TRIVIA_ANSWERS2[627] = "foe hammer";

NORMAL_TRIVIA_QUESTIONS[628] = "(Lord Of The Rings): Who was Legolas' father?";
NORMAL_TRIVIA_ANSWERS1[628] = "Thranduil";

NORMAL_TRIVIA_QUESTIONS[629] = "(Lord Of The Rings): What does the name \"Legolas\" mean?";
NORMAL_TRIVIA_ANSWERS1[629] = "leaves";

NORMAL_TRIVIA_QUESTIONS[630] = "(Lord Of The Rings): What land did Legolas help restore to its former beauty after the War of the Ring?";
NORMAL_TRIVIA_ANSWERS1[630] = "Ithilien";

NORMAL_TRIVIA_QUESTIONS[631] = "(Lord Of The Rings): What was the common name for the Istari?";
NORMAL_TRIVIA_ANSWERS1[631] = "wizards";

NORMAL_TRIVIA_QUESTIONS[632] = "(Lord Of The Rings): Saruman, Gandalf, Galadriel, Elrond, and Cirdan were the members of what organization formed to develop a strategy to deal with Sauron?";
NORMAL_TRIVIA_ANSWERS1[632] = "White Council";

NORMAL_TRIVIA_QUESTIONS[633] = "(Lord Of The Rings): Who replaced the Lord of the Nazgul as commander of Sauron's forces in the Battle of the Pelennor Fields?";
NORMAL_TRIVIA_ANSWERS1[633] = "Gothmog";

NORMAL_TRIVIA_QUESTIONS[634] = "(Lord Of The Rings): Which famous Dwarf did the Watcher in the Water kill?";
NORMAL_TRIVIA_ANSWERS1[634] = "Oin";

NORMAL_TRIVIA_QUESTIONS[635] = "(Lord Of The Rings): What was Barad-dur called in Orkish?";
NORMAL_TRIVIA_ANSWERS1[635] = "Lugburz";

NORMAL_TRIVIA_QUESTIONS[636] = "(Lord Of The Rings): What was Gollum's last word?";
NORMAL_TRIVIA_ANSWERS1[636] = "precious";

NORMAL_TRIVIA_QUESTIONS[637] = "(Lord Of The Rings): What was the name of Sauron's stronghold in Mirkwood?";
NORMAL_TRIVIA_ANSWERS1[637] = "Dol Guldur";

NORMAL_TRIVIA_QUESTIONS[638] = "(Lord Of The Rings): What was Sauron called during his reign in Dol Guldur?";
NORMAL_TRIVIA_ANSWERS1[638] = "Necromancer";

NORMAL_TRIVIA_QUESTIONS[639] = "(Lord Of The Rings): Who was Gimli's father?";
NORMAL_TRIVIA_ANSWERS1[639] = "Gloin";

NORMAL_TRIVIA_QUESTIONS[640] = "(Lord Of The Rings): Who was Prince of Dol Amroth during the War of the Rings?";
NORMAL_TRIVIA_ANSWERS1[640] = "Imrahil";

NORMAL_TRIVIA_QUESTIONS[641] = "(Lord Of The Rings): What was the name of the wild tree-creatures that the Ents controlled and brought to Helm's Deep?";
NORMAL_TRIVIA_ANSWERS1[641] = "huorns";

NORMAL_TRIVIA_QUESTIONS[642] = "(Lord Of The Rings): According to legend, who sailed his ship in the sky, with a Silmaril as a sign of hope to those oppressed by evil?";
NORMAL_TRIVIA_ANSWERS1[642] = "Earendil";

NORMAL_TRIVIA_QUESTIONS[643] = "(Lord Of The Rings): What were the evil wolves of Rhovanion (Mirkwood) called?";
NORMAL_TRIVIA_ANSWERS1[643] = "wargs";

NORMAL_TRIVIA_QUESTIONS[644] = "(Lord Of The Rings): What alias did Eowyn use when she disguised herself as a Rider of Rohan?";
NORMAL_TRIVIA_ANSWERS1[644] = "Dernhelm";

NORMAL_TRIVIA_QUESTIONS[645] = "(Lord Of The Rings): What were the elves of Lorien known as?";
NORMAL_TRIVIA_ANSWERS1[645] = "galadrim";

NORMAL_TRIVIA_QUESTIONS[646] = "(Lord Of The Rings): The Rangers of Ithilien called certain large battle creatures, mumakil.  What did the Hobbits call them?";
NORMAL_TRIVIA_ANSWERS1[646] = "oliphaunts";

NORMAL_TRIVIA_QUESTIONS[647] = "(Lord Of The Rings): Where was the only place you could shoot a mumak to kill it?";
NORMAL_TRIVIA_ANSWERS1[647] = "eye";
NORMAL_TRIVIA_ANSWERS2[647] = "the eye";

NORMAL_TRIVIA_QUESTIONS[648] = "(Lord Of The Rings): Name Tom Bombadil's wife.";
NORMAL_TRIVIA_ANSWERS1[648] = "Goldberry";

NORMAL_TRIVIA_QUESTIONS[649] = "(Lord Of The Rings): Who were the \"Three Hunters\" (in alphabetical order)?";
NORMAL_TRIVIA_ANSWERS1[649] = "Aragorn, Gimli, Legolas";
NORMAL_TRIVIA_ANSWERS2[649] = "Aragorn,Gimli,Legolas";
NORMAL_TRIVIA_ANSWERS3[649] = "Aragorn, Gimli, Legolas";

NORMAL_TRIVIA_QUESTIONS[650] = "(Lord Of The Rings): The heir of Isildur was the only living man who could safely pass where?";
NORMAL_TRIVIA_ANSWERS1[650] = "Paths of the Dead";

NORMAL_TRIVIA_QUESTIONS[651] = "(Lord Of The Rings): Who was the greatest ship-builder of Middle Earth?";
NORMAL_TRIVIA_ANSWERS1[651] = "Cirdan";

NORMAL_TRIVIA_QUESTIONS[652] = "(Lord Of The Rings): Who or what attacked Frodo, Merry and Pippin in the Old Forest?";
NORMAL_TRIVIA_ANSWERS1[652] = "Old Man Willow";

NORMAL_TRIVIA_QUESTIONS[653] = "(Lord Of The Rings): Who was Bill Ferny working for?";
NORMAL_TRIVIA_ANSWERS1[653] = "Saruman";

NORMAL_TRIVIA_QUESTIONS[654] = "(Lord Of The Rings): Who was the Lord of the Eagles?";
NORMAL_TRIVIA_ANSWERS1[654] = "Gwaihir";

NORMAL_TRIVIA_QUESTIONS[655] = "(Lord Of The Rings): Whom did the elves worship and sing about?";
NORMAL_TRIVIA_ANSWERS1[655] = "Elbereth";

NORMAL_TRIVIA_QUESTIONS[656] = "(Lord Of The Rings): What was the capital of Rohan?";
NORMAL_TRIVIA_ANSWERS1[656] = "Edoras";

NORMAL_TRIVIA_QUESTIONS[657] = "(Lord Of The Rings): What symbolic item was sent from Gondor to Rohan when the former needed help?";
NORMAL_TRIVIA_ANSWERS1[657] = "red arrow";
NORMAL_TRIVIA_ANSWERS2[657] = "arrow";

NORMAL_TRIVIA_QUESTIONS[658] = "(Lord Of The Rings): What priceless gift did King Elessar give to Sam Gamgee after the War of the Ring?";
NORMAL_TRIVIA_ANSWERS1[658] = "The Star of Elendil";
NORMAL_TRIVIA_ANSWERS2[658] = "diamond";
NORMAL_TRIVIA_ANSWERS3[658] = "star of elendil";

NORMAL_TRIVIA_QUESTIONS[659] = "(Lord Of The Rings): What large, treeless plain between the Dead Marshes and Cirith Gorgor was the site of the ancient battle between Sauron and the Last Alliance?";
NORMAL_TRIVIA_ANSWERS1[659] = "Dagorlad, the Battle Plain";
NORMAL_TRIVIA_ANSWERS2[659] = "Dagorlad";
NORMAL_TRIVIA_ANSWERS3[659] = "Battle Plain";

NORMAL_TRIVIA_QUESTIONS[660] = "(Lord Of The Rings): What was the land of the Corsairs?";
NORMAL_TRIVIA_ANSWERS1[660] = "Umbar";

NORMAL_TRIVIA_QUESTIONS[661] = "(Lord Of The Rings): Which Ranger was Aragorn's friend and standard-bearer?";
NORMAL_TRIVIA_ANSWERS1[661] = "Halbarad";

NORMAL_TRIVIA_QUESTIONS[662] = "(Lord Of The Rings): The Barrow-wights were evil spirits originally from where?";
NORMAL_TRIVIA_ANSWERS1[662] = "Angmar";

NORMAL_TRIVIA_QUESTIONS[663] = "(Lord Of The Rings): Who loaned his swift white horse, Asfaloth, to Frodo at the Ford of Bruinen?";
NORMAL_TRIVIA_ANSWERS1[663] = "Glorfindel";

NORMAL_TRIVIA_QUESTIONS[664] = "(Lord Of The Rings): What forest did the Ents inhabit?";
NORMAL_TRIVIA_ANSWERS1[664] = "Fangorn";

NORMAL_TRIVIA_QUESTIONS[665] = "(Lord Of The Rings): What unbreakable, black stone tower's name means \"the cunning mind\"?";
NORMAL_TRIVIA_ANSWERS1[665] = "Orthanc";

NORMAL_TRIVIA_QUESTIONS[666] = "(Lord Of The Rings): What parting gift did Galadriel give Frodo when he left Lorien?";
NORMAL_TRIVIA_ANSWERS1[666] = "Phial of Galadriel";
NORMAL_TRIVIA_ANSWERS2[666] = "phial";

NORMAL_TRIVIA_QUESTIONS[667] = "(Lord Of The Rings): What was used to wound Frodo on Weathertop?";
NORMAL_TRIVIA_ANSWERS1[667] = "Morgul-knife";
NORMAL_TRIVIA_ANSWERS2[667] = "knife";
NORMAL_TRIVIA_ANSWERS3[667] = "dagger";

NORMAL_TRIVIA_QUESTIONS[668] = "(Lord Of The Rings): What fortress at Helm's Deep was said to be unconquerable if defended?";
NORMAL_TRIVIA_ANSWERS1[668] = "Hornburg";

NORMAL_TRIVIA_QUESTIONS[669] = "(Lord Of The Rings): What did Sam call his pony from Bree?";
NORMAL_TRIVIA_ANSWERS1[669] = "Bill";

NORMAL_TRIVIA_QUESTIONS[670] = "(Geography): What structure's crowning spire stands out in the Courusant skyline?";
NORMAL_TRIVIA_ANSWERS1[670] = "The Jedi Temple's";
NORMAL_TRIVIA_ANSWERS2[670] = "Jedi Temple";

NORMAL_TRIVIA_QUESTIONS[671] = "(History): What Episode I star turned \"sweet sixteen\" on June 9, 1997?";
NORMAL_TRIVIA_ANSWERS1[671] = "Natalie Portman";
NORMAL_TRIVIA_ANSWERS2[671] = "Natalie";
NORMAL_TRIVIA_ANSWERS3[671] = "Portman";

NORMAL_TRIVIA_QUESTIONS[672] = "(History): What Pulp Fiction star landed a significant role in Episode I?";
NORMAL_TRIVIA_ANSWERS1[672] = "Samuel L. Jackson";
NORMAL_TRIVIA_ANSWERS2[672] = "Jackson";

NORMAL_TRIVIA_QUESTIONS[673] = "(History): What Episode I role was finally cast after casting director Robin Gurland looked at 3,000 actors?";
NORMAL_TRIVIA_ANSWERS1[673] = "Anakin Skywalker";
NORMAL_TRIVIA_ANSWERS2[673] = "Anakin";

NORMAL_TRIVIA_QUESTIONS[674] = "(History): Who starred in the movies Trainspotting and Shallow Grave before landing an Episode I role?";
NORMAL_TRIVIA_ANSWERS1[674] = "Ewan McGregor";
NORMAL_TRIVIA_ANSWERS2[674] = "Ewin MacGregor";
NORMAL_TRIVIA_ANSWERS3[674] = "mcgregor";

NORMAL_TRIVIA_QUESTIONS[675] = "(DroidsCreatures&Aliens): What role does Kenny Baker play for the fourth time, in Episode I?";
NORMAL_TRIVIA_ANSWERS1[675] = "R2-D2";
NORMAL_TRIVIA_ANSWERS2[675] = "r2d2";

NORMAL_TRIVIA_QUESTIONS[676] = "(Characters): What two actors did Nick Gillard train to be Jedi's for Episode I?";
NORMAL_TRIVIA_ANSWERS1[676] = "Liam Neeson and Ewan McGregor";
NORMAL_TRIVIA_ANSWERS2[676] = "Neeson and McGregor";
NORMAL_TRIVIA_ANSWERS3[676] = "neeson and macgregor";

NORMAL_TRIVIA_QUESTIONS[677] = "(History): Who served as producer of Episode I?";
NORMAL_TRIVIA_ANSWERS1[677] = "Rick McCallum";
NORMAL_TRIVIA_ANSWERS2[677] = "McCallum";
NORMAL_TRIVIA_ANSWERS3[677] = "maccallum";

NORMAL_TRIVIA_QUESTIONS[678] = "(History): Who landed a role in Episode I after he announced on a talk show that he was a huge Star Wars fan?";
NORMAL_TRIVIA_ANSWERS1[678] = "Samuel L. Jackson";
NORMAL_TRIVIA_ANSWERS2[678] = "Jackson";

NORMAL_TRIVIA_QUESTIONS[679] = "(Characters): What British actor portrays the Chancellor of the Galactic Senate in Episode I?";
NORMAL_TRIVIA_ANSWERS1[679] = "Terence Stamp";
NORMAL_TRIVIA_ANSWERS2[679] = "Terrence Stamp";
NORMAL_TRIVIA_ANSWERS3[679] = "stamp";

NORMAL_TRIVIA_QUESTIONS[680] = "(DroidsCreatures&Aliens): What type of droids monitor ship systems from the socket at the rear of some vehicles, in Episode I?";
NORMAL_TRIVIA_ANSWERS1[680] = "R2 units, or Astromech droids";
NORMAL_TRIVIA_ANSWERS2[680] = "R2 units";
NORMAL_TRIVIA_ANSWERS3[680] = "Astromech droids";

NORMAL_TRIVIA_QUESTIONS[681] = "(Wild Card): What Episode I star was discovered in a pizza parlor in 1992?";
NORMAL_TRIVIA_ANSWERS1[681] = "Natalie Portman";
NORMAL_TRIVIA_ANSWERS2[681] = "Portman";

NORMAL_TRIVIA_QUESTIONS[682] = "(Characters): What first name did Anakin's mother have?";
NORMAL_TRIVIA_ANSWERS1[682] = "Shmi";
NORMAL_TRIVIA_ANSWERS2[682] = "shimmi";
NORMAL_TRIVIA_ANSWERS3[682] = "shimmy";

NORMAL_TRIVIA_QUESTIONS[683] = "(History): What was Trisha Biggar in charge of designing for Episode I?";
NORMAL_TRIVIA_ANSWERS1[683] = "Costumes";

NORMAL_TRIVIA_QUESTIONS[684] = "(Geography): What Italian city were many Episode I scenes filmed in?";
NORMAL_TRIVIA_ANSWERS1[684] = "Naples";
NORMAL_TRIVIA_ANSWERS2[684] = "napoli";

NORMAL_TRIVIA_QUESTIONS[685] = "(Geography): What planet serves as the capital of the Galactic Republic in Episode I?";
NORMAL_TRIVIA_ANSWERS1[685] = "Coruscant";

NORMAL_TRIVIA_QUESTIONS[686] = "(History): Who starred opposite Arnold Schwarzenegger in Jingle All the Way before landing an Episode I role?";
NORMAL_TRIVIA_ANSWERS1[686] = "Jake Lloyd";
NORMAL_TRIVIA_ANSWERS2[686] = "lloyd";
NORMAL_TRIVIA_ANSWERS3[686] = "loyd";

NORMAL_TRIVIA_QUESTIONS[687] = "(Wild Card): What Star Wars role did Ewan McGregor say it would be interesting to play after sticking \"some big pastries\" on his head?";
NORMAL_TRIVIA_ANSWERS1[687] = "Princess Leia";
NORMAL_TRIVIA_ANSWERS2[687] = "Leia";

NORMAL_TRIVIA_QUESTIONS[688] = "(Geography): What North African country were Episode I's Tatooine village scenes filmed in?";
NORMAL_TRIVIA_ANSWERS1[688] = "Tunisia";

NORMAL_TRIVIA_QUESTIONS[689] = "(History): How many Star Wars prequels does George Lucas plan to film?";
NORMAL_TRIVIA_ANSWERS1[689] = "Three";
NORMAL_TRIVIA_ANSWERS2[689] = "3";

NORMAL_TRIVIA_QUESTIONS[690] = "(Characters): Who portrays Anakin Skywalker's mother in Episode I?";
NORMAL_TRIVIA_ANSWERS1[690] = "Pernilla August";
NORMAL_TRIVIA_ANSWERS2[690] = "Pernilla";
NORMAL_TRIVIA_ANSWERS3[690] = "August";

NORMAL_TRIVIA_QUESTIONS[691] = "(Characters): What political office does Palpatine hold, at the beginning of Episode I?";
NORMAL_TRIVIA_ANSWERS1[691] = "Senator";

NORMAL_TRIVIA_QUESTIONS[692] = "(Geography): What Episode I city did filmgoers get a glimpse of at the end of Return of the Jedi Special Edition?";
NORMAL_TRIVIA_ANSWERS1[692] = "Coruscant";

NORMAL_TRIVIA_QUESTIONS[693] = "(Wild Card): What Episode I actor did George Lucas describe as \"the center of the movie\"?";
NORMAL_TRIVIA_ANSWERS1[693] = "Liam Neeson";
NORMAL_TRIVIA_ANSWERS2[693] = "Neeson";
NORMAL_TRIVIA_ANSWERS3[693] = "nesson";

NORMAL_TRIVIA_QUESTIONS[694] = "(Characters): What Episode I star has been called \"the biggest thing out of Scotland since argyle socks\"?";
NORMAL_TRIVIA_ANSWERS1[694] = "Ewan McGregor";
NORMAL_TRIVIA_ANSWERS2[694] = "Ewan MacGregor";
NORMAL_TRIVIA_ANSWERS3[694] = "mcgregor";

NORMAL_TRIVIA_QUESTIONS[695] = "(Wild Card): What Episode I star majored in physics, computer science and drama at Queens College in Belfast?";
NORMAL_TRIVIA_ANSWERS1[695] = "Liam Neeson";
NORMAL_TRIVIA_ANSWERS2[695] = "Neeson";
NORMAL_TRIVIA_ANSWERS3[695] = "neison";

NORMAL_TRIVIA_QUESTIONS[696] = "(Characters): What holy city was Natalie Portman born in?";
NORMAL_TRIVIA_ANSWERS1[696] = "Jerusalem";

NORMAL_TRIVIA_QUESTIONS[697] = "(DroidsCreatures&Aliens): What are power droids also known as in Episode I, due to the strange sound they make?";
NORMAL_TRIVIA_ANSWERS1[697] = "Gonk Droids";
NORMAL_TRIVIA_ANSWERS2[697] = "gonk";

NORMAL_TRIVIA_QUESTIONS[698] = "(DroidsCreatures&Aliens): Who had the daunting task of overseeing creature effects for Episode I?";
NORMAL_TRIVIA_ANSWERS1[698] = "Nick Dudman";
NORMAL_TRIVIA_ANSWERS2[698] = "Dudman";
NORMAL_TRIVIA_ANSWERS3[698] = "dudeman";

NORMAL_TRIVIA_QUESTIONS[699] = "(Characters): What role does Frank Oz reprise in Episode I?";
NORMAL_TRIVIA_ANSWERS1[699] = "Yoda";

NORMAL_TRIVIA_QUESTIONS[700] = "(Geography): What structure is topped by a ring of spikes?";
NORMAL_TRIVIA_ANSWERS1[700] = "The Jedi Temple's";
NORMAL_TRIVIA_ANSWERS2[700] = "Jedi Temple";

NORMAL_TRIVIA_QUESTIONS[701] = "(Characters): Who portrays the younger version of a character originally played by Sir Alex Guinness?";
NORMAL_TRIVIA_ANSWERS1[701] = "Ewan McGregor";
NORMAL_TRIVIA_ANSWERS2[701] = "MacGregor";
NORMAL_TRIVIA_ANSWERS3[701] = "Ewin Mcgregor";

NORMAL_TRIVIA_QUESTIONS[702] = "(Characters): What twins are slated to be born in the prequel trilogy?";
NORMAL_TRIVIA_ANSWERS1[702] = "Luke and Leia";
NORMAL_TRIVIA_ANSWERS2[702] = "Luke & Leia";
NORMAL_TRIVIA_ANSWERS3[702] = "Leia and Luke";

NORMAL_TRIVIA_QUESTIONS[703] = "(History): What famed Kurosawa film did Liam Neeson draw inspiration from while preparing to play a Jedi warrior in Episode I?";
NORMAL_TRIVIA_ANSWERS1[703] = "The Seven Samurai";
NORMAL_TRIVIA_ANSWERS2[703] = "seven samurai";
NORMAL_TRIVIA_ANSWERS3[703] = "7 samurai";

NORMAL_TRIVIA_QUESTIONS[704] = "(DroidsCreatures&Aliens): What Return of the Jedi gangster also gets to rear his ugly head in Episode I?";
NORMAL_TRIVIA_ANSWERS1[704] = "Jabba the Hutt";
NORMAL_TRIVIA_ANSWERS2[704] = "jabba";
NORMAL_TRIVIA_ANSWERS3[704] = "jabba the hut";

NORMAL_TRIVIA_QUESTIONS[705] = "(Wild Card): What Episode I star was six years old when the original Star Wars film was first released?";
NORMAL_TRIVIA_ANSWERS1[705] = "Ewan McGregor";
NORMAL_TRIVIA_ANSWERS2[705] = "McGregor";
NORMAL_TRIVIA_ANSWERS3[705] = "macgregor";

NORMAL_TRIVIA_QUESTIONS[706] = "(Geography): What Episode I planet consists entirely of one large city?";
NORMAL_TRIVIA_ANSWERS1[706] = "Coruscant";

NORMAL_TRIVIA_QUESTIONS[707] = "(Characters): Who portrays Anakin Skywalker in Episode I?";
NORMAL_TRIVIA_ANSWERS1[707] = "Jake Lloyd";
NORMAL_TRIVIA_ANSWERS2[707] = "Lloyd";
NORMAL_TRIVIA_ANSWERS3[707] = "loyd";

NORMAL_TRIVIA_QUESTIONS[708] = "(Characters): What actor portrays Obi-Wan Kenobi's mentor in Episode I?";
NORMAL_TRIVIA_ANSWERS1[708] = "Liam Neeson";
NORMAL_TRIVIA_ANSWERS2[708] = "Neeson";
NORMAL_TRIVIA_ANSWERS3[708] = "liam neison";

NORMAL_TRIVIA_QUESTIONS[709] = "(History): What Episode in the Star Wars saga will feature the marriage of Anakin Skywalker?";
NORMAL_TRIVIA_ANSWERS1[709] = "Episode II";
NORMAL_TRIVIA_ANSWERS2[709] = "episode 2";
NORMAL_TRIVIA_ANSWERS3[709] = "2";

NORMAL_TRIVIA_QUESTIONS[710] = "(History): What Episode I star did George Lucas describe as \"the perfect young Harrison Ford\"?";
NORMAL_TRIVIA_ANSWERS1[710] = "Ewan McGregor";
NORMAL_TRIVIA_ANSWERS2[710] = "Ewan MacGregor";
NORMAL_TRIVIA_ANSWERS3[710] = "ewin mcgregor";

NORMAL_TRIVIA_QUESTIONS[711] = "(Wild Card): What Episode I city was first mentioned in a Timothy Zahn novel?";
NORMAL_TRIVIA_ANSWERS1[711] = "Coruscant";

NORMAL_TRIVIA_QUESTIONS[712] = "(Geography): What Episode I city boasts the most two-mile-high skyscrapers?";
NORMAL_TRIVIA_ANSWERS1[712] = "Coruscant";

NORMAL_TRIVIA_QUESTIONS[713] = "(History): What did David Tattersall serve as director of for Episode I?";
NORMAL_TRIVIA_ANSWERS1[713] = "Photography";

NORMAL_TRIVIA_QUESTIONS[714] = "(History): What Episode I star is the real -life nephew of Dennis \"Wedge Antilles\" Lawson?";
NORMAL_TRIVIA_ANSWERS1[714] = "Ewan McGregor";
NORMAL_TRIVIA_ANSWERS2[714] = "Ewan MacGregor";
NORMAL_TRIVIA_ANSWERS3[714] = "ewin mcgregor";

NORMAL_TRIVIA_QUESTIONS[715] = "(DroidsCreatures&Aliens): What droid is ILM (Industrial Light & Magic) model maker Don Bies the foremost expert on the operation of?";
NORMAL_TRIVIA_ANSWERS1[715] = "R2-D2";
NORMAL_TRIVIA_ANSWERS2[715] = "R2D2";

NORMAL_TRIVIA_QUESTIONS[716] = "(Characters): Who was able to schedule her Episode I shooting schedule around rehearsals for a Broadway production of The Diary of Anne Frank?";
NORMAL_TRIVIA_ANSWERS1[716] = "Natalie Portman";
NORMAL_TRIVIA_ANSWERS2[716] = "Portman";

NORMAL_TRIVIA_QUESTIONS[717] = "(Characters): What Swedish actress plays a key role in Episode I?";
NORMAL_TRIVIA_ANSWERS1[717] = "Pernilla August";
NORMAL_TRIVIA_ANSWERS2[717] = "August";
NORMAL_TRIVIA_ANSWERS3[717] = "pernilla";

NORMAL_TRIVIA_QUESTIONS[718] = "(Characters): What astromech droid plays a major role in Episode I?";
NORMAL_TRIVIA_ANSWERS1[718] = "R2-D2";
NORMAL_TRIVIA_ANSWERS2[718] = "R2D2";

NORMAL_TRIVIA_QUESTIONS[719] = "(History): Who penned the screenplay for Episode I?";
NORMAL_TRIVIA_ANSWERS1[719] = "George Lucas";
NORMAL_TRIVIA_ANSWERS2[719] = "Lucas";

NORMAL_TRIVIA_QUESTIONS[720] = "(Characters): Who played Zod in two Superman movies before being tapped to play an Episode I role?";
NORMAL_TRIVIA_ANSWERS1[720] = "Terence Stamp";
NORMAL_TRIVIA_ANSWERS2[720] = "Terrence Stamp";
NORMAL_TRIVIA_ANSWERS3[720] = "tarrence stamp";

NORMAL_TRIVIA_QUESTIONS[721] = "(Geography): What desert's sandstorm devastated a set during Episode I filming?";
NORMAL_TRIVIA_ANSWERS1[721] = "The Sahara's";
NORMAL_TRIVIA_ANSWERS2[721] = "sahara's";

NORMAL_TRIVIA_QUESTIONS[722] = "(-DroidsCreatures&Aliens): What Episode I star did Liam Neeson describe as \"very, very gifted performer and a incredibly funny guy\"?";
NORMAL_TRIVIA_ANSWERS1[722] = "Ahmed Best";
NORMAL_TRIVIA_ANSWERS2[722] = "Best";

NORMAL_TRIVIA_QUESTIONS[723] = "(Wild Card): What Episode I star first appeared on the silver screen as the friend of the hitman?";
NORMAL_TRIVIA_ANSWERS1[723] = "Natalie Portman";
NORMAL_TRIVIA_ANSWERS2[723] = "Natalie";
NORMAL_TRIVIA_ANSWERS3[723] = "Portman";

NORMAL_TRIVIA_QUESTIONS[724] = "(Disney Names): In 'Beauty and the Beast', what is Beauty's name?";
NORMAL_TRIVIA_ANSWERS1[724] = "Belle";

NORMAL_TRIVIA_QUESTIONS[725] = "(Disney Names): In 'Toy Story', what is the name of the spaceman?";
NORMAL_TRIVIA_ANSWERS1[725] = "Buzz Lightyear";

NORMAL_TRIVIA_QUESTIONS[726] = "(Disney Names): What is the name of Mickey Mouse's dog?";
NORMAL_TRIVIA_ANSWERS1[726] = "Pluto";

NORMAL_TRIVIA_QUESTIONS[727] = "(Disney Names): Who is the good sorcerer in 'The Sword and the Stone'?";
NORMAL_TRIVIA_ANSWERS1[727] = "Merlin";

NORMAL_TRIVIA_QUESTIONS[728] = "(Disney Names): What is the name of the princess in 'Aladdin'?";
NORMAL_TRIVIA_ANSWERS1[728] = "Jasmine";

NORMAL_TRIVIA_QUESTIONS[729] = "(Disney Names): Who was the bad guy in 'Three Little Pigs'?";
NORMAL_TRIVIA_ANSWERS1[729] = "Big Bad Wolf";

NORMAL_TRIVIA_QUESTIONS[730] = "(Disney Names): Who is the tiny fairy in 'Peter Pan'?";
NORMAL_TRIVIA_ANSWERS1[730] = "Tinkerbell";
NORMAL_TRIVIA_ANSWERS2[730] = "Tinker bell";

NORMAL_TRIVIA_QUESTIONS[731] = "(Disney Names): Who is the leader of the grasshopper gang in 'A Bug's Life'?";
NORMAL_TRIVIA_ANSWERS1[731] = "Hopper";

NORMAL_TRIVIA_QUESTIONS[732] = "(Disney Names): What is the name of the 'Hunchback of Notre Dame'?";
NORMAL_TRIVIA_ANSWERS1[732] = "Quasimodo";

NORMAL_TRIVIA_QUESTIONS[733] = "(Disney Names): Who is the bad queen of the sea in 'The Little Mermaid'?";
NORMAL_TRIVIA_ANSWERS1[733] = "Ursula";

NORMAL_TRIVIA_QUESTIONS[734] = "(Disney Names): What is the name of the wart hog in 'The Lion King'?";
NORMAL_TRIVIA_ANSWERS1[734] = "Pumbaa";

NORMAL_TRIVIA_QUESTIONS[735] = "(Disney Names): What is the name of the cowboy in 'Toy Story'?";
NORMAL_TRIVIA_ANSWERS1[735] = "Woody";

NORMAL_TRIVIA_QUESTIONS[736] = "(Disney Names): What is the name of the baby lion who will become 'The Lion King'?";
NORMAL_TRIVIA_ANSWERS1[736] = "Simba";

NORMAL_TRIVIA_QUESTIONS[737] = "(Disney Names): What is the name of the meerkat in 'The Lion King'?";
NORMAL_TRIVIA_ANSWERS1[737] = "Timon";

NORMAL_TRIVIA_QUESTIONS[738] = "(Disney Names): What is the name of Winnie the Pooh's porky friend?";
NORMAL_TRIVIA_ANSWERS1[738] = "Piglet";

NORMAL_TRIVIA_QUESTIONS[739] = "(Disney Names): What is the name of the prince in 'Cinderella'?";
NORMAL_TRIVIA_ANSWERS1[739] = "Prince Charming";
NORMAL_TRIVIA_ANSWERS2[739] = "Charming";

NORMAL_TRIVIA_QUESTIONS[740] = "(Disney Names): Who is the lobster/crab in 'The Little Mermaid'?";
NORMAL_TRIVIA_ANSWERS1[740] = "Sebastian";

NORMAL_TRIVIA_QUESTIONS[741] = "(Disney Names): What is the name of the mermaid in 'The Little Mermaid'?";
NORMAL_TRIVIA_ANSWERS1[741] = "Ariel";

NORMAL_TRIVIA_QUESTIONS[742] = "(Disney Names): Who is the teapot in 'Beauty and the Beast'?";
NORMAL_TRIVIA_ANSWERS1[742] = "Mrs. Potts";
NORMAL_TRIVIA_ANSWERS2[742] = "Potts";

NORMAL_TRIVIA_QUESTIONS[743] = "(Disney Names): What is the name of Roger Rabbit's wife?";
NORMAL_TRIVIA_ANSWERS1[743] = "Jessica Rabbit";
NORMAL_TRIVIA_ANSWERS2[743] = "Jessica";

NORMAL_TRIVIA_QUESTIONS[744] = "(Disney Names): Who is 'The Little Mermaid's father?";
NORMAL_TRIVIA_ANSWERS1[744] = "King Triton";
NORMAL_TRIVIA_ANSWERS2[744] = "Triton";

NORMAL_TRIVIA_QUESTIONS[745] = "(Disney Names): Who is Mickey Mouse's girlfriend?";
NORMAL_TRIVIA_ANSWERS1[745] = "Minnie Mouse";
NORMAL_TRIVIA_ANSWERS2[745] = "Minnie";

NORMAL_TRIVIA_QUESTIONS[746] = "(Disney Names): Who is Donald Duck's girlfriend?";
NORMAL_TRIVIA_ANSWERS1[746] = "Daisy Duck";
NORMAL_TRIVIA_ANSWERS2[746] = "Daisy";

NORMAL_TRIVIA_QUESTIONS[747] = "(Disney Names): What is the name of Goofy's son?";
NORMAL_TRIVIA_ANSWERS1[747] = "Max";

NORMAL_TRIVIA_QUESTIONS[748] = "(Disney Names): Who is the pirate captain in 'Peter Pan'?";
NORMAL_TRIVIA_ANSWERS1[748] = "Captain Hook";

NORMAL_TRIVIA_QUESTIONS[749] = "(Disney Names): What is the name of 'The Little Mermaid's fish friend?";
NORMAL_TRIVIA_ANSWERS1[749] = "Flounder";

NORMAL_TRIVIA_QUESTIONS[750] = "(Disney Names): What friend of Winnie the Pooh bounces?";
NORMAL_TRIVIA_ANSWERS1[750] = "Tigger";

NORMAL_TRIVIA_QUESTIONS[751] = "(Disney Names): Who are the helpful matrons in 'Sleeping Beauty'?";
NORMAL_TRIVIA_ANSWERS1[751] = "Fairy Godmothers";
NORMAL_TRIVIA_ANSWERS2[751] = "godmother";

NORMAL_TRIVIA_QUESTIONS[752] = "(Disney Names): Who is the big blue star in 'Aladdin'?";
NORMAL_TRIVIA_ANSWERS1[752] = "The Genie";
NORMAL_TRIVIA_ANSWERS2[752] = "Genie";

NORMAL_TRIVIA_QUESTIONS[753] = "(Disney Names): What is the name of the main character in 'A Bug's Life'?";
NORMAL_TRIVIA_ANSWERS1[753] = "Flik";

NORMAL_TRIVIA_QUESTIONS[754] = "(Disney Names): Who is Winnie the Pooh's donkey friend?";
NORMAL_TRIVIA_ANSWERS1[754] = "Eeyore";

NORMAL_TRIVIA_QUESTIONS[755] = "(Disney Names): What is the name of the prince in 'Sleeping Beauty'?";
NORMAL_TRIVIA_ANSWERS1[755] = "Prince Phillip";
NORMAL_TRIVIA_ANSWERS2[755] = "Phillip";
NORMAL_TRIVIA_ANSWERS3[755] = "Philip";

NORMAL_TRIVIA_QUESTIONS[756] = "(Disney Names): What is the name of the goat in 'The Hunchback of Notre Dame'?";
NORMAL_TRIVIA_ANSWERS1[756] = "Djali";

NORMAL_TRIVIA_QUESTIONS[757] = "(Disney Names): What is the name of the baby princess in 'A Bug's Life'?";
NORMAL_TRIVIA_ANSWERS1[757] = "Princess Dot";
NORMAL_TRIVIA_ANSWERS2[757] = "Dot";

NORMAL_TRIVIA_QUESTIONS[758] = "(Disney Names): Name the cat in 'Pinocchio'";
NORMAL_TRIVIA_ANSWERS1[758] = "Figaro";

NORMAL_TRIVIA_QUESTIONS[759] = "(Disney Names): Who is the cowboy's girlfriend in 'Toy Story'?";
NORMAL_TRIVIA_ANSWERS1[759] = "Bo Peep";

NORMAL_TRIVIA_QUESTIONS[760] = "(Disney Names): What is the name of the car in 'Who Framed Roger Rabbit'?";
NORMAL_TRIVIA_ANSWERS1[760] = "Benny the Cab";
NORMAL_TRIVIA_ANSWERS2[760] = "Benny";
NORMAL_TRIVIA_ANSWERS3[760] = "Bennie";

NORMAL_TRIVIA_QUESTIONS[761] = "(Disney Names): Who is the good guy in 'The Rescuers'?";
NORMAL_TRIVIA_ANSWERS1[761] = "Bernard";

NORMAL_TRIVIA_QUESTIONS[762] = "(Disney Names): What is the name of the evil queen in 'Sleeping Beauty'?";
NORMAL_TRIVIA_ANSWERS1[762] = "Maleficent";

NORMAL_TRIVIA_QUESTIONS[763] = "(Disney Names): Who is the main deck hand on the pirate ship in 'Peter Pan'?";
NORMAL_TRIVIA_ANSWERS1[763] = "Mr. Smee";
NORMAL_TRIVIA_ANSWERS2[763] = "Mr Smee";
NORMAL_TRIVIA_ANSWERS3[763] = "Smee";

NORMAL_TRIVIA_QUESTIONS[764] = "(Disney Names): Name the racoon in 'Pocahontas'";
NORMAL_TRIVIA_ANSWERS1[764] = "Meeko";

NORMAL_TRIVIA_QUESTIONS[765] = "(Disney Names): Huey, Dewey and ?";
NORMAL_TRIVIA_ANSWERS1[765] = "Louie";

NORMAL_TRIVIA_QUESTIONS[766] = "(Disney Names): Who is the dog in 'Peter Pan'?";
NORMAL_TRIVIA_ANSWERS1[766] = "Nana";

NORMAL_TRIVIA_QUESTIONS[767] = "(Disney Names): Which dwarf had allergies?";
NORMAL_TRIVIA_ANSWERS1[767] = "Sneezy";

NORMAL_TRIVIA_QUESTIONS[768] = "(Disney Names): Which dwarf took too much NyQuil?";
NORMAL_TRIVIA_ANSWERS1[768] = "Sleepy";

NORMAL_TRIVIA_QUESTIONS[769] = "(Disney Names): Which dwarf never talked?";
NORMAL_TRIVIA_ANSWERS1[769] = "Dopey";

NORMAL_TRIVIA_QUESTIONS[770] = "(Disney Names): Which dwarf blushes a lot?";
NORMAL_TRIVIA_ANSWERS1[770] = "Bashful";

NORMAL_TRIVIA_QUESTIONS[771] = "(Disney Names): Which dwarf is in a bad mood?";
NORMAL_TRIVIA_ANSWERS1[771] = "Grumpy";

NORMAL_TRIVIA_QUESTIONS[772] = "(Disney Names): Which dwarf wears glasses?";
NORMAL_TRIVIA_ANSWERS1[772] = "Doc";

NORMAL_TRIVIA_QUESTIONS[773] = "(Disney Names): Which dwarf laughs a lot?";
NORMAL_TRIVIA_ANSWERS1[773] = "Happy";

NORMAL_TRIVIA_QUESTIONS[774] = "(Disney Names): Who is the protagonist in 'Song of the South'?";
NORMAL_TRIVIA_ANSWERS1[774] = "Brer Rabbit";

NORMAL_TRIVIA_QUESTIONS[775] = "(Disney Names): Who is Robin Hood's girlfriend?";
NORMAL_TRIVIA_ANSWERS1[775] = "Maid Marian";
NORMAL_TRIVIA_ANSWERS2[775] = "Marian";

NORMAL_TRIVIA_QUESTIONS[776] = "(Disney Names): Who runs the traveling circus in 'Pinocchio'?";
NORMAL_TRIVIA_ANSWERS1[776] = "Stromboli";

NORMAL_TRIVIA_QUESTIONS[777] = "(Disney Names): Name the rabbit in 'Bambi'";
NORMAL_TRIVIA_ANSWERS1[777] = "Thumper";

NORMAL_TRIVIA_QUESTIONS[778] = "(Disney Names): Name the skunk in 'Bambi'";
NORMAL_TRIVIA_ANSWERS1[778] = "Flower";

NORMAL_TRIVIA_QUESTIONS[779] = "(Disney Names): Who is the king of the apes in 'The Jungle Book'?";
NORMAL_TRIVIA_ANSWERS1[779] = "King Louie";
NORMAL_TRIVIA_ANSWERS2[779] = "Louie";

NORMAL_TRIVIA_QUESTIONS[780] = "(Disney Names): Who is the king of the apes, according to Edgar Rice Burroughs?";
NORMAL_TRIVIA_ANSWERS1[780] = "Tarzan";

NORMAL_TRIVIA_QUESTIONS[781] = "(Disney Names): Name the goldfish in 'Pinocchio'";
NORMAL_TRIVIA_ANSWERS1[781] = "Cleo";

NORMAL_TRIVIA_QUESTIONS[782] = "(Disney Names): Who is the hunter in 'Tarzan'?";
NORMAL_TRIVIA_ANSWERS1[782] = "Clayton";

NORMAL_TRIVIA_QUESTIONS[783] = "(Disney Names): In 'Alice in Wonderland', who exclaims \"Off with her head\"?";
NORMAL_TRIVIA_ANSWERS1[783] = "Queen of Hearts";

NORMAL_TRIVIA_QUESTIONS[784] = "(Disney Names): Who crossed the USA planting fruit trees?";
NORMAL_TRIVIA_ANSWERS1[784] = "Johnny Appleseed";

NORMAL_TRIVIA_QUESTIONS[785] = "(Disney Names): Who is the exotic dancer in 'A Bug's Life'?";
NORMAL_TRIVIA_ANSWERS1[785] = "Gypsy";

NORMAL_TRIVIA_QUESTIONS[786] = "(Disney Names): Who carved 'Pinocchio'?";
NORMAL_TRIVIA_ANSWERS1[786] = "Gepetto";

NORMAL_TRIVIA_QUESTIONS[787] = "(Disney Names): Name the dragon with attitude in 'Mulan'";
NORMAL_TRIVIA_ANSWERS1[787] = "Mushu";

NORMAL_TRIVIA_QUESTIONS[788] = "(Disney Names): Name the two chipmunk friends of Donald Duck.";
NORMAL_TRIVIA_ANSWERS1[788] = "Chip 'n Dale";
NORMAL_TRIVIA_ANSWERS2[788] = "Chip and Dale";
NORMAL_TRIVIA_ANSWERS3[788] = "Chip n Dale";

NORMAL_TRIVIA_QUESTIONS[789] = "(Disney Names): Who helps Cinderella get ready for the ball?";
NORMAL_TRIVIA_ANSWERS1[789] = "Fairy Godmother";

NORMAL_TRIVIA_QUESTIONS[790] = "(Disney Names): Who is the clock in 'Beauty and the Beast'?";
NORMAL_TRIVIA_ANSWERS1[790] = "Cogsworth";

NORMAL_TRIVIA_QUESTIONS[791] = "(Disney Names): Who is the bird in 'Aladdin'?";
NORMAL_TRIVIA_ANSWERS1[791] = "Iago";

NORMAL_TRIVIA_QUESTIONS[792] = "(Disney Names): Who is the father dog in '101 Dalmatians'?";
NORMAL_TRIVIA_ANSWERS1[792] = "Pongo";

NORMAL_TRIVIA_QUESTIONS[793] = "(Disney Names): Who is the bloodhound in \"Lady and the Tramp'?";
NORMAL_TRIVIA_ANSWERS1[793] = "Trusty";

NORMAL_TRIVIA_QUESTIONS[794] = "(Disney Names): Who is the leader of China in 'Mulan'?";
NORMAL_TRIVIA_ANSWERS1[794] = "The Emperor";
NORMAL_TRIVIA_ANSWERS2[794] = "emperor";

NORMAL_TRIVIA_QUESTIONS[795] = "(Disney Names): Who are the roly-poly bugs in 'A Bug's Life'?";
NORMAL_TRIVIA_ANSWERS1[795] = "Tuck 'n Roll";
NORMAL_TRIVIA_ANSWERS2[795] = "Tuck n Roll";
NORMAL_TRIVIA_ANSWERS3[795] = "Tuck and Roll";

NORMAL_TRIVIA_QUESTIONS[796] = "(Disney Names): Who is the Hunchback of Notre Dame's girlfriend?";
NORMAL_TRIVIA_ANSWERS1[796] = "Esmeralda";

NORMAL_TRIVIA_QUESTIONS[797] = "(Disney Names): Who is the heroine in 'The Rescuers'?";
NORMAL_TRIVIA_ANSWERS1[797] = "Ms. Bianca";
NORMAL_TRIVIA_ANSWERS2[797] = "Bianca";

NORMAL_TRIVIA_QUESTIONS[798] = "(Disney Names): Who is the bovine friend of Mickey and Goofy?";
NORMAL_TRIVIA_ANSWERS1[798] = "Clarabelle Cow";
NORMAL_TRIVIA_ANSWERS2[798] = "Clarabelle";

NORMAL_TRIVIA_QUESTIONS[799] = "(Disney Names): Who smokes a hookah in 'Alice in Wonderland'?";
NORMAL_TRIVIA_ANSWERS1[799] = "Caterpillar";

NORMAL_TRIVIA_QUESTIONS[800] = "(Disney Names): Who is the bad lion in 'The Lion King'?";
NORMAL_TRIVIA_ANSWERS1[800] = "Uncle Scar";
NORMAL_TRIVIA_ANSWERS2[800] = "Scar";

NORMAL_TRIVIA_QUESTIONS[801] = "(Disney Names): Which cat from 'Alice in Wonderland' fades to just a smile?";
NORMAL_TRIVIA_ANSWERS1[801] = "Cheshire Cat";
NORMAL_TRIVIA_ANSWERS2[801] = "cheshire";

NORMAL_TRIVIA_QUESTIONS[802] = "(Disney Names): Name one of the hoodlums in '101 Dalmatians'";
NORMAL_TRIVIA_ANSWERS1[802] = "Horace and Jasper";
NORMAL_TRIVIA_ANSWERS2[802] = "Horace";
NORMAL_TRIVIA_ANSWERS3[802] = "Jasper";

NORMAL_TRIVIA_QUESTIONS[803] = "(Disney Names): Who is the sidekick of the antagonist in 'Beauty and the Beast'?";
NORMAL_TRIVIA_ANSWERS1[803] = "LeFou";

NORMAL_TRIVIA_QUESTIONS[804] = "(Disney Names): Name the monkey in 'Aladdin'";
NORMAL_TRIVIA_ANSWERS1[804] = "Abu";

NORMAL_TRIVIA_QUESTIONS[805] = "(Disney Names): Who is the evil clergyman in 'The Hunchback of Notre Dame'?";
NORMAL_TRIVIA_ANSWERS1[805] = "Frollo";

NORMAL_TRIVIA_QUESTIONS[806] = "(Disney Names): Name the twin cats in 'Lady and the Tramp'";
NORMAL_TRIVIA_ANSWERS1[806] = "Si and Am";
NORMAL_TRIVIA_ANSWERS2[806] = "Si n Am";
NORMAL_TRIVIA_ANSWERS3[806] = "Am and Si";

NORMAL_TRIVIA_QUESTIONS[807] = "(Disney Names): Name the mother marsupial in 'Winnie the Pooh'";
NORMAL_TRIVIA_ANSWERS1[807] = "Kanga";

NORMAL_TRIVIA_QUESTIONS[808] = "(Disney Names): Name the baby marsupial in 'Winnie the Pooh'";
NORMAL_TRIVIA_ANSWERS1[808] = "Roo";

NORMAL_TRIVIA_QUESTIONS[809] = "(Disney Names): Name one of the eels in 'The Little Mermaid'";
NORMAL_TRIVIA_ANSWERS1[809] = "Flotsam and Jetsam";
NORMAL_TRIVIA_ANSWERS2[809] = "Flotsam";
NORMAL_TRIVIA_ANSWERS3[809] = "Jetsam";

NORMAL_TRIVIA_QUESTIONS[810] = "(Disney Names): Who falls asleep at the tea party in 'Alice in Wonderland'?";
NORMAL_TRIVIA_ANSWERS1[810] = "The Dormouse";
NORMAL_TRIVIA_ANSWERS2[810] = "Dormouse";

NORMAL_TRIVIA_QUESTIONS[811] = "(Disney Names): Who is 'The Great Mouse Detective'?";
NORMAL_TRIVIA_ANSWERS1[811] = "Basil";

NORMAL_TRIVIA_QUESTIONS[812] = "(Disney Names): Name the pipe organ in 'Beauty and the Beast Enchanted Christmas'";
NORMAL_TRIVIA_ANSWERS1[812] = "Forte";

NORMAL_TRIVIA_QUESTIONS[813] = "(Disney Names): Who is the crazy inventor and Beauty's father in 'Beauty and the Beast'?";
NORMAL_TRIVIA_ANSWERS1[813] = "Maurice";

NORMAL_TRIVIA_QUESTIONS[814] = "(Disney Names): Who is the hunter and all around egotist in 'Beauty and the Beast'?";
NORMAL_TRIVIA_ANSWERS1[814] = "Gaston";

NORMAL_TRIVIA_QUESTIONS[815] = "(Disney Names): Who wants to make a coat out of 101 Dalmatians?";
NORMAL_TRIVIA_ANSWERS1[815] = "Cruella de Vil";
NORMAL_TRIVIA_ANSWERS2[815] = "Cruella";
NORMAL_TRIVIA_ANSWERS3[815] = "De Vil";

NORMAL_TRIVIA_QUESTIONS[816] = "(Disney Names): What is the name of the teacup in 'Beauty and the Beast'?";
NORMAL_TRIVIA_ANSWERS1[816] = "Chip";

NORMAL_TRIVIA_QUESTIONS[817] = "(Disney Names): Which tea partier in 'Alice in Wonderland' wears a tophat?";
NORMAL_TRIVIA_ANSWERS1[817] = "The Mad Hatter";
NORMAL_TRIVIA_ANSWERS2[817] = "hatter";

NORMAL_TRIVIA_QUESTIONS[818] = "(Disney Names): Who is Pinocchio's conscience?";
NORMAL_TRIVIA_ANSWERS1[818] = "Jiminy Cricket";
NORMAL_TRIVIA_ANSWERS2[818] = "Jiminy";

NORMAL_TRIVIA_QUESTIONS[819] = "(Disney Names): Who is king in 'The Sword in the Stone'?";
NORMAL_TRIVIA_ANSWERS1[819] = "King Arthur";
NORMAL_TRIVIA_ANSWERS2[819] = "Arthur";

NORMAL_TRIVIA_QUESTIONS[820] = "(Disney Names): Name the princess' tiger in 'Aladdin'";
NORMAL_TRIVIA_ANSWERS1[820] = "Rajah";

NORMAL_TRIVIA_QUESTIONS[821] = "(Disney Names): Name the whale in 'Pinocchio'";
NORMAL_TRIVIA_ANSWERS1[821] = "Monstro";

NORMAL_TRIVIA_QUESTIONS[822] = "(Disney Names): Who is Mulan's trainer, leader, and love interest?";
NORMAL_TRIVIA_ANSWERS1[822] = "Shang";

NORMAL_TRIVIA_QUESTIONS[823] = "(Disney Names): Name the little dog in 'Pocahontas'";
NORMAL_TRIVIA_ANSWERS1[823] = "Percy";

NORMAL_TRIVIA_QUESTIONS[824] = "(Disney Names): Who is the snake in 'Robin Hood'?";
NORMAL_TRIVIA_ANSWERS1[824] = "Sir Hiss";

NORMAL_TRIVIA_QUESTIONS[825] = "(Disney Names): What is the name of the girl in 'Peter Pan'?";
NORMAL_TRIVIA_ANSWERS1[825] = "Wendy Darling";
NORMAL_TRIVIA_ANSWERS2[825] = "Wendy";

NORMAL_TRIVIA_QUESTIONS[826] = "(Disney Names): Who is the older brother in 'Peter Pan'?";
NORMAL_TRIVIA_ANSWERS1[826] = "John Darling";
NORMAL_TRIVIA_ANSWERS2[826] = "John";

NORMAL_TRIVIA_QUESTIONS[827] = "(Disney Names): Who owns the male dalmatian in '101 Dalmatians'?";
NORMAL_TRIVIA_ANSWERS1[827] = "Roger";

NORMAL_TRIVIA_QUESTIONS[828] = "(Disney Names): Name the piggy bank in 'Toy Story'";
NORMAL_TRIVIA_ANSWERS1[828] = "Hamm";

NORMAL_TRIVIA_QUESTIONS[829] = "(Disney Names): Who is Tarzan's girlfriend?";
NORMAL_TRIVIA_ANSWERS1[829] = "Jane Porter";
NORMAL_TRIVIA_ANSWERS2[829] = "Jane";

NORMAL_TRIVIA_QUESTIONS[830] = "(Disney Names): Who rules the country in 'Aladdin'?";
NORMAL_TRIVIA_ANSWERS1[830] = "The Sultan";
NORMAL_TRIVIA_ANSWERS2[830] = "sultan";

NORMAL_TRIVIA_QUESTIONS[831] = "(Disney Names): Who struck out 'at the bat'?";
NORMAL_TRIVIA_ANSWERS1[831] = "Casey";

NORMAL_TRIVIA_QUESTIONS[832] = "(Disney Names): Who was the giant in 'Mickey and the Beanstalk'?";
NORMAL_TRIVIA_ANSWERS1[832] = "Willie the Giant";
NORMAL_TRIVIA_ANSWERS2[832] = "Willie";

NORMAL_TRIVIA_QUESTIONS[833] = "(Disney Names): Who was the wise baboon in 'The Lion King'?";
NORMAL_TRIVIA_ANSWERS1[833] = "Rafiki";

NORMAL_TRIVIA_QUESTIONS[834] = "(Disney Names): Who was the boy in 'Winnie the Pooh'?";
NORMAL_TRIVIA_ANSWERS1[834] = "Christopher Robin";

NORMAL_TRIVIA_QUESTIONS[835] = "(Disney Names): Who was The Tramp's girlfriend?";
NORMAL_TRIVIA_ANSWERS1[835] = "Lady";

NORMAL_TRIVIA_QUESTIONS[836] = "(Disney Names): Name the bear in 'The Jungle Book'";
NORMAL_TRIVIA_ANSWERS1[836] = "Baloo";

NORMAL_TRIVIA_QUESTIONS[837] = "(Disney Names): Who wants the pirate captain for lunch in 'Peter Pan'?";
NORMAL_TRIVIA_ANSWERS1[837] = "Tic Toc Crocodile";
NORMAL_TRIVIA_ANSWERS2[837] = "crocodile";
NORMAL_TRIVIA_ANSWERS3[837] = "tic toc";

NORMAL_TRIVIA_QUESTIONS[838] = "(Disney Names): Name the elephant-bee in 'Winnie the Pooh'";
NORMAL_TRIVIA_ANSWERS1[838] = "Hefalumps";

NORMAL_TRIVIA_QUESTIONS[839] = "(Disney Names): Who leads the Huns in 'Mulan'?";
NORMAL_TRIVIA_ANSWERS1[839] = "Shan Yu";

NORMAL_TRIVIA_QUESTIONS[840] = "(Disney Names): Name the elephant in 'Tarzan'";
NORMAL_TRIVIA_ANSWERS1[840] = "Tantor";

NORMAL_TRIVIA_QUESTIONS[841] = "(Disney Names): Name the bird in 'The Lion King'";
NORMAL_TRIVIA_ANSWERS1[841] = "Zazu";

NORMAL_TRIVIA_QUESTIONS[842] = "(Disney Names): Name the good luck charm in 'Mulan'";
NORMAL_TRIVIA_ANSWERS1[842] = "Cri-Kee";
NORMAL_TRIVIA_ANSWERS2[842] = "Crikee";

NORMAL_TRIVIA_QUESTIONS[843] = "(Disney Names): Which bad guy in 'The Great Mouse Detective' had a wooden leg?";
NORMAL_TRIVIA_ANSWERS1[843] = "Fidget";

NORMAL_TRIVIA_QUESTIONS[844] = "(Disney Names): Who is Mulan's father?";
NORMAL_TRIVIA_ANSWERS1[844] = "Fa Zhou";

NORMAL_TRIVIA_QUESTIONS[845] = "(Disney Names): Who is the witch in 'The Sword in the Stone'?";
NORMAL_TRIVIA_ANSWERS1[845] = "Madam Mim";

NORMAL_TRIVIA_QUESTIONS[846] = "(Disney Names): Name the panther in 'The Jungle Book'";
NORMAL_TRIVIA_ANSWERS1[846] = "Bagheera";

NORMAL_TRIVIA_QUESTIONS[847] = "(Disney Names): Who is Hercules' father?";
NORMAL_TRIVIA_ANSWERS1[847] = "Zeus";

NORMAL_TRIVIA_QUESTIONS[848] = "(Disney Names): Who is the bad guy in 'Aladdin'?";
NORMAL_TRIVIA_ANSWERS1[848] = "Jafar";

NORMAL_TRIVIA_QUESTIONS[849] = "(Disney Names): Which Russian boy went hunting for wolves?";
NORMAL_TRIVIA_ANSWERS1[849] = "Peter";

NORMAL_TRIVIA_QUESTIONS[850] = "(Disney Names): Which of the Three Little Pigs built a brick house?";
NORMAL_TRIVIA_ANSWERS1[850] = "Practical Pig";
NORMAL_TRIVIA_ANSWERS2[850] = "practical";

NORMAL_TRIVIA_QUESTIONS[851] = "(Disney Names): Who is the beautiful lady cat in 'Aristocats'?";
NORMAL_TRIVIA_ANSWERS1[851] = "Duchess";

NORMAL_TRIVIA_QUESTIONS[852] = "(Disney Names): Who had a clam feast in 'Alice in Wonderland'?";
NORMAL_TRIVIA_ANSWERS1[852] = "Walrus";

NORMAL_TRIVIA_QUESTIONS[853] = "(Disney Names): Name Pete's Dragon";
NORMAL_TRIVIA_ANSWERS1[853] = "Elliot";

NORMAL_TRIVIA_QUESTIONS[854] = "(Disney Names): Bunyon/Bunyan//Who is the famous cartoon lumberjack?";
NORMAL_TRIVIA_ANSWERS1[854] = "Paul Bunyon";

NORMAL_TRIVIA_QUESTIONS[855] = "(Disney Names): Who knows 'who is fairest of all' in 'Snow White and the Seven Dwarfs'?";
NORMAL_TRIVIA_ANSWERS1[855] = "Magic Mirror";
NORMAL_TRIVIA_ANSWERS2[855] = "mirror";

NORMAL_TRIVIA_QUESTIONS[856] = "(Disney Names): What mother gorilla adopted Tarzan?";
NORMAL_TRIVIA_ANSWERS1[856] = "Kala";

NORMAL_TRIVIA_QUESTIONS[857] = "(Disney Names): Who was advisor to the leader of the country in 'Mulan'?";
NORMAL_TRIVIA_ANSWERS1[857] = "Chi Fu";

NORMAL_TRIVIA_QUESTIONS[858] = "(Disney Names): Name the cat in 'Cinderella'";
NORMAL_TRIVIA_ANSWERS1[858] = "Lucifer";

NORMAL_TRIVIA_QUESTIONS[859] = "(Disney Names): Who was the wife of the head god in 'Hercules'?";
NORMAL_TRIVIA_ANSWERS1[859] = "Hera";

NORMAL_TRIVIA_QUESTIONS[860] = "(Disney Names): Who was the baby gorilla in 'Tarzan'?";
NORMAL_TRIVIA_ANSWERS1[860] = "Turk";

NORMAL_TRIVIA_QUESTIONS[861] = "(Disney Names): Which of the Three Little Pigs built a straw house?";
NORMAL_TRIVIA_ANSWERS1[861] = "Fifer Pig";
NORMAL_TRIVIA_ANSWERS2[861] = "Fifer";

NORMAL_TRIVIA_QUESTIONS[862] = "(Disney Names): What are the jack-in-the-boxes called in 'Winnie the Pooh'?";
NORMAL_TRIVIA_ANSWERS1[862] = "Woozles";
NORMAL_TRIVIA_ANSWERS2[862] = "woozle";

NORMAL_TRIVIA_QUESTIONS[863] = "(Disney Names): Name Cinderella's stepmother";
NORMAL_TRIVIA_ANSWERS1[863] = "Lady Tremaine";

NORMAL_TRIVIA_QUESTIONS[864] = "(Disney Names): Who was the religious member of Robin Hood's gang?";
NORMAL_TRIVIA_ANSWERS1[864] = "Friar Tuck";

NORMAL_TRIVIA_QUESTIONS[865] = "(Disney Names): Which animal drank tea at the tea party in 'Alice in Wonderland'?";
NORMAL_TRIVIA_ANSWERS1[865] = "March Hare";

NORMAL_TRIVIA_QUESTIONS[866] = "(Disney Names): Name the older princess in 'A Bug's Life'";
NORMAL_TRIVIA_ANSWERS1[866] = "Princess Atta";
NORMAL_TRIVIA_ANSWERS2[866] = "Atta";

NORMAL_TRIVIA_QUESTIONS[867] = "(Disney Names): Who was the head rat in 'The Great Mouse Detective'?";
NORMAL_TRIVIA_ANSWERS1[867] = "Ratigan";

NORMAL_TRIVIA_QUESTIONS[868] = "(Disney Names): Who was Dumbo's mother?";
NORMAL_TRIVIA_ANSWERS1[868] = "Mrs. Jumbo";
NORMAL_TRIVIA_ANSWERS2[868] = "Jumbo";

NORMAL_TRIVIA_QUESTIONS[869] = "(Disney Names): Name the walking stick in 'A Bug's Life'";
NORMAL_TRIVIA_ANSWERS1[869] = "Slim";

NORMAL_TRIVIA_QUESTIONS[870] = "(Disney Names): Who was the candlestick holder in 'Beauty and the Beast'?";
NORMAL_TRIVIA_ANSWERS1[870] = "Lumiere";

NORMAL_TRIVIA_QUESTIONS[871] = "(Disney Names): Who was the evil ruler in 'Hercules'?";
NORMAL_TRIVIA_ANSWERS1[871] = "Hades";

NORMAL_TRIVIA_QUESTIONS[872] = "(Disney Names): Who was the prince in 'Robin Hood'?";
NORMAL_TRIVIA_ANSWERS1[872] = "Prince John";
NORMAL_TRIVIA_ANSWERS2[872] = "John";

NORMAL_TRIVIA_QUESTIONS[873] = "(Disney Names): Who was the younger brother in 'Peter Pan'?";
NORMAL_TRIVIA_ANSWERS1[873] = "Michael Darling";
NORMAL_TRIVIA_ANSWERS2[873] = "Michael";

NORMAL_TRIVIA_QUESTIONS[874] = "(Disney Names): Name the dinosaur in 'Toy Story'";
NORMAL_TRIVIA_ANSWERS1[874] = "Rex";

NORMAL_TRIVIA_QUESTIONS[875] = "(Disney Names): Name The Little Mermaid's bird friend";
NORMAL_TRIVIA_ANSWERS1[875] = "Scuttle";

NORMAL_TRIVIA_QUESTIONS[876] = "(Disney Names): Who was The Lion King's mother?";
NORMAL_TRIVIA_ANSWERS1[876] = "Sarabi";

NORMAL_TRIVIA_QUESTIONS[877] = "(Disney Names): Who was The Lion King's girlfriend?";
NORMAL_TRIVIA_ANSWERS1[877] = "Nala";

NORMAL_TRIVIA_QUESTIONS[878] = "(Disney Names): Who did Pocahontas save from the 'savages'?";
NORMAL_TRIVIA_ANSWERS1[878] = "John Smith";

NORMAL_TRIVIA_QUESTIONS[879] = "(Disney Names): Who did Alice follow down the rabbit hole?";
NORMAL_TRIVIA_ANSWERS1[879] = "White Rabbit";

NORMAL_TRIVIA_QUESTIONS[880] = "(Disney Names): Who is The Little Mermaid's boyfriend?";
NORMAL_TRIVIA_ANSWERS1[880] = "Prince Eric";
NORMAL_TRIVIA_ANSWERS2[880] = "Eric";

NORMAL_TRIVIA_QUESTIONS[881] = "(Disney Names): Who is Donald Duck's rich uncle?";
NORMAL_TRIVIA_ANSWERS1[881] = "Scrooge McDuck";
NORMAL_TRIVIA_ANSWERS2[881] = "Scrooge";

NORMAL_TRIVIA_QUESTIONS[882] = "(Disney Names): Who is the native adventurer mouse in 'The Rescuers Down Under'?";
NORMAL_TRIVIA_ANSWERS1[882] = "Jake";

NORMAL_TRIVIA_QUESTIONS[883] = "(Disney Names): Name the tiger in 'The Jungle Book'";
NORMAL_TRIVIA_ANSWERS1[883] = "Shere Khan";

NORMAL_TRIVIA_QUESTIONS[884] = "(Disney Names): Who were Cinderella's siblings?";
NORMAL_TRIVIA_ANSWERS1[884] = "The Evil Stepsisters";
NORMAL_TRIVIA_ANSWERS2[884] = "stepsister";

NORMAL_TRIVIA_QUESTIONS[885] = "(Disney Names): Name the flying horse in 'Hercules'";
NORMAL_TRIVIA_ANSWERS1[885] = "Pegasus";

NORMAL_TRIVIA_QUESTIONS[886] = "(Disney Names): What is the boy's name in 'The Jungle Book'?";
NORMAL_TRIVIA_ANSWERS1[886] = "Mowgli";

NORMAL_TRIVIA_QUESTIONS[887] = "(Disney Names): Who is the mouse in 'Dumbo'?";
NORMAL_TRIVIA_ANSWERS1[887] = "Timothy";

NORMAL_TRIVIA_QUESTIONS[888] = "(Disney Names): Who is the mouse in 'Aristocats'?";
NORMAL_TRIVIA_ANSWERS1[888] = "Roquefort";

NORMAL_TRIVIA_QUESTIONS[889] = "(Disney Names): Who is the mother dog in '101 Dalmatians'?";
NORMAL_TRIVIA_ANSWERS1[889] = "Perdita";
NORMAL_TRIVIA_ANSWERS2[889] = "Perdi";
NORMAL_TRIVIA_ANSWERS3[889] = "Perdy";

NORMAL_TRIVIA_QUESTIONS[890] = "(Disney Names): Who feeds a poison apple to Snow White?";
NORMAL_TRIVIA_ANSWERS1[890] = "The Old Witch";
NORMAL_TRIVIA_ANSWERS2[890] = "old witch";

NORMAL_TRIVIA_QUESTIONS[891] = "(Disney Names): Which of the Three Little Pigs built a wood house?";
NORMAL_TRIVIA_ANSWERS1[891] = "Fiddler Pig";

NORMAL_TRIVIA_QUESTIONS[892] = "(Disney Names): Who was the sheriff in 'Robin Hood'?";
NORMAL_TRIVIA_ANSWERS1[892] = "Sheriff of Nottingham";
NORMAL_TRIVIA_ANSWERS2[892] = "nottingham";

NORMAL_TRIVIA_QUESTIONS[893] = "(Disney Names): Who was The Lion King's father?";
NORMAL_TRIVIA_ANSWERS1[893] = "Mufasa";

NORMAL_TRIVIA_QUESTIONS[894] = "(Disney Names): Who is the boy in \"The Rescuers Down Under'?";
NORMAL_TRIVIA_ANSWERS1[894] = "Cody";

NORMAL_TRIVIA_QUESTIONS[895] = "(Disney Names): Who was in charge of the world before Zeus?";
NORMAL_TRIVIA_ANSWERS1[895] = "The Titans";
NORMAL_TRIVIA_ANSWERS2[895] = "Titan";

NORMAL_TRIVIA_QUESTIONS[896] = "(Disney Names): Who had a big adventure in a giant peach?";
NORMAL_TRIVIA_ANSWERS1[896] = "James";

NORMAL_TRIVIA_QUESTIONS[897] = "(Disney Names): Who was the snake in 'The Jungle Book'?";
NORMAL_TRIVIA_ANSWERS1[897] = "Kaa";

NORMAL_TRIVIA_QUESTIONS[898] = "(Disney Names): Name the multiheaded monster in 'Hercules'";
NORMAL_TRIVIA_ANSWERS1[898] = "Hydra";

NORMAL_TRIVIA_QUESTIONS[899] = "(Disney Names): Name the horse in 'Aristocats'";
NORMAL_TRIVIA_ANSWERS1[899] = "Frou Frou";

NORMAL_TRIVIA_QUESTIONS[900] = "(Disney Names): Name the twins in 'Alice in Wonderland'";
NORMAL_TRIVIA_ANSWERS1[900] = "Tweedledee and Tweedledum";
NORMAL_TRIVIA_ANSWERS2[900] = "Tweedledee";
NORMAL_TRIVIA_ANSWERS3[900] = "Tweedledum";

NORMAL_TRIVIA_QUESTIONS[901] = "(Disney Names): Who was the evil governor in 'Pocahontas'?";
NORMAL_TRIVIA_ANSWERS1[901] = "Governor Ratcliffe";
NORMAL_TRIVIA_ANSWERS2[901] = "ratcliff";

NORMAL_TRIVIA_QUESTIONS[902] = "(Disney Names): Who was the elephant-in-charge in 'The Jungle Book'?";
NORMAL_TRIVIA_ANSWERS1[902] = "Colonel Hathi";

NORMAL_TRIVIA_QUESTIONS[903] = "(Disney Names): Who is Goofy's neighbor in 'The Goofy Movie'?";
NORMAL_TRIVIA_ANSWERS1[903] = "Pete";

NORMAL_TRIVIA_QUESTIONS[904] = "(Disney Names): Who is the evil poacher in 'The Rescuers Down Under'?";
NORMAL_TRIVIA_ANSWERS1[904] = "Percival McLeach";
NORMAL_TRIVIA_ANSWERS2[904] = "Percival";
NORMAL_TRIVIA_ANSWERS3[904] = "Mcleach";

NORMAL_TRIVIA_QUESTIONS[905] = "(Disney Names): Who was the Sheepish Lion?";
NORMAL_TRIVIA_ANSWERS1[905] = "Lambert";

NORMAL_TRIVIA_QUESTIONS[906] = "(Lord Of The Rings): What was the name of Gandalf's great horse?";
NORMAL_TRIVIA_ANSWERS1[906] = "Shadowfax";

NORMAL_TRIVIA_QUESTIONS[907] = "(Lord Of The Rings): Who was Bilbo's nephew?";
NORMAL_TRIVIA_ANSWERS1[907] = "Frodo";

NORMAL_TRIVIA_QUESTIONS[908] = "(Lord Of The Rings): What was Bilbo's family name?";
NORMAL_TRIVIA_ANSWERS1[908] = "Baggins";

NORMAL_TRIVIA_QUESTIONS[909] = "(Lord Of The Rings): What branch of Bilbo's family did he not like?";
NORMAL_TRIVIA_ANSWERS1[909] = "Sackville-Baggins";
NORMAL_TRIVIA_ANSWERS2[909] = "Sackville";

NORMAL_TRIVIA_QUESTIONS[910] = "(Lord Of The Rings): Name the dragon that destroyed the lake-town of Esgaroth.";
NORMAL_TRIVIA_ANSWERS1[910] = "Smaug";

NORMAL_TRIVIA_QUESTIONS[911] = "(Lord Of The Rings): Who slew the dragon who was thought to be the King beneath the Mountain?";
NORMAL_TRIVIA_ANSWERS1[911] = "Bard";

NORMAL_TRIVIA_QUESTIONS[912] = "(Lord Of The Rings): At what age to Hobbits \"come of age\"?";
NORMAL_TRIVIA_ANSWERS1[912] = "Thirty three";
NORMAL_TRIVIA_ANSWERS2[912] = "33";
NORMAL_TRIVIA_ANSWERS3[912] = "thirtythree";

NORMAL_TRIVIA_QUESTIONS[913] = "(Lord Of The Rings): By what name was Aragorn known when Frodo first met him?";
NORMAL_TRIVIA_ANSWERS1[913] = "Strider";

NORMAL_TRIVIA_QUESTIONS[914] = "(Lord Of The Rings): Who were the shepherds of the trees?";
NORMAL_TRIVIA_ANSWERS1[914] = "The Ents";
NORMAL_TRIVIA_ANSWERS2[914] = "Ents";

NORMAL_TRIVIA_QUESTIONS[915] = "(Lord Of The Rings): What was the name of Frodo's elf-blade?";
NORMAL_TRIVIA_ANSWERS1[915] = "Sting";

NORMAL_TRIVIA_QUESTIONS[916] = "(Lord Of The Rings): What was Merry's full name?";
NORMAL_TRIVIA_ANSWERS1[916] = "Meriadoc Brandybuck";
NORMAL_TRIVIA_ANSWERS2[916] = "Meriadoc";
NORMAL_TRIVIA_ANSWERS3[916] = "Brandybuck";

NORMAL_TRIVIA_QUESTIONS[917] = "(Lord Of The Rings): What was Pippin's full name?";
NORMAL_TRIVIA_ANSWERS1[917] = "Peregrin Took";
NORMAL_TRIVIA_ANSWERS2[917] = "Peregrin";

NORMAL_TRIVIA_QUESTIONS[918] = "(Lord Of The Rings): What was Lobelia Sackville-Baggins known for snitching from Bilbo?";
NORMAL_TRIVIA_ANSWERS1[918] = "Silver spoons";
NORMAL_TRIVIA_ANSWERS2[918] = "spoon";

NORMAL_TRIVIA_QUESTIONS[919] = "(Lord Of The Rings): What was Bilbo's age at his birthday party where he disappeared?";
NORMAL_TRIVIA_ANSWERS1[919] = "One hundred and eleven";
NORMAL_TRIVIA_ANSWERS2[919] = "111";

NORMAL_TRIVIA_QUESTIONS[920] = "(Lord Of The Rings): Where did Frodo first meet Aragorn?";
NORMAL_TRIVIA_ANSWERS1[920] = "The Prancing Pony";
NORMAL_TRIVIA_ANSWERS2[920] = "Prancing";

NORMAL_TRIVIA_QUESTIONS[921] = "(Lord Of The Rings): Who was King of the Mark of Rohan?";
NORMAL_TRIVIA_ANSWERS1[921] = "Theoden";

NORMAL_TRIVIA_QUESTIONS[922] = "(Lord Of The Rings): What was the name of the great Ent host who helped Merry and Pippin?";
NORMAL_TRIVIA_ANSWERS1[922] = "Treebeard";

NORMAL_TRIVIA_QUESTIONS[923] = "(Lord Of The Rings): What was Gimli's weapon of choice?";
NORMAL_TRIVIA_ANSWERS1[923] = "Axe";

NORMAL_TRIVIA_QUESTIONS[924] = "(Lord Of The Rings): Who was the heir of Denethor, Lord of the Tower of Guard?";
NORMAL_TRIVIA_ANSWERS1[924] = "Boromir";

NORMAL_TRIVIA_QUESTIONS[925] = "(Lord Of The Rings): What was Thorin's greatest treasure?";
NORMAL_TRIVIA_ANSWERS1[925] = "Arkenstone of Thrain";
NORMAL_TRIVIA_ANSWERS2[925] = "arkenstone";

NORMAL_TRIVIA_QUESTIONS[926] = "(Lord Of The Rings): Name the Orc who tried to steal the hobbits from Ugluk.";
NORMAL_TRIVIA_ANSWERS1[926] = "Grishnakh";

NORMAL_TRIVIA_QUESTIONS[927] = "(Lord Of The Rings): What do you call a gathering of Ents?";
NORMAL_TRIVIA_ANSWERS1[927] = "Entmoot";

NORMAL_TRIVIA_QUESTIONS[928] = "(Lord Of The Rings): Name the young, hasty Ent.";
NORMAL_TRIVIA_ANSWERS1[928] = "Quickbeam (Bregalad)";
NORMAL_TRIVIA_ANSWERS2[928] = "Quickbeam";
NORMAL_TRIVIA_ANSWERS3[928] = "Bregalad";

NORMAL_TRIVIA_QUESTIONS[929] = "(Lord Of The Rings): When Bilbo first met him, what was Galdalf's trademark color?";
NORMAL_TRIVIA_ANSWERS1[929] = "Galdalf The Grey";
NORMAL_TRIVIA_ANSWERS2[929] = "grey";
NORMAL_TRIVIA_ANSWERS3[929] = "gray";

NORMAL_TRIVIA_QUESTIONS[930] = "(Lord Of The Rings): Who took on the enchanted shape of a bear?";
NORMAL_TRIVIA_ANSWERS1[930] = "Beorn";

NORMAL_TRIVIA_QUESTIONS[931] = "(Lord Of The Rings): How did Gollum say that he acquired the One ring?";
NORMAL_TRIVIA_ANSWERS1[931] = "Birthday present";
NORMAL_TRIVIA_ANSWERS2[931] = "birthday";

NORMAL_TRIVIA_QUESTIONS[932] = "(Lord Of The Rings): Who was Bilbo's father?";
NORMAL_TRIVIA_ANSWERS1[932] = "Bungo Baggins";
NORMAL_TRIVIA_ANSWERS2[932] = "Bungo";

NORMAL_TRIVIA_QUESTIONS[933] = "(Lord Of The Rings): Name the second book of the Lord Of The Rings trilogy.";
NORMAL_TRIVIA_ANSWERS1[933] = "The Two Towers";
NORMAL_TRIVIA_ANSWERS2[933] = "Two Towers";

NORMAL_TRIVIA_QUESTIONS[934] = "(Lord Of The Rings): What was the title of the prelude book to the Lord Of The Rings trilogy?";
NORMAL_TRIVIA_ANSWERS1[934] = "The Hobbit";
NORMAL_TRIVIA_ANSWERS2[934] = "Hobbit";

NORMAL_TRIVIA_QUESTIONS[935] = "(Lord Of The Rings): What year was The Hobbit first published?";
NORMAL_TRIVIA_ANSWERS1[935] = "1937";

NORMAL_TRIVIA_QUESTIONS[936] = "(Lord Of The Rings): What was Bilbo's original job description, according to Galdalf?";
NORMAL_TRIVIA_ANSWERS1[936] = "Burglar";

NORMAL_TRIVIA_QUESTIONS[937] = "(Lord Of The Rings): Where was the Mountain Of Fire?";
NORMAL_TRIVIA_ANSWERS1[937] = "Mordor";

NORMAL_TRIVIA_QUESTIONS[938] = "(Sports&Leisure): Who played hoops with Godzilla in a Nike ad?";
NORMAL_TRIVIA_ANSWERS1[938] = "Charles Barkley";
NORMAL_TRIVIA_ANSWERS2[938] = "Barkley";

NORMAL_TRIVIA_QUESTIONS[939] = "(World): What soul singer said: \"Hair and teeth. If a man got those two things, he got it all\"?";
NORMAL_TRIVIA_ANSWERS1[939] = "James Brown";
NORMAL_TRIVIA_ANSWERS2[939] = "Brown";

NORMAL_TRIVIA_QUESTIONS[940] = "(World): Which gabber used the name Rusty Sharpe as a Top 40 disk jockey?";
NORMAL_TRIVIA_ANSWERS1[940] = "Rush Limbaugh";
NORMAL_TRIVIA_ANSWERS2[940] = "Limbaugh";

NORMAL_TRIVIA_QUESTIONS[941] = "(Sports&Leisure): Who improved her speed in the 50-yard dash by chasing jackrabbits in the Mojave Desert?";
NORMAL_TRIVIA_ANSWERS1[941] = "Florence Griffith Joyner";
NORMAL_TRIVIA_ANSWERS2[941] = "Joyner";

NORMAL_TRIVIA_QUESTIONS[942] = "(History): What member of the Supreme Court once complained about being the victim of a \"high-tech lynching\"?";
NORMAL_TRIVIA_ANSWERS1[942] = "Clarence Thomas";
NORMAL_TRIVIA_ANSWERS2[942] = "Thomas";
NORMAL_TRIVIA_ANSWERS3[942] = "Clarence";

NORMAL_TRIVIA_QUESTIONS[943] = "(World): Whose salute became one of the most widely circulated photos of 1963?";
NORMAL_TRIVIA_ANSWERS1[943] = "John Kennedy Jr.'s";
NORMAL_TRIVIA_ANSWERS2[943] = "Kennedy";

NORMAL_TRIVIA_QUESTIONS[944] = "(History): What dictator did George Bush accuse of a crime?";
NORMAL_TRIVIA_ANSWERS1[944] = "Saddam Hussein";
NORMAL_TRIVIA_ANSWERS2[944] = "Saddam";
NORMAL_TRIVIA_ANSWERS3[944] = "Hussein";

NORMAL_TRIVIA_QUESTIONS[945] = "(Arts&Entertainment): Who played a fisherman in 1937 and a priest in 1938 to win back-to-back best actor Oscars?";
NORMAL_TRIVIA_ANSWERS1[945] = "Spencer Tracy";
NORMAL_TRIVIA_ANSWERS2[945] = "Tracy";
NORMAL_TRIVIA_ANSWERS3[945] = "Spencer";

NORMAL_TRIVIA_QUESTIONS[946] = "(Arts&Entertainment): What TV talk show host did Eddie Murphy give a break to by casting him in \"Coming to America\"?";
NORMAL_TRIVIA_ANSWERS1[946] = "Arsenio Hall";
NORMAL_TRIVIA_ANSWERS2[946] = "Arsenio";
NORMAL_TRIVIA_ANSWERS3[946] = " Hall";

NORMAL_TRIVIA_QUESTIONS[947] = "(People&Places): What U.S. state adopted a cactus blossom as its state flower?";
NORMAL_TRIVIA_ANSWERS1[947] = "Arizona";

NORMAL_TRIVIA_QUESTIONS[948] = "(World): What rock-and-roller encouraged his teenage girlfriend to make a beehive hair statement?";
NORMAL_TRIVIA_ANSWERS1[948] = "Elvis Presley";
NORMAL_TRIVIA_ANSWERS2[948] = "Presley";
NORMAL_TRIVIA_ANSWERS3[948] = "Elvis";

NORMAL_TRIVIA_QUESTIONS[949] = "(Science&Nature): How many North American species have disappeared since the Pilgrims landed here?";
NORMAL_TRIVIA_ANSWERS1[949] = "500";
NORMAL_TRIVIA_ANSWERS2[949] = "five hundred";
NORMAL_TRIVIA_ANSWERS3[949] = "5 hundred";

NORMAL_TRIVIA_QUESTIONS[950] = "(Science&Nature): What did the developers dub the first genetically engineered tomato to get FDA approval?";
NORMAL_TRIVIA_ANSWERS1[950] = "Flavr Savr";

NORMAL_TRIVIA_QUESTIONS[951] = "(Science&Nature): What plant made Queen Elizabeth I gasp in 1560: \"It bites like an adder!\"?";
NORMAL_TRIVIA_ANSWERS1[951] = "Tobacco";

NORMAL_TRIVIA_QUESTIONS[952] = "(Sports&Leisure): What's the only country to have played in every World Cup soccer tournament?";
NORMAL_TRIVIA_ANSWERS1[952] = "Brazil";

NORMAL_TRIVIA_QUESTIONS[953] = "(World): Which president watched the most movies in his first year at the White House?";
NORMAL_TRIVIA_ANSWERS1[953] = "Bill Clinton";
NORMAL_TRIVIA_ANSWERS2[953] = "Clinton";

NORMAL_TRIVIA_QUESTIONS[954] = "(Arts&Entertainment): What four-letter word does Madonna sing most often, ranking ahead of \"baby\" and \"time\"? ";
NORMAL_TRIVIA_ANSWERS1[954] = "Love";
NORMAL_TRIVIA_ANSWERS2[954] = "love ";
NORMAL_TRIVIA_ANSWERS3[954] = " love";

NORMAL_TRIVIA_QUESTIONS[955] = "(People&Places): What war-torn former Olympic city saw Susan Sontag direct \"Waiting for Godot\" in 1993?";
NORMAL_TRIVIA_ANSWERS1[955] = "Sarajevo";

NORMAL_TRIVIA_QUESTIONS[956] = "(People&Places): How many stripes did the U.S. flag sport from 1795 to 1818?";
NORMAL_TRIVIA_ANSWERS1[956] = "Fifteen";
NORMAL_TRIVIA_ANSWERS2[956] = "15";

NORMAL_TRIVIA_QUESTIONS[957] = "(Science&Nature): What metallic element do you need 15 pounds of to build an atomic bomb?";
NORMAL_TRIVIA_ANSWERS1[957] = "Plutonium";

NORMAL_TRIVIA_QUESTIONS[958] = "(History): Who was the English queen, who had Mary Queen of Scots killed but named Mary's son her successor?";
NORMAL_TRIVIA_ANSWERS1[958] = "Elizabeth I";
NORMAL_TRIVIA_ANSWERS2[958] = "Elizabeth";

NORMAL_TRIVIA_QUESTIONS[959] = "(Arts&Entertainment): What movie did Paramount production head Dawn Steel dub \"a female Rocky\"?";
NORMAL_TRIVIA_ANSWERS1[959] = "Flashdance";

NORMAL_TRIVIA_QUESTIONS[960] = "(Arts&Entertainment): Who helmed four of the top 10 highest-grossing movies before finally winning an Oscar for his craft?";
NORMAL_TRIVIA_ANSWERS1[960] = "Steven Spielberg";
NORMAL_TRIVIA_ANSWERS2[960] = "Spielberg";
NORMAL_TRIVIA_ANSWERS3[960] = "Speilberg";

NORMAL_TRIVIA_QUESTIONS[961] = "(Arts&Entertainment): What three-word mantra do Wayne and Garth repeat upon meeting Alice Cooper in \"Wayne's World\"?";
NORMAL_TRIVIA_ANSWERS1[961] = "We're not worthy!";
NORMAL_TRIVIA_ANSWERS2[961] = "not worthy";

NORMAL_TRIVIA_QUESTIONS[962] = "(Science&Nature): What fly's appearance in 1975 threatened California's $16 billion agricultural industry?";
NORMAL_TRIVIA_ANSWERS1[962] = "The Mediterranean fruit fly's";
NORMAL_TRIVIA_ANSWERS2[962] = "fruit fly";
NORMAL_TRIVIA_ANSWERS3[962] = "Mediterranean";

NORMAL_TRIVIA_QUESTIONS[963] = "(World): What actress, wife of the company president, became this company's spokesperson in 1954?";
NORMAL_TRIVIA_ANSWERS1[963] = "Joan Crawford";
NORMAL_TRIVIA_ANSWERS2[963] = "Crawford";

NORMAL_TRIVIA_QUESTIONS[964] = "(Sports&Leisure): What substitute catcher, a lifetime .200 hitter, made 80 appearances on the \"Tonight\" show? ";
NORMAL_TRIVIA_ANSWERS1[964] = "Bob Uecker";
NORMAL_TRIVIA_ANSWERS2[964] = "Uecker";

NORMAL_TRIVIA_QUESTIONS[965] = "(World): What celebrity is with Richard Nixon in the National Archives' most-requested photo?";
NORMAL_TRIVIA_ANSWERS1[965] = "Elvis Presley";
NORMAL_TRIVIA_ANSWERS2[965] = "Presley";

NORMAL_TRIVIA_QUESTIONS[966] = "(World): What biblical prophet was hurled onto the beach?";
NORMAL_TRIVIA_ANSWERS1[966] = "Jonah";

NORMAL_TRIVIA_QUESTIONS[967] = "(Sports&Leisure): Which tendon, named for a thick-skinned Greek, is most likely to cause men trouble?";
NORMAL_TRIVIA_ANSWERS1[967] = "Achilles";

NORMAL_TRIVIA_QUESTIONS[968] = "(Science&Nature): What 1993 movie had folks gushing over the fate of an Orca whale?";
NORMAL_TRIVIA_ANSWERS1[968] = "Free Willy";

NORMAL_TRIVIA_QUESTIONS[969] = "(Arts&Entertainment): What type of enemy jet do potential Top Guns fight?";
NORMAL_TRIVIA_ANSWERS1[969] = "MiGs";
NORMAL_TRIVIA_ANSWERS2[969] = "migs ";
NORMAL_TRIVIA_ANSWERS3[969] = " migs";

NORMAL_TRIVIA_QUESTIONS[970] = "(People&Places): What city rings in the new year with a descending ball or apple?";
NORMAL_TRIVIA_ANSWERS1[970] = "New York";

NORMAL_TRIVIA_QUESTIONS[971] = "(History): Which member of a royal couple admitted: \"I'm as thick as a plank\"?";
NORMAL_TRIVIA_ANSWERS1[971] = "Princess Diana";
NORMAL_TRIVIA_ANSWERS2[971] = "diana";

NORMAL_TRIVIA_QUESTIONS[972] = "(People&Places): What is one of the three U.S. states that Glacier National Park is found in?";
NORMAL_TRIVIA_ANSWERS1[972] = "Idaho, Montana, Wyoming";
NORMAL_TRIVIA_ANSWERS2[972] = "idaho";
NORMAL_TRIVIA_ANSWERS3[972] = "montana";

NORMAL_TRIVIA_QUESTIONS[973] = "(Science&Nature): What's the term for a device that uses the sun and horizon to determine location?";
NORMAL_TRIVIA_ANSWERS1[973] = "Sextant";

NORMAL_TRIVIA_QUESTIONS[974] = "(Science&Nature): What product is well known for the slogan: \"Plop plop, fizz fizz, oh what a relief it is!\"?";
NORMAL_TRIVIA_ANSWERS1[974] = "Alka-Seltzer";
NORMAL_TRIVIA_ANSWERS2[974] = "seltzer";

NORMAL_TRIVIA_QUESTIONS[975] = "(History): What were shantytowns of the homeless dubbed during the Depression?";
NORMAL_TRIVIA_ANSWERS1[975] = "Hoovervilles";

NORMAL_TRIVIA_QUESTIONS[976] = "(Sports&Leisure): Who broke 93 bones trying to leap 36 cars on his motorcycle at the Astrodome?";
NORMAL_TRIVIA_ANSWERS1[976] = "Evel Knievel";
NORMAL_TRIVIA_ANSWERS2[976] = "Knievel";
NORMAL_TRIVIA_ANSWERS3[976] = "Kneivel";

NORMAL_TRIVIA_QUESTIONS[977] = "(World): Which future president would later see an exuberant Sammy Davis Jr. embrace him, from behind?";
NORMAL_TRIVIA_ANSWERS1[977] = "Richard Nixon";
NORMAL_TRIVIA_ANSWERS2[977] = "Nixon";

NORMAL_TRIVIA_QUESTIONS[978] = "(People&Places): What Caribbean nation saw its military leader threaten a man with a \"voodoo curse\" in 1994?";
NORMAL_TRIVIA_ANSWERS1[978] = "Haiti";

NORMAL_TRIVIA_QUESTIONS[979] = "(World): What six words completed the 1980s bumper sticker that started with \"I owe, I owe\"?";
NORMAL_TRIVIA_ANSWERS1[979] = "So off to work I go";

NORMAL_TRIVIA_QUESTIONS[980] = "(Arts&Entertainment): What 6.5-ton attraction was bought from the London Zoo over Queen Victoria's protest?";
NORMAL_TRIVIA_ANSWERS1[980] = "Jumbo";

NORMAL_TRIVIA_QUESTIONS[981] = "(Sports&Leisure): What chess piece is second in strength only to the queen?";
NORMAL_TRIVIA_ANSWERS1[981] = "Rook";

NORMAL_TRIVIA_QUESTIONS[982] = "(History): Whose heroics were cheered by all but New York City's street maintenance crew in 1927?";
NORMAL_TRIVIA_ANSWERS1[982] = "Charles Lindbergh's";
NORMAL_TRIVIA_ANSWERS2[982] = "Lindburg";
NORMAL_TRIVIA_ANSWERS3[982] = "Lindbergh";

NORMAL_TRIVIA_QUESTIONS[983] = "(Sports&Leisure): Who won the NBA's MVP award in 1984, 1985 and 1986?";
NORMAL_TRIVIA_ANSWERS1[983] = "Larry Bird";
NORMAL_TRIVIA_ANSWERS2[983] = "Bird ";
NORMAL_TRIVIA_ANSWERS3[983] = " Bird";

NORMAL_TRIVIA_QUESTIONS[984] = "(Science&Nature): What biblical unit of measure was defined as the length of forearm to fingertip on a grown man?";
NORMAL_TRIVIA_ANSWERS1[984] = "Cubit";

NORMAL_TRIVIA_QUESTIONS[985] = "(Arts&Entertainment): What Led Zeppelin tune was a rewrite of Willie Dixon's \"You Need Love\"?";
NORMAL_TRIVIA_ANSWERS1[985] = "Whole Lotta Love";

NORMAL_TRIVIA_QUESTIONS[986] = "(Science&Nature): What's the common term for the layout of a computer keyboard?";
NORMAL_TRIVIA_ANSWERS1[986] = "QWERTY keyboard";
NORMAL_TRIVIA_ANSWERS2[986] = "qwerty";

NORMAL_TRIVIA_QUESTIONS[987] = "(People&Places): What did Richard Gere's model and wife-to-be fashion from Reynolds Wrap before a quickie Las Vegas marriage?";
NORMAL_TRIVIA_ANSWERS1[987] = "Wedding rings";
NORMAL_TRIVIA_ANSWERS2[987] = "rings";

NORMAL_TRIVIA_QUESTIONS[988] = "(People&Places): Which country out-vetoed the other 48-to-4 in the United Nations Security Council in the 1980s?";
NORMAL_TRIVIA_ANSWERS1[988] = "The U.S.";
NORMAL_TRIVIA_ANSWERS2[988] = "USA";
NORMAL_TRIVIA_ANSWERS3[988] = "United";

NORMAL_TRIVIA_QUESTIONS[989] = "(People&Places): What city attracted Van Gogh and Toulouse-Lautrec to its bohemian Montmartre district?";
NORMAL_TRIVIA_ANSWERS1[989] = "Paris";

NORMAL_TRIVIA_QUESTIONS[990] = "(History): Who committed \"The Slice Felt Round the World\" in 1993?";
NORMAL_TRIVIA_ANSWERS1[990] = "Lorena Bobbitt";
NORMAL_TRIVIA_ANSWERS2[990] = "Bobbitt";

NORMAL_TRIVIA_QUESTIONS[991] = "(History): Who's portrayed on the Purple Heart medal?";
NORMAL_TRIVIA_ANSWERS1[991] = "George Washington";
NORMAL_TRIVIA_ANSWERS2[991] = "Washington";

NORMAL_TRIVIA_QUESTIONS[992] = "(Sports&Leisure): Who's the shortest basketballer to win the NBA's Slam Dunk contest?";
NORMAL_TRIVIA_ANSWERS1[992] = "Spud Webb";
NORMAL_TRIVIA_ANSWERS2[992] = "Webb ";
NORMAL_TRIVIA_ANSWERS3[992] = " Webb";

NORMAL_TRIVIA_QUESTIONS[993] = "(Science&Nature): How many bolts of lightning strike somewhere on Earth each second?";
NORMAL_TRIVIA_ANSWERS1[993] = "100";
NORMAL_TRIVIA_ANSWERS2[993] = "hundred";

NORMAL_TRIVIA_QUESTIONS[994] = "(People&Places): What city boasts the world's largest Kentucky Fried Chicken restaurant?";
NORMAL_TRIVIA_ANSWERS1[994] = "Beijing";

NORMAL_TRIVIA_QUESTIONS[995] = "(Arts&Entertainment): What \"Saturday Night Live\" character's signature line was: \"Well, isn't that special?\"";
NORMAL_TRIVIA_ANSWERS1[995] = "Church Lady's";
NORMAL_TRIVIA_ANSWERS2[995] = "Church lady";

NORMAL_TRIVIA_QUESTIONS[996] = "(Science&Nature): What prevented Alexander Graham Bell from using the telephone to speak to his wife?";
NORMAL_TRIVIA_ANSWERS1[996] = "Her deafness";
NORMAL_TRIVIA_ANSWERS2[996] = "deaf";
NORMAL_TRIVIA_ANSWERS3[996] = " deaf";

NORMAL_TRIVIA_QUESTIONS[997] = "(Arts&Entertainment): What precocious preteen on \"Saturday Night Live\" sat in an oversized rocking chair?";
NORMAL_TRIVIA_ANSWERS1[997] = "Edith Ann";

NORMAL_TRIVIA_QUESTIONS[998] = "(World): What late German is the world's most-often-cited author in academic journals?";
NORMAL_TRIVIA_ANSWERS1[998] = "Karl Marx";
NORMAL_TRIVIA_ANSWERS2[998] = "Marx";
NORMAL_TRIVIA_ANSWERS3[998] = "Marx ";

NORMAL_TRIVIA_QUESTIONS[999] = "(Science&Nature): What are Eskimos believed to have 600 words for?";
NORMAL_TRIVIA_ANSWERS1[999] = "Snow";
NORMAL_TRIVIA_ANSWERS2[999] = " snow";
NORMAL_TRIVIA_ANSWERS3[999] = "snow ";

NORMAL_TRIVIA_QUESTIONS[1000] = "(Science&Nature): What emissions from cars dropped an amazing 96 percent in the U.S. from 1983 to 1993?";
NORMAL_TRIVIA_ANSWERS1[1000] = "Lead emissions";
NORMAL_TRIVIA_ANSWERS2[1000] = "lead";
NORMAL_TRIVIA_ANSWERS3[1000] = "lead ";

NORMAL_TRIVIA_QUESTIONS[1001] = "(Science&Nature): Which of Stephen Hawkings books is subtitled \"From the Big Bang to the Black Holes\"?";
NORMAL_TRIVIA_ANSWERS1[1001] = "A Brief History of Time";
NORMAL_TRIVIA_ANSWERS2[1001] = "brief history";
NORMAL_TRIVIA_ANSWERS3[1001] = "history of time";

NORMAL_TRIVIA_QUESTIONS[1002] = "(Sports&Leisure): What feat was Nolan Ryan the oldest pitcher in major league history to achieve, at age 43?";
NORMAL_TRIVIA_ANSWERS1[1002] = "Pitching a no-hitter";
NORMAL_TRIVIA_ANSWERS2[1002] = "no hitter";

NORMAL_TRIVIA_QUESTIONS[1003] = "(Science&Nature): What dangerous disease do dogs spread in the U.S. northeast and elsewhere?";
NORMAL_TRIVIA_ANSWERS1[1003] = "Rabies";

NORMAL_TRIVIA_QUESTIONS[1004] = "(People&Places): What Pacific island is home to mysterious statues?";
NORMAL_TRIVIA_ANSWERS1[1004] = "Easter Island";
NORMAL_TRIVIA_ANSWERS2[1004] = "easter";

NORMAL_TRIVIA_QUESTIONS[1005] = "(Science&Nature): What animal does the Australian government authorize killing two million of per year?";
NORMAL_TRIVIA_ANSWERS1[1005] = "Kangaroo";

NORMAL_TRIVIA_QUESTIONS[1006] = "(Arts&Entertainment): What Gloria Gaynor chart-topper was originally the \"B\" side of the single \"Substitute\"?";
NORMAL_TRIVIA_ANSWERS1[1006] = "I Will Survive";

NORMAL_TRIVIA_QUESTIONS[1007] = "(Arts&Entertainment): What's the name of the classic two-volume compendium from Rudyard Kipling?";
NORMAL_TRIVIA_ANSWERS1[1007] = "The Jungle Books ";
NORMAL_TRIVIA_ANSWERS2[1007] = "Jungle book";

NORMAL_TRIVIA_QUESTIONS[1008] = "(People&Places): Who answered a \"Today\" show question on French leader Valery Giscard d'Estaing with \"Who?\"?";
NORMAL_TRIVIA_ANSWERS1[1008] = "Ronald Reagan";
NORMAL_TRIVIA_ANSWERS2[1008] = "Reagan";

NORMAL_TRIVIA_QUESTIONS[1009] = "(Arts&Entertainment): What '50s sitcom airs every hour of every day somewhere in the world?";
NORMAL_TRIVIA_ANSWERS1[1009] = "I Love Lucy";

NORMAL_TRIVIA_QUESTIONS[1010] = "(Science&Nature): What archipelago did Charles Darwin call the \"origin of all my views\"?";
NORMAL_TRIVIA_ANSWERS1[1010] = "The Galapagos";
NORMAL_TRIVIA_ANSWERS2[1010] = "galapago";

NORMAL_TRIVIA_QUESTIONS[1011] = "(Sports&Leisure): What Clinton cabinet member wrestled an aligator for sport in the Everglades?";
NORMAL_TRIVIA_ANSWERS1[1011] = "Janet Reno";
NORMAL_TRIVIA_ANSWERS2[1011] = "Reno ";
NORMAL_TRIVIA_ANSWERS3[1011] = "reno";

NORMAL_TRIVIA_QUESTIONS[1012] = "(World): Who was Hugh Hefner's first \"Sweetheart of the Month\"?";
NORMAL_TRIVIA_ANSWERS1[1012] = "Marilyn Monroe";
NORMAL_TRIVIA_ANSWERS2[1012] = "Marilyn";
NORMAL_TRIVIA_ANSWERS3[1012] = "Monroe";

NORMAL_TRIVIA_QUESTIONS[1013] = "(Science&Nature): What unit of sound intensity commemorates an inventor's last name?";
NORMAL_TRIVIA_ANSWERS1[1013] = "Decibel";

NORMAL_TRIVIA_QUESTIONS[1014] = "(People&Places): Whose first night in jail prompted her hubby, Harry, to kill the lights in a skyscraper's tower?";
NORMAL_TRIVIA_ANSWERS1[1014] = "Leona Helmsley's";
NORMAL_TRIVIA_ANSWERS2[1014] = "Helmsley";

NORMAL_TRIVIA_QUESTIONS[1015] = "(Arts&Entertainment): What Jefferson Airplane hit described Alice of Wonderland fame as being 10 feet tall?";
NORMAL_TRIVIA_ANSWERS1[1015] = "White Rabbit";

NORMAL_TRIVIA_QUESTIONS[1016] = "(History): What kind of \"shadow\" adversely affected the telegenics of Richard Nixon in a 1960 debate?";
NORMAL_TRIVIA_ANSWERS1[1016] = "Five o'clock shadow";
NORMAL_TRIVIA_ANSWERS2[1016] = "5 o'clock";

NORMAL_TRIVIA_QUESTIONS[1017] = "(People&Places): What U.S. holiday took flight from a humble Pilgrim beginning?";
NORMAL_TRIVIA_ANSWERS1[1017] = "Thanksgiving";

NORMAL_TRIVIA_QUESTIONS[1018] = "(Science&Nature): How many species of sea turtles aren't endangered?";
NORMAL_TRIVIA_ANSWERS1[1018] = "Zero";
NORMAL_TRIVIA_ANSWERS2[1018] = "0";

NORMAL_TRIVIA_QUESTIONS[1019] = "(World): Who did Frank Sinatra reportedly call \"Botto\" before his duet on \"I've Got You Under My Skin\"?";
NORMAL_TRIVIA_ANSWERS1[1019] = "Bono";
NORMAL_TRIVIA_ANSWERS2[1019] = "bono ";
NORMAL_TRIVIA_ANSWERS3[1019] = " bono";

NORMAL_TRIVIA_QUESTIONS[1020] = "(Science&Nature): What president's name adorns the plaque left on the moon by the first astronauts to visit there?";
NORMAL_TRIVIA_ANSWERS1[1020] = "Richard Nixon's";
NORMAL_TRIVIA_ANSWERS2[1020] = "Nixon";

NORMAL_TRIVIA_QUESTIONS[1021] = "(People&Places): What 98-acre piece of real estate does the Imperial Palace in China overlook?";
NORMAL_TRIVIA_ANSWERS1[1021] = "Tiananmen Square";
NORMAL_TRIVIA_ANSWERS2[1021] = "Tiananmen";

NORMAL_TRIVIA_QUESTIONS[1022] = "(World): Which famous outlaw was a souvenir seeker trying to saw an ear off when the coroner stepped in?";
NORMAL_TRIVIA_ANSWERS1[1022] = "Clyde Barrow";
NORMAL_TRIVIA_ANSWERS2[1022] = "clyde";
NORMAL_TRIVIA_ANSWERS3[1022] = "barrow";

NORMAL_TRIVIA_QUESTIONS[1023] = "(World): Who declared: \"Everybody is ignorant, only on different subjects\"?";
NORMAL_TRIVIA_ANSWERS1[1023] = "Will Rogers";
NORMAL_TRIVIA_ANSWERS2[1023] = "rogers";

NORMAL_TRIVIA_QUESTIONS[1024] = "(People&Places): What nation sees Mount Everest share a border with Tibet?";
NORMAL_TRIVIA_ANSWERS1[1024] = "Nepal";

NORMAL_TRIVIA_QUESTIONS[1025] = "(People&Places): What amusement park has had three of its rides designated as New York City historical landmarks?";
NORMAL_TRIVIA_ANSWERS1[1025] = "Coney Island";
NORMAL_TRIVIA_ANSWERS2[1025] = "coney";

NORMAL_TRIVIA_QUESTIONS[1026] = "(People&Places): Who tap-danced at the Toledo, Ohio, Elks Club before turning to feminist pursuits?";
NORMAL_TRIVIA_ANSWERS1[1026] = "Gloria Steinem";
NORMAL_TRIVIA_ANSWERS2[1026] = "Steinem";

NORMAL_TRIVIA_QUESTIONS[1027] = "(Sports&Leisure): In blackjack, a hand of Ace and Nine can count as Ten or what?";
NORMAL_TRIVIA_ANSWERS1[1027] = "Twenty";
NORMAL_TRIVIA_ANSWERS2[1027] = "20";

NORMAL_TRIVIA_QUESTIONS[1028] = "(People&Places): What is the name of the isle that John and Paul want to summer on at age 64 \"if it's not too dear\"?";
NORMAL_TRIVIA_ANSWERS1[1028] = "The Isle of Wight";
NORMAL_TRIVIA_ANSWERS2[1028] = "Wight";

NORMAL_TRIVIA_QUESTIONS[1029] = "(Arts&Entertainment): What kind of pet did the Beaver and Wally hide from June and Ward in their toilet tank?";
NORMAL_TRIVIA_ANSWERS1[1029] = "Alligator";

NORMAL_TRIVIA_QUESTIONS[1030] = "(Sports&Leisure): What term was coined to describe a man's pioneering approach to clearing a high jump bar?";
NORMAL_TRIVIA_ANSWERS1[1030] = "The Fosbury flop";
NORMAL_TRIVIA_ANSWERS2[1030] = "Fosbury";

NORMAL_TRIVIA_QUESTIONS[1031] = "(Science&Nature): What type of power enables a submarine to circle the globe without surfacing?";
NORMAL_TRIVIA_ANSWERS1[1031] = "Nuclear";

NORMAL_TRIVIA_QUESTIONS[1032] = "(Arts&Entertainment): Whose 1994 \"Letterman\" appearance did Charles Grodin spoof by handing Dave his boxer shorts?";
NORMAL_TRIVIA_ANSWERS1[1032] = "Madonna's";
NORMAL_TRIVIA_ANSWERS2[1032] = "madonna";

NORMAL_TRIVIA_QUESTIONS[1033] = "(Arts&Entertainment): What Shakespeare play included creatures named Peaseblossom, Cobweb and Mustardseed?";
NORMAL_TRIVIA_ANSWERS1[1033] = "A Midsummer Night's Dream";
NORMAL_TRIVIA_ANSWERS2[1033] = "midsummer";
NORMAL_TRIVIA_ANSWERS3[1033] = "mid summer";

NORMAL_TRIVIA_QUESTIONS[1034] = "(People&Places): What color flower should never be sent to newlyweds in Hong Kong?";
NORMAL_TRIVIA_ANSWERS1[1034] = "White";

NORMAL_TRIVIA_QUESTIONS[1035] = "(World): What pop star bid adieu to his \"Uptown Girl\" during the Thanksgiving holidays in 1993?";
NORMAL_TRIVIA_ANSWERS1[1035] = "Billy Joel";
NORMAL_TRIVIA_ANSWERS2[1035] = "joel";
NORMAL_TRIVIA_ANSWERS3[1035] = "joel ";

NORMAL_TRIVIA_QUESTIONS[1036] = "(Science&Nature): Which of Thomas Edison's inventions did skeptic Jean Bouillaud attribute to ventriloquism?";
NORMAL_TRIVIA_ANSWERS1[1036] = "Phonograph";

NORMAL_TRIVIA_QUESTIONS[1037] = "(World): What did Angela Bowie say she made after she saw David in bed with Mick Jagger?";
NORMAL_TRIVIA_ANSWERS1[1037] = "Breakfast";

NORMAL_TRIVIA_QUESTIONS[1038] = "(People&Places): Where could you float a boat at 1,292 feet below sea level?";
NORMAL_TRIVIA_ANSWERS1[1038] = "The Dead Sea";
NORMAL_TRIVIA_ANSWERS2[1038] = "dead sea";

NORMAL_TRIVIA_QUESTIONS[1039] = "(World): What action star signed a $500,000 pact to include cigarettes in five feature films?";
NORMAL_TRIVIA_ANSWERS1[1039] = "Sylvester Stallone";
NORMAL_TRIVIA_ANSWERS2[1039] = "Stallone";

NORMAL_TRIVIA_QUESTIONS[1040] = "(Sports&Leisure): What pitcher's 2.58 earned run average was tops in the major leagues during the 1970s?";
NORMAL_TRIVIA_ANSWERS1[1040] = "Jim Palmer's";
NORMAL_TRIVIA_ANSWERS2[1040] = "Palmer";

NORMAL_TRIVIA_QUESTIONS[1041] = "(People&Places): Which is Big Ben - the tower, the clock or the bell?";
NORMAL_TRIVIA_ANSWERS1[1041] = "Bell";
NORMAL_TRIVIA_ANSWERS2[1041] = "bell ";
NORMAL_TRIVIA_ANSWERS3[1041] = " bell";

NORMAL_TRIVIA_QUESTIONS[1042] = "(Sports&Leisure): What Minnesota Twin noted: \"You don't get to pick your body. God just hands 'em out as He sees fit\"?";
NORMAL_TRIVIA_ANSWERS1[1042] = "Kirby Puckett";
NORMAL_TRIVIA_ANSWERS2[1042] = "Puckett";

NORMAL_TRIVIA_QUESTIONS[1043] = "(World): What enduring entree did McDonalds unleash on the world in 1983?";
NORMAL_TRIVIA_ANSWERS1[1043] = "Chicken McNuggets";
NORMAL_TRIVIA_ANSWERS2[1043] = "McNugget";

NORMAL_TRIVIA_QUESTIONS[1044] = "(History): What U.S. service academy displays \"Bring Me Men...\" atop a main quad entrance, despite female cadets?";
NORMAL_TRIVIA_ANSWERS1[1044] = "The Air Force Academy";
NORMAL_TRIVIA_ANSWERS2[1044] = "Air Force";

NORMAL_TRIVIA_QUESTIONS[1045] = "(World): Whose movies were banned in Germany when she defied a Nazi order to return to her homeland?";
NORMAL_TRIVIA_ANSWERS1[1045] = "Marlene Dietrich's";
NORMAL_TRIVIA_ANSWERS2[1045] = "Dietrich";

NORMAL_TRIVIA_QUESTIONS[1046] = "(Science&Nature): How many in eight smokers will die as a direct result of tobacco, according to a 1994 study?";
NORMAL_TRIVIA_ANSWERS1[1046] = "Four";
NORMAL_TRIVIA_ANSWERS2[1046] = "4";
NORMAL_TRIVIA_ANSWERS3[1046] = "four ";

NORMAL_TRIVIA_QUESTIONS[1047] = "(People&Places): What's the official language of Brazil?";
NORMAL_TRIVIA_ANSWERS1[1047] = "Portuguese";

NORMAL_TRIVIA_QUESTIONS[1048] = "(World): What 1960 chart-topper celebrated beach wear?";
NORMAL_TRIVIA_ANSWERS1[1048] = "Itsy Bitsy Teenie Weenie Yellow Polka Dot Bikini";
NORMAL_TRIVIA_ANSWERS2[1048] = "itsy bitsy";
NORMAL_TRIVIA_ANSWERS3[1048] = "teenie weenie";

NORMAL_TRIVIA_QUESTIONS[1049] = "(World): What flamboyant country diva chirped: \"You'd be surprised how much it costs to look this cheap\"?";
NORMAL_TRIVIA_ANSWERS1[1049] = "Dolly Parton";
NORMAL_TRIVIA_ANSWERS2[1049] = "parton";

NORMAL_TRIVIA_QUESTIONS[1050] = "(People&Places): What future \"Saturday Night Live\" star attended a Long Island high school?";
NORMAL_TRIVIA_ANSWERS1[1050] = "Eddie Murphy";
NORMAL_TRIVIA_ANSWERS2[1050] = "Murphy";

NORMAL_TRIVIA_QUESTIONS[1051] = "(Arts&Entertainment): What movie saw Whoopi Goldberg receive an Oscar nomination for her first screen role?";
NORMAL_TRIVIA_ANSWERS1[1051] = "The Color Purple";
NORMAL_TRIVIA_ANSWERS2[1051] = "color purple";

NORMAL_TRIVIA_QUESTIONS[1052] = "(Sports&Leisure): What basketballer's reluctance to talk to the media prompted them to dub him \"The Silent Sycamore\"?";
NORMAL_TRIVIA_ANSWERS1[1052] = "Larry Bird's";
NORMAL_TRIVIA_ANSWERS2[1052] = "Bird";
NORMAL_TRIVIA_ANSWERS3[1052] = "Bird ";

NORMAL_TRIVIA_QUESTIONS[1053] = "(History): What country did the \"President-for-Life\" beat a hasty retreat from on February 7, 1986?";
NORMAL_TRIVIA_ANSWERS1[1053] = "Haiti";

NORMAL_TRIVIA_QUESTIONS[1054] = "(Science&Nature): Which of Little Richard's songs did a Georgia politician push as the state rock song?";
NORMAL_TRIVIA_ANSWERS1[1054] = "Tutti Frutti";

NORMAL_TRIVIA_QUESTIONS[1055] = "(History): What holy man built an air-conditioned doghouse before going to the pen for misusing funds?";
NORMAL_TRIVIA_ANSWERS1[1055] = "Jim Bakker";
NORMAL_TRIVIA_ANSWERS2[1055] = "Bakker";

NORMAL_TRIVIA_QUESTIONS[1056] = "(Science&Nature): What U.S. state saw 60 people and much wildlife perish when a volcano erupted in 1980?";
NORMAL_TRIVIA_ANSWERS1[1056] = "Washington";

NORMAL_TRIVIA_QUESTIONS[1057] = "(History): What month saw the New York Stock Exchange's biggest price dives in both 1929 and 1987?";
NORMAL_TRIVIA_ANSWERS1[1057] = "October";

NORMAL_TRIVIA_QUESTIONS[1058] = "(People&Places): Who thrilled the Woodstock festival crowd with a rendition of a patriotic melody?";
NORMAL_TRIVIA_ANSWERS1[1058] = "Jimi Hendrix";
NORMAL_TRIVIA_ANSWERS2[1058] = "Hendrix";

NORMAL_TRIVIA_QUESTIONS[1059] = "(Sports&Leisure): What 10-time Chicago Cubs all-star abruptly retired three months into the 1994 season?";
NORMAL_TRIVIA_ANSWERS1[1059] = "Ryne Sandberg";
NORMAL_TRIVIA_ANSWERS2[1059] = "Sandberg";

NORMAL_TRIVIA_QUESTIONS[1060] = "(Arts&Entertainment): What onetime \"Mission: Impossible\" star suffered lung cancer, a brain tumor and a car crash?";
NORMAL_TRIVIA_ANSWERS1[1060] = "Greg Morris";
NORMAL_TRIVIA_ANSWERS2[1060] = "Morris";

NORMAL_TRIVIA_QUESTIONS[1061] = "(People&Places): What Judith Krantz TV miniseries had eight days of shooting in New York City and 75 in Toronto?";
NORMAL_TRIVIA_ANSWERS1[1061] = "I'll Take Manhattan";
NORMAL_TRIVIA_ANSWERS2[1061] = "Manhattan";

NORMAL_TRIVIA_QUESTIONS[1062] = "(People&Places): What four-letter nickname do Londoners apply to their subway?";
NORMAL_TRIVIA_ANSWERS1[1062] = "The tube";
NORMAL_TRIVIA_ANSWERS2[1062] = "Tube";
NORMAL_TRIVIA_ANSWERS3[1062] = "tube ";

NORMAL_TRIVIA_QUESTIONS[1063] = "(Sports&Leisure): What New York Yankees star was classified 4-F due to osteomyelitis in his left shin?";
NORMAL_TRIVIA_ANSWERS1[1063] = "Mickey Mantle";
NORMAL_TRIVIA_ANSWERS2[1063] = "mantle";

NORMAL_TRIVIA_QUESTIONS[1064] = "(World): What woman was the top gun in Buffalo Bill's Wild West Show?";
NORMAL_TRIVIA_ANSWERS1[1064] = "Annie Oakley";
NORMAL_TRIVIA_ANSWERS2[1064] = "oakley";

NORMAL_TRIVIA_QUESTIONS[1065] = "(World): Whose TV talk show had an elected official and Ross Perot clashing over NAFTA?";
NORMAL_TRIVIA_ANSWERS1[1065] = "Larry King's";
NORMAL_TRIVIA_ANSWERS2[1065] = "king";
NORMAL_TRIVIA_ANSWERS3[1065] = "king ";

NORMAL_TRIVIA_QUESTIONS[1066] = "(Sports&Leisure): What champ of chess ended a 20-year exile in 1992 to play Boris Spassky? ";
NORMAL_TRIVIA_ANSWERS1[1066] = "Bobby Fischer";
NORMAL_TRIVIA_ANSWERS2[1066] = "fischer";
NORMAL_TRIVIA_ANSWERS3[1066] = "fisher";

NORMAL_TRIVIA_QUESTIONS[1067] = "(World): What pre-\"Flashdance\" film also boasted a hit title tune sung by Irene Cara?";
NORMAL_TRIVIA_ANSWERS1[1067] = "Fame";
NORMAL_TRIVIA_ANSWERS2[1067] = "fame ";
NORMAL_TRIVIA_ANSWERS3[1067] = " fame";

NORMAL_TRIVIA_QUESTIONS[1068] = "(People&Places): What pioneering special effects company is located at Stephen Spielberg's facility in Marin County, California?";
NORMAL_TRIVIA_ANSWERS1[1068] = "Industrial Light & Magic";
NORMAL_TRIVIA_ANSWERS2[1068] = "ILM";
NORMAL_TRIVIA_ANSWERS3[1068] = "ILM ";

NORMAL_TRIVIA_QUESTIONS[1069] = "(People&Places): Who took out an ad in the \"The New York Times\" suggesting Saddam Hussein \"check out\" of Kuwait?";
NORMAL_TRIVIA_ANSWERS1[1069] = "Leona Helmsley";
NORMAL_TRIVIA_ANSWERS2[1069] = "Helmsley";

NORMAL_TRIVIA_QUESTIONS[1070] = "(People&Places): Who was the first European to stand atop Mount Everest?";
NORMAL_TRIVIA_ANSWERS1[1070] = "Edmund Hillary";
NORMAL_TRIVIA_ANSWERS2[1070] = "hillary";

NORMAL_TRIVIA_QUESTIONS[1071] = "(Arts&Entertainment): Who did Franco Zeffirelli call \"the most beautiful creation I have ever seen ... almost like a drug\"?";
NORMAL_TRIVIA_ANSWERS1[1071] = "Brooke Shields";
NORMAL_TRIVIA_ANSWERS2[1071] = "shields";

NORMAL_TRIVIA_QUESTIONS[1072] = "(History): What flying ace's nickname was inspired by the color of his Albatross biplane?";
NORMAL_TRIVIA_ANSWERS1[1072] = "Manfred von Richthofen (the Red Baron)";
NORMAL_TRIVIA_ANSWERS2[1072] = "Richthofen";
NORMAL_TRIVIA_ANSWERS3[1072] = "red baron";

NORMAL_TRIVIA_QUESTIONS[1073] = "(Sports&Leisure): What, drawn from a Greek epic, is the most popular sailboat name in the U.S.?";
NORMAL_TRIVIA_ANSWERS1[1073] = "Odyssey";

NORMAL_TRIVIA_QUESTIONS[1074] = "(History): Who did John Hinckley Jr. mean in writing: \"(She's) got the look I crave. What else can I say?\"?";
NORMAL_TRIVIA_ANSWERS1[1074] = "Jodie Foster";
NORMAL_TRIVIA_ANSWERS2[1074] = "foster";

NORMAL_TRIVIA_QUESTIONS[1075] = "(World): Who made the Statue Of Liberty disappear in a 1983 telecast?";
NORMAL_TRIVIA_ANSWERS1[1075] = "David Copperfield ";
NORMAL_TRIVIA_ANSWERS2[1075] = "copperfield";

NORMAL_TRIVIA_QUESTIONS[1076] = "(World): What Long Islander's beeper contract fetched $1,430 at auction?";
NORMAL_TRIVIA_ANSWERS1[1076] = "Amy Fisher's";
NORMAL_TRIVIA_ANSWERS2[1076] = "Fisher";

NORMAL_TRIVIA_QUESTIONS[1077] = "(Sports&Leisure): What amusement park's stock plunged 350 percent between 1992 and the end of 1993?";
NORMAL_TRIVIA_ANSWERS1[1077] = "Euro Disney's";
NORMAL_TRIVIA_ANSWERS2[1077] = "euro disney";
NORMAL_TRIVIA_ANSWERS3[1077] = "eurodisney";

NORMAL_TRIVIA_QUESTIONS[1078] = "(History): What three-word phrase hit \"The Washington Post\" 135 times in President Bush's first two years in office?";
NORMAL_TRIVIA_ANSWERS1[1078] = "Read my lips";

NORMAL_TRIVIA_QUESTIONS[1079] = "(World): What church secretary took it off for \"Playboy\" and hosted the mud-wrestling show \"Thunder & Mud\"?";
NORMAL_TRIVIA_ANSWERS1[1079] = "Jessica Hahn";
NORMAL_TRIVIA_ANSWERS2[1079] = "hahn";
NORMAL_TRIVIA_ANSWERS3[1079] = "hahn ";

NORMAL_TRIVIA_QUESTIONS[1080] = "(Science&Nature): What remote spot did an explorer finally reach on his third attempt, in 1909?";
NORMAL_TRIVIA_ANSWERS1[1080] = "The North Pole";
NORMAL_TRIVIA_ANSWERS2[1080] = "north pole";

NORMAL_TRIVIA_QUESTIONS[1081] = "(Science&Nature): What were a reported 1,519 New York City residents bitten by in 1985?";
NORMAL_TRIVIA_ANSWERS1[1081] = "Other people";
NORMAL_TRIVIA_ANSWERS2[1081] = "people";

NORMAL_TRIVIA_QUESTIONS[1082] = "(Sports&Leisure): What Kansas City Royals rookie stunned teammates by giving them autographed photos when he reported?";
NORMAL_TRIVIA_ANSWERS1[1082] = "Bo Jackson";
NORMAL_TRIVIA_ANSWERS2[1082] = "jackson";

NORMAL_TRIVIA_QUESTIONS[1083] = "(World): What former child star originated the role of Mordred in the Broadway musical \"Camelot\"?";
NORMAL_TRIVIA_ANSWERS1[1083] = "Roddy McDowall";
NORMAL_TRIVIA_ANSWERS2[1083] = "mcdowall";

NORMAL_TRIVIA_QUESTIONS[1084] = "(Science&Nature): What 1962 book by Rachel Carson is credited with increasing public interest in environmental dangers?";
NORMAL_TRIVIA_ANSWERS1[1084] = "Silent Spring";

NORMAL_TRIVIA_QUESTIONS[1085] = "(Sports&Leisure): What decathlon star claimed he kept in shape as a youth by running from police?";
NORMAL_TRIVIA_ANSWERS1[1085] = "Dave Johnson";
NORMAL_TRIVIA_ANSWERS2[1085] = "johnson";

NORMAL_TRIVIA_QUESTIONS[1086] = "(Arts&Entertainment): What did Murphy Brown name her child in 1992, in the most-watched TV birth since 1953's Little Ricky?";
NORMAL_TRIVIA_ANSWERS1[1086] = "Avery";

NORMAL_TRIVIA_QUESTIONS[1087] = "(Sports&Leisure): Which chess term comes from the Arabic phrase meaning \"the Shah is dead\"?";
NORMAL_TRIVIA_ANSWERS1[1087] = "Checkmate";

NORMAL_TRIVIA_QUESTIONS[1088] = "(Sports&Leisure): What golfer did \"Sports Illustrated\" say \"has destroyed more hotel rooms than water seepage\"?";
NORMAL_TRIVIA_ANSWERS1[1088] = "John Daly";
NORMAL_TRIVIA_ANSWERS2[1088] = "daly";
NORMAL_TRIVIA_ANSWERS3[1088] = "daly ";

NORMAL_TRIVIA_QUESTIONS[1089] = "(History): Who earned international headlines for slapping a battle-fatigued soldier in 1943?";
NORMAL_TRIVIA_ANSWERS1[1089] = "George Patton";
NORMAL_TRIVIA_ANSWERS2[1089] = "patton";

NORMAL_TRIVIA_QUESTIONS[1090] = "(Sports&Leisure): In what game does a batsman protect a wicket?";
NORMAL_TRIVIA_ANSWERS1[1090] = "Cricket";

NORMAL_TRIVIA_QUESTIONS[1091] = "(People&Places): Who had his likeness added to a Michelangelo work when he ordered a replica for his Las Vegas bedroom?";
NORMAL_TRIVIA_ANSWERS1[1091] = "Liberace";

NORMAL_TRIVIA_QUESTIONS[1092] = "(Sports&Leisure): Who failed a drug test and lost a 100 meters gold medal at the 1988 Olympics?";
NORMAL_TRIVIA_ANSWERS1[1092] = "Ben Johnson's";
NORMAL_TRIVIA_ANSWERS2[1092] = "johnson";

NORMAL_TRIVIA_QUESTIONS[1093] = "(History): Along with Lady Bird Johnson, who stood beside Lyndon B. Johnson when he was sworn in as president in 1963?";
NORMAL_TRIVIA_ANSWERS1[1093] = "Jacqueline Kennedy";
NORMAL_TRIVIA_ANSWERS2[1093] = "kennedy";

NORMAL_TRIVIA_QUESTIONS[1094] = "(World): What London museum was named for a Swiss miss who sculpted fellow prisoners' severed heads?";
NORMAL_TRIVIA_ANSWERS1[1094] = "Madame Tussaud's Wax Exhibition";
NORMAL_TRIVIA_ANSWERS2[1094] = "Tussaud";

NORMAL_TRIVIA_QUESTIONS[1095] = "(World): What movie monster fought King Kong atop a mountain?";
NORMAL_TRIVIA_ANSWERS1[1095] = "Godzilla";

NORMAL_TRIVIA_QUESTIONS[1096] = "(Arts&Entertainment): What Seattle band saw its second album spawn record first-week U.S. sales of 950,000 copies in 1993?";
NORMAL_TRIVIA_ANSWERS1[1096] = "Pearl Jam";

NORMAL_TRIVIA_QUESTIONS[1097] = "(Arts&Entertainment): Who concentrated on the guitar full-time after an injury shortened his paratrooper career?";
NORMAL_TRIVIA_ANSWERS1[1097] = "Jimi Hendrix";
NORMAL_TRIVIA_ANSWERS2[1097] = "hendrix";

NORMAL_TRIVIA_QUESTIONS[1098] = "(People&Places): What European capital sandbagged air raid shelters in World War II?";
NORMAL_TRIVIA_ANSWERS1[1098] = "London";

NORMAL_TRIVIA_QUESTIONS[1099] = "(Sports&Leisure): Who was standing at home plate when he heard about the birth of his son, Mickey Elvin?";
NORMAL_TRIVIA_ANSWERS1[1099] = "Mickey Mantle";
NORMAL_TRIVIA_ANSWERS2[1099] = "mantle";

NORMAL_TRIVIA_QUESTIONS[1100] = "(Arts&Entertainment): What speed did Marty McFly have to reach to get his souped-up DeLorean car back to the future?";
NORMAL_TRIVIA_ANSWERS1[1100] = "Eighty-eight miles an hour";
NORMAL_TRIVIA_ANSWERS2[1100] = "88";
NORMAL_TRIVIA_ANSWERS3[1100] = "88mph";

NORMAL_TRIVIA_QUESTIONS[1101] = "(World): What alien's voice was produced by electronically mixing an actress' voice with another actor's?";
NORMAL_TRIVIA_ANSWERS1[1101] = "E.T.'s";
NORMAL_TRIVIA_ANSWERS2[1101] = "ET";
NORMAL_TRIVIA_ANSWERS3[1101] = "E.T.";

NORMAL_TRIVIA_QUESTIONS[1102] = "(Sports&Leisure): What Dallas Cowboys star always adds the number \"8\" after his name when signing autographs?";
NORMAL_TRIVIA_ANSWERS1[1102] = "Troy Aikman";
NORMAL_TRIVIA_ANSWERS2[1102] = "aikman";

NORMAL_TRIVIA_QUESTIONS[1103] = "(Arts&Entertainment): What was the question, according to Hamlet?";
NORMAL_TRIVIA_ANSWERS1[1103] = "To be or not to be";

NORMAL_TRIVIA_QUESTIONS[1104] = "(World): What airline tripled its business during the years it used a koala as a pitchman?";
NORMAL_TRIVIA_ANSWERS1[1104] = "Qantas";

NORMAL_TRIVIA_QUESTIONS[1105] = "(People&Places): Name one of the three Southern gentlemen etched in Stone Mountain?";
NORMAL_TRIVIA_ANSWERS1[1105] = "Robert E. Lee, Jefferson Davis, Stonewall Jackson";
NORMAL_TRIVIA_ANSWERS2[1105] = "robert";
NORMAL_TRIVIA_ANSWERS3[1105] = "stonewall";

NORMAL_TRIVIA_QUESTIONS[1106] = "(Arts&Entertainment): Who shaved his head and lost 30 pounds for a role that won him an Oscar in 1994?";
NORMAL_TRIVIA_ANSWERS1[1106] = "Tom Hanks";
NORMAL_TRIVIA_ANSWERS2[1106] = "hanks";

NORMAL_TRIVIA_QUESTIONS[1107] = "(Science&Nature): Where have the ashes of \"Star Trek\" producer Gene Roddenberry gone that few ashes have gone before?";
NORMAL_TRIVIA_ANSWERS1[1107] = "Outer space";
NORMAL_TRIVIA_ANSWERS2[1107] = "space";

NORMAL_TRIVIA_QUESTIONS[1108] = "(Science&Nature): What U.S. president did Albert Einstein write, warning it was possible to build an atomic bomb?";
NORMAL_TRIVIA_ANSWERS1[1108] = "Franklin D. Roosevelt";
NORMAL_TRIVIA_ANSWERS2[1108] = "roosevelt";

NORMAL_TRIVIA_QUESTIONS[1109] = "(Sports&Leisure): What does a red flag with a diagonal white stripe mean, when floating on the water?";
NORMAL_TRIVIA_ANSWERS1[1109] = "Diver down";

NORMAL_TRIVIA_QUESTIONS[1110] = "(History): What did the sign read on the house of ill repute that televangelist Jimmy Swaggart frequented?";
NORMAL_TRIVIA_ANSWERS1[1110] = "No refunds after 15 minutes";

NORMAL_TRIVIA_QUESTIONS[1111] = "(People&Places): How many of General Custer's brothers bit the dust with him at Little Bighorn?";
NORMAL_TRIVIA_ANSWERS1[1111] = "Two";
NORMAL_TRIVIA_ANSWERS2[1111] = "2";

NORMAL_TRIVIA_QUESTIONS[1112] = "(World): What city did Mr. Potato Head and his bride honeymoon in, according to Hasbro?";
NORMAL_TRIVIA_ANSWERS1[1112] = "Boise, Idaho";
NORMAL_TRIVIA_ANSWERS2[1112] = "boise";

NORMAL_TRIVIA_QUESTIONS[1113] = "(History): What method of propulsion was used to ferry \"durham\" boats - wind, oars or poles?";
NORMAL_TRIVIA_ANSWERS1[1113] = "Poles";

NORMAL_TRIVIA_QUESTIONS[1114] = "(World): What did Ms. Gabor instruct reporters to call her, after she married Frederick von Anhalt?";
NORMAL_TRIVIA_ANSWERS1[1114] = "Princess Zsa Zsa";

NORMAL_TRIVIA_QUESTIONS[1115] = "(People&Places): What song did Crosby, Stills, Nash and Young sing to commemorate a bloody 1970 campus scene?";
NORMAL_TRIVIA_ANSWERS1[1115] = "Ohio";
NORMAL_TRIVIA_ANSWERS2[1115] = "ohio ";
NORMAL_TRIVIA_ANSWERS3[1115] = " ohio";

NORMAL_TRIVIA_QUESTIONS[1116] = "(Sports&Leisure): Whose cable to Italy's 1938 World Cup soccer team read: \"Win or die!\"?";
NORMAL_TRIVIA_ANSWERS1[1116] = "Benito Mussolini's";
NORMAL_TRIVIA_ANSWERS2[1116] = "mussolini";

NORMAL_TRIVIA_QUESTIONS[1117] = "(World): What kind of burger went for 5.5 rubles when McDonalds opened up on Red Square?";
NORMAL_TRIVIA_ANSWERS1[1117] = "A Bolshoi Mak (Big Mac)";
NORMAL_TRIVIA_ANSWERS2[1117] = "bolshoi mak";
NORMAL_TRIVIA_ANSWERS3[1117] = "big mac";

NORMAL_TRIVIA_QUESTIONS[1118] = "(Science&Nature): Where do geocarpic fruits ripen?";
NORMAL_TRIVIA_ANSWERS1[1118] = "Underground";

NORMAL_TRIVIA_QUESTIONS[1119] = "(World): What Nobel Peace Prize winner shares his last name with ballet apparel?";
NORMAL_TRIVIA_ANSWERS1[1119] = "Desmond Tutu";
NORMAL_TRIVIA_ANSWERS2[1119] = "Tutu";

NORMAL_TRIVIA_QUESTIONS[1120] = "(World): What show saw Bob Barker give losers a bottle of Jungle Gardenia perfume?";
NORMAL_TRIVIA_ANSWERS1[1120] = "Truth or Consequences";

NORMAL_TRIVIA_QUESTIONS[1121] = "(Arts&Entertainment): What corpulent comedian donated a pair of his pants to complete Charlie Chaplin's Little Tramp outfit?";
NORMAL_TRIVIA_ANSWERS1[1121] = "Fatty Arbuckle";
NORMAL_TRIVIA_ANSWERS2[1121] = "arbuckle";

NORMAL_TRIVIA_QUESTIONS[1122] = "(Sports&Leisure): What town did Babe Ruth begin and end his major league playing career in?";
NORMAL_TRIVIA_ANSWERS1[1122] = "Boston";

NORMAL_TRIVIA_QUESTIONS[1123] = "(History): What button sold 20 million units in 1971?";
NORMAL_TRIVIA_ANSWERS1[1123] = "The happy face button";
NORMAL_TRIVIA_ANSWERS2[1123] = "happy face";

NORMAL_TRIVIA_QUESTIONS[1124] = "(People&Places): What U.S. state contains almost all of Yellowstone National Park?";
NORMAL_TRIVIA_ANSWERS1[1124] = "Wyoming";

NORMAL_TRIVIA_QUESTIONS[1125] = "(People&Places): What assassin had a sliver of his thorax end up at Philadelphia's Mutter Museum?";
NORMAL_TRIVIA_ANSWERS1[1125] = "John Wilkes Booth";
NORMAL_TRIVIA_ANSWERS2[1125] = "booth";

NORMAL_TRIVIA_QUESTIONS[1126] = "(History): Who predicted in March, 1930, that Wall Street's crash \"will have passed during the next 60 days\"?";
NORMAL_TRIVIA_ANSWERS1[1126] = "Herbert Hoover";
NORMAL_TRIVIA_ANSWERS2[1126] = "hoover";

NORMAL_TRIVIA_QUESTIONS[1127] = "(Sports&Leisure): Who inspired Phillies catcher Darren Daulton to quip: \"It ain't over till the fat guy swings\"?";
NORMAL_TRIVIA_ANSWERS1[1127] = "John Kruk";
NORMAL_TRIVIA_ANSWERS2[1127] = "kruk";
NORMAL_TRIVIA_ANSWERS3[1127] = "kruk ";

NORMAL_TRIVIA_QUESTIONS[1128] = "(Science&Nature): What method of suicide is second most popular in the U.S.?";
NORMAL_TRIVIA_ANSWERS1[1128] = "Poison";

NORMAL_TRIVIA_QUESTIONS[1129] = "(People&Places): What U.S. city saw only 15 of its 33 daily newspapers published in English by 1990?";
NORMAL_TRIVIA_ANSWERS1[1129] = "New York";

NORMAL_TRIVIA_QUESTIONS[1130] = "(Sports&Leisure): What banished ballplayer couldn't honestly comply with the request, \"Say it ain't so, Joe\"?";
NORMAL_TRIVIA_ANSWERS1[1130] = "Shoeless Joe Jackson";
NORMAL_TRIVIA_ANSWERS2[1130] = "joe jackson";
NORMAL_TRIVIA_ANSWERS3[1130] = "shoeless";

NORMAL_TRIVIA_QUESTIONS[1131] = "(History): What were early 20th-century American feminists best known as?";
NORMAL_TRIVIA_ANSWERS1[1131] = "Suffragettes";

NORMAL_TRIVIA_QUESTIONS[1132] = "(Arts&Entertainment): Name one of the three rock 'n' rollers who bit the dust when their plane plunged into a farm field in 1959?";
NORMAL_TRIVIA_ANSWERS1[1132] = "The Big Bopper, Buddy Holly, Ritchie Valens \"";
NORMAL_TRIVIA_ANSWERS2[1132] = "Big bopper";
NORMAL_TRIVIA_ANSWERS3[1132] = "holly";

NORMAL_TRIVIA_QUESTIONS[1133] = "(Sports&Leisure): Who has scored against more than 140 goaltenders in his NHL career?";
NORMAL_TRIVIA_ANSWERS1[1133] = "Wayne Gretzky";
NORMAL_TRIVIA_ANSWERS2[1133] = "gretzky";
NORMAL_TRIVIA_ANSWERS3[1133] = "gretsky";

NORMAL_TRIVIA_QUESTIONS[1134] = "(Sports&Leisure): What golfer turned around and aimed a screamer just over the heads of the gallery in August, 1993?";
NORMAL_TRIVIA_ANSWERS1[1134] = "John Daly";
NORMAL_TRIVIA_ANSWERS2[1134] = "daly";
NORMAL_TRIVIA_ANSWERS3[1134] = "daly ";

NORMAL_TRIVIA_QUESTIONS[1135] = "(Science&Nature): What's the most common affliction causing wrist pain in keyboard users?";
NORMAL_TRIVIA_ANSWERS1[1135] = "Carpal tunnel syndrome";
NORMAL_TRIVIA_ANSWERS2[1135] = "carpal tunnel";

NORMAL_TRIVIA_QUESTIONS[1136] = "(People&Places): What ocean was Amelia Earhart crossing when she vanished in 1937?";
NORMAL_TRIVIA_ANSWERS1[1136] = "Pacific";

NORMAL_TRIVIA_QUESTIONS[1137] = "(Science&Nature): Which dinosaur reasoned with the smallest brain relative to its size?";
NORMAL_TRIVIA_ANSWERS1[1137] = "Stegosaurus";

NORMAL_TRIVIA_QUESTIONS[1138] = "(Arts&Entertainment): What animated TV character admonished: \"Don't have a cow, man\"?";
NORMAL_TRIVIA_ANSWERS1[1138] = "Bart Simpson";

NORMAL_TRIVIA_QUESTIONS[1139] = "(Science&Nature): Who is five times more likely to die in an accident - a right-handed or a left-handed person?";
NORMAL_TRIVIA_ANSWERS1[1139] = "A left-handed person";
NORMAL_TRIVIA_ANSWERS2[1139] = "left hand";
NORMAL_TRIVIA_ANSWERS3[1139] = "left-hand";

NORMAL_TRIVIA_QUESTIONS[1140] = "(People&Places): What river is responsible for the Grand Canyon?";
NORMAL_TRIVIA_ANSWERS1[1140] = "Colorado";

NORMAL_TRIVIA_QUESTIONS[1141] = "(World): What actress' bouts of flatulence inspired friends to nickname her for a novelty store item?";
NORMAL_TRIVIA_ANSWERS1[1141] = "Whoopi Goldberg's";
NORMAL_TRIVIA_ANSWERS2[1141] = "whoopi";
NORMAL_TRIVIA_ANSWERS3[1141] = "goldberg";

NORMAL_TRIVIA_QUESTIONS[1142] = "(Arts&Entertainment): What Tony Orlando and Dawn ditty asked to rap on the ceiling?";
NORMAL_TRIVIA_ANSWERS1[1142] = "Knock Three Times";

NORMAL_TRIVIA_QUESTIONS[1143] = "(Sports&Leisure): What figure skater was offered 35 movie deals during a single week in January, 1994?";
NORMAL_TRIVIA_ANSWERS1[1143] = "Nancy Kerrigan";
NORMAL_TRIVIA_ANSWERS2[1143] = "Kerrigan";

NORMAL_TRIVIA_QUESTIONS[1144] = "(History): What substance do the Bill Of Rights 18th and 21st amendments reflect different views of?";
NORMAL_TRIVIA_ANSWERS1[1144] = "Alcohol";

NORMAL_TRIVIA_QUESTIONS[1145] = "(History): Who shook hands with Yitzhak Rabin in 1993 for \"the handshake that shook the world\"?";
NORMAL_TRIVIA_ANSWERS1[1145] = "Yasser Arafat";
NORMAL_TRIVIA_ANSWERS2[1145] = "Arafat";

NORMAL_TRIVIA_QUESTIONS[1146] = "(People&Places): What three-word phrase did James Brown exclaim when released from a Georgia work center in 1991?";
NORMAL_TRIVIA_ANSWERS1[1146] = "I feel good";

NORMAL_TRIVIA_QUESTIONS[1147] = "(Sports&Leisure): What name did basketballer Kareem Abdul-Jabbar answer to when he played for UCLA?";
NORMAL_TRIVIA_ANSWERS1[1147] = "Lew Alcindor";
NORMAL_TRIVIA_ANSWERS2[1147] = "alcindor";

NORMAL_TRIVIA_QUESTIONS[1148] = "(Sports&Leisure): Which clothing outfits joined Levi Strauss as ranking Nos. 1 and 2 in U.S. sales in 1993?";
NORMAL_TRIVIA_ANSWERS1[1148] = "The Gap";
NORMAL_TRIVIA_ANSWERS2[1148] = "gap ";
NORMAL_TRIVIA_ANSWERS3[1148] = " gap";

NORMAL_TRIVIA_QUESTIONS[1149] = "(Science&Nature): What 1992 event created 214,000 new jobs in Florida?";
NORMAL_TRIVIA_ANSWERS1[1149] = "Hurricane Andrew";
NORMAL_TRIVIA_ANSWERS2[1149] = "Andrew";

NORMAL_TRIVIA_QUESTIONS[1150] = "(World): Who was born Belle Silverman before becoming America's most popular coloratura soprano?";
NORMAL_TRIVIA_ANSWERS1[1150] = "Beverly Sills";
NORMAL_TRIVIA_ANSWERS2[1150] = "sills";

NORMAL_TRIVIA_QUESTIONS[1151] = "(History): Which presidential debater in 1960 had a right leg three-quarters of an inch longer than the left?";
NORMAL_TRIVIA_ANSWERS1[1151] = "John F. Kennedy";
NORMAL_TRIVIA_ANSWERS2[1151] = "Kennedy";

NORMAL_TRIVIA_QUESTIONS[1152] = "(Sports&Leisure): Who copped the NBA's Most Valuable Player and Rookie of the Year awards in 1960?";
NORMAL_TRIVIA_ANSWERS1[1152] = "Wilt Chamberlain";
NORMAL_TRIVIA_ANSWERS2[1152] = "Chamberlain";

NORMAL_TRIVIA_QUESTIONS[1153] = "(People&Places): What Southern state saw Bonnie and Clyde have a final date with dozens of bullets?";
NORMAL_TRIVIA_ANSWERS1[1153] = "Louisiana";

NORMAL_TRIVIA_QUESTIONS[1154] = "(World): What brand of cat food was hawked by Morris in TV spots? ";
NORMAL_TRIVIA_ANSWERS1[1154] = "9-Lives";
NORMAL_TRIVIA_ANSWERS2[1154] = "9 lives";
NORMAL_TRIVIA_ANSWERS3[1154] = "nine lives";

NORMAL_TRIVIA_QUESTIONS[1155] = "(Science&Nature): What surgical procedure temporarily relieved Kenny Rogers of his love handles?";
NORMAL_TRIVIA_ANSWERS1[1155] = "Liposuction";

NORMAL_TRIVIA_QUESTIONS[1156] = "(Science&Nature): What sentence was given to the traders caught in China selling illegal animal hides for $24,000?";
NORMAL_TRIVIA_ANSWERS1[1156] = "Death";

NORMAL_TRIVIA_QUESTIONS[1157] = "(People&Places): What kind of music is most closely associated with the country of Jamaica?";
NORMAL_TRIVIA_ANSWERS1[1157] = "Reggae";

NORMAL_TRIVIA_QUESTIONS[1158] = "(Science&Nature): What covered one-fourth of the earth's land surface in 1950 but will cover only one-sixth by 2000?";
NORMAL_TRIVIA_ANSWERS1[1158] = "Forest";

NORMAL_TRIVIA_QUESTIONS[1159] = "(Sports&Leisure): Who began life as an arch-villain in a computer software game and went on to her own TV series?";
NORMAL_TRIVIA_ANSWERS1[1159] = "Carmen Sandiego";
NORMAL_TRIVIA_ANSWERS2[1159] = "Carmen";
NORMAL_TRIVIA_ANSWERS3[1159] = "Sandiego";

NORMAL_TRIVIA_QUESTIONS[1160] = "(Arts&Entertainment): Who wielded the knife during the filming of the shower scene in \"Psycho\"?";
NORMAL_TRIVIA_ANSWERS1[1160] = "Alfred Hitchcock";
NORMAL_TRIVIA_ANSWERS2[1160] = "hitchcock";

NORMAL_TRIVIA_QUESTIONS[1161] = "(History): What Brit was less than thrilled to learn he'd won \"Mad\" magazine's Alfred E. Neuman Look-Alike Contest?";
NORMAL_TRIVIA_ANSWERS1[1161] = "Prince Charles";

NORMAL_TRIVIA_QUESTIONS[1162] = "(History): What federal office did Janet Reno become the first female to occupy?";
NORMAL_TRIVIA_ANSWERS1[1162] = "U.S. Attorney General";
NORMAL_TRIVIA_ANSWERS2[1162] = "attorney general";

NORMAL_TRIVIA_QUESTIONS[1163] = "(World): What black screen star toiled as a mortuary cosmetologist before Hollywood beckoned?";
NORMAL_TRIVIA_ANSWERS1[1163] = "Whoopi Goldberg";
NORMAL_TRIVIA_ANSWERS2[1163] = "goldberg";

NORMAL_TRIVIA_QUESTIONS[1164] = "(World): What 1969 event saw stoned music buffs wallow in the mud and rain for three days?";
NORMAL_TRIVIA_ANSWERS1[1164] = "Woodstock";

NORMAL_TRIVIA_QUESTIONS[1165] = "(World): What \"Cheers\" character did a general say \"we've had a lot of people like\" in the military?";
NORMAL_TRIVIA_ANSWERS1[1165] = "Cliff Clavin";
NORMAL_TRIVIA_ANSWERS2[1165] = "clavin";
NORMAL_TRIVIA_ANSWERS3[1165] = "cliff";

NORMAL_TRIVIA_QUESTIONS[1166] = "(Arts&Entertainment): What was the only part of the costume that Charlie Chaplin owned the day he created The Tramp?";
NORMAL_TRIVIA_ANSWERS1[1166] = "cane";
NORMAL_TRIVIA_ANSWERS2[1166] = "cane ";
NORMAL_TRIVIA_ANSWERS3[1166] = " cane";

NORMAL_TRIVIA_QUESTIONS[1167] = "(Sports&Leisure): What association saw admissions soar due to a 1979 Village People hit?";
NORMAL_TRIVIA_ANSWERS1[1167] = "YMCA";
NORMAL_TRIVIA_ANSWERS2[1167] = "ymca";
NORMAL_TRIVIA_ANSWERS3[1167] = "ymca ";

NORMAL_TRIVIA_QUESTIONS[1168] = "(People&Places): What's the only country to fly a square flag?";
NORMAL_TRIVIA_ANSWERS1[1168] = "Switzerland";

NORMAL_TRIVIA_QUESTIONS[1169] = "(Arts&Entertainment): Which songstress prompted David Letterman to quip: \"I think she's trying to shock us\"?";
NORMAL_TRIVIA_ANSWERS1[1169] = "Madonna";

NORMAL_TRIVIA_QUESTIONS[1170] = "(World): What Homeric warrior was still trying to get home 10 years after the Trojan Horse did the trick?";
NORMAL_TRIVIA_ANSWERS1[1170] = "Odysseus";

NORMAL_TRIVIA_QUESTIONS[1171] = "(Arts&Entertainment): Other than Dick Sargent, what other Dick played the hubby of Elizabeth Montgomery's sitcom witch?";
NORMAL_TRIVIA_ANSWERS1[1171] = "Dick York";
NORMAL_TRIVIA_ANSWERS2[1171] = "york";
NORMAL_TRIVIA_ANSWERS3[1171] = " york";

NORMAL_TRIVIA_QUESTIONS[1172] = "(Arts&Entertainment): Who sang the No. 1 \"Grease\" tune, \"You're the One That I Want,\" in a duet with John Travolta?";
NORMAL_TRIVIA_ANSWERS1[1172] = "Olivia Newton-John";
NORMAL_TRIVIA_ANSWERS2[1172] = "newton";
NORMAL_TRIVIA_ANSWERS3[1172] = "olivia";

NORMAL_TRIVIA_QUESTIONS[1173] = "(World): What did publicist Chuck Jones admit to being sexually fascinated by, at a 1994 trial?";
NORMAL_TRIVIA_ANSWERS1[1173] = "Marla Trump's shoes";
NORMAL_TRIVIA_ANSWERS2[1173] = "marla trump";

NORMAL_TRIVIA_QUESTIONS[1174] = "(History): Which president died after a poultice of dried cantharide beetles was applied to his raw throat?";
NORMAL_TRIVIA_ANSWERS1[1174] = "George Washington";
NORMAL_TRIVIA_ANSWERS2[1174] = "washington";

NORMAL_TRIVIA_QUESTIONS[1175] = "(History): Whose death on April 22, 1994, caused the American flag to be flown at half-staff for a month?";
NORMAL_TRIVIA_ANSWERS1[1175] = "Richard Nixon's";
NORMAL_TRIVIA_ANSWERS2[1175] = "nixon";

NORMAL_TRIVIA_QUESTIONS[1176] = "(People&Places): What feat was Amelia Earhart attempting when she disappeared in 1937?";
NORMAL_TRIVIA_ANSWERS1[1176] = "Flying around the world";
NORMAL_TRIVIA_ANSWERS2[1176] = "around the world";

NORMAL_TRIVIA_QUESTIONS[1177] = "(World): What's the most popular day of the week for companies to announce layoffs?";
NORMAL_TRIVIA_ANSWERS1[1177] = "Monday";

NORMAL_TRIVIA_QUESTIONS[1178] = "(History): What U.S. president survived two assassination attempts 17 days apart?";
NORMAL_TRIVIA_ANSWERS1[1178] = "Gerald Ford";
NORMAL_TRIVIA_ANSWERS2[1178] = "Ford";
NORMAL_TRIVIA_ANSWERS3[1178] = "ford ";

NORMAL_TRIVIA_QUESTIONS[1179] = "(Science&Nature): What was Dr. Glenn Warden accused of drawing on the genitals of two patients during surgery in 1992?";
NORMAL_TRIVIA_ANSWERS1[1179] = "Happy faces";
NORMAL_TRIVIA_ANSWERS2[1179] = "happy face";

NORMAL_TRIVIA_QUESTIONS[1180] = "(History): Who commanded the U.S.  forces that halted Erwin Rommel's Afrika Korps in Tunisia?";
NORMAL_TRIVIA_ANSWERS1[1180] = "George Patton";
NORMAL_TRIVIA_ANSWERS2[1180] = "patton";

NORMAL_TRIVIA_QUESTIONS[1181] = "(Arts&Entertainment): What Hollywood legend was a strapping 13 pounds when he came out of the womb on May 26, 1907? ";
NORMAL_TRIVIA_ANSWERS1[1181] = "John Wayne";
NORMAL_TRIVIA_ANSWERS2[1181] = "wayne";

NORMAL_TRIVIA_QUESTIONS[1182] = "(Arts&Entertainment): What book was Randy Shilts typing the last page of when he found out he was HIV-positive?";
NORMAL_TRIVIA_ANSWERS1[1182] = "And the Band Played On";

NORMAL_TRIVIA_QUESTIONS[1183] = "(Sports&Leisure): What basketball player claimed in his autobiography that he bedded some 20,000 women?";
NORMAL_TRIVIA_ANSWERS1[1183] = "Wilt Chamberlain";
NORMAL_TRIVIA_ANSWERS2[1183] = "chamberlain";

NORMAL_TRIVIA_QUESTIONS[1184] = "(World): What pop star had almost decided to quit touring when a pal suggested he don a \"punk Amadeus\" look?";
NORMAL_TRIVIA_ANSWERS1[1184] = "Elton John";
NORMAL_TRIVIA_ANSWERS2[1184] = "elton";

NORMAL_TRIVIA_QUESTIONS[1185] = "(World): Who once sighed: \"Playing with yarn is stupid, but cat owners expect it\"?";
NORMAL_TRIVIA_ANSWERS1[1185] = "Morris the Cat";
NORMAL_TRIVIA_ANSWERS2[1185] = "morris";

NORMAL_TRIVIA_QUESTIONS[1186] = "(Arts&Entertainment): What original Not Ready for Prime Time Player was born with the first name Cornelius?";
NORMAL_TRIVIA_ANSWERS1[1186] = "Chevy Chase";
NORMAL_TRIVIA_ANSWERS2[1186] = "chase";

NORMAL_TRIVIA_QUESTIONS[1187] = "(Arts&Entertainment): What TV hero opened every episode galloping to the strains of the William Tell Overture?";
NORMAL_TRIVIA_ANSWERS1[1187] = "The Lone Ranger";
NORMAL_TRIVIA_ANSWERS2[1187] = "lone ranger";

NORMAL_TRIVIA_QUESTIONS[1188] = "(Science&Nature): What does the koala eat exclusively?";
NORMAL_TRIVIA_ANSWERS1[1188] = "Eucalyptus";

NORMAL_TRIVIA_QUESTIONS[1189] = "(Arts&Entertainment): What Orkan phrase did Mork utter to say goodbye?";
NORMAL_TRIVIA_ANSWERS1[1189] = "Nanoo nanoo";

NORMAL_TRIVIA_QUESTIONS[1190] = "(People&Places): What's the Russian word for a walled citadel in the middle of a city?";
NORMAL_TRIVIA_ANSWERS1[1190] = "Kremlin";

NORMAL_TRIVIA_QUESTIONS[1191] = "(World): What antacid mascot disappeared en route to the Philippines in 1971?";
NORMAL_TRIVIA_ANSWERS1[1191] = "Speedy Alka-Seltzer";
NORMAL_TRIVIA_ANSWERS2[1191] = "speedy";

NORMAL_TRIVIA_QUESTIONS[1192] = "(History): What revolutionary proclaimed: \"Political power grows out of the barrel of a gun\"?";
NORMAL_TRIVIA_ANSWERS1[1192] = "Mao Zedong";
NORMAL_TRIVIA_ANSWERS2[1192] = "zedong";

NORMAL_TRIVIA_QUESTIONS[1193] = "(World): What famous national news anchor was a high school dropout?";
NORMAL_TRIVIA_ANSWERS1[1193] = "Peter Jennings";
NORMAL_TRIVIA_ANSWERS2[1193] = "jennings";

NORMAL_TRIVIA_QUESTIONS[1194] = "(Science&Nature): Who said Thomas Edison's invention of the phonograph was \"not of any commercial value\"?";
NORMAL_TRIVIA_ANSWERS1[1194] = "Thomas Edison";
NORMAL_TRIVIA_ANSWERS2[1194] = "edison";

NORMAL_TRIVIA_QUESTIONS[1195] = "(Sports&Leisure): What's the point total of a baccarat hand of five and five?";
NORMAL_TRIVIA_ANSWERS1[1195] = "Zero";
NORMAL_TRIVIA_ANSWERS2[1195] = "0";

NORMAL_TRIVIA_QUESTIONS[1196] = "(People&Places): What did Ben Franklin prefer to the eagle as the U.S. national emblem?";
NORMAL_TRIVIA_ANSWERS1[1196] = "The turkey";
NORMAL_TRIVIA_ANSWERS2[1196] = "turkey";

NORMAL_TRIVIA_QUESTIONS[1197] = "(Sports&Leisure): What quarterback vomited on tight end Bob Adams in his first huddle with the Pittsburgh Steelers?";
NORMAL_TRIVIA_ANSWERS1[1197] = "Terry Bradshaw";
NORMAL_TRIVIA_ANSWERS2[1197] = "bradshaw";

NORMAL_TRIVIA_QUESTIONS[1198] = "(Sports&Leisure): What NBA team leased a custom-made jet in 1991 so their superstar could lie flat to soothe his back?";
NORMAL_TRIVIA_ANSWERS1[1198] = "The Boston Celtics";
NORMAL_TRIVIA_ANSWERS2[1198] = "celtics";

NORMAL_TRIVIA_QUESTIONS[1199] = "(World): What deficiency kept Elvis Presley out of his high school glee club?";
NORMAL_TRIVIA_ANSWERS1[1199] = "His singing";
NORMAL_TRIVIA_ANSWERS2[1199] = "singing";

NORMAL_TRIVIA_QUESTIONS[1200] = "(Sports&Leisure): What was the first soft drink to be slurped from a 12-ounce bottle, in 1934?";
NORMAL_TRIVIA_ANSWERS1[1200] = "Pepsi-Cola";
NORMAL_TRIVIA_ANSWERS2[1200] = "pepsi";

NORMAL_TRIVIA_QUESTIONS[1201] = "(People&Places): What holiday did Berkeley, California, propose changing to Indigenous Peoples Day in 1992?";
NORMAL_TRIVIA_ANSWERS1[1201] = "Columbus Day";
NORMAL_TRIVIA_ANSWERS2[1201] = "columbus";

NORMAL_TRIVIA_QUESTIONS[1202] = "(World): Whose brief stint as a talk show host earned him an \"Esquire\" \"Corpse of the Year\" award?";
NORMAL_TRIVIA_ANSWERS1[1202] = "Chevy Chase's";
NORMAL_TRIVIA_ANSWERS2[1202] = "chevy";
NORMAL_TRIVIA_ANSWERS3[1202] = "chase";

NORMAL_TRIVIA_QUESTIONS[1203] = "(History): Where was Howard Hunt's office, for which two Watergate burglars had the phone number?";
NORMAL_TRIVIA_ANSWERS1[1203] = "The White House";
NORMAL_TRIVIA_ANSWERS2[1203] = "white house";

NORMAL_TRIVIA_QUESTIONS[1204] = "(Science&Nature): Who beat John Glenn by a year as the first to orbit Earth, in 1961?";
NORMAL_TRIVIA_ANSWERS1[1204] = "Yuri Gagarin";
NORMAL_TRIVIA_ANSWERS2[1204] = "gagarin";

NORMAL_TRIVIA_QUESTIONS[1205] = "(World): What Egyptian's treasure trove shared headlines with Billy Beer and \"Star Wars\" in 1977?";
NORMAL_TRIVIA_ANSWERS1[1205] = "King Tutankhamen's";
NORMAL_TRIVIA_ANSWERS2[1205] = "king tut";

NORMAL_TRIVIA_QUESTIONS[1206] = "(History): What U.S. president was once chased out of his house while his wife threw potatoes at him?";
NORMAL_TRIVIA_ANSWERS1[1206] = "Abraham Lincoln";
NORMAL_TRIVIA_ANSWERS2[1206] = "lincoln";

NORMAL_TRIVIA_QUESTIONS[1207] = "(Sports&Leisure): Who's the only NBA player to have scored 4,000 points in a season?";
NORMAL_TRIVIA_ANSWERS1[1207] = "Wilt Chamberlain";
NORMAL_TRIVIA_ANSWERS2[1207] = "chamberlain";

NORMAL_TRIVIA_QUESTIONS[1208] = "(Arts&Entertainment): What song brought Little Richard out of a bus station kitchen and into the limelight?";
NORMAL_TRIVIA_ANSWERS1[1208] = "Tutti Frutti";

NORMAL_TRIVIA_QUESTIONS[1209] = "(People&Places): What North African capital was built atop the ancient city of Memphis?";
NORMAL_TRIVIA_ANSWERS1[1209] = "Cairo";

NORMAL_TRIVIA_QUESTIONS[1210] = "(Science&Nature): How many miles away did lightning strike, if you heard thunder five seconds after you saw it?";
NORMAL_TRIVIA_ANSWERS1[1210] = "One";
NORMAL_TRIVIA_ANSWERS2[1210] = "1";

NORMAL_TRIVIA_QUESTIONS[1211] = "(Arts&Entertainment): What does the winner get when cars are \"racing for pinks\"?";
NORMAL_TRIVIA_ANSWERS1[1211] = "The loser's registration card";
NORMAL_TRIVIA_ANSWERS2[1211] = "registration";
NORMAL_TRIVIA_ANSWERS3[1211] = "ownership";

NORMAL_TRIVIA_QUESTIONS[1212] = "(World): Who has hosted the most hours of TV network programming?";
NORMAL_TRIVIA_ANSWERS1[1212] = "Johnny Carson";
NORMAL_TRIVIA_ANSWERS2[1212] = "carson";

NORMAL_TRIVIA_QUESTIONS[1213] = "(Science&Nature): Who noted: \"It will make a big bang - a very big bang - but it is not a weapon which is useful in war\"?";
NORMAL_TRIVIA_ANSWERS1[1213] = "J. Robert Oppenheimer";
NORMAL_TRIVIA_ANSWERS2[1213] = "oppenheimer";

NORMAL_TRIVIA_QUESTIONS[1214] = "(Sports&Leisure): What inning is \"Take me out to the ballgame\" usually reserved for?";
NORMAL_TRIVIA_ANSWERS1[1214] = "Seventh";
NORMAL_TRIVIA_ANSWERS2[1214] = "7th";
NORMAL_TRIVIA_ANSWERS3[1214] = "7th ";

NORMAL_TRIVIA_QUESTIONS[1215] = "(History): What future South Dakota senator piloted a B-24 in 355 combat missions during World War II?";
NORMAL_TRIVIA_ANSWERS1[1215] = "George McGovern";
NORMAL_TRIVIA_ANSWERS2[1215] = "mcgovern";

NORMAL_TRIVIA_QUESTIONS[1216] = "(History): What stoic British statesman smoked an  estimated 300,000 stogies?";
NORMAL_TRIVIA_ANSWERS1[1216] = "Winston Churchill";
NORMAL_TRIVIA_ANSWERS2[1216] = "churchill";

NORMAL_TRIVIA_QUESTIONS[1217] = "(Arts&Entertainment): What movie had Chevy Chase dreaming he was a member of the Los Angeles Lakers?";
NORMAL_TRIVIA_ANSWERS1[1217] = "Fletch";

NORMAL_TRIVIA_QUESTIONS[1218] = "(History): Which presidential candidate promised in TV spots: \"I would not tell a lie\"?";
NORMAL_TRIVIA_ANSWERS1[1218] = "Jimmy Carter";
NORMAL_TRIVIA_ANSWERS2[1218] = "carter";

NORMAL_TRIVIA_QUESTIONS[1219] = "(Arts&Entertainment): Which hand does Rodin's \"Thinker\" rest his chin on?";
NORMAL_TRIVIA_ANSWERS1[1219] = "Right";

NORMAL_TRIVIA_QUESTIONS[1220] = "(Arts&Entertainment): What actor got to play a game of \"strip croquet\"  with Winona Ryder in a 1989 movie? ";
NORMAL_TRIVIA_ANSWERS1[1220] = "Christian Slater";
NORMAL_TRIVIA_ANSWERS2[1220] = "slater";

NORMAL_TRIVIA_QUESTIONS[1221] = "(Sports&Leisure): Who did Babe Ruth call \"the greatest first baseman of all time\"?";
NORMAL_TRIVIA_ANSWERS1[1221] = "Lou Gehrig";
NORMAL_TRIVIA_ANSWERS2[1221] = "gehrig";

NORMAL_TRIVIA_QUESTIONS[1222] = "(World): What TV title role required Sally Field to appear to be 90 pounds?";
NORMAL_TRIVIA_ANSWERS1[1222] = "The Flying Nun";
NORMAL_TRIVIA_ANSWERS2[1222] = "flying nun";

NORMAL_TRIVIA_QUESTIONS[1223] = "(Sports&Leisure): Who is baseball's all-time RBI leader, with 2,297?";
NORMAL_TRIVIA_ANSWERS1[1223] = "Hank Aaron";
NORMAL_TRIVIA_ANSWERS2[1223] = "aaron";
NORMAL_TRIVIA_ANSWERS3[1223] = "arron";

NORMAL_TRIVIA_QUESTIONS[1224] = "(Arts&Entertainment): Which of Bruce Lee's movies was the first film co-produced by the U.S. and Hong Kong?";
NORMAL_TRIVIA_ANSWERS1[1224] = "Enter the Dragon";

NORMAL_TRIVIA_QUESTIONS[1225] = "(World): What did the Susan B. Anthony dollar coin feel too much like, according to most Americans?";
NORMAL_TRIVIA_ANSWERS1[1225] = "A quarter";
NORMAL_TRIVIA_ANSWERS2[1225] = "quarter";

NORMAL_TRIVIA_QUESTIONS[1226] = "(Science&Nature): What 10-foot-long lizard can detect the smell of carrion from a distance of seven kilometers?";
NORMAL_TRIVIA_ANSWERS1[1226] = "The komodo dragon";
NORMAL_TRIVIA_ANSWERS2[1226] = "komodo";
NORMAL_TRIVIA_ANSWERS3[1226] = "dragon";

NORMAL_TRIVIA_QUESTIONS[1227] = "(World): What orange-haired persona did David Bowie adopt in the early 1970s?";
NORMAL_TRIVIA_ANSWERS1[1227] = "Ziggy Stardust";
NORMAL_TRIVIA_ANSWERS2[1227] = "ziggy";
NORMAL_TRIVIA_ANSWERS3[1227] = "stardust";

NORMAL_TRIVIA_QUESTIONS[1228] = "(People&Places): What country formally asked the U.S. to defend it in August, 1990?";
NORMAL_TRIVIA_ANSWERS1[1228] = "Saudi Arabia";
NORMAL_TRIVIA_ANSWERS2[1228] = "saudi";
NORMAL_TRIVIA_ANSWERS3[1228] = "arabia";

NORMAL_TRIVIA_QUESTIONS[1229] = "(People&Places): Where can you make it, if you can make it here, according to a Frank Sinatra hit?";
NORMAL_TRIVIA_ANSWERS1[1229] = "Anywhere";

NORMAL_TRIVIA_QUESTIONS[1230] = "(World): What legendary recording artist was coined \"The King of Pop\" by actress Elizabeth Taylor?";
NORMAL_TRIVIA_ANSWERS1[1230] = "Michael Jackson";
NORMAL_TRIVIA_ANSWERS2[1230] = "jackson";

NORMAL_TRIVIA_QUESTIONS[1231] = "(Sports&Leisure): What country did Switzerland tie in the first World Cup soccer game held indoors?";
NORMAL_TRIVIA_ANSWERS1[1231] = "The U.S.";
NORMAL_TRIVIA_ANSWERS2[1231] = "USA";
NORMAL_TRIVIA_ANSWERS3[1231] = " USA";

NORMAL_TRIVIA_QUESTIONS[1232] = "(History): What Texas governor was wounded by a shot from the gun that killed John F. Kennedy?";
NORMAL_TRIVIA_ANSWERS1[1232] = "John Connally";
NORMAL_TRIVIA_ANSWERS2[1232] = "connally";

NORMAL_TRIVIA_QUESTIONS[1233] = "(Arts&Entertainment): What 1986 blockbuster was the first home video to be preceded by a product ad?";
NORMAL_TRIVIA_ANSWERS1[1233] = "Top Gun";

NORMAL_TRIVIA_QUESTIONS[1234] = "(Science&Nature): What term, denoting the limiting of reproduction, was originally coined by Margaret Sanger in 1924?";
NORMAL_TRIVIA_ANSWERS1[1234] = "Birth control";

NORMAL_TRIVIA_QUESTIONS[1235] = "(History): What U.S. war cost $33 million per day to fight, in 1990 dollars?";
NORMAL_TRIVIA_ANSWERS1[1235] = "The Civil War";
NORMAL_TRIVIA_ANSWERS2[1235] = "civil war";

NORMAL_TRIVIA_QUESTIONS[1236] = "(Arts&Entertainment): What TV show did Joan Rivers, David Letterman, Jay Leno and Garry Shandling all guest-host?";
NORMAL_TRIVIA_ANSWERS1[1236] = "The Tonight Show Starring Johnny Carson";
NORMAL_TRIVIA_ANSWERS2[1236] = "tonight show";

NORMAL_TRIVIA_QUESTIONS[1237] = "(People&Places): Which country's consumer tastes led to the creation of \"Oreo\" cookies without the cream in 1991?";
NORMAL_TRIVIA_ANSWERS1[1237] = "Japan";

NORMAL_TRIVIA_QUESTIONS[1238] = "(Sports&Leisure): What country hosted the most-watched Winter Olympics of all time?";
NORMAL_TRIVIA_ANSWERS1[1238] = "Norway";

NORMAL_TRIVIA_QUESTIONS[1239] = "(World): What famed canine declined to share the cover of \"TV Guide\" with other Hollywood dogs?";
NORMAL_TRIVIA_ANSWERS1[1239] = "Lassie";

NORMAL_TRIVIA_QUESTIONS[1240] = "(Arts&Entertainment): What song by Eric Clapton was inspired by the death of his son?";
NORMAL_TRIVIA_ANSWERS1[1240] = "Tears in Heaven";

NORMAL_TRIVIA_QUESTIONS[1241] = "(Arts&Entertainment): What TV character made life perilous for racoons in 1955?";
NORMAL_TRIVIA_ANSWERS1[1241] = "Davy Crockett";
NORMAL_TRIVIA_ANSWERS2[1241] = "crockett";

NORMAL_TRIVIA_QUESTIONS[1242] = "(People&Places): What's the most popular Humphrey Bogart movie, set on the edge of an African desert?";
NORMAL_TRIVIA_ANSWERS1[1242] = "Casablanca";

NORMAL_TRIVIA_QUESTIONS[1243] = "(Science&Nature): What explosive element made the zeppelin a perilous way to get around?";
NORMAL_TRIVIA_ANSWERS1[1243] = "Hydrogen";

NORMAL_TRIVIA_QUESTIONS[1244] = "(History): What future president saw 22 of his slaves join British forces in the American Revolution?";
NORMAL_TRIVIA_ANSWERS1[1244] = "Thomas Jefferson";
NORMAL_TRIVIA_ANSWERS2[1244] = "jefferson";

NORMAL_TRIVIA_QUESTIONS[1245] = "(Science&Nature): What volcanic peak lost 3,773 feet in height in 1980?";
NORMAL_TRIVIA_ANSWERS1[1245] = "Mount St. Helens";
NORMAL_TRIVIA_ANSWERS2[1245] = "helens";

NORMAL_TRIVIA_QUESTIONS[1246] = "(World): What cult leader earns a dime every time Zooport Riot Gear sells a T-shirt featuring his likeness?";
NORMAL_TRIVIA_ANSWERS1[1246] = "Charles Manson";
NORMAL_TRIVIA_ANSWERS2[1246] = "manson";

NORMAL_TRIVIA_QUESTIONS[1247] = "(History): What line did President Reagan steal from Jack Dempsey after John Hinckley Jr. winged him?";
NORMAL_TRIVIA_ANSWERS1[1247] = "Honey, I forgot to duck\"";
NORMAL_TRIVIA_ANSWERS2[1247] = "forgot to duck";

NORMAL_TRIVIA_QUESTIONS[1248] = "(World): What Tolstoy tome can be listened to on audiotape by anyone with 58 hours to spare?";
NORMAL_TRIVIA_ANSWERS1[1248] = "War and Peace";

NORMAL_TRIVIA_QUESTIONS[1249] = "(Arts&Entertainment): Who made his movie debut playing a corpse in \"The Big Chill\"?";
NORMAL_TRIVIA_ANSWERS1[1249] = "Kevin Costner";
NORMAL_TRIVIA_ANSWERS2[1249] = "costner";

NORMAL_TRIVIA_QUESTIONS[1250] = "(World): What does the term \"dinks\" stand for, that could describe a professional couple without children?";
NORMAL_TRIVIA_ANSWERS1[1250] = "Double income, no kids\"";
NORMAL_TRIVIA_ANSWERS2[1250] = "double income";
NORMAL_TRIVIA_ANSWERS3[1250] = "no kids";

NORMAL_TRIVIA_QUESTIONS[1251] = "(Sports&Leisure): What tennis star defected to the U.S. during the 1975 U.S. Open?";
NORMAL_TRIVIA_ANSWERS1[1251] = "Martina Navratilova";
NORMAL_TRIVIA_ANSWERS2[1251] = "Navratilova";

NORMAL_TRIVIA_QUESTIONS[1252] = "(People&Places): Who'd just stuck his neck into a gillotine when he yelled: \"May my blood cement the happiness of France\"?";
NORMAL_TRIVIA_ANSWERS1[1252] = "Louis XVI";
NORMAL_TRIVIA_ANSWERS2[1252] = "louis";

NORMAL_TRIVIA_QUESTIONS[1253] = "(People&Places): What American city hosted the 1939-40 and 1964-65 World's Fairs, both in the same location?";
NORMAL_TRIVIA_ANSWERS1[1253] = "New York";

NORMAL_TRIVIA_QUESTIONS[1254] = "(World): What comic strip canine's bride-to-be ran off with his best friend Spike?";
NORMAL_TRIVIA_ANSWERS1[1254] = "Snoopy's";
NORMAL_TRIVIA_ANSWERS2[1254] = "snoopy";

NORMAL_TRIVIA_QUESTIONS[1255] = "(Arts&Entertainment): What 1923 volume made a rich man of Lebanese poet Khalil Gibran?";
NORMAL_TRIVIA_ANSWERS1[1255] = "The Prophet";
NORMAL_TRIVIA_ANSWERS2[1255] = "prophet";

NORMAL_TRIVIA_QUESTIONS[1256] = "(Science&Nature): What psychiatric diagnosis would be meant if a shrink dubbed a patient a \"double-header\"?";
NORMAL_TRIVIA_ANSWERS1[1256] = "Schizophrenia";

NORMAL_TRIVIA_QUESTIONS[1257] = "(Sports&Leisure): Who, according to P.T. Barnum, was killed by a train while trying to save a pint-sized star?";
NORMAL_TRIVIA_ANSWERS1[1257] = "Jumbo";

NORMAL_TRIVIA_QUESTIONS[1258] = "(People&Places): Who spent three grueling summers de-tasseling corn before a modeling career beckoned?";
NORMAL_TRIVIA_ANSWERS1[1258] = "Cindy Crawford";
NORMAL_TRIVIA_ANSWERS2[1258] = "crawford";

NORMAL_TRIVIA_QUESTIONS[1259] = "(Science&Nature): What term for a computer error is said to have been coined when one caused a short circuit?";
NORMAL_TRIVIA_ANSWERS1[1259] = "Bug";

NORMAL_TRIVIA_QUESTIONS[1260] = "(Sports&Leisure): What Mobile, Alabama, native skipped high school baseball to play in a semi-pro league at age 15?";
NORMAL_TRIVIA_ANSWERS1[1260] = "Hank Aaron";
NORMAL_TRIVIA_ANSWERS2[1260] = "aaron";
NORMAL_TRIVIA_ANSWERS3[1260] = "arron";

NORMAL_TRIVIA_QUESTIONS[1261] = "(Arts&Entertainment): Who did Mork want to kidnap when he first came down to earth?";
NORMAL_TRIVIA_ANSWERS1[1261] = "Richie Cunningham";
NORMAL_TRIVIA_ANSWERS2[1261] = "cunningham";

NORMAL_TRIVIA_QUESTIONS[1262] = "(Arts&Entertainment): What musical group challenged Volvo as Sweden's top moneymaker?";
NORMAL_TRIVIA_ANSWERS1[1262] = "ABBA";

NORMAL_TRIVIA_QUESTIONS[1263] = "(Science&Nature): What Australian carnivore shares its name with a Saturday morning cartoon creature?";
NORMAL_TRIVIA_ANSWERS1[1263] = "The Tasmanian devil";
NORMAL_TRIVIA_ANSWERS2[1263] = "tasmanian";
NORMAL_TRIVIA_ANSWERS3[1263] = "devil";

NORMAL_TRIVIA_QUESTIONS[1264] = "(Sports&Leisure): Whose eight home run titles are the most ever won by a National League player?";
NORMAL_TRIVIA_ANSWERS1[1264] = "Mike Schmidt's";
NORMAL_TRIVIA_ANSWERS2[1264] = "schmidt";

NORMAL_TRIVIA_QUESTIONS[1265] = "(People&Places): What continent features the world's largest monolith, Ayers Rock?";
NORMAL_TRIVIA_ANSWERS1[1265] = "Australia";

NORMAL_TRIVIA_QUESTIONS[1266] = "(Sports&Leisure): Other than Spades, which card suit boasts one-eyed jacks?";
NORMAL_TRIVIA_ANSWERS1[1266] = "Hearts";

NORMAL_TRIVIA_QUESTIONS[1267] = "(History): What Shoshone woman was traded to a member of this expedition by her Mandan  captors?";
NORMAL_TRIVIA_ANSWERS1[1267] = "Sacajawea";

NORMAL_TRIVIA_QUESTIONS[1268] = "(Science&Nature): What Russian is best remembered for getting a dog to salivate?";
NORMAL_TRIVIA_ANSWERS1[1268] = "Ivan Pavlov";
NORMAL_TRIVIA_ANSWERS2[1268] = "Pavlov";

NORMAL_TRIVIA_QUESTIONS[1269] = "(World): What distinguished ABC-TV interviewer was called \"Dumbo\" by kids in school because he was all ears?";
NORMAL_TRIVIA_ANSWERS1[1269] = "Ted Koppel";
NORMAL_TRIVIA_ANSWERS2[1269] = "Koppel";

NORMAL_TRIVIA_QUESTIONS[1270] = "(Science&Nature): What's the most expensive solid form of the element carbon?";
NORMAL_TRIVIA_ANSWERS1[1270] = "Diamond";

NORMAL_TRIVIA_QUESTIONS[1271] = "(People&Places): What European Olympic city celebrated the 500th anniversary of the New World's discovery?";
NORMAL_TRIVIA_ANSWERS1[1271] = "Barcelona";

NORMAL_TRIVIA_QUESTIONS[1272] = "(World): What religion did Tina Turner embrace in the mid-seventies?";
NORMAL_TRIVIA_ANSWERS1[1272] = "Buddhism";

NORMAL_TRIVIA_QUESTIONS[1273] = "(Science&Nature): What was the \"garderobe\" built above and outside a castle wall used as?";
NORMAL_TRIVIA_ANSWERS1[1273] = "A toilet";
NORMAL_TRIVIA_ANSWERS2[1273] = "toilet";

NORMAL_TRIVIA_QUESTIONS[1274] = "(Sports&Leisure): How many points is the letter \"Z\" worth in the Polish-language version of Scrabble?";
NORMAL_TRIVIA_ANSWERS1[1274] = "One";
NORMAL_TRIVIA_ANSWERS2[1274] = "1";

NORMAL_TRIVIA_QUESTIONS[1275] = "(People&Places): What island is seen in the background of a Bay Area view?";
NORMAL_TRIVIA_ANSWERS1[1275] = "Alcatraz";

NORMAL_TRIVIA_QUESTIONS[1276] = "(Sports&Leisure): What rotund gridiron gourmand was nicknamed for a refrigerator?";
NORMAL_TRIVIA_ANSWERS1[1276] = "William Perry";
NORMAL_TRIVIA_ANSWERS2[1276] = "perry";

NORMAL_TRIVIA_QUESTIONS[1277] = "(Sports&Leisure): Who set a single-season scoring record in his rookie year in the NBA in 1959-60?";
NORMAL_TRIVIA_ANSWERS1[1277] = "Wilt Chamberlain";
NORMAL_TRIVIA_ANSWERS2[1277] = "chamberlain";

NORMAL_TRIVIA_QUESTIONS[1278] = "(Sports&Leisure): What decathlon star kept a hurdle in his living room to step across when he wasn't at track practice?";
NORMAL_TRIVIA_ANSWERS1[1278] = "Bruce Jenner";
NORMAL_TRIVIA_ANSWERS2[1278] = "jenner";

NORMAL_TRIVIA_QUESTIONS[1279] = "(Science&Nature): What condom brand shares its name with an ancient Egyptian?";
NORMAL_TRIVIA_ANSWERS1[1279] = "Ramses";

NORMAL_TRIVIA_QUESTIONS[1280] = "(Science&Nature): What's the name of the cooking variety banana, which is starchy instead of sweet?";
NORMAL_TRIVIA_ANSWERS1[1280] = "Plantain";

NORMAL_TRIVIA_QUESTIONS[1281] = "(People&Places): What rock column in Wyoming's Black Hills became the first U.S. National Monument in 1906?";
NORMAL_TRIVIA_ANSWERS1[1281] = "Devil's Tower";
NORMAL_TRIVIA_ANSWERS2[1281] = "devil";

NORMAL_TRIVIA_QUESTIONS[1282] = "(Science&Nature): What act by aliens is categorized as a close encounter of the fourth kind?";
NORMAL_TRIVIA_ANSWERS1[1282] = "Abduction";

NORMAL_TRIVIA_QUESTIONS[1283] = "(Science&Nature): What lawyer defended John Scopes, teacher of Charles Darwin's theory of evolution, in 1925?";
NORMAL_TRIVIA_ANSWERS1[1283] = "Clarence Darrow";
NORMAL_TRIVIA_ANSWERS2[1283] = "darrow";

NORMAL_TRIVIA_QUESTIONS[1284] = "(History): What U.S. Chief Justice chaired the commission to investigate John F. Kennedy's assassination?";
NORMAL_TRIVIA_ANSWERS1[1284] = "Earl Warren";
NORMAL_TRIVIA_ANSWERS2[1284] = "warren";

NORMAL_TRIVIA_QUESTIONS[1285] = "(Science&Nature): What diagnostic procedure produced a view of a brain?";
NORMAL_TRIVIA_ANSWERS1[1285] = "A CAT scan";
NORMAL_TRIVIA_ANSWERS2[1285] = "CAT";
NORMAL_TRIVIA_ANSWERS3[1285] = "CAT ";

NORMAL_TRIVIA_QUESTIONS[1286] = "(People&Places): What former Middle Eastern tourist mecca has been reduced to rubble by civil war and terrorism?";
NORMAL_TRIVIA_ANSWERS1[1286] = "Beirut";

NORMAL_TRIVIA_QUESTIONS[1287] = "(Science&Nature): What ship made the first navigational use of the new S.O.S. signal, on April 14, 1912?";
NORMAL_TRIVIA_ANSWERS1[1287] = "The \"Titanic\"";
NORMAL_TRIVIA_ANSWERS2[1287] = "titanic";

NORMAL_TRIVIA_QUESTIONS[1288] = "(World): What's the only type of vehicle an intoxicated person can legally operate on a Utah public highway?";
NORMAL_TRIVIA_ANSWERS1[1288] = "A wheelbarrow";
NORMAL_TRIVIA_ANSWERS2[1288] = "wheelbarrow";

NORMAL_TRIVIA_QUESTIONS[1289] = "(Science&Nature): What might a pulsar near Virgo have that only one other star in the universe is known to have?";
NORMAL_TRIVIA_ANSWERS1[1289] = "Planets";
NORMAL_TRIVIA_ANSWERS2[1289] = "planet";

NORMAL_TRIVIA_QUESTIONS[1290] = "(World): What comedian communicated by honking a Bombay taxi horn?";
NORMAL_TRIVIA_ANSWERS1[1290] = "Harpo Marx";
NORMAL_TRIVIA_ANSWERS2[1290] = "harpo";

NORMAL_TRIVIA_QUESTIONS[1291] = "(Sports&Leisure): Who insisted the toilets be raised an inch before he'd begin a chess match with Boris Spassky?";
NORMAL_TRIVIA_ANSWERS1[1291] = "Bobby Fischer";
NORMAL_TRIVIA_ANSWERS2[1291] = "fischer";
NORMAL_TRIVIA_ANSWERS3[1291] = "fisher";

NORMAL_TRIVIA_QUESTIONS[1292] = "(Science&Nature): How many Earths could fit side by side on Jupiter's Great Red Spot?";
NORMAL_TRIVIA_ANSWERS1[1292] = "Three";
NORMAL_TRIVIA_ANSWERS2[1292] = "3";

NORMAL_TRIVIA_QUESTIONS[1293] = "(Sports&Leisure): Whose 48 touchdown passes in 1984 were the most in one season in NFL history?";
NORMAL_TRIVIA_ANSWERS1[1293] = "Dan Marino's";
NORMAL_TRIVIA_ANSWERS2[1293] = "marino";

NORMAL_TRIVIA_QUESTIONS[1294] = "(Science&Nature): How many minutes does the Channel Tunnel train take to cover its 23.6-mile route?";
NORMAL_TRIVIA_ANSWERS1[1294] = "35";
NORMAL_TRIVIA_ANSWERS2[1294] = "thirtyfive";
NORMAL_TRIVIA_ANSWERS3[1294] = "thirty five";

NORMAL_TRIVIA_QUESTIONS[1295] = "(People&Places): What was the target of the worst terrorist attack on U.S. soil, in 1993?";
NORMAL_TRIVIA_ANSWERS1[1295] = "The World Trade Center";
NORMAL_TRIVIA_ANSWERS2[1295] = "world trade";

NORMAL_TRIVIA_QUESTIONS[1296] = "(History): What was Billy the Kid's original name first name?";
NORMAL_TRIVIA_ANSWERS1[1296] = "Henry";

NORMAL_TRIVIA_QUESTIONS[1297] = "(Science&Nature): How many identical armadillos will regularly pop out of a single egg?";
NORMAL_TRIVIA_ANSWERS1[1297] = "Four";
NORMAL_TRIVIA_ANSWERS2[1297] = "4";

NORMAL_TRIVIA_QUESTIONS[1298] = "(Sports&Leisure): What boat gave its name to the 100 Guineas Cup after winning it in 1851?";
NORMAL_TRIVIA_ANSWERS1[1298] = "The \"America\"";
NORMAL_TRIVIA_ANSWERS2[1298] = "america";

NORMAL_TRIVIA_QUESTIONS[1299] = "(People&Places): What city hosted the 1967 World's Fair that featured a geodesic dome?";
NORMAL_TRIVIA_ANSWERS1[1299] = "Montreal";

NORMAL_TRIVIA_QUESTIONS[1300] = "(Science&Nature): What's not needed in the cultivation of a hydroponic plant?";
NORMAL_TRIVIA_ANSWERS1[1300] = "Soil";

NORMAL_TRIVIA_QUESTIONS[1301] = "(Science&Nature): What was the name of the first reusable space shuttle?";
NORMAL_TRIVIA_ANSWERS1[1301] = "Columbia";

NORMAL_TRIVIA_QUESTIONS[1302] = "(History): Whose last words while facing a firing squad on April 28, 1945, were: \"No ... No!\"?";
NORMAL_TRIVIA_ANSWERS1[1302] = "Benito Mussolini's";
NORMAL_TRIVIA_ANSWERS2[1302] = "mussolini";

NORMAL_TRIVIA_QUESTIONS[1303] = "(World): What corporate mascot kept on going and going and going and going?";
NORMAL_TRIVIA_ANSWERS1[1303] = "The Energizer Bunny";
NORMAL_TRIVIA_ANSWERS2[1303] = "energizer";

NORMAL_TRIVIA_QUESTIONS[1304] = "(Sports&Leisure): What did Muhammad Ali dub the tactic he used to knock out the heavyweight champ in Zaire?";
NORMAL_TRIVIA_ANSWERS1[1304] = "Rope-a-dope";
NORMAL_TRIVIA_ANSWERS2[1304] = "rope a dope";

NORMAL_TRIVIA_QUESTIONS[1305] = "(World): What 1971 fashion craze inspired a new look for entertainers?";
NORMAL_TRIVIA_ANSWERS1[1305] = "Hot pants";

NORMAL_TRIVIA_QUESTIONS[1306] = "(Sports&Leisure): Who did the PGA name Golfer of the Century in 1988?";
NORMAL_TRIVIA_ANSWERS1[1306] = "Jack Nicklaus";
NORMAL_TRIVIA_ANSWERS2[1306] = "nicklaus";

NORMAL_TRIVIA_QUESTIONS[1307] = "(History): What 20th-century era had jobless folks singing \"Brother, can you spare a dime?\"?";
NORMAL_TRIVIA_ANSWERS1[1307] = "The Great Depression";
NORMAL_TRIVIA_ANSWERS2[1307] = "great depression";

NORMAL_TRIVIA_QUESTIONS[1308] = "(Arts&Entertainment): What \"Grease\" gang rebuilt and drove a white sportster?";
NORMAL_TRIVIA_ANSWERS1[1308] = "The T-birds";
NORMAL_TRIVIA_ANSWERS2[1308] = "Tbirds";
NORMAL_TRIVIA_ANSWERS3[1308] = "t-birds";

NORMAL_TRIVIA_QUESTIONS[1309] = "(Sports&Leisure): Who did Bobby Riggs challenge when he declared: \"Women play about 25 percent as good as men\"?";
NORMAL_TRIVIA_ANSWERS1[1309] = "Billie Jean King";
NORMAL_TRIVIA_ANSWERS2[1309] = "billie jean";

NORMAL_TRIVIA_QUESTIONS[1310] = "(Science&Nature): How many of every 10 unnamed species are thought to inhabit the tropical rain forests?";
NORMAL_TRIVIA_ANSWERS1[1310] = "Five";
NORMAL_TRIVIA_ANSWERS2[1310] = "5";

NORMAL_TRIVIA_QUESTIONS[1311] = "(Sports&Leisure): What shoe outfit saw red when half of its hyped \"Dan vs. Dave\" decathlon duo missed an Olympic cut?";
NORMAL_TRIVIA_ANSWERS1[1311] = "Reebok";

NORMAL_TRIVIA_QUESTIONS[1312] = "(World): What four-word phrase would Herve Villechaize no longer have to endure after he died at age 50?";
NORMAL_TRIVIA_ANSWERS1[1312] = "The plane! The plane!";
NORMAL_TRIVIA_ANSWERS2[1312] = "the plane";

NORMAL_TRIVIA_QUESTIONS[1313] = "(People&Places): What's the only independent state in the world whose permanent residents are all male?";
NORMAL_TRIVIA_ANSWERS1[1313] = "Vatican City";
NORMAL_TRIVIA_ANSWERS2[1313] = "vatican";

NORMAL_TRIVIA_QUESTIONS[1314] = "(Arts&Entertainment): What's the most famous screen line attributed to Humphrey Bogart that he never uttered? ";
NORMAL_TRIVIA_ANSWERS1[1314] = "Play it again, Sam\"";
NORMAL_TRIVIA_ANSWERS2[1314] = "play it again";

NORMAL_TRIVIA_QUESTIONS[1315] = "(Sports&Leisure): What 51-year-old granddad played in the All-Star Game during his 26th NHL season?";
NORMAL_TRIVIA_ANSWERS1[1315] = "Gordie Howe";
NORMAL_TRIVIA_ANSWERS2[1315] = "howe";
NORMAL_TRIVIA_ANSWERS3[1315] = "howe ";

NORMAL_TRIVIA_QUESTIONS[1316] = "(World): What name does Rob Reiner hate being called when recognized on the street?";
NORMAL_TRIVIA_ANSWERS1[1316] = "Meathead";

NORMAL_TRIVIA_QUESTIONS[1317] = "(Arts&Entertainment): What character from \"M*A*S*H\" was a cross-dresser?";
NORMAL_TRIVIA_ANSWERS1[1317] = "Maxwell Klinger";
NORMAL_TRIVIA_ANSWERS2[1317] = "klinger";

NORMAL_TRIVIA_QUESTIONS[1318] = "(World): What late '50s group, best known for \"The Great Pretender,\" has sued almost 50 others for using their name?";
NORMAL_TRIVIA_ANSWERS1[1318] = "The Platters";
NORMAL_TRIVIA_ANSWERS2[1318] = "platters";

NORMAL_TRIVIA_QUESTIONS[1319] = "(Sports&Leisure): What sportscaster wrote that he was \"painfully aware\" of the \"inane blathering of ex-jocks\"?";
NORMAL_TRIVIA_ANSWERS1[1319] = "Howard Cosell";
NORMAL_TRIVIA_ANSWERS2[1319] = "cosell";

NORMAL_TRIVIA_QUESTIONS[1320] = "(People&Places): What name is commonly used to denote the countries Norway, Sweden, and Finland?";
NORMAL_TRIVIA_ANSWERS1[1320] = "Scandinavia";

NORMAL_TRIVIA_QUESTIONS[1321] = "(World): Who did an MCI poll determine to be the most admired mom in history?";
NORMAL_TRIVIA_ANSWERS1[1321] = "The Virgin Mary";
NORMAL_TRIVIA_ANSWERS2[1321] = "virgin mary";

NORMAL_TRIVIA_QUESTIONS[1322] = "(Arts&Entertainment): What did an actress' character have auctioned off in the movie \"Pretty Baby\"?";
NORMAL_TRIVIA_ANSWERS1[1322] = "Her virginity";
NORMAL_TRIVIA_ANSWERS2[1322] = "virginity";

NORMAL_TRIVIA_QUESTIONS[1323] = "(Sports&Leisure): What one word did coach Paul William Bryant use to title his autobiography?";
NORMAL_TRIVIA_ANSWERS1[1323] = "Bear";

NORMAL_TRIVIA_QUESTIONS[1324] = "(Sports&Leisure): What are Arnold Palmer's adoring fans collectively known as?";
NORMAL_TRIVIA_ANSWERS1[1324] = "Arnie's army";
NORMAL_TRIVIA_ANSWERS2[1324] = "arnies army";

NORMAL_TRIVIA_QUESTIONS[1325] = "(History): What ancient Greek philosopher bit the dust after downing a drink infused with hemlock?";
NORMAL_TRIVIA_ANSWERS1[1325] = "Socrates";

NORMAL_TRIVIA_QUESTIONS[1326] = "(Science&Nature): What did officials in Volusia County, Florida, give away 50,000 of during spring break in 1994?";
NORMAL_TRIVIA_ANSWERS1[1326] = "Condoms";

NORMAL_TRIVIA_QUESTIONS[1327] = "(People&Places): Whose death certificate were hordes of fans buying copies of from Post Mortem Arts in Seattle for $25?";
NORMAL_TRIVIA_ANSWERS1[1327] = "Kurt Cobain's";
NORMAL_TRIVIA_ANSWERS2[1327] = "cobain";

NORMAL_TRIVIA_QUESTIONS[1328] = "(World): What TV talk show host got his nose broken when skinheads hit him with a chair during a show?";
NORMAL_TRIVIA_ANSWERS1[1328] = "Geraldo Rivera";
NORMAL_TRIVIA_ANSWERS2[1328] = "geraldo";
NORMAL_TRIVIA_ANSWERS3[1328] = "rivera";

NORMAL_TRIVIA_QUESTIONS[1329] = "(People&Places): Who banned smoking in the White House?";
NORMAL_TRIVIA_ANSWERS1[1329] = "Hillary Clinton";
NORMAL_TRIVIA_ANSWERS2[1329] = "hillary";

NORMAL_TRIVIA_QUESTIONS[1330] = "(Science&Nature): What trade halved the elephant population between 1981 and 1989?";
NORMAL_TRIVIA_ANSWERS1[1330] = "The ivory trade";
NORMAL_TRIVIA_ANSWERS2[1330] = "ivory";

NORMAL_TRIVIA_QUESTIONS[1331] = "(History): What Soviet rose to power after V.I. Lenin's death in 1924?";
NORMAL_TRIVIA_ANSWERS1[1331] = "Joseph Stalin";
NORMAL_TRIVIA_ANSWERS2[1331] = "stalin";

NORMAL_TRIVIA_QUESTIONS[1332] = "(Science&Nature): What word does the U.S. Weather Bureau define as a \"horizontal motion of the air past a given point\"?";
NORMAL_TRIVIA_ANSWERS1[1332] = "Wind";

NORMAL_TRIVIA_QUESTIONS[1333] = "(History): What feisty feminist claimed at a 1992 rally that she was \"the mother of you all\"?";
NORMAL_TRIVIA_ANSWERS1[1333] = "Betty Friedan";
NORMAL_TRIVIA_ANSWERS2[1333] = "friedan";

NORMAL_TRIVIA_QUESTIONS[1334] = "(People&Places): What Spaniard designed the five-story horse in Chicago's Daley Plaza?";
NORMAL_TRIVIA_ANSWERS1[1334] = "Pablo Picasso";
NORMAL_TRIVIA_ANSWERS2[1334] = "picasso";

NORMAL_TRIVIA_QUESTIONS[1335] = "(Science&Nature): What's the fastest-selling drug of the 1990s to take you from anxiety to confidence?";
NORMAL_TRIVIA_ANSWERS1[1335] = "Prozac";

NORMAL_TRIVIA_QUESTIONS[1336] = "(Science&Nature): What did F. Sherwood Rowland and Mario Molinas warn chloro- fluorocarbons were destroying, in 1974?";
NORMAL_TRIVIA_ANSWERS1[1336] = "The ozone layer";
NORMAL_TRIVIA_ANSWERS2[1336] = "ozone layer";

NORMAL_TRIVIA_QUESTIONS[1337] = "(World): What TV host ordered french fries at a Maine eatery just so she could stare longingly at them?";
NORMAL_TRIVIA_ANSWERS1[1337] = "Oprah Winfrey";
NORMAL_TRIVIA_ANSWERS2[1337] = "oprah";
NORMAL_TRIVIA_ANSWERS3[1337] = "winfrey";

NORMAL_TRIVIA_QUESTIONS[1338] = "(Science&Nature): What monstrous name did critics give to the first genetically engineered, FDA-approved tomato?";
NORMAL_TRIVIA_ANSWERS1[1338] = "Frankentomato";

NORMAL_TRIVIA_QUESTIONS[1339] = "(Sports&Leisure): What chess piece combines the powers of the Rook and the Bishop?";
NORMAL_TRIVIA_ANSWERS1[1339] = "The queen";
NORMAL_TRIVIA_ANSWERS2[1339] = "queen";

NORMAL_TRIVIA_QUESTIONS[1340] = "(Sports&Leisure): Who smashed Daley Thompson's eight-year-old decathlon world record at a 1992 meet in France?";
NORMAL_TRIVIA_ANSWERS1[1340] = "Dan O'Brien";
NORMAL_TRIVIA_ANSWERS2[1340] = "obrien";
NORMAL_TRIVIA_ANSWERS3[1340] = "o'brien";

NORMAL_TRIVIA_QUESTIONS[1341] = "(World): What seven-foot-one graduate of the U.S. Naval Academy was deemed too tall for shipboard work?";
NORMAL_TRIVIA_ANSWERS1[1341] = "David Robinson";
NORMAL_TRIVIA_ANSWERS2[1341] = "Robinson";

NORMAL_TRIVIA_QUESTIONS[1342] = "(Arts&Entertainment): What film featured far-flung folk drawn to Devil's Tower in Wyoming?";
NORMAL_TRIVIA_ANSWERS1[1342] = "Close Encounters of the Third Kind";
NORMAL_TRIVIA_ANSWERS2[1342] = "close encounter";

NORMAL_TRIVIA_QUESTIONS[1343] = "(Sports&Leisure): What NBA star's surname translates to English as \"always being on top\"?";
NORMAL_TRIVIA_ANSWERS1[1343] = "Hakeem Olajuwon's";
NORMAL_TRIVIA_ANSWERS2[1343] = "olajuwon";

NORMAL_TRIVIA_QUESTIONS[1344] = "(Arts&Entertainment): What one-season wonder on the \"Saturday Night Live\" show played the Land Shark?";
NORMAL_TRIVIA_ANSWERS1[1344] = "Chevy Chase";
NORMAL_TRIVIA_ANSWERS2[1344] = "chase";

NORMAL_TRIVIA_QUESTIONS[1345] = "(World): Who won a coin toss with guitarist Tommy Allsup to secure a seat on Buddy Holly's final flight?";
NORMAL_TRIVIA_ANSWERS1[1345] = "Ritchie Valens";
NORMAL_TRIVIA_ANSWERS2[1345] = "valens";

NORMAL_TRIVIA_QUESTIONS[1346] = "(Sports&Leisure): What's the last railroad players encounter before passing Go?";
NORMAL_TRIVIA_ANSWERS1[1346] = "Short Line";

NORMAL_TRIVIA_QUESTIONS[1347] = "(Sports&Leisure): What 1994 sports gala opened with 70 percent of Americans not knowing the U.S. was hosting it?";
NORMAL_TRIVIA_ANSWERS1[1347] = "The World Cup of soccer";
NORMAL_TRIVIA_ANSWERS2[1347] = "soccer";
NORMAL_TRIVIA_ANSWERS3[1347] = "world cup";

NORMAL_TRIVIA_QUESTIONS[1348] = "(Arts&Entertainment): Who is David Cassidy's half-brother?";
NORMAL_TRIVIA_ANSWERS1[1348] = "Shaun Cassidy";
NORMAL_TRIVIA_ANSWERS2[1348] = "shawn";
NORMAL_TRIVIA_ANSWERS3[1348] = "sean";

NORMAL_TRIVIA_QUESTIONS[1349] = "(People&Places): How many people did Bernhard Goetz shoot in a New York subway in 1985?";
NORMAL_TRIVIA_ANSWERS1[1349] = "Four";
NORMAL_TRIVIA_ANSWERS2[1349] = "4";

NORMAL_TRIVIA_QUESTIONS[1350] = "(Sports&Leisure): Who landed the blow that left Mike Tyson groping for his mouthpiece on February 10, 1990?";
NORMAL_TRIVIA_ANSWERS1[1350] = "Buster Douglas";
NORMAL_TRIVIA_ANSWERS2[1350] = "douglas";

NORMAL_TRIVIA_QUESTIONS[1351] = "(History): What 15th-century prince is thought to have been the inspiration for the classic \"Dracula\"?";
NORMAL_TRIVIA_ANSWERS1[1351] = "Vlad the Impaler";
NORMAL_TRIVIA_ANSWERS2[1351] = "impaler";
NORMAL_TRIVIA_ANSWERS3[1351] = "vlad";

NORMAL_TRIVIA_QUESTIONS[1352] = "(Science&Nature): Who first found that landing an airplane was almost as tough as getting off the ground?";
NORMAL_TRIVIA_ANSWERS1[1352] = "Orville Wright";
NORMAL_TRIVIA_ANSWERS2[1352] = "orville";
NORMAL_TRIVIA_ANSWERS3[1352] = "wright";

NORMAL_TRIVIA_QUESTIONS[1353] = "(Science&Nature): What type of vehicle, eventually a best-seller, did Lee Iacocca's company launch in 1984?";
NORMAL_TRIVIA_ANSWERS1[1353] = "The minivan";
NORMAL_TRIVIA_ANSWERS2[1353] = "minivan";

NORMAL_TRIVIA_QUESTIONS[1354] = "(People&Places): What racist outfit visited Long Island's posh Hamptons in search of new members in 1992?";
NORMAL_TRIVIA_ANSWERS1[1354] = "The Ku Klux Klan";
NORMAL_TRIVIA_ANSWERS2[1354] = "KKK";
NORMAL_TRIVIA_ANSWERS3[1354] = " KKK";

NORMAL_TRIVIA_QUESTIONS[1355] = "(World): What fish appeared in the first of a marathon run of TV commercials in 1961?";
NORMAL_TRIVIA_ANSWERS1[1355] = "Charlie the Tuna";
NORMAL_TRIVIA_ANSWERS2[1355] = "charlie";

NORMAL_TRIVIA_QUESTIONS[1356] = "(History): Which military man was nicknamed \"The Little Corporal\"?";
NORMAL_TRIVIA_ANSWERS1[1356] = "Napoleon";

NORMAL_TRIVIA_QUESTIONS[1357] = "(People&Places): Who opined: \"Everybody has a right to pronounce foreign names as he chooses\"?";
NORMAL_TRIVIA_ANSWERS1[1357] = "Winston Churchill";
NORMAL_TRIVIA_ANSWERS2[1357] = "churchill";

NORMAL_TRIVIA_QUESTIONS[1358] = "(Arts&Entertainment): What rating did the film \"Flashdance\" earn, due in part to it's dances?";
NORMAL_TRIVIA_ANSWERS1[1358] = "R";
NORMAL_TRIVIA_ANSWERS2[1358] = "r ";
NORMAL_TRIVIA_ANSWERS3[1358] = " r";

NORMAL_TRIVIA_QUESTIONS[1359] = "(People&Places): How did Rasputin die, after being poisoned, shot, beaten, bound and thrown in the Neva River?";
NORMAL_TRIVIA_ANSWERS1[1359] = "He drowned";
NORMAL_TRIVIA_ANSWERS2[1359] = "drown";

NORMAL_TRIVIA_QUESTIONS[1360] = "(World): What type of jacket did the \"Top Gun\" actress help to make a major fashion statement?";
NORMAL_TRIVIA_ANSWERS1[1360] = "The bomber jacket";
NORMAL_TRIVIA_ANSWERS2[1360] = "bomber";

NORMAL_TRIVIA_QUESTIONS[1361] = "(Arts&Entertainment): Who discovered nothing but an empty bottle when he opened Al Capone's safe in a highly-rated TV special?";
NORMAL_TRIVIA_ANSWERS1[1361] = "Geraldo Rivera";
NORMAL_TRIVIA_ANSWERS2[1361] = "rivera";

NORMAL_TRIVIA_QUESTIONS[1362] = "(Arts&Entertainment): What city did Eddie Murphy serve to protect before events took him to Beverly Hills?";
NORMAL_TRIVIA_ANSWERS1[1362] = "Detroit";

NORMAL_TRIVIA_QUESTIONS[1363] = "(Arts&Entertainment): What TV bigot did the Jeffersons live next to on Houser Street?";
NORMAL_TRIVIA_ANSWERS1[1363] = "Archie Bunker";
NORMAL_TRIVIA_ANSWERS2[1363] = "bunker";

NORMAL_TRIVIA_QUESTIONS[1364] = "(Arts&Entertainment): Who was the insect-eating assistant of Bram Stoker's classic wall-crawling blood-drinker?";
NORMAL_TRIVIA_ANSWERS1[1364] = "Renfield";

NORMAL_TRIVIA_QUESTIONS[1365] = "(Science&Nature): What Elisha Otis invention is credited with making skyscrapers feasible? ";
NORMAL_TRIVIA_ANSWERS1[1365] = "The elevator";
NORMAL_TRIVIA_ANSWERS2[1365] = "elevator";

NORMAL_TRIVIA_QUESTIONS[1366] = "(World): What hairstyle did Angela Davis help popularize?";
NORMAL_TRIVIA_ANSWERS1[1366] = "The Afro";
NORMAL_TRIVIA_ANSWERS2[1366] = "afro";
NORMAL_TRIVIA_ANSWERS3[1366] = "afro ";

NORMAL_TRIVIA_QUESTIONS[1367] = "(Sports&Leisure): What did the press Wilt Chamberlain, although he preferred to be called \"The Big Dipper\"?";
NORMAL_TRIVIA_ANSWERS1[1367] = "Wilt the Stilt";
NORMAL_TRIVIA_ANSWERS2[1367] = "stilt";

NORMAL_TRIVIA_QUESTIONS[1368] = "(World): What state has a law that bans the serving or eating of apple pie without a slice of cheese on top?";
NORMAL_TRIVIA_ANSWERS1[1368] = "Wisconsin";

NORMAL_TRIVIA_QUESTIONS[1369] = "(Sports&Leisure): What member of the 1919 Black Sox was banned from baseball despite a World Series-best .375 average?";
NORMAL_TRIVIA_ANSWERS1[1369] = "Shoeless Joe Jackson ";
NORMAL_TRIVIA_ANSWERS2[1369] = "jackson";
NORMAL_TRIVIA_ANSWERS3[1369] = "shoeless";

NORMAL_TRIVIA_QUESTIONS[1370] = "(Arts&Entertainment): Who played the mystery woman trying to kill Blues Brother John Belushi?";
NORMAL_TRIVIA_ANSWERS1[1370] = "Carrie Fisher";
NORMAL_TRIVIA_ANSWERS2[1370] = "fisher";

NORMAL_TRIVIA_QUESTIONS[1371] = "(People&Places): What section of Los Angeles did these National Guardsmen patrol during this 1965 riot?";
NORMAL_TRIVIA_ANSWERS1[1371] = "Watts";

NORMAL_TRIVIA_QUESTIONS[1372] = "(World): What David Lynch movie might some film buffs have attended expecting to see Bobby Vinton's life story?";
NORMAL_TRIVIA_ANSWERS1[1372] = "Blue Velvet";

NORMAL_TRIVIA_QUESTIONS[1373] = "(Arts&Entertainment): What songbird uttered the F-word 13 times as David Letterman's TV guest?";
NORMAL_TRIVIA_ANSWERS1[1373] = "Madonna";

NORMAL_TRIVIA_QUESTIONS[1374] = "(World): Who left Genesis in 1975?";
NORMAL_TRIVIA_ANSWERS1[1374] = "Peter Gabriel";
NORMAL_TRIVIA_ANSWERS2[1374] = "gabriel";

NORMAL_TRIVIA_QUESTIONS[1375] = "(History): What commodity did Jay Gould and James Fisk corner here in 1869, sparking \"Black Friday\"?";
NORMAL_TRIVIA_ANSWERS1[1375] = "Gold";
NORMAL_TRIVIA_ANSWERS2[1375] = "gold ";
NORMAL_TRIVIA_ANSWERS3[1375] = " gold";

NORMAL_TRIVIA_QUESTIONS[1376] = "(History): What Native American currency was the first market commodity to be \"cornered,\" in 1666?";
NORMAL_TRIVIA_ANSWERS1[1376] = "Wampum";

NORMAL_TRIVIA_QUESTIONS[1377] = "(Science&Nature): What feathered creature is sometimes called the \"man-o'-war bird\"?";
NORMAL_TRIVIA_ANSWERS1[1377] = "The frigate bird";
NORMAL_TRIVIA_ANSWERS2[1377] = "frigate";

NORMAL_TRIVIA_QUESTIONS[1378] = "(History): What ship had lifeboat space for half of its passengers when it rammed an iceberg in 1912?";
NORMAL_TRIVIA_ANSWERS1[1378] = "The \"Titanic\"";
NORMAL_TRIVIA_ANSWERS2[1378] = "titanic";

NORMAL_TRIVIA_QUESTIONS[1379] = "(History): What the name of the go-for-broke football play?";
NORMAL_TRIVIA_ANSWERS1[1379] = "The Hail Mary";
NORMAL_TRIVIA_ANSWERS2[1379] = "hail mary";

NORMAL_TRIVIA_QUESTIONS[1380] = "(Arts&Entertainment): What Pink Floyd album logged more than 20 years on the charts?";
NORMAL_TRIVIA_ANSWERS1[1380] = "Dark Side of the Moon";

NORMAL_TRIVIA_QUESTIONS[1381] = "(Sports&Leisure): Who took two rounds to put Joe Frazier on dream street in winning the heavyweight title in 1973?";
NORMAL_TRIVIA_ANSWERS1[1381] = "George Foreman";
NORMAL_TRIVIA_ANSWERS2[1381] = "foreman";

NORMAL_TRIVIA_QUESTIONS[1382] = "(Sports&Leisure): Which champion racketeer was taught tennis by a doting mother?";
NORMAL_TRIVIA_ANSWERS1[1382] = "Jimmy Connors";
NORMAL_TRIVIA_ANSWERS2[1382] = "connors";

NORMAL_TRIVIA_QUESTIONS[1383] = "(History): Whose 1923 death prompted Henry Cabot Lodge to gush: \"My God! That means Coolidge is president\"?";
NORMAL_TRIVIA_ANSWERS1[1383] = "Warren G. Harding's";
NORMAL_TRIVIA_ANSWERS2[1383] = "harding";

NORMAL_TRIVIA_QUESTIONS[1384] = "(Science&Nature): What did Nikita Khrushchev call the rocket NASA tried to launch two months after \"Sputnik\" made history?";
NORMAL_TRIVIA_ANSWERS1[1384] = "Kaputnik";

NORMAL_TRIVIA_QUESTIONS[1385] = "(Sports&Leisure): What woeful team chose a player named Steve Chilcott in the 1966 free agent draft?";
NORMAL_TRIVIA_ANSWERS1[1385] = "The New York Mets";
NORMAL_TRIVIA_ANSWERS2[1385] = "new york met";

NORMAL_TRIVIA_QUESTIONS[1386] = "(World): What's the derivation of the term \"woopie,\" which could be used to denote older affluent folks?";
NORMAL_TRIVIA_ANSWERS1[1386] = "Well-off older person";
NORMAL_TRIVIA_ANSWERS2[1386] = "well off older person";

NORMAL_TRIVIA_QUESTIONS[1387] = "(People&Places): Who did Tenzing Norkay of Nepal help scale Mt. Everest on May 28, 1953?";
NORMAL_TRIVIA_ANSWERS1[1387] = "Edmund Hillary";
NORMAL_TRIVIA_ANSWERS2[1387] = "hillary";

NORMAL_TRIVIA_QUESTIONS[1388] = "(People&Places): What U.S. state has the highest percentage of people who hoof it to work?";
NORMAL_TRIVIA_ANSWERS1[1388] = "Alaska";

NORMAL_TRIVIA_QUESTIONS[1389] = "(People&Places): What U.S. state boasts license plates emblazoned with a rodeo rider?";
NORMAL_TRIVIA_ANSWERS1[1389] = "Wyoming";

NORMAL_TRIVIA_QUESTIONS[1390] = "(World): What Beatles album had just come out when John Lennon dressed up a Rolls-Royce?";
NORMAL_TRIVIA_ANSWERS1[1390] = "Sgt. Pepper's Lonely Hearts Club Band";
NORMAL_TRIVIA_ANSWERS2[1390] = "pepper";
NORMAL_TRIVIA_ANSWERS3[1390] = "lonely hearts club";

NORMAL_TRIVIA_QUESTIONS[1391] = "(Science&Nature): What does a television set have if it comes with \"PIP\"?";
NORMAL_TRIVIA_ANSWERS1[1391] = "Picture-in-picture";
NORMAL_TRIVIA_ANSWERS2[1391] = "picture in picture";

NORMAL_TRIVIA_QUESTIONS[1392] = "(Arts&Entertainment): What color sail was the signal to the ailing Tristan that his love was coming to him?";
NORMAL_TRIVIA_ANSWERS1[1392] = "White";

NORMAL_TRIVIA_QUESTIONS[1393] = "(History): What war first gave Americans Uncle Sam on a poster, saying \"I Want You\"?";
NORMAL_TRIVIA_ANSWERS1[1393] = "World War I";
NORMAL_TRIVIA_ANSWERS2[1393] = "World War 1";
NORMAL_TRIVIA_ANSWERS3[1393] = "WW1";

NORMAL_TRIVIA_QUESTIONS[1394] = "(Science&Nature): How many natural satellites does Earth have?";
NORMAL_TRIVIA_ANSWERS1[1394] = "One";
NORMAL_TRIVIA_ANSWERS2[1394] = "1";

NORMAL_TRIVIA_QUESTIONS[1395] = "(Science&Nature): What member of Bill Clinton's administration first championed the information highway?";
NORMAL_TRIVIA_ANSWERS1[1395] = "Al Gore";
NORMAL_TRIVIA_ANSWERS2[1395] = "Gore";
NORMAL_TRIVIA_ANSWERS3[1395] = "Gore ";

NORMAL_TRIVIA_QUESTIONS[1396] = "(Science&Nature): What's the most abundant element on earth?";
NORMAL_TRIVIA_ANSWERS1[1396] = "Oxygen";

NORMAL_TRIVIA_QUESTIONS[1397] = "(Science&Nature): What's the astronomical phenomenon where the moon partially covers the sun called?";
NORMAL_TRIVIA_ANSWERS1[1397] = "An eclipse";
NORMAL_TRIVIA_ANSWERS2[1397] = "eclipse";

NORMAL_TRIVIA_QUESTIONS[1398] = "(History): Whose crew is blamed for introducing smallpox to America and syphilis to Europe?";
NORMAL_TRIVIA_ANSWERS1[1398] = "Christopher Columbus'";
NORMAL_TRIVIA_ANSWERS2[1398] = "columbus";

NORMAL_TRIVIA_QUESTIONS[1399] = "(Science&Nature): What oceanic climatic condition is named after the Spanish term for \"the Christ Child\"?";
NORMAL_TRIVIA_ANSWERS1[1399] = "El Nino";

NORMAL_TRIVIA_QUESTIONS[1400] = "(World): Who manned a mop as a janitor at a Miami radio station before mopping up as a TV talk show host?";
NORMAL_TRIVIA_ANSWERS1[1400] = "Larry King";
NORMAL_TRIVIA_ANSWERS2[1400] = "king";
NORMAL_TRIVIA_ANSWERS3[1400] = "king ";

NORMAL_TRIVIA_QUESTIONS[1401] = "(Arts&Entertainment): Which songstress prompted David Letterman to quip: \"I think she's trying to shock us\"?";
NORMAL_TRIVIA_ANSWERS1[1401] = "Madonna";

NORMAL_TRIVIA_QUESTIONS[1402] = "(Science&Nature): What letter does the first four notes of Beethoven's Fifth Symphony denote in Morse code, making it a onetime favorite of the Allies?";
NORMAL_TRIVIA_ANSWERS1[1402] = "V";
NORMAL_TRIVIA_ANSWERS2[1402] = "v ";
NORMAL_TRIVIA_ANSWERS3[1402] = " v";

NORMAL_TRIVIA_QUESTIONS[1403] = "(People&Places): How many days of his three-year prison sentence did Iran-Contra felon Oliver North serve?";
NORMAL_TRIVIA_ANSWERS1[1403] = "Zero";
NORMAL_TRIVIA_ANSWERS2[1403] = "0";

NORMAL_TRIVIA_QUESTIONS[1404] = "(Science&Nature): What product did you need if you marveled: \"I can't believe I ate the whole thing\"?";
NORMAL_TRIVIA_ANSWERS1[1404] = "Alka-Seltzer";
NORMAL_TRIVIA_ANSWERS2[1404] = "alka seltzer";

NORMAL_TRIVIA_QUESTIONS[1405] = "(Sports&Leisure): What Olympic skater worked off her community service sentence serving meals to Oregon's elderly?";
NORMAL_TRIVIA_ANSWERS1[1405] = "Tonya Harding";
NORMAL_TRIVIA_ANSWERS2[1405] = "harding";

NORMAL_TRIVIA_QUESTIONS[1406] = "(People&Places): What country did the U.S. and Britain blame for the 1988 plane bombing over Scotland?";
NORMAL_TRIVIA_ANSWERS1[1406] = "Libya";

NORMAL_TRIVIA_QUESTIONS[1407] = "(World): Which lovely got the call for Revlon's first effort into TV infomercial shopping?";
NORMAL_TRIVIA_ANSWERS1[1407] = "Dolly Parton";
NORMAL_TRIVIA_ANSWERS2[1407] = "parton";

NORMAL_TRIVIA_QUESTIONS[1408] = "(World): What child star was the first person signed by MGM without having to take a screen or sound test?";
NORMAL_TRIVIA_ANSWERS1[1408] = "Judy Garland";
NORMAL_TRIVIA_ANSWERS2[1408] = "garland";

NORMAL_TRIVIA_QUESTIONS[1409] = "(Sports&Leisure): What Muhammad Ali tactical advice was inspired by insects?";
NORMAL_TRIVIA_ANSWERS1[1409] = "Float like a butterfly, sting like a bee";
NORMAL_TRIVIA_ANSWERS2[1409] = "float like a butterfly";
NORMAL_TRIVIA_ANSWERS3[1409] = "sting like a bee";

NORMAL_TRIVIA_QUESTIONS[1410] = "(World): What was received on the second day of Christmas, according to the song?";
NORMAL_TRIVIA_ANSWERS1[1410] = "Two turtledoves";
NORMAL_TRIVIA_ANSWERS2[1410] = "turtle dove";
NORMAL_TRIVIA_ANSWERS3[1410] = "turtledove";

NORMAL_TRIVIA_QUESTIONS[1411] = "(Arts&Entertainment): What Indiana Jones movie saw an actress make her mark on future hubby Steven Spielberg? ";
NORMAL_TRIVIA_ANSWERS1[1411] = "Indiana Jones and the Temple of Doom ";
NORMAL_TRIVIA_ANSWERS2[1411] = "temple of doom";

NORMAL_TRIVIA_QUESTIONS[1412] = "(Arts&Entertainment): Who portrayed legendary boxer Jack Johnson in the movie \"The Great White Hope\"?";
NORMAL_TRIVIA_ANSWERS1[1412] = "James Earl Jones";
NORMAL_TRIVIA_ANSWERS2[1412] = "james earl";

NORMAL_TRIVIA_QUESTIONS[1413] = "(Science&Nature): Who did the Roman Catholic Church admit was right 350 years ago to suggest Earth revolved around the sun?";
NORMAL_TRIVIA_ANSWERS1[1413] = "Galileo";

NORMAL_TRIVIA_QUESTIONS[1414] = "(Science&Nature): What's the term for chemicals that kill weeds and unwanted plants?";
NORMAL_TRIVIA_ANSWERS1[1414] = "Herbicides";

NORMAL_TRIVIA_QUESTIONS[1415] = "(Science&Nature): Where do 12 percent of American teenagers lose their virginity?";
NORMAL_TRIVIA_ANSWERS1[1415] = "In a car";
NORMAL_TRIVIA_ANSWERS2[1415] = "car";
NORMAL_TRIVIA_ANSWERS3[1415] = "car ";

NORMAL_TRIVIA_QUESTIONS[1416] = "(History): Which president almost died during birth, when his mother was given an overdose of chloroform?";
NORMAL_TRIVIA_ANSWERS1[1416] = "Franklin D. Roosevelt";
NORMAL_TRIVIA_ANSWERS2[1416] = "roosevelt";

NORMAL_TRIVIA_QUESTIONS[1417] = "(History): Who warned in 1917: \"This is only a preliminary step toward a similar revolution everywhere\"?";
NORMAL_TRIVIA_ANSWERS1[1417] = "V.I. Lenin";
NORMAL_TRIVIA_ANSWERS2[1417] = "lenin";

NORMAL_TRIVIA_QUESTIONS[1418] = "(World): What English-language song is the most frequently sung?";
NORMAL_TRIVIA_ANSWERS1[1418] = "Happy Birthday to You";
NORMAL_TRIVIA_ANSWERS2[1418] = "happy birthday";

NORMAL_TRIVIA_QUESTIONS[1419] = "(People&Places): What skyscraper shares New York state's nickname?";
NORMAL_TRIVIA_ANSWERS1[1419] = "The Empire State Building";
NORMAL_TRIVIA_ANSWERS2[1419] = "empire state";

NORMAL_TRIVIA_QUESTIONS[1420] = "(Sports&Leisure): What city saw its streets become household names after the Monopoly game hit the jackpot?";
NORMAL_TRIVIA_ANSWERS1[1420] = "Atlantic City";
NORMAL_TRIVIA_ANSWERS2[1420] = "atlantic";

NORMAL_TRIVIA_QUESTIONS[1421] = "(Science&Nature): What twosome made history at Kill Devil Hill, North Carolina, on December 17, 1903?";
NORMAL_TRIVIA_ANSWERS1[1421] = "Orville and Wilbur Wright";
NORMAL_TRIVIA_ANSWERS2[1421] = "wright";

NORMAL_TRIVIA_QUESTIONS[1422] = "(Arts&Entertainment): What movie had Dan Ackroyd losing his job, home, fiancee, limo and butler?";
NORMAL_TRIVIA_ANSWERS1[1422] = "Trading Places";

NORMAL_TRIVIA_QUESTIONS[1423] = "(Sports&Leisure): What U.S. president asked for rules changes after 18 players died during the 1905 football season?";
NORMAL_TRIVIA_ANSWERS1[1423] = "Theodore Roosevelt";
NORMAL_TRIVIA_ANSWERS2[1423] = "roosevelt";

NORMAL_TRIVIA_QUESTIONS[1424] = "(People&Places): What president was so unpopular that he almost didn't get his name on a dam?";
NORMAL_TRIVIA_ANSWERS1[1424] = "Herbert Hoover";
NORMAL_TRIVIA_ANSWERS2[1424] = "hoover";

NORMAL_TRIVIA_QUESTIONS[1425] = "(World): What Disney animated feature required the drawing of 6,469,952 black spots?";
NORMAL_TRIVIA_ANSWERS1[1425] = "101 Dalmatians";
NORMAL_TRIVIA_ANSWERS2[1425] = "dalmatian";
NORMAL_TRIVIA_ANSWERS3[1425] = "dalmation";

NORMAL_TRIVIA_QUESTIONS[1426] = "(Arts&Entertainment): What comedian's signature line was: \"This is another fine mess you've gotten us into\"?";
NORMAL_TRIVIA_ANSWERS1[1426] = "Oliver Hardy's";
NORMAL_TRIVIA_ANSWERS2[1426] = "hardy";

NORMAL_TRIVIA_QUESTIONS[1427] = "(World): What film puts an animated rodent to work, hauling buckets of water in his masters abode?";
NORMAL_TRIVIA_ANSWERS1[1427] = "Fantasia";

NORMAL_TRIVIA_QUESTIONS[1428] = "(History): Who was the first living American to have his name appear on a postage stamp?";
NORMAL_TRIVIA_ANSWERS1[1428] = "Charles Lindbergh";
NORMAL_TRIVIA_ANSWERS2[1428] = "lindbergh";

NORMAL_TRIVIA_QUESTIONS[1429] = "(Sports&Leisure): Whose 565-foot home run over the wall at Griffith Stadium gave birth to the term \"tape measure shot\"?";
NORMAL_TRIVIA_ANSWERS1[1429] = "Mickey Mantle's";
NORMAL_TRIVIA_ANSWERS2[1429] = "mantle";

NORMAL_TRIVIA_QUESTIONS[1430] = "(History): What general's father was in charge of investigating the case of Charles Lindberg's kidnapped child?";
NORMAL_TRIVIA_ANSWERS1[1430] = "Norman Schwarzkopf's";
NORMAL_TRIVIA_ANSWERS2[1430] = "schwarzkopf";

NORMAL_TRIVIA_QUESTIONS[1431] = "(World): What cult leader was rejected at an audition for The Monkees for just not being cute enough?";
NORMAL_TRIVIA_ANSWERS1[1431] = "Charles Manson";
NORMAL_TRIVIA_ANSWERS2[1431] = "manson";

NORMAL_TRIVIA_QUESTIONS[1432] = "(Sports&Leisure): What did Chicago Cubs owner Phil Wrigley say, in 1935, was  \"just a fad, a passing fancy\"?";
NORMAL_TRIVIA_ANSWERS1[1432] = "Night baseball";
NORMAL_TRIVIA_ANSWERS2[1432] = "night game";

NORMAL_TRIVIA_QUESTIONS[1433] = "(Arts&Entertainment): What Brady Buncher carped about being \"everybody's answer to a 'Trivial Pursuit' question\"?";
NORMAL_TRIVIA_ANSWERS1[1433] = "Eve Plumb";
NORMAL_TRIVIA_ANSWERS2[1433] = "plumb";

NORMAL_TRIVIA_QUESTIONS[1434] = "(Science&Nature): How many of every 10 boys born in the U.S. are circumcised?";
NORMAL_TRIVIA_ANSWERS1[1434] = "Seven";
NORMAL_TRIVIA_ANSWERS2[1434] = "7";

NORMAL_TRIVIA_QUESTIONS[1435] = "(Arts&Entertainment): What bird inspired Edgar Allen Poe to write a poem?";
NORMAL_TRIVIA_ANSWERS1[1435] = "The raven";
NORMAL_TRIVIA_ANSWERS2[1435] = "raven";

NORMAL_TRIVIA_QUESTIONS[1436] = "(History): Who surrendered on April 9, 1865, without Jefferson Davis' approval?";
NORMAL_TRIVIA_ANSWERS1[1436] = "Robert E. Lee";
NORMAL_TRIVIA_ANSWERS2[1436] = "robert";

NORMAL_TRIVIA_QUESTIONS[1437] = "(World): What top-selling Christmas single of 1985 was not the least bit amusing to many senior citizens?";
NORMAL_TRIVIA_ANSWERS1[1437] = "Grandma Got Run Over by a Reindeer";
NORMAL_TRIVIA_ANSWERS2[1437] = "got run over";

NORMAL_TRIVIA_QUESTIONS[1438] = "(People&Places): How many cars does the average Kuwaiti driver have registered?";
NORMAL_TRIVIA_ANSWERS1[1438] = "Three";
NORMAL_TRIVIA_ANSWERS2[1438] = "3";

NORMAL_TRIVIA_QUESTIONS[1439] = "(World): What do some stock market wizards call a \"007\"? ";
NORMAL_TRIVIA_ANSWERS1[1439] = "A bond";
NORMAL_TRIVIA_ANSWERS2[1439] = "bond";
NORMAL_TRIVIA_ANSWERS3[1439] = "bond ";

NORMAL_TRIVIA_QUESTIONS[1440] = "(World): 1 Jan of what year will mark the first day of the 21st century?";
NORMAL_TRIVIA_ANSWERS1[1440] = "2001";

NORMAL_TRIVIA_QUESTIONS[1441] = "(People&Places): What general's estate did a vengeful Congress confiscate as the site for a cemetery?";
NORMAL_TRIVIA_ANSWERS1[1441] = "Robert E. Lee's";
NORMAL_TRIVIA_ANSWERS2[1441] = "robert";
NORMAL_TRIVIA_ANSWERS3[1441] = "lee";

NORMAL_TRIVIA_QUESTIONS[1442] = "(History): What woman did Hitler hire to glamorize scenes in films such as \"Triumph of the Will\"?";
NORMAL_TRIVIA_ANSWERS1[1442] = "Leni Riefenstahl";
NORMAL_TRIVIA_ANSWERS2[1442] = "riefenstahl";

NORMAL_TRIVIA_QUESTIONS[1443] = "(Science&Nature): What's defined as \"species not definitely located in the wild during the past 50 years\"?";
NORMAL_TRIVIA_ANSWERS1[1443] = "Endangered species";
NORMAL_TRIVIA_ANSWERS2[1443] = "endangered";

NORMAL_TRIVIA_QUESTIONS[1444] = "(People&Places): Who might never have found the Pacific Ocean without the help of a Native American?";
NORMAL_TRIVIA_ANSWERS1[1444] = "Meriwether Lewis and William Clark";
NORMAL_TRIVIA_ANSWERS2[1444] = "lewis";
NORMAL_TRIVIA_ANSWERS3[1444] = "clark";

NORMAL_TRIVIA_QUESTIONS[1445] = "(People&Places): What autonomous region would the Dalai Lama like to call home?";
NORMAL_TRIVIA_ANSWERS1[1445] = "Tibet";

NORMAL_TRIVIA_QUESTIONS[1446] = "(People&Places): What late female painter's art, drawn from desert scenes fueled calendar sales?";
NORMAL_TRIVIA_ANSWERS1[1446] = "Georgia O'Keeffe's";
NORMAL_TRIVIA_ANSWERS2[1446] = "keeffe";
NORMAL_TRIVIA_ANSWERS3[1446] = "keefe";

NORMAL_TRIVIA_QUESTIONS[1447] = "(People&Places): What did Supreme Court nominee Douglas Ginsberg describe as a \"mistake\" he made as a Harvard prof?";
NORMAL_TRIVIA_ANSWERS1[1447] = "Smoking marijuana";
NORMAL_TRIVIA_ANSWERS2[1447] = "smoking pot";

NORMAL_TRIVIA_QUESTIONS[1448] = "(History): What assassin's low self-esteem is often attributed to his undiagnosed dyslexia?";
NORMAL_TRIVIA_ANSWERS1[1448] = "Lee Harvey Oswald's";
NORMAL_TRIVIA_ANSWERS2[1448] = "oswald";

NORMAL_TRIVIA_QUESTIONS[1449] = "(History): How many aircraft carriers were in Pearl Harbor when the Japanese attack occurred?";
NORMAL_TRIVIA_ANSWERS1[1449] = "Zero";
NORMAL_TRIVIA_ANSWERS2[1449] = "0";

NORMAL_TRIVIA_QUESTIONS[1450] = "(Science&Nature): What fixture in the White House was called a \"Quincy,\" after the president at the time of its installation?";
NORMAL_TRIVIA_ANSWERS1[1450] = "The toilet";
NORMAL_TRIVIA_ANSWERS2[1450] = "toilet";

NORMAL_TRIVIA_QUESTIONS[1451] = "(Sports&Leisure): What kind of sportsman is endangered by \"nitrogen narcosis\" at a depth of more than 130 feet?";
NORMAL_TRIVIA_ANSWERS1[1451] = "A scuba diver";
NORMAL_TRIVIA_ANSWERS2[1451] = "scuba diver";

NORMAL_TRIVIA_QUESTIONS[1452] = "(Sports&Leisure): What New York Yankees captain died when he crashed his plane short of the runway?";
NORMAL_TRIVIA_ANSWERS1[1452] = "Thurman Munson";
NORMAL_TRIVIA_ANSWERS2[1452] = "munson";

NORMAL_TRIVIA_QUESTIONS[1453] = "(Sports&Leisure): Who said, \"You don't know what a weight it was off my shoulders, a tremendous weight,\" on April 8, 1974?";
NORMAL_TRIVIA_ANSWERS1[1453] = "Hank Aaron";
NORMAL_TRIVIA_ANSWERS2[1453] = "Aaron";

NORMAL_TRIVIA_QUESTIONS[1454] = "(Sports&Leisure): Who arrived on court for a 1973 tennis match in a Chinese rickshaw?";
NORMAL_TRIVIA_ANSWERS1[1454] = "Bobby Riggs";
NORMAL_TRIVIA_ANSWERS2[1454] = "riggs";

NORMAL_TRIVIA_QUESTIONS[1455] = "(Science&Nature): Where was a meal of bacon squares, cookies, peaches, fruit drink and coffee enjoyed on July 20, 1969?";
NORMAL_TRIVIA_ANSWERS1[1455] = "the moon";
NORMAL_TRIVIA_ANSWERS2[1455] = "moon";

NORMAL_TRIVIA_QUESTIONS[1456] = "(Arts&Entertainment): What character did John Belushi portray at his \"Saturday Night Live\" audition?";
NORMAL_TRIVIA_ANSWERS1[1456] = "A samurai warrior";
NORMAL_TRIVIA_ANSWERS2[1456] = "samurai";
NORMAL_TRIVIA_ANSWERS3[1456] = "samerai";

NORMAL_TRIVIA_QUESTIONS[1457] = "(World): What's the name of the \"Citizen Kane\" sled owned by Steven Spielberg?";
NORMAL_TRIVIA_ANSWERS1[1457] = "Rosebud";

NORMAL_TRIVIA_QUESTIONS[1458] = "(History): What country declared war on Japan between the bombings of Hiroshima and Nagasaki?";
NORMAL_TRIVIA_ANSWERS1[1458] = "The Soviet Union";
NORMAL_TRIVIA_ANSWERS2[1458] = "Russia";
NORMAL_TRIVIA_ANSWERS3[1458] = "USSR";

NORMAL_TRIVIA_QUESTIONS[1459] = "(History): What nation was horrified to see its state dinner disagree with the US president in 1992?";
NORMAL_TRIVIA_ANSWERS1[1459] = "Japan";

NORMAL_TRIVIA_QUESTIONS[1460] = "(People&Places): What did David Koresh aptly name his ranch before it went up in flames?";
NORMAL_TRIVIA_ANSWERS1[1460] = "Ranch Apocalypse";
NORMAL_TRIVIA_ANSWERS2[1460] = "apocolipse";
NORMAL_TRIVIA_ANSWERS3[1460] = "apocolypse";

NORMAL_TRIVIA_QUESTIONS[1461] = "(Arts&Entertainment): What showman unleashed a pint-sized performer on the world?";
NORMAL_TRIVIA_ANSWERS1[1461] = "P.T. Barnum";
NORMAL_TRIVIA_ANSWERS2[1461] = "barnum";

NORMAL_TRIVIA_QUESTIONS[1462] = "(Science&Nature): What fungus are dogs taught to sniff out in the Perigord district of France?";
NORMAL_TRIVIA_ANSWERS1[1462] = "Truffles";
NORMAL_TRIVIA_ANSWERS2[1462] = "trufles";

NORMAL_TRIVIA_QUESTIONS[1463] = "(People&Places): What British naval hero stands atop a column in Trafalgar Square?";
NORMAL_TRIVIA_ANSWERS1[1463] = "Horatio Nelson";
NORMAL_TRIVIA_ANSWERS2[1463] = "Lord Nelson";
NORMAL_TRIVIA_ANSWERS3[1463] = "nelson";

NORMAL_TRIVIA_QUESTIONS[1464] = "(Science&Nature): What's the term for the nest of eagles to which they return every year?";
NORMAL_TRIVIA_ANSWERS1[1464] = "Aerie";
NORMAL_TRIVIA_ANSWERS2[1464] = "aiery";
NORMAL_TRIVIA_ANSWERS3[1464] = "airery";

NORMAL_TRIVIA_QUESTIONS[1465] = "(History): Which of the signers of the Declaration of Independance is believed to have been the richest man in the 13 colonies?";
NORMAL_TRIVIA_ANSWERS1[1465] = "John Hancock";
NORMAL_TRIVIA_ANSWERS2[1465] = "hancock";

NORMAL_TRIVIA_QUESTIONS[1466] = "(Arts&Entertainment): What game show got in gear after Johnny Olsen yelled \"Come on down\"?";
NORMAL_TRIVIA_ANSWERS1[1466] = "The Price Is Right";
NORMAL_TRIVIA_ANSWERS2[1466] = "price is right";

NORMAL_TRIVIA_QUESTIONS[1467] = "(Arts&Entertainment): What TV show opened: \"Once upon a time there were three girls who went to the police academy\"?";
NORMAL_TRIVIA_ANSWERS1[1467] = "Charlie's Angels";
NORMAL_TRIVIA_ANSWERS2[1467] = "charlies angels";

NORMAL_TRIVIA_QUESTIONS[1468] = "(Sports&Leisure): What visual condition prevents people from seeing greens properly?";
NORMAL_TRIVIA_ANSWERS1[1468] = "Color blindness";
NORMAL_TRIVIA_ANSWERS2[1468] = "color blind";
NORMAL_TRIVIA_ANSWERS3[1468] = "colorblind";

NORMAL_TRIVIA_QUESTIONS[1469] = "(Sports&Leisure): Who broke Lou Brock's career steals record on May 1, 1991?";
NORMAL_TRIVIA_ANSWERS1[1469] = "Rickey Henderson";
NORMAL_TRIVIA_ANSWERS2[1469] = "henderson";
NORMAL_TRIVIA_ANSWERS3[1469] = "hendersen";

NORMAL_TRIVIA_QUESTIONS[1470] = "(Arts&Entertainment): What performer pocketed the most cash at 1969's Woodstock?";
NORMAL_TRIVIA_ANSWERS1[1470] = "Jimi Hendrix";
NORMAL_TRIVIA_ANSWERS2[1470] = "Hendrix";
NORMAL_TRIVIA_ANSWERS3[1470] = "jimi";

NORMAL_TRIVIA_QUESTIONS[1471] = "(People&Places): What city's opera lovers first flocked to this facility in 1973?";
NORMAL_TRIVIA_ANSWERS1[1471] = "Sydney's";
NORMAL_TRIVIA_ANSWERS2[1471] = "sydney";
NORMAL_TRIVIA_ANSWERS3[1471] = "sidney";

NORMAL_TRIVIA_QUESTIONS[1472] = "(World): What boat took Gary Hart and Donna Rice on their infamous excursion to Bimini?";
NORMAL_TRIVIA_ANSWERS1[1472] = "Monkey Business";

NORMAL_TRIVIA_QUESTIONS[1473] = "(World): Who was the first president to have a brother with a beer named for him?";
NORMAL_TRIVIA_ANSWERS1[1473] = "Jimmy Carter";
NORMAL_TRIVIA_ANSWERS2[1473] = "carter";

NORMAL_TRIVIA_QUESTIONS[1474] = "(Sports&Leisure): What apt weapon was used in an 1843 duel between two Frenchmen who had argued over billiards?";
NORMAL_TRIVIA_ANSWERS1[1474] = "Billiard balls";
NORMAL_TRIVIA_ANSWERS2[1474] = "pool balls";

NORMAL_TRIVIA_QUESTIONS[1475] = "(World): What color was a mood ring supposed to turn if its wearer were depressed?";
NORMAL_TRIVIA_ANSWERS1[1475] = "Black";

NORMAL_TRIVIA_QUESTIONS[1476] = "(History): Who was the first recipient of a full, free and absolute pardon given by the 38th president of the USA?\"";
NORMAL_TRIVIA_ANSWERS1[1476] = "Richard Nixon";
NORMAL_TRIVIA_ANSWERS2[1476] = "nixon";
NORMAL_TRIVIA_ANSWERS3[1476] = "dick nixon";

NORMAL_TRIVIA_QUESTIONS[1477] = "(People&Places): What one-time federal prison got its name from the Spanish word for pelican?";
NORMAL_TRIVIA_ANSWERS1[1477] = "Alcatraz";

NORMAL_TRIVIA_QUESTIONS[1478] = "(Arts&Entertainment): What was the sequel to the book \"Alice In Wonderland\"?";
NORMAL_TRIVIA_ANSWERS1[1478] = "Through the Looking Glass";

NORMAL_TRIVIA_QUESTIONS[1479] = "(World): What president-to-be wore one black and one brown shoe on his wedding day?";
NORMAL_TRIVIA_ANSWERS1[1479] = "Gerald Ford";
NORMAL_TRIVIA_ANSWERS2[1479] = "ford";

NORMAL_TRIVIA_QUESTIONS[1480] = "(Arts&Entertainment): What hit movie spent 10 percent of its budget for the rights to 41 golden oldies?";
NORMAL_TRIVIA_ANSWERS1[1480] = "American Graffiti";
NORMAL_TRIVIA_ANSWERS2[1480] = "american grafitti";

NORMAL_TRIVIA_QUESTIONS[1481] = "(Arts&Entertainment): What coin did Patrick Swayze use to perform magical mind-over-matter feats in the movie \"Ghost\"?";
NORMAL_TRIVIA_ANSWERS1[1481] = "A penny";
NORMAL_TRIVIA_ANSWERS2[1481] = "one cent";
NORMAL_TRIVIA_ANSWERS3[1481] = "penny";

NORMAL_TRIVIA_QUESTIONS[1482] = "(Arts&Entertainment): What movie sees Tom Cruise sound off: \"I feel the need, the need for speed\"?";
NORMAL_TRIVIA_ANSWERS1[1482] = "Top Gun";

NORMAL_TRIVIA_QUESTIONS[1483] = "(Sports&Leisure): Who's the only American to win, defend and lose a world heavyweight title outside the U.S.?";
NORMAL_TRIVIA_ANSWERS1[1483] = "George Foreman";
NORMAL_TRIVIA_ANSWERS2[1483] = "foreman";
NORMAL_TRIVIA_ANSWERS3[1483] = "forman";

NORMAL_TRIVIA_QUESTIONS[1484] = "(Science&Nature): What software mogul planned to put over 850 of these in space to pave the information superhighway?";
NORMAL_TRIVIA_ANSWERS1[1484] = "Bill Gates";

NORMAL_TRIVIA_QUESTIONS[1485] = "(World): What four-word phrase sums up the quality of a well-known fried chicken franchise's fare?";
NORMAL_TRIVIA_ANSWERS1[1485] = "it's finger-lickin' good!";
NORMAL_TRIVIA_ANSWERS2[1485] = "finger licking";
NORMAL_TRIVIA_ANSWERS3[1485] = "finger lickin";

NORMAL_TRIVIA_QUESTIONS[1486] = "(Sports&Leisure): Who strong-armed his way to a record 109 men's tennis tournament wins?";
NORMAL_TRIVIA_ANSWERS1[1486] = "Jimmy Connors";
NORMAL_TRIVIA_ANSWERS2[1486] = "connors";

NORMAL_TRIVIA_QUESTIONS[1487] = "(Arts&Entertainment): What two sitcoms did Ronnie Howard co-star in before becoming a movie director?";
NORMAL_TRIVIA_ANSWERS1[1487] = "The Andy Griffith Show and Happy Days";
NORMAL_TRIVIA_ANSWERS2[1487] = "andy griffith an happy days";
NORMAL_TRIVIA_ANSWERS3[1487] = "andy grifith and happy days";

NORMAL_TRIVIA_QUESTIONS[1488] = "(World): What pop song can be heard at the Amsterdam museum that features this artist's paintings?";
NORMAL_TRIVIA_ANSWERS1[1488] = "Vincent";

NORMAL_TRIVIA_QUESTIONS[1489] = "(Sports&Leisure): Who surpassed George Halas to become the NFL's all-time winningest coach?";
NORMAL_TRIVIA_ANSWERS1[1489] = "Don Shula";
NORMAL_TRIVIA_ANSWERS2[1489] = "shula";

NORMAL_TRIVIA_QUESTIONS[1490] = "(History): Who had the higher approval rating after a year in office - Ronald Reagan or Bill Clinton?";
NORMAL_TRIVIA_ANSWERS1[1490] = "Bill Clinton";
NORMAL_TRIVIA_ANSWERS2[1490] = "clinton";

NORMAL_TRIVIA_QUESTIONS[1491] = "(Arts&Entertainment): What mythological hero beheaded the Gorgon, Medusa?";
NORMAL_TRIVIA_ANSWERS1[1491] = "Perseus";

NORMAL_TRIVIA_QUESTIONS[1492] = "(World): What actress portrayed a 'spiritual go-between' in \"Ghost\"?";
NORMAL_TRIVIA_ANSWERS1[1492] = "Whoopi Goldberg";
NORMAL_TRIVIA_ANSWERS2[1492] = "whoopi";
NORMAL_TRIVIA_ANSWERS3[1492] = "goldberg";

NORMAL_TRIVIA_QUESTIONS[1493] = "(History): What was Lady Di's maiden name before she kissed her prince?";
NORMAL_TRIVIA_ANSWERS1[1493] = "Spencer";

NORMAL_TRIVIA_QUESTIONS[1494] = "(World): What Russian's corpse was washed twice a week in 1993?";
NORMAL_TRIVIA_ANSWERS1[1494] = "V.I. Lenin's";
NORMAL_TRIVIA_ANSWERS2[1494] = "lenin";

NORMAL_TRIVIA_QUESTIONS[1495] = "(Arts&Entertainment): What late \"Theatre of Blood\" horror actor left behind a $5 million art collection?";
NORMAL_TRIVIA_ANSWERS1[1495] = "Vincent Price";
NORMAL_TRIVIA_ANSWERS2[1495] = "price";

NORMAL_TRIVIA_QUESTIONS[1496] = "(Sports&Leisure): Who played and won more singles matches than any other pro tennis player in history?";
NORMAL_TRIVIA_ANSWERS1[1496] = "Martina Navratilova";
NORMAL_TRIVIA_ANSWERS2[1496] = "martina";
NORMAL_TRIVIA_ANSWERS3[1496] = "navratilova";

NORMAL_TRIVIA_QUESTIONS[1497] = "(Sports&Leisure): What interrupted a World Series showdown between Oakland and San Francisco for 11 days in 1989?";
NORMAL_TRIVIA_ANSWERS1[1497] = "An earthquake";
NORMAL_TRIVIA_ANSWERS2[1497] = "earthquake";

NORMAL_TRIVIA_QUESTIONS[1498] = "(World): What condiment was heralded in 19th-century ads reading \"57 Varieties\"?";
NORMAL_TRIVIA_ANSWERS1[1498] = "Heinz Ketchup";
NORMAL_TRIVIA_ANSWERS2[1498] = "ketchup";

NORMAL_TRIVIA_QUESTIONS[1499] = "(World): Whose son Phil starred when \"Mission: Impossible\" returned to TV in 1988?";
NORMAL_TRIVIA_ANSWERS1[1499] = "Greg Morris'";
NORMAL_TRIVIA_ANSWERS2[1499] = "greg morris";

NORMAL_TRIVIA_QUESTIONS[1500] = "(Sports&Leisure): Who did the Los Angeles Dodgers finally beat in a third trip to the World Series?";
NORMAL_TRIVIA_ANSWERS1[1500] = "The New York Yankees";
NORMAL_TRIVIA_ANSWERS2[1500] = "yankees";

NORMAL_TRIVIA_QUESTIONS[1501] = "(History): What president surprised reporters by showing off the scar from his gall bladder surgery?";
NORMAL_TRIVIA_ANSWERS1[1501] = "Lyndon B. Johnson";
NORMAL_TRIVIA_ANSWERS2[1501] = "lyndon";
NORMAL_TRIVIA_ANSWERS3[1501] = "johnson";

NORMAL_TRIVIA_QUESTIONS[1502] = "(Sports&Leisure): What running back did Packers' tackle, Henry Jordan, say was invisible when he ran with the ball?";
NORMAL_TRIVIA_ANSWERS1[1502] = "Gale Sayers";
NORMAL_TRIVIA_ANSWERS2[1502] = "sayers";

NORMAL_TRIVIA_QUESTIONS[1503] = "(Sports&Leisure): What golfer was famous for hitching up his pants while making one of his final round charges?";
NORMAL_TRIVIA_ANSWERS1[1503] = "Arnold Palmer";
NORMAL_TRIVIA_ANSWERS2[1503] = "palmer";

NORMAL_TRIVIA_QUESTIONS[1504] = "(Arts&Entertainment): What movie resulted in Arnold Schwarzenegger reportedly receiving a $14 million Gulfstream jet?";
NORMAL_TRIVIA_ANSWERS1[1504] = "Terminator 2: Judgment Day";
NORMAL_TRIVIA_ANSWERS2[1504] = "terminator 2";

NORMAL_TRIVIA_QUESTIONS[1505] = "(World): What 1974 fad had adults dashing through public places naked?";
NORMAL_TRIVIA_ANSWERS1[1505] = "Streaking";

NORMAL_TRIVIA_QUESTIONS[1506] = "(History): What First Lady thought she was doing White House guests a great favor by serving them peanut soup?";
NORMAL_TRIVIA_ANSWERS1[1506] = "Rosalynn Carter";
NORMAL_TRIVIA_ANSWERS2[1506] = "carter";

NORMAL_TRIVIA_QUESTIONS[1507] = "(People&Places): What country saw the Battle of the Bulge's \"battered bastards of Bastogne\" make a stand?";
NORMAL_TRIVIA_ANSWERS1[1507] = "Belgium";

NORMAL_TRIVIA_QUESTIONS[1508] = "(History): Who did Fawn Hall describe as \"every secretary's dream of a boss\"?";
NORMAL_TRIVIA_ANSWERS1[1508] = "Oliver North";

NORMAL_TRIVIA_QUESTIONS[1509] = "(Science&Nature): What would be most likely to rock your spacecraft between Mars and Jupiter?";
NORMAL_TRIVIA_ANSWERS1[1509] = "Asteroids";

NORMAL_TRIVIA_QUESTIONS[1510] = "(Arts&Entertainment): What prop did Will Rogers, the \"cowboy philosopher\", use to rope in audiences at the Ziegfeld Follies?";
NORMAL_TRIVIA_ANSWERS1[1510] = "A lasso";
NORMAL_TRIVIA_ANSWERS2[1510] = "lasso";

NORMAL_TRIVIA_QUESTIONS[1511] = "(Science&Nature): What five-letter word denotes the smallest picture element displayed on a computer screen?";
NORMAL_TRIVIA_ANSWERS1[1511] = "Pixel";

NORMAL_TRIVIA_QUESTIONS[1512] = "(Science&Nature): What was the nationality of the first test tube baby?";
NORMAL_TRIVIA_ANSWERS1[1512] = "British";
NORMAL_TRIVIA_ANSWERS2[1512] = "English";

NORMAL_TRIVIA_QUESTIONS[1513] = "(Sports&Leisure): Who's the only National League manager to win pennants in his first two seasons?";
NORMAL_TRIVIA_ANSWERS1[1513] = "Tommy Lasorda";
NORMAL_TRIVIA_ANSWERS2[1513] = "Lasorda";
NORMAL_TRIVIA_ANSWERS3[1513] = "La sorda";

NORMAL_TRIVIA_QUESTIONS[1514] = "(Science&Nature): How many times greater is the magnitude of a 5.0 earthquake than one of 2.0 on the Richter scale?";
NORMAL_TRIVIA_ANSWERS1[1514] = "1000";
NORMAL_TRIVIA_ANSWERS2[1514] = "thousand";

NORMAL_TRIVIA_QUESTIONS[1515] = "(World): What did Henry Ford offer Model T owners after 1915 sales exceeded projections?";
NORMAL_TRIVIA_ANSWERS1[1515] = "A rebate";
NORMAL_TRIVIA_ANSWERS2[1515] = "rebate";

NORMAL_TRIVIA_QUESTIONS[1516] = "(People&Places): Who was the first U.S. president to take a stroll on the Great Wall of China?";
NORMAL_TRIVIA_ANSWERS1[1516] = "Richard Nixon";
NORMAL_TRIVIA_ANSWERS2[1516] = "nixon";

NORMAL_TRIVIA_QUESTIONS[1517] = "(Sports&Leisure): What pastime was banned in Scotland in 1457 because it took too much time away from archery practice?";
NORMAL_TRIVIA_ANSWERS1[1517] = "Golf";

NORMAL_TRIVIA_QUESTIONS[1518] = "(World): Which Marx brother, caught by his wife with a chorus girl, said: \"I was whispering in her mouth\"?";
NORMAL_TRIVIA_ANSWERS1[1518] = "Chico";

NORMAL_TRIVIA_QUESTIONS[1519] = "(Sports&Leisure): What golfer hyped Hertz rental cars in TV spots?";
NORMAL_TRIVIA_ANSWERS1[1519] = "Arnold Palmer";
NORMAL_TRIVIA_ANSWERS2[1519] = "palmer";

NORMAL_TRIVIA_QUESTIONS[1520] = "(Sports&Leisure): Who starred in five World Series during his tenures with the Oakland A's and the New York Yankees?";
NORMAL_TRIVIA_ANSWERS1[1520] = "Reggie Jackson";
NORMAL_TRIVIA_ANSWERS2[1520] = "jackson";

NORMAL_TRIVIA_QUESTIONS[1521] = "(Sports&Leisure): Who was the first diver to receive perfect scores from all seven judges at an international event?";
NORMAL_TRIVIA_ANSWERS1[1521] = "Greg Louganis";
NORMAL_TRIVIA_ANSWERS2[1521] = "louganis";
NORMAL_TRIVIA_ANSWERS3[1521] = "Luganis";

NORMAL_TRIVIA_QUESTIONS[1522] = "(Sports&Leisure): What quarterback, while serving in Vietnam, threw passes on a makeshift field in Chu Lai?";
NORMAL_TRIVIA_ANSWERS1[1522] = "Roger Staubach";
NORMAL_TRIVIA_ANSWERS2[1522] = "staubach";
NORMAL_TRIVIA_ANSWERS3[1522] = "Staback";

NORMAL_TRIVIA_QUESTIONS[1523] = "(History): What war saw the future Confederate president head a Mississippi regiment in 1846?";
NORMAL_TRIVIA_ANSWERS1[1523] = "The Mexican War";
NORMAL_TRIVIA_ANSWERS2[1523] = "mexican";

NORMAL_TRIVIA_QUESTIONS[1524] = "(Sports&Leisure): What Sega video game machine system shares its name with a band once fronted by Phil Collins?";
NORMAL_TRIVIA_ANSWERS1[1524] = "Genesis";

NORMAL_TRIVIA_QUESTIONS[1525] = "(Science&Nature): How many bolts of lightning strike the U.S. every day - 2,500, 25,000 or 250,000?";
NORMAL_TRIVIA_ANSWERS1[1525] = "250,000";

NORMAL_TRIVIA_QUESTIONS[1526] = "(World): What former U.S. president was issued Medicare Card Number 1 in 1965?";
NORMAL_TRIVIA_ANSWERS1[1526] = "Harry Truman";
NORMAL_TRIVIA_ANSWERS2[1526] = "truman";

NORMAL_TRIVIA_QUESTIONS[1527] = "(Arts&Entertainment): Who got to give Liz Taylor a spanking in \"Father of the Bride\"?";
NORMAL_TRIVIA_ANSWERS1[1527] = "Spencer Tracy";
NORMAL_TRIVIA_ANSWERS2[1527] = "tracy";
NORMAL_TRIVIA_ANSWERS3[1527] = "tracey";

NORMAL_TRIVIA_QUESTIONS[1528] = "(Arts&Entertainment): Who hit No. 1 with a song after her release from a hospital for spinal surgery?";
NORMAL_TRIVIA_ANSWERS1[1528] = "Gloria Gaynor";
NORMAL_TRIVIA_ANSWERS2[1528] = "gaynor";
NORMAL_TRIVIA_ANSWERS3[1528] = "ganor";

NORMAL_TRIVIA_QUESTIONS[1529] = "(World): What did over 20 percent of kids say they'd eat at every meal if they were president?";
NORMAL_TRIVIA_ANSWERS1[1529] = "Ice cream";
NORMAL_TRIVIA_ANSWERS2[1529] = "icecream";

NORMAL_TRIVIA_QUESTIONS[1530] = "(Science&Nature): What's likely to be the only planet visible between Venus and the horizon?";
NORMAL_TRIVIA_ANSWERS1[1530] = "Mercury";

NORMAL_TRIVIA_QUESTIONS[1531] = "(Science&Nature): What U.S. state features an endangered manatee on some license plates?";
NORMAL_TRIVIA_ANSWERS1[1531] = "Florida";

NORMAL_TRIVIA_QUESTIONS[1532] = "(World): What celebratory New Orleans song does a \"Baby Lodie\" diaper play at the first sign of wetness?";
NORMAL_TRIVIA_ANSWERS1[1532] = "When the Saints Go Marching In";

NORMAL_TRIVIA_QUESTIONS[1533] = "(World): What explosive fashion sensation was named for the Pacific atoll where atomic bombs were tested?";
NORMAL_TRIVIA_ANSWERS1[1533] = "The bikini";
NORMAL_TRIVIA_ANSWERS2[1533] = "bikini";

NORMAL_TRIVIA_QUESTIONS[1534] = "(World): What did Pricilla Presley decide to open up to the public to stave off bankruptcy?";
NORMAL_TRIVIA_ANSWERS1[1534] = "Graceland";

NORMAL_TRIVIA_QUESTIONS[1535] = "(Arts&Entertainment): What married woman caused an international scandal while playing Cleopatra in 1962?";
NORMAL_TRIVIA_ANSWERS1[1535] = "Elizabeth Taylor";
NORMAL_TRIVIA_ANSWERS2[1535] = "taylor";

NORMAL_TRIVIA_QUESTIONS[1536] = "(Sports&Leisure): What's the rarest poker hand?";
NORMAL_TRIVIA_ANSWERS1[1536] = "A royal flush";
NORMAL_TRIVIA_ANSWERS2[1536] = "royal flush";

NORMAL_TRIVIA_QUESTIONS[1537] = "(World): What section of Queens did Mr. Whipple aptly film his first toilet paper commercial in?";
NORMAL_TRIVIA_ANSWERS1[1537] = "Flushing";

NORMAL_TRIVIA_QUESTIONS[1538] = "(Sports&Leisure): What movie star had his shooting schedule worked around Los Angeles Lakers home games?";
NORMAL_TRIVIA_ANSWERS1[1538] = "Jack Nicholson";
NORMAL_TRIVIA_ANSWERS2[1538] = "nickelson";
NORMAL_TRIVIA_ANSWERS3[1538] = "nicholson";

NORMAL_TRIVIA_QUESTIONS[1539] = "(World): What 1976 role featuring multiple personalities earned Sally Fields an Emmy?";
NORMAL_TRIVIA_ANSWERS1[1539] = "Sybil";

NORMAL_TRIVIA_QUESTIONS[1540] = "(Sports&Leisure): What sport are you engaged in if you hang five, bomb out and spend the night with a wahine?";
NORMAL_TRIVIA_ANSWERS1[1540] = "Surfing";

NORMAL_TRIVIA_QUESTIONS[1541] = "(Sports&Leisure): Whose all-time career record of 4,191 hits did Pete Rose break on September 11, 1985?";
NORMAL_TRIVIA_ANSWERS1[1541] = "Ty Cobb's";
NORMAL_TRIVIA_ANSWERS2[1541] = "cobbs";
NORMAL_TRIVIA_ANSWERS3[1541] = "cobb";

NORMAL_TRIVIA_QUESTIONS[1542] = "(Sports&Leisure): What NHL team shares its name with a well-known antarctic bird?";
NORMAL_TRIVIA_ANSWERS1[1542] = "The Pittsburgh Penguins";
NORMAL_TRIVIA_ANSWERS2[1542] = "penguin";

NORMAL_TRIVIA_QUESTIONS[1543] = "(History): What academy was a Civil War general superintendent of from 1852 to 1855?";
NORMAL_TRIVIA_ANSWERS1[1543] = "U.S. Military Academy";

NORMAL_TRIVIA_QUESTIONS[1544] = "(History): What US founding father drew and published the first cartoon in an American newspaper?";
NORMAL_TRIVIA_ANSWERS1[1544] = "Benjamin Franklin";
NORMAL_TRIVIA_ANSWERS2[1544] = "franklin";

NORMAL_TRIVIA_QUESTIONS[1545] = "(History): Who became Haiti's first democratically elected leader four years after Jean Claude Duvalier fled?";
NORMAL_TRIVIA_ANSWERS1[1545] = "Jean-Bertrand Aristide";
NORMAL_TRIVIA_ANSWERS2[1545] = "aristide";

NORMAL_TRIVIA_QUESTIONS[1546] = "(World): What budding pop star spiced up her high school cheerleading by wearing flesh-colored panties?";
NORMAL_TRIVIA_ANSWERS1[1546] = "Madonna";

NORMAL_TRIVIA_QUESTIONS[1547] = "(Science&Nature): What did Kim Basinger wear in her 1994 advertisement against wearing animal skin coats?";
NORMAL_TRIVIA_ANSWERS1[1547] = "Nothing";
NORMAL_TRIVIA_ANSWERS2[1547] = "she was nude";
NORMAL_TRIVIA_ANSWERS3[1547] = "she was naked";

NORMAL_TRIVIA_QUESTIONS[1548] = "(Sports&Leisure): What did Americans sip most of by 1976 - coffee, milk or soft drinks?";
NORMAL_TRIVIA_ANSWERS1[1548] = "Soft drinks";

NORMAL_TRIVIA_QUESTIONS[1549] = "(World): What feminist author donned ears and a tail while working in one of this man's clubs in 1964?";
NORMAL_TRIVIA_ANSWERS1[1549] = "Gloria Steinem";
NORMAL_TRIVIA_ANSWERS2[1549] = "steinam";
NORMAL_TRIVIA_ANSWERS3[1549] = "steinem";

NORMAL_TRIVIA_QUESTIONS[1550] = "(History): What British monarch and her consort both share the same great-great-grandmother?";
NORMAL_TRIVIA_ANSWERS1[1550] = "Queen Elizabeth and Prince Philip";
NORMAL_TRIVIA_ANSWERS2[1550] = "Elizabeth and Philip";
NORMAL_TRIVIA_ANSWERS3[1550] = "Elizabeth and Phillip";

NORMAL_TRIVIA_QUESTIONS[1551] = "(Sports&Leisure): Who was the first golfer to amass $1 million in official earnings?";
NORMAL_TRIVIA_ANSWERS1[1551] = "Arnold Palmer";
NORMAL_TRIVIA_ANSWERS2[1551] = "palmer";

NORMAL_TRIVIA_QUESTIONS[1552] = "(World): What \"Saturday Night Live\" star portrayed Ross Perot in skits in 1992?";
NORMAL_TRIVIA_ANSWERS1[1552] = "Dana Carvey";
NORMAL_TRIVIA_ANSWERS2[1552] = "carvey";

NORMAL_TRIVIA_QUESTIONS[1553] = "(History): What did a lone Chinese demonstrator do right after standing in front of a tank in Tiennamen Square?";
NORMAL_TRIVIA_ANSWERS1[1553] = "He climbed on top of it";
NORMAL_TRIVIA_ANSWERS2[1553] = "climbed on it";
NORMAL_TRIVIA_ANSWERS3[1553] = "climbed on top";

NORMAL_TRIVIA_QUESTIONS[1554] = "(Arts&Entertainment): What Lewis Carroll work offers this bit of whimsy: \"All mimsy were the borogoves, and the mome raths outgrabe\"?";
NORMAL_TRIVIA_ANSWERS1[1554] = "Alice's Adventures in Wonderland";
NORMAL_TRIVIA_ANSWERS2[1554] = "Alice in wonderland";

NORMAL_TRIVIA_QUESTIONS[1555] = "(Sports&Leisure): What tennis great wielded an obsolete wooden racket in a failed 1991 comeback attempt?";
NORMAL_TRIVIA_ANSWERS1[1555] = "Bjorn Borg";
NORMAL_TRIVIA_ANSWERS2[1555] = "bjorn";
NORMAL_TRIVIA_ANSWERS3[1555] = "borg";

NORMAL_TRIVIA_QUESTIONS[1556] = "(Science&Nature): What phenomena's emissions are called \"Hawking radiation\" in honor of this physicist?";
NORMAL_TRIVIA_ANSWERS1[1556] = "A black hole's";
NORMAL_TRIVIA_ANSWERS2[1556] = "black holes";
NORMAL_TRIVIA_ANSWERS3[1556] = "black hole";

NORMAL_TRIVIA_QUESTIONS[1557] = "(Science&Nature): What French sex symbol made the killing of baby harp seals a worldwide cause celebre?";
NORMAL_TRIVIA_ANSWERS1[1557] = "Brigitte Bardot";
NORMAL_TRIVIA_ANSWERS2[1557] = "bardot";

NORMAL_TRIVIA_QUESTIONS[1558] = "(People&Places): What was banned in France, prompting 3'11\" Manuel Wackenheim to sue the Interior Ministry?";
NORMAL_TRIVIA_ANSWERS1[1558] = "Dwarf tossing";

NORMAL_TRIVIA_QUESTIONS[1559] = "(World): What TV show's headliner hit the White House to promote statehood for Moosylvania?";
NORMAL_TRIVIA_ANSWERS1[1559] = "The Bullwinkle Show's";
NORMAL_TRIVIA_ANSWERS2[1559] = "bullwinkle";

NORMAL_TRIVIA_QUESTIONS[1560] = "(Sports&Leisure): What first baseman played a major league record 2,130 consecutive games?";
NORMAL_TRIVIA_ANSWERS1[1560] = "Lou Gehrig";
NORMAL_TRIVIA_ANSWERS2[1560] = "gehrig";
NORMAL_TRIVIA_ANSWERS3[1560] = "garig";

NORMAL_TRIVIA_QUESTIONS[1561] = "(Arts&Entertainment): What did Liberace adorn his piano with?";
NORMAL_TRIVIA_ANSWERS1[1561] = "A candelabra";
NORMAL_TRIVIA_ANSWERS2[1561] = "candelabra";

NORMAL_TRIVIA_QUESTIONS[1562] = "(World): What feline sent out the most autographed 8-by-10 glossies during the early 1970s?";
NORMAL_TRIVIA_ANSWERS1[1562] = "Morris the Cat";
NORMAL_TRIVIA_ANSWERS2[1562] = "Morris";

NORMAL_TRIVIA_QUESTIONS[1563] = "(Arts&Entertainment): Who ya gonna call?";
NORMAL_TRIVIA_ANSWERS1[1563] = "Ghostbusters";

NORMAL_TRIVIA_QUESTIONS[1564] = "(Sports&Leisure): How many of every 10 baseball players who sign pro contracts never play in a major league game?";
NORMAL_TRIVIA_ANSWERS1[1564] = "Nine";
NORMAL_TRIVIA_ANSWERS2[1564] = "9";

NORMAL_TRIVIA_QUESTIONS[1565] = "(World): What movie saw Dustin Hoffman win an Oscar for playing an autistic savant?";
NORMAL_TRIVIA_ANSWERS1[1565] = "Rain Man";
NORMAL_TRIVIA_ANSWERS2[1565] = "rainman";

NORMAL_TRIVIA_QUESTIONS[1566] = "(History): What tragic event did Herb Morrison describe in very emotionally in a live radio broadcast?";
NORMAL_TRIVIA_ANSWERS1[1566] = "The Hindenburg disaster";
NORMAL_TRIVIA_ANSWERS2[1566] = "hindenburg";
NORMAL_TRIVIA_ANSWERS3[1566] = "hindenberg";

NORMAL_TRIVIA_QUESTIONS[1567] = "(History): Who did Italian porn star Illona Staller offer to have sex with if he'd free foreigners, in 1990?";
NORMAL_TRIVIA_ANSWERS1[1567] = "Saddam Hussein";
NORMAL_TRIVIA_ANSWERS2[1567] = "saddam";
NORMAL_TRIVIA_ANSWERS3[1567] = "hussein";

NORMAL_TRIVIA_QUESTIONS[1568] = "(Science&Nature): Which of the big, jungle cats is the only cat to be social rather than solitary?";
NORMAL_TRIVIA_ANSWERS1[1568] = "The lion";
NORMAL_TRIVIA_ANSWERS2[1568] = "lion";

NORMAL_TRIVIA_QUESTIONS[1569] = "(People&Places): What Olympic city boasts an ornate church designed by Antonio Gaudi?";
NORMAL_TRIVIA_ANSWERS1[1569] = "Barcelona";

NORMAL_TRIVIA_QUESTIONS[1570] = "(History): What three-word phrase was most frequently scribbled as graffiti during World War II?";
NORMAL_TRIVIA_ANSWERS1[1570] = "Kilroy was here";

NORMAL_TRIVIA_QUESTIONS[1571] = "(Sports&Leisure): What team has failed to win a World Series since selling Babe Ruth to the New York Yankees in 1920?";
NORMAL_TRIVIA_ANSWERS1[1571] = "The Boston Red Sox";
NORMAL_TRIVIA_ANSWERS2[1571] = "red sox";

NORMAL_TRIVIA_QUESTIONS[1572] = "(People&Places): What collection of architectural marvels is The Great Pyramid the only modern survivor of?";
NORMAL_TRIVIA_ANSWERS1[1572] = "The Seven Wonders of the World";
NORMAL_TRIVIA_ANSWERS2[1572] = "7 wonders of the world";
NORMAL_TRIVIA_ANSWERS3[1572] = "7 wonders of the ancient world";

NORMAL_TRIVIA_QUESTIONS[1573] = "(Science&Nature): What type of nucleic acid carries hereditary information from generation to generation?";
NORMAL_TRIVIA_ANSWERS1[1573] = "DNA";
NORMAL_TRIVIA_ANSWERS2[1573] = "Deoxyribonucleic acid";
NORMAL_TRIVIA_ANSWERS3[1573] = "DNA ";

NORMAL_TRIVIA_QUESTIONS[1574] = "(Arts&Entertainment): Where did Peter, Paul and Mary say the answer is in a 1962 song?";
NORMAL_TRIVIA_ANSWERS1[1574] = "Blowin' in the wind";
NORMAL_TRIVIA_ANSWERS2[1574] = "blowing in the wind";

NORMAL_TRIVIA_QUESTIONS[1575] = "(Sports&Leisure): Who were the combatants in a 1993 prize fight rudely interrupted by parachuter James \"Fanman\" Miller?";
NORMAL_TRIVIA_ANSWERS1[1575] = "Riddick Bowe and Evander Holyfield";
NORMAL_TRIVIA_ANSWERS2[1575] = "bowe and holyfield";
NORMAL_TRIVIA_ANSWERS3[1575] = "riddick and evander";

NORMAL_TRIVIA_QUESTIONS[1576] = "(Science&Nature): What's the parallel halfway between the equator and the North Pole?";
NORMAL_TRIVIA_ANSWERS1[1576] = "The forty-fifth";
NORMAL_TRIVIA_ANSWERS2[1576] = "45th";

NORMAL_TRIVIA_QUESTIONS[1577] = "(People&Places): What's the Statue of Liberty's formal name?";
NORMAL_TRIVIA_ANSWERS1[1577] = "Liberty Enlightening the World";

NORMAL_TRIVIA_QUESTIONS[1578] = "(World): What milkshake-machine salesman began franchising a popular, fast-food empire in 1955?";
NORMAL_TRIVIA_ANSWERS1[1578] = "Ray Kroc";
NORMAL_TRIVIA_ANSWERS2[1578] = "kroc";

NORMAL_TRIVIA_QUESTIONS[1579] = "(Science&Nature): What gives manatees indelible scars by which they're identified and tracked?";
NORMAL_TRIVIA_ANSWERS1[1579] = "Boat propellers";
NORMAL_TRIVIA_ANSWERS2[1579] = "propellers";

NORMAL_TRIVIA_QUESTIONS[1580] = "(Sports&Leisure): What coating insulates the ice cream in a Baked Alaska from an oven's heat?";
NORMAL_TRIVIA_ANSWERS1[1580] = "meringue";
NORMAL_TRIVIA_ANSWERS2[1580] = "merang";
NORMAL_TRIVIA_ANSWERS3[1580] = "meraing";

NORMAL_TRIVIA_QUESTIONS[1581] = "(Arts&Entertainment): What action star was set to play the Axel Foley role in \"Beverly Hills Cop\" but was tagged as too violent?";
NORMAL_TRIVIA_ANSWERS1[1581] = "Sylvester Stallone";
NORMAL_TRIVIA_ANSWERS2[1581] = "stallone";

NORMAL_TRIVIA_QUESTIONS[1582] = "(Science&Nature): What star is 93 million miles from this planet?";
NORMAL_TRIVIA_ANSWERS1[1582] = "The sun";
NORMAL_TRIVIA_ANSWERS2[1582] = "our sun";
NORMAL_TRIVIA_ANSWERS3[1582] = "sun";

NORMAL_TRIVIA_QUESTIONS[1583] = "(People&Places): What London landmark houses the crown jewels?";
NORMAL_TRIVIA_ANSWERS1[1583] = "The Tower of London";
NORMAL_TRIVIA_ANSWERS2[1583] = "tower of london";
NORMAL_TRIVIA_ANSWERS3[1583] = "tower";

NORMAL_TRIVIA_QUESTIONS[1584] = "(History): How many tons did a coal miner, helped by veterans, load his first day, as an initiation?";
NORMAL_TRIVIA_ANSWERS1[1584] = "Sixteen";
NORMAL_TRIVIA_ANSWERS2[1584] = "16";

NORMAL_TRIVIA_QUESTIONS[1585] = "(World): What's Vanna White's favorite vowel?";
NORMAL_TRIVIA_ANSWERS1[1585] = "E";

NORMAL_TRIVIA_QUESTIONS[1586] = "(History): What U.S. Civil War general got the middle name \"Simpson\" through a West Point clerical error?";
NORMAL_TRIVIA_ANSWERS1[1586] = "Ulysses S. Grant";
NORMAL_TRIVIA_ANSWERS2[1586] = "grant";

NORMAL_TRIVIA_QUESTIONS[1587] = "(People&Places): What capital city's McDonald's became the world's largest eatery, at 40,000 customers a day?";
NORMAL_TRIVIA_ANSWERS1[1587] = "Moscow's";
NORMAL_TRIVIA_ANSWERS2[1587] = "moscow";

NORMAL_TRIVIA_QUESTIONS[1588] = "(Sports&Leisure): Who broke Yogi Berra's career home run record for a catcher?";
NORMAL_TRIVIA_ANSWERS1[1588] = "Johnny Bench";
NORMAL_TRIVIA_ANSWERS2[1588] = "bench";

NORMAL_TRIVIA_QUESTIONS[1589] = "(Science&Nature): What naturalist spent five years aboard the \"Beagle\"?";
NORMAL_TRIVIA_ANSWERS1[1589] = "Charles Darwin";
NORMAL_TRIVIA_ANSWERS2[1589] = "darwin";

NORMAL_TRIVIA_QUESTIONS[1590] = "(Science&Nature): Which US coin tests out at 97.5 percent zinc?";
NORMAL_TRIVIA_ANSWERS1[1590] = "The penny";
NORMAL_TRIVIA_ANSWERS2[1590] = "one cent";
NORMAL_TRIVIA_ANSWERS3[1590] = "penny";

NORMAL_TRIVIA_QUESTIONS[1591] = "(World): Who sent out \"breakers\" from the White House during the 1970s under the CB handle \"First Mama\"?";
NORMAL_TRIVIA_ANSWERS1[1591] = "Betty Ford";

NORMAL_TRIVIA_QUESTIONS[1592] = "(World): What word did Teenage Mutant Ninja Turtles use often that was first heard on the \"Howdy Doody\" show?";
NORMAL_TRIVIA_ANSWERS1[1592] = "Cowabunga";

NORMAL_TRIVIA_QUESTIONS[1593] = "(Sports&Leisure): Which of Chicago Bears running back, Gayle Sayers' roommates was the subject of a TV movie?";
NORMAL_TRIVIA_ANSWERS1[1593] = "Brian Piccolo";
NORMAL_TRIVIA_ANSWERS2[1593] = "piccolo";
NORMAL_TRIVIA_ANSWERS3[1593] = "picolo";

NORMAL_TRIVIA_QUESTIONS[1594] = "(History): Which president wore dresses until the age of five and kilts until age eight?";
NORMAL_TRIVIA_ANSWERS1[1594] = "Franklin D. Roosevelt";
NORMAL_TRIVIA_ANSWERS2[1594] = "FDR";
NORMAL_TRIVIA_ANSWERS3[1594] = "Franklin Roosevelt";

NORMAL_TRIVIA_QUESTIONS[1595] = "(Arts&Entertainment): o'keeffe//What artist said that if she could \"paint a flower in a huge scale, you could not ignore its beauty\"?";
NORMAL_TRIVIA_ANSWERS1[1595] = "Georgia O'Keeffe";

NORMAL_TRIVIA_QUESTIONS[1596] = "(World): What is more popular name of the symphonic instrument, a \"cor anglais\"?";
NORMAL_TRIVIA_ANSWERS1[1596] = "A French horn";
NORMAL_TRIVIA_ANSWERS2[1596] = "french horn";

NORMAL_TRIVIA_QUESTIONS[1597] = "(People&Places): What country has the most pay telephones per capita?";
NORMAL_TRIVIA_ANSWERS1[1597] = "Canada";

NORMAL_TRIVIA_QUESTIONS[1598] = "(People&Places): Which U.S. city attracted the most immigrants in the 1980s?";
NORMAL_TRIVIA_ANSWERS1[1598] = "Los Angeles";

NORMAL_TRIVIA_QUESTIONS[1599] = "(World): What alien language can you immerse yourself in at a camp in Red Lake Falls, Minnesota for $350 a week?";
NORMAL_TRIVIA_ANSWERS1[1599] = "Klingon";

NORMAL_TRIVIA_QUESTIONS[1600] = "(Arts&Entertainment): What prop from the movie \"Basic Instinct\" fetched $4,125 at a 1993 auction?";
NORMAL_TRIVIA_ANSWERS1[1600] = "The ice pick";
NORMAL_TRIVIA_ANSWERS2[1600] = "ice pick";
NORMAL_TRIVIA_ANSWERS3[1600] = "icepick";

NORMAL_TRIVIA_QUESTIONS[1601] = "(Arts&Entertainment): What 1976 chart-topping song did Barry Manilow sing but not write?";
NORMAL_TRIVIA_ANSWERS1[1601] = "I Write the Songs";

NORMAL_TRIVIA_QUESTIONS[1602] = "(Sports&Leisure): What playing card is also called the \"suicide king\"?";
NORMAL_TRIVIA_ANSWERS1[1602] = "The king of hearts";
NORMAL_TRIVIA_ANSWERS2[1602] = "king of hearts";

NORMAL_TRIVIA_QUESTIONS[1603] = "(Arts&Entertainment): What Bonnie Tyler hit, with an astronomical event in it's title, spent a month atop the charts in 1983?";
NORMAL_TRIVIA_ANSWERS1[1603] = "Total Eclipse of the Heart";

NORMAL_TRIVIA_QUESTIONS[1604] = "(Sports&Leisure): What ESPN star coined the nicknames Bert \"Be Home\" Blyleven and Walt \"Three Blind\" Weiss?";
NORMAL_TRIVIA_ANSWERS1[1604] = "Chris Berman";
NORMAL_TRIVIA_ANSWERS2[1604] = "berman";

NORMAL_TRIVIA_QUESTIONS[1605] = "(Science&Nature): What pain reliever did Miles Laboratories unleash on the world in 1931?";
NORMAL_TRIVIA_ANSWERS1[1605] = "Alka-Seltzer";
NORMAL_TRIVIA_ANSWERS2[1605] = "alka seltzer";

NORMAL_TRIVIA_QUESTIONS[1606] = "(World): What future USA general's dyslexia forced him to repeat his first year at West Point?";
NORMAL_TRIVIA_ANSWERS1[1606] = "George Patton's";
NORMAL_TRIVIA_ANSWERS2[1606] = "patton";

NORMAL_TRIVIA_QUESTIONS[1607] = "(Sports&Leisure): Who ran the four fastest 100 meter races in women's track history over a two-day period in 1988?";
NORMAL_TRIVIA_ANSWERS1[1607] = "Florence Griffith-Joyner";
NORMAL_TRIVIA_ANSWERS2[1607] = "Griffith Joyner";
NORMAL_TRIVIA_ANSWERS3[1607] = "griffith-joyner";

NORMAL_TRIVIA_QUESTIONS[1608] = "(World): What former steamboat pilot got his pen name from river lingo meaning 12 feet in depth?";
NORMAL_TRIVIA_ANSWERS1[1608] = "Mark Twain";
NORMAL_TRIVIA_ANSWERS2[1608] = "twain";
NORMAL_TRIVIA_ANSWERS3[1608] = "samuel clemens";

NORMAL_TRIVIA_QUESTIONS[1609] = "(History): What U.S. military decoration was first established in 1782 and revived in 1932?";
NORMAL_TRIVIA_ANSWERS1[1609] = "The Purple Heart";
NORMAL_TRIVIA_ANSWERS2[1609] = "purple heart";

NORMAL_TRIVIA_QUESTIONS[1610] = "(People&Places): What country was Australian actor Mel Gibson born in?";
NORMAL_TRIVIA_ANSWERS1[1610] = "The U.S.";
NORMAL_TRIVIA_ANSWERS2[1610] = "USA";
NORMAL_TRIVIA_ANSWERS3[1610] = "America";

NORMAL_TRIVIA_QUESTIONS[1611] = "(History): What, according to Shakespeare, were Julius Caesar's last three words?";
NORMAL_TRIVIA_ANSWERS1[1611] = "Et tu, Brute?";
NORMAL_TRIVIA_ANSWERS2[1611] = "et tu brute";
NORMAL_TRIVIA_ANSWERS3[1611] = "et tu brutus";

NORMAL_TRIVIA_QUESTIONS[1612] = "(World): What 1982 movie theme song by Survivor had an endangered cat species in its title? ";
NORMAL_TRIVIA_ANSWERS1[1612] = "Eye of the Tiger";

NORMAL_TRIVIA_QUESTIONS[1613] = "(History): What marauding sea captain was honored by his king by being knighted aboard his own ship, the \"Golden Hind\"?";
NORMAL_TRIVIA_ANSWERS1[1613] = "Sir Francis Drake";
NORMAL_TRIVIA_ANSWERS2[1613] = "drake";

NORMAL_TRIVIA_QUESTIONS[1614] = "(Science&Nature): What substance is the largest single preventable cause of death?";
NORMAL_TRIVIA_ANSWERS1[1614] = "Tobacco";

NORMAL_TRIVIA_QUESTIONS[1615] = "(Sports&Leisure): How many copies of the 1856 British Guiana stamp are known to exist?";
NORMAL_TRIVIA_ANSWERS1[1615] = "One";
NORMAL_TRIVIA_ANSWERS2[1615] = "1";

NORMAL_TRIVIA_QUESTIONS[1616] = "(Sports&Leisure): What country has won the most World Cup soccer titles?";
NORMAL_TRIVIA_ANSWERS1[1616] = "Brazil";

NORMAL_TRIVIA_QUESTIONS[1617] = "(Arts&Entertainment): Who was the philosophical bartender played by Whoopi Goldberg on \"Star Trek: The Next Generation\"?";
NORMAL_TRIVIA_ANSWERS1[1617] = "Guinan";
NORMAL_TRIVIA_ANSWERS2[1617] = "guynan";

NORMAL_TRIVIA_QUESTIONS[1618] = "(World): What's the subtitle of the traditional American song \"I've Been Working On The Railroad\"? ";
NORMAL_TRIVIA_ANSWERS1[1618] = "Someone's in the Kitchen with Dinah";

NORMAL_TRIVIA_QUESTIONS[1619] = "(History): What fabled German phrase, when attempted by one of America's presidents, translated into \"I am a jelly-filled doughnut\"?";
NORMAL_TRIVIA_ANSWERS1[1619] = "Ich bin ein Berliner";

NORMAL_TRIVIA_QUESTIONS[1620] = "(Science&Nature): What movie had Michael Keaton playing a character named after a huge star in the constellation of Orion?";
NORMAL_TRIVIA_ANSWERS1[1620] = "Beetlejuice";
NORMAL_TRIVIA_ANSWERS2[1620] = "Betelguese";

NORMAL_TRIVIA_QUESTIONS[1621] = "(People&Places): What was Manhattan's tallest building before the Empire State Building was erected?";
NORMAL_TRIVIA_ANSWERS1[1621] = "The Chrysler Building";
NORMAL_TRIVIA_ANSWERS2[1621] = "chrysler";

NORMAL_TRIVIA_QUESTIONS[1622] = "(People&Places): What 60 storey building was completed in 1913 and remained the world's tallest buiding for 17 years? ";
NORMAL_TRIVIA_ANSWERS1[1622] = "The Woolworth Building";
NORMAL_TRIVIA_ANSWERS2[1622] = "woolworth";

NORMAL_TRIVIA_QUESTIONS[1623] = "(History): What form of ancient writing was finally deciphered with the help of a chunk of basalt known as the Rosetta Stone?";
NORMAL_TRIVIA_ANSWERS1[1623] = "Hieroglyphics";
NORMAL_TRIVIA_ANSWERS2[1623] = "hirogliphics";
NORMAL_TRIVIA_ANSWERS3[1623] = "hiroglyphics";

NORMAL_TRIVIA_QUESTIONS[1624] = "(History): What four-word moniker (nickname) did General Patton earn while commanding the Second Armored Division in 1940?";
NORMAL_TRIVIA_ANSWERS1[1624] = "Old Blood and Guts";
NORMAL_TRIVIA_ANSWERS2[1624] = "ol blood n guts";
NORMAL_TRIVIA_ANSWERS3[1624] = "old blood & guts";

NORMAL_TRIVIA_QUESTIONS[1625] = "(World): What 1958 fad, according to \"Pravda,\" summed up the \"emptiness of American culture\"?";
NORMAL_TRIVIA_ANSWERS1[1625] = "The hula hoop";
NORMAL_TRIVIA_ANSWERS2[1625] = "hula hoop";

NORMAL_TRIVIA_QUESTIONS[1626] = "(Arts&Entertainment): How many kids did the sitcom mom have to deal with on \"The Brady Bunch\"?";
NORMAL_TRIVIA_ANSWERS1[1626] = "Six";
NORMAL_TRIVIA_ANSWERS2[1626] = "6";

NORMAL_TRIVIA_QUESTIONS[1627] = "(Sports&Leisure): How many gold medals did swimmer Mark Spitz win at the 1972 Olympics?";
NORMAL_TRIVIA_ANSWERS1[1627] = "Seven";
NORMAL_TRIVIA_ANSWERS2[1627] = "7";

NORMAL_TRIVIA_QUESTIONS[1628] = "(World): What city was the first to be terrorized by Godzilla's radioactive bad breath?";
NORMAL_TRIVIA_ANSWERS1[1628] = "Tokyo";

NORMAL_TRIVIA_QUESTIONS[1629] = "(Sports&Leisure): Who was the first quarterback the Miami Dolphins ever chose with a first-round draft choice?";
NORMAL_TRIVIA_ANSWERS1[1629] = "Dan Marino";
NORMAL_TRIVIA_ANSWERS2[1629] = "marino";

NORMAL_TRIVIA_QUESTIONS[1630] = "(People&Places): What U.S. coastal monument's internal structure was designed by Gustave Eiffel?";
NORMAL_TRIVIA_ANSWERS1[1630] = "The Statue of Liberty's";
NORMAL_TRIVIA_ANSWERS2[1630] = "statue of liberty";

NORMAL_TRIVIA_QUESTIONS[1631] = "(World): Which well-known Irish actor was booted out of 15 grade schools during his rebellious youth?";
NORMAL_TRIVIA_ANSWERS1[1631] = "Spencer Tracy";
NORMAL_TRIVIA_ANSWERS2[1631] = "tracy";

NORMAL_TRIVIA_QUESTIONS[1632] = "(World): Who told David Frost: \"When the president does it, that means that it is not illegal\"?";
NORMAL_TRIVIA_ANSWERS1[1632] = "Richard Nixon";
NORMAL_TRIVIA_ANSWERS2[1632] = "nixon";

NORMAL_TRIVIA_QUESTIONS[1633] = "(Sports&Leisure): What Baltimore Orioles pitcher never gave up a grand slam home run in his 3,948 career innings?";
NORMAL_TRIVIA_ANSWERS1[1633] = "Jim Palmer";
NORMAL_TRIVIA_ANSWERS2[1633] = "palmer";

NORMAL_TRIVIA_QUESTIONS[1634] = "(Arts&Entertainment): Who conducted Mozart's memorial service in Vienna?";
NORMAL_TRIVIA_ANSWERS1[1634] = "Antonio Salieri";
NORMAL_TRIVIA_ANSWERS2[1634] = "salieri";
NORMAL_TRIVIA_ANSWERS3[1634] = "saleri";

NORMAL_TRIVIA_QUESTIONS[1635] = "(People&Places): What country was the British monarch empress of from 1876 until 1901?";
NORMAL_TRIVIA_ANSWERS1[1635] = "India";

NORMAL_TRIVIA_QUESTIONS[1636] = "(Science&Nature): What Culture Club hit song featured a member of the lizard family in it's refrain?";
NORMAL_TRIVIA_ANSWERS1[1636] = "Karma Chameleon";

NORMAL_TRIVIA_QUESTIONS[1637] = "(Arts&Entertainment): What movie prompted \"Premiere\" to put a man on it's cover with the line \"In Your Face\"?";
NORMAL_TRIVIA_ANSWERS1[1637] = "The Man Without a Face";

NORMAL_TRIVIA_QUESTIONS[1638] = "(History): What Wall Streeter paid fellow prison inmates to do his laundry?";
NORMAL_TRIVIA_ANSWERS1[1638] = "Ivan Boesky";
NORMAL_TRIVIA_ANSWERS2[1638] = "boesky";

NORMAL_TRIVIA_QUESTIONS[1639] = "(World): What Ray Charles catch phrase appeared on Pepsi cans in 1990?";
NORMAL_TRIVIA_ANSWERS1[1639] = "Uh huh!";
NORMAL_TRIVIA_ANSWERS2[1639] = "uh huh";

NORMAL_TRIVIA_QUESTIONS[1640] = "(Science&Nature): What Washington state mountain blew its top in 1980, killing 61 people?";
NORMAL_TRIVIA_ANSWERS1[1640] = "Mount St. Helens";
NORMAL_TRIVIA_ANSWERS2[1640] = "mt st helens";
NORMAL_TRIVIA_ANSWERS3[1640] = "st. helens";

NORMAL_TRIVIA_QUESTIONS[1641] = "(People&Places): What western hemisphere event in October 1962 prompted John F. Kennedy to deliver a grave warning to the Soviet Union?";
NORMAL_TRIVIA_ANSWERS1[1641] = "The Cuban Missile Crisis";
NORMAL_TRIVIA_ANSWERS2[1641] = "cuban missile";

NORMAL_TRIVIA_QUESTIONS[1642] = "(Arts&Entertainment): How long should a well-known but short Chopin waltz last if it's popular title is taken literally?";
NORMAL_TRIVIA_ANSWERS1[1642] = "One minute";
NORMAL_TRIVIA_ANSWERS2[1642] = "1 minute";

NORMAL_TRIVIA_QUESTIONS[1643] = "(World): What cookie does Nabisco estimate it has made more than 345 billion of since 1912? ";
NORMAL_TRIVIA_ANSWERS1[1643] = "Oreo Cookies";
NORMAL_TRIVIA_ANSWERS2[1643] = "oreo";

NORMAL_TRIVIA_QUESTIONS[1644] = "(World): Which Clinton admitted his fantasy was \"to make love in the front yard of the White House\"?";
NORMAL_TRIVIA_ANSWERS1[1644] = "Roger Clinton";
NORMAL_TRIVIA_ANSWERS2[1644] = "roger";

NORMAL_TRIVIA_QUESTIONS[1645] = "(People&Places): What onetime Tennessee congressman bit the dust at the Alamo?";
NORMAL_TRIVIA_ANSWERS1[1645] = "Davy Crockett";
NORMAL_TRIVIA_ANSWERS2[1645] = "crockett";
NORMAL_TRIVIA_ANSWERS3[1645] = "crokett";

NORMAL_TRIVIA_QUESTIONS[1646] = "(Sports&Leisure): Who played hoops with Godzilla in a Nike ad?";
NORMAL_TRIVIA_ANSWERS1[1646] = "Charles Barkley";
NORMAL_TRIVIA_ANSWERS2[1646] = "barkley";

NORMAL_TRIVIA_QUESTIONS[1647] = "(Arts&Entertainment): What character did Dan Aykroyd portray in the movie \"Trading Places\"?";
NORMAL_TRIVIA_ANSWERS1[1647] = "Louis Winthorpe III";
NORMAL_TRIVIA_ANSWERS2[1647] = "winthorpe";

NORMAL_TRIVIA_QUESTIONS[1648] = "(Sports&Leisure): Who's the only golfer to play in U.S. Open tournaments in five different decades?";
NORMAL_TRIVIA_ANSWERS1[1648] = "Arnold Palmer";
NORMAL_TRIVIA_ANSWERS2[1648] = "palmer";

NORMAL_TRIVIA_QUESTIONS[1649] = "(Arts&Entertainment): What 1985 movie did Oprah Winfrey play a large role in, despite having no acting experience?";
NORMAL_TRIVIA_ANSWERS1[1649] = "The Color Purple";
NORMAL_TRIVIA_ANSWERS2[1649] = "color purple";

NORMAL_TRIVIA_QUESTIONS[1650] = "(Arts&Entertainment): Who rode a motorcycle to John Belushi's funeral?";
NORMAL_TRIVIA_ANSWERS1[1650] = "Dan Aykroyd";
NORMAL_TRIVIA_ANSWERS2[1650] = "aykroyd";
NORMAL_TRIVIA_ANSWERS3[1650] = "ackroyd";

NORMAL_TRIVIA_QUESTIONS[1651] = "(Science&Nature): What purification process is derived from scientist, Louis Pasteur's name?";
NORMAL_TRIVIA_ANSWERS1[1651] = "Pasteurization";

NORMAL_TRIVIA_QUESTIONS[1652] = "(History): What war saw General Douglas MacArthur command United Nations forces?";
NORMAL_TRIVIA_ANSWERS1[1652] = "The Korean War";
NORMAL_TRIVIA_ANSWERS2[1652] = "korean";

NORMAL_TRIVIA_QUESTIONS[1653] = "(People&Places): Which loquacious Latin leader gave the longest speech in United Nations history?";
NORMAL_TRIVIA_ANSWERS1[1653] = "Fidel Castro";
NORMAL_TRIVIA_ANSWERS2[1653] = "castro";

NORMAL_TRIVIA_QUESTIONS[1654] = "(Sports&Leisure): What record, single-season, home run total did Roger Maris establish in 1961?";
NORMAL_TRIVIA_ANSWERS1[1654] = "Sixty-one";
NORMAL_TRIVIA_ANSWERS2[1654] = "61";

NORMAL_TRIVIA_QUESTIONS[1655] = "(World): Who refused to shake Jesse Owen's hand after he won a gold medal at the 1936 Olympics?";
NORMAL_TRIVIA_ANSWERS1[1655] = "Adolf Hitler";
NORMAL_TRIVIA_ANSWERS2[1655] = "hitler";

NORMAL_TRIVIA_QUESTIONS[1656] = "(People&Places): What region in France must wine come from to be considered true champagne?";
NORMAL_TRIVIA_ANSWERS1[1656] = "Champagne";

NORMAL_TRIVIA_QUESTIONS[1657] = "(World): Who's the female love interest in the tune, \"Bicycle Built For Two?";
NORMAL_TRIVIA_ANSWERS1[1657] = "Daisy";

NORMAL_TRIVIA_QUESTIONS[1658] = "(Sports&Leisure): What track star's numerous endorsements inspired advertising honchos to nickname her \"Cash Flo\"?";
NORMAL_TRIVIA_ANSWERS1[1658] = "Florence Griffith Joyner's";
NORMAL_TRIVIA_ANSWERS2[1658] = "griffith";
NORMAL_TRIVIA_ANSWERS3[1658] = "joyner";

NORMAL_TRIVIA_QUESTIONS[1659] = "(Arts&Entertainment): What screen character discovered a novel new use for a banana in the 1984 movie, \"Beverly Hills Cop\"?";
NORMAL_TRIVIA_ANSWERS1[1659] = "Axel Foley";

NORMAL_TRIVIA_QUESTIONS[1660] = "(Arts&Entertainment): What musical instrument helped win Jane Campion an Oscar for best original screenplay in 1994?";
NORMAL_TRIVIA_ANSWERS1[1660] = "The piano";
NORMAL_TRIVIA_ANSWERS2[1660] = "piano";

NORMAL_TRIVIA_QUESTIONS[1661] = "(History): Whose voice did Al Gore not recognize when she phoned him on \"Larry King Live\"?";
NORMAL_TRIVIA_ANSWERS1[1661] = "Tipper Gore's";
NORMAL_TRIVIA_ANSWERS2[1661] = "tipper";
NORMAL_TRIVIA_ANSWERS3[1661] = "wife's";

NORMAL_TRIVIA_QUESTIONS[1662] = "(Arts&Entertainment): What beloved TV sitcom star played a plainclothes nun in the movie, \"Change of Habit\"?";
NORMAL_TRIVIA_ANSWERS1[1662] = "Mary Tyler Moore";
NORMAL_TRIVIA_ANSWERS2[1662] = "moore";

NORMAL_TRIVIA_QUESTIONS[1663] = "(World): What 19th-century cartoonist assigned the elephant and the donkey to U.S. political parties?";
NORMAL_TRIVIA_ANSWERS1[1663] = "Thomas Nast";
NORMAL_TRIVIA_ANSWERS2[1663] = "nast";

NORMAL_TRIVIA_QUESTIONS[1664] = "(History): What native of Braunau, Upper Austria, marched through the Arc de Triomphe in 1940?";
NORMAL_TRIVIA_ANSWERS1[1664] = "Adolf Hitler";
NORMAL_TRIVIA_ANSWERS2[1664] = "hitler";

NORMAL_TRIVIA_QUESTIONS[1665] = "(World): What warbler's marriage on \"The Johnny Carson Show\" had more viewers than any previous late-night event?";
NORMAL_TRIVIA_ANSWERS1[1665] = "Tiny Tim's";
NORMAL_TRIVIA_ANSWERS2[1665] = "tiny tim";

NORMAL_TRIVIA_QUESTIONS[1666] = "(People&Places): At what Phillipine island was a very famous picture of U.S. Marines raising a USA flag taken in World War II?";
NORMAL_TRIVIA_ANSWERS1[1666] = "Iwo Jima";

NORMAL_TRIVIA_QUESTIONS[1667] = "(Arts&Entertainment): What 3-D Walt Disney World short movie attraction did Francis Coppola direct?";
NORMAL_TRIVIA_ANSWERS1[1667] = "Captain EO";

NORMAL_TRIVIA_QUESTIONS[1668] = "(History): Whose final resting place did Boris Yeltsin yank the honor guard from in 1993?";
NORMAL_TRIVIA_ANSWERS1[1668] = "V.I. Lenin's";
NORMAL_TRIVIA_ANSWERS2[1668] = "lenin";

NORMAL_TRIVIA_QUESTIONS[1669] = "(History): What country did Hitler's troops invade, kicking off World War II?";
NORMAL_TRIVIA_ANSWERS1[1669] = "Poland";

NORMAL_TRIVIA_QUESTIONS[1670] = "(Sports&Leisure): What president got stuck in a gondola lift for 45 minutes during a ski trip to Vail, Colorado?";
NORMAL_TRIVIA_ANSWERS1[1670] = "Gerald Ford";
NORMAL_TRIVIA_ANSWERS2[1670] = "ford";

NORMAL_TRIVIA_QUESTIONS[1671] = "(Sports&Leisure): What model stepped out of the \"Sports Illustrated\" swimsuit issue to pose nude for \"Playboy\" in '94?";
NORMAL_TRIVIA_ANSWERS1[1671] = "Elle Macpherson";
NORMAL_TRIVIA_ANSWERS2[1671] = "macpherson";
NORMAL_TRIVIA_ANSWERS3[1671] = "mcpherson";

NORMAL_TRIVIA_QUESTIONS[1672] = "(People&Places): What country was tabbed to reclaim a certain prime piece of Oriental real estate in 1997 after a British lease was up?";
NORMAL_TRIVIA_ANSWERS1[1672] = "China";

NORMAL_TRIVIA_QUESTIONS[1673] = "(World): What famous rock star proposed to a model while nibbling on a tuna sandwich in a state park?";
NORMAL_TRIVIA_ANSWERS1[1673] = "Rod Stewart";
NORMAL_TRIVIA_ANSWERS2[1673] = "stewart";

NORMAL_TRIVIA_QUESTIONS[1674] = "(History): What general announced in 1968 that the Viet Cong were \"about to run out of steam\"?";
NORMAL_TRIVIA_ANSWERS1[1674] = "William Westmoreland";
NORMAL_TRIVIA_ANSWERS2[1674] = "westmorland";
NORMAL_TRIVIA_ANSWERS3[1674] = "westmoreland";

NORMAL_TRIVIA_QUESTIONS[1675] = "(History): Whose death elicited Vietnam's terse statement: \"May he rest in peace\"?";
NORMAL_TRIVIA_ANSWERS1[1675] = "Richard Nixon's";
NORMAL_TRIVIA_ANSWERS2[1675] = "nixon";

NORMAL_TRIVIA_QUESTIONS[1676] = "(Sports&Leisure): What sports move did a well-known, former TV talk show host conclude his opening monologues with?";
NORMAL_TRIVIA_ANSWERS1[1676] = "A golf swing";
NORMAL_TRIVIA_ANSWERS2[1676] = "golf swing";

NORMAL_TRIVIA_QUESTIONS[1677] = "(Sports&Leisure): What NFL coach warned: \"If you aren't 'fired' with enthusiasm, you will be fired with enthusiasm\"?";
NORMAL_TRIVIA_ANSWERS1[1677] = "Vince Lombardi";
NORMAL_TRIVIA_ANSWERS2[1677] = "lombardi";

NORMAL_TRIVIA_QUESTIONS[1678] = "(Sports&Leisure): What hurler said of Earl Weaver: \"The only thing he knows about pitching is that he couldn't hit it\"?";
NORMAL_TRIVIA_ANSWERS1[1678] = "Jim Palmer";
NORMAL_TRIVIA_ANSWERS2[1678] = "palmer";

NORMAL_TRIVIA_QUESTIONS[1679] = "(World): What TV host announced Smokey Robinson and the Miracles as \"Smokey and the Little Smokies\"?";
NORMAL_TRIVIA_ANSWERS1[1679] = "Ed Sullivan";
NORMAL_TRIVIA_ANSWERS2[1679] = "sullivan";

NORMAL_TRIVIA_QUESTIONS[1680] = "(Arts&Entertainment): What original 'Not Ready for Prime Time Player' portrayed US president Gerald Ford in skits?";
NORMAL_TRIVIA_ANSWERS1[1680] = "Chevy Chase";
NORMAL_TRIVIA_ANSWERS2[1680] = "chase";
NORMAL_TRIVIA_ANSWERS3[1680] = "chevy";

NORMAL_TRIVIA_QUESTIONS[1681] = "(Sports&Leisure): What decathlete competed despite a stress fracture of the right fibula at the 1992 U.S. Olympic trials?";
NORMAL_TRIVIA_ANSWERS1[1681] = "Dan O'Brien";
NORMAL_TRIVIA_ANSWERS2[1681] = "o'brien";
NORMAL_TRIVIA_ANSWERS3[1681] = "o'brian";

NORMAL_TRIVIA_QUESTIONS[1682] = "(Science&Nature): What bothers someone with pogonophobia?";
NORMAL_TRIVIA_ANSWERS1[1682] = "a beard";
NORMAL_TRIVIA_ANSWERS2[1682] = "beard";

NORMAL_TRIVIA_QUESTIONS[1683] = "(People&Places): Who was the first Democrat elected president without carrying Texas?";
NORMAL_TRIVIA_ANSWERS1[1683] = "Bill Clinton";
NORMAL_TRIVIA_ANSWERS2[1683] = "clinton";

NORMAL_TRIVIA_QUESTIONS[1684] = "(World): What Republican president scratched the ears of a dog named Ranger?";
NORMAL_TRIVIA_ANSWERS1[1684] = "George Bush";
NORMAL_TRIVIA_ANSWERS2[1684] = "bush";

NORMAL_TRIVIA_QUESTIONS[1685] = "(Sports&Leisure): What grand slam golf tournament did Arnold Palmer win in 1958, '60, '62 and '64?";
NORMAL_TRIVIA_ANSWERS1[1685] = "The Masters";
NORMAL_TRIVIA_ANSWERS2[1685] = "masters";

NORMAL_TRIVIA_QUESTIONS[1686] = "(Sports&Leisure): Who was given a red Corvette with a special license plate when he set a major league baseball record?";
NORMAL_TRIVIA_ANSWERS1[1686] = "Pete Rose";
NORMAL_TRIVIA_ANSWERS2[1686] = "rose";

NORMAL_TRIVIA_QUESTIONS[1687] = "(Arts&Entertainment): What were the names of the two different animals that, as a child star, Roddy McDowell play opposite in 1943 movies?";
NORMAL_TRIVIA_ANSWERS1[1687] = "Lassie and Flicka";
NORMAL_TRIVIA_ANSWERS2[1687] = "Lassie";
NORMAL_TRIVIA_ANSWERS3[1687] = "Flicka";

NORMAL_TRIVIA_QUESTIONS[1688] = "(Arts&Entertainment): Who went double platinum by warbling \"Vaya Con Dios\" and \"Indian Love Call\" in TV ads?";
NORMAL_TRIVIA_ANSWERS1[1688] = "Slim Whitman";
NORMAL_TRIVIA_ANSWERS2[1688] = "whitman";

NORMAL_TRIVIA_QUESTIONS[1689] = "(Science&Nature): What rapid-firing gun did the Union army turn down in 1862?";
NORMAL_TRIVIA_ANSWERS1[1689] = "The Gatling gun";
NORMAL_TRIVIA_ANSWERS2[1689] = "gattling";
NORMAL_TRIVIA_ANSWERS3[1689] = "gatling";

NORMAL_TRIVIA_QUESTIONS[1690] = "(Science&Nature): Which of these Florida cities boasts the largest average consumption of prunes:  Miami, Bradenton, or Tallahassee?";
NORMAL_TRIVIA_ANSWERS1[1690] = "Miami";

NORMAL_TRIVIA_QUESTIONS[1691] = "(Sports&Leisure): Who donned size 11 gloves when he wasn't using his giant paws to handle a basketball for the 76ers?";
NORMAL_TRIVIA_ANSWERS1[1691] = "Julius Erving";
NORMAL_TRIVIA_ANSWERS2[1691] = "Dr. J";

NORMAL_TRIVIA_QUESTIONS[1692] = "(Sports&Leisure): Who became the third pro basketballer to score 30,000 points in his career?";
NORMAL_TRIVIA_ANSWERS1[1692] = "Julius Erving";
NORMAL_TRIVIA_ANSWERS2[1692] = "erving";
NORMAL_TRIVIA_ANSWERS3[1692] = "Dr. J";

NORMAL_TRIVIA_QUESTIONS[1693] = "(History): Who did Lloyd Bentsen tell in 1988: \"I knew Jack Kennedy.... You're no Jack Kennedy\"?";
NORMAL_TRIVIA_ANSWERS1[1693] = "Dan Quayle";
NORMAL_TRIVIA_ANSWERS2[1693] = "quayle";

NORMAL_TRIVIA_QUESTIONS[1694] = "(History): What couple were executed for espionage in 1953 despite pleas from Albert Einstein and the Pope, among others?";
NORMAL_TRIVIA_ANSWERS1[1694] = "Julius and Ethel Rosenberg";
NORMAL_TRIVIA_ANSWERS2[1694] = "Rosenberg";

NORMAL_TRIVIA_QUESTIONS[1695] = "(Science&Nature): What do American parents of infants dump 17 billion of each year?";
NORMAL_TRIVIA_ANSWERS1[1695] = "Disposable diapers";

NORMAL_TRIVIA_QUESTIONS[1696] = "(Sports&Leisure): What New York Yankees great once was timed running from home to first in a record 2.9 seconds?";
NORMAL_TRIVIA_ANSWERS1[1696] = "Mickey Mantle";
NORMAL_TRIVIA_ANSWERS2[1696] = "mantle";

NORMAL_TRIVIA_QUESTIONS[1697] = "(World): What 1989 film earned Dan Aykroyd an Oscar nomination as best supporting actor?";
NORMAL_TRIVIA_ANSWERS1[1697] = "Driving Miss Daisy";

NORMAL_TRIVIA_QUESTIONS[1698] = "(Sports&Leisure): What coach gave mink stoles to the wives of his players after winning his first NFL title in 1961?";
NORMAL_TRIVIA_ANSWERS1[1698] = "Vince Lombardi";
NORMAL_TRIVIA_ANSWERS2[1698] = "lombardi";

NORMAL_TRIVIA_QUESTIONS[1699] = "(Arts&Entertainment): Which of Madonna's videos drew a stern condemnation from the Vatican in 1989?";
NORMAL_TRIVIA_ANSWERS1[1699] = "Like a Prayer";

NORMAL_TRIVIA_QUESTIONS[1700] = "(People&Places): What state's license plates began saying 'Famous Potatoes' in 1957?";
NORMAL_TRIVIA_ANSWERS1[1700] = "Idaho's";
NORMAL_TRIVIA_ANSWERS2[1700] = "idaho";

NORMAL_TRIVIA_QUESTIONS[1701] = "(Science&Nature): What's an organism made from the genetic material of another commonly called?";
NORMAL_TRIVIA_ANSWERS1[1701] = "A clone";
NORMAL_TRIVIA_ANSWERS2[1701] = "clone";

NORMAL_TRIVIA_QUESTIONS[1702] = "(People&Places): What Egyptian leader was Gerald Ford meeting when he made a 'graceful exit' from Air Force One?  :o)";
NORMAL_TRIVIA_ANSWERS1[1702] = "Anwar Sadat";
NORMAL_TRIVIA_ANSWERS2[1702] = "Sadat";

NORMAL_TRIVIA_QUESTIONS[1703] = "(World): What mega-selling book took Robert James Waller two weeks to write?";
NORMAL_TRIVIA_ANSWERS1[1703] = "The Bridges of Madison County";

NORMAL_TRIVIA_QUESTIONS[1704] = "(People&Places): What tropical U.S. state has chosen the yellow hibiscus as it's state flower?";
NORMAL_TRIVIA_ANSWERS1[1704] = "Hawaii";

NORMAL_TRIVIA_QUESTIONS[1705] = "(People&Places): What country boasts a maple leaf as its national symbol?";
NORMAL_TRIVIA_ANSWERS1[1705] = "Canada";

NORMAL_TRIVIA_QUESTIONS[1706] = "(People&Places): What Los Angeles landmark did Sam Rodia build from steel, broken glass, sea shells and found objects?";
NORMAL_TRIVIA_ANSWERS1[1706] = "The Watts Towers";
NORMAL_TRIVIA_ANSWERS2[1706] = "watts tower";

NORMAL_TRIVIA_QUESTIONS[1707] = "(Science&Nature): What accident prompted U.S. utility outfits to cancel orders for 11 nuclear reactors by 1980?";
NORMAL_TRIVIA_ANSWERS1[1707] = "Three Mile Island";
NORMAL_TRIVIA_ANSWERS2[1707] = "3 mile island";

NORMAL_TRIVIA_QUESTIONS[1708] = "(World): What park's tourists are in danger of having their picnic baskets picked by Yogi Bear?";
NORMAL_TRIVIA_ANSWERS1[1708] = "Jellystone Park's";
NORMAL_TRIVIA_ANSWERS2[1708] = "jellystone";

NORMAL_TRIVIA_QUESTIONS[1709] = "(Arts&Entertainment): Who'd starred in seven of the top 25 highest grossing movies in history by 1994?";
NORMAL_TRIVIA_ANSWERS1[1709] = "Harrison Ford";
NORMAL_TRIVIA_ANSWERS2[1709] = "harrison";
NORMAL_TRIVIA_ANSWERS3[1709] = "ford";

NORMAL_TRIVIA_QUESTIONS[1710] = "(World): What physicist is given a \"special thanks\" for his synthesized vocals on Pink Floyd's \"Keep Talking\"?";
NORMAL_TRIVIA_ANSWERS1[1710] = "Stephen Hawking";
NORMAL_TRIVIA_ANSWERS2[1710] = "hawking";

NORMAL_TRIVIA_QUESTIONS[1711] = "(Arts&Entertainment): What movie did Spencer Tracy complete filming a matter of weeks before he died?";
NORMAL_TRIVIA_ANSWERS1[1711] = "Guess Who's Coming to Dinner";

NORMAL_TRIVIA_QUESTIONS[1712] = "(World): What hosiery product was \"hatched\" in 1970 using an innovative packaging concept?";
NORMAL_TRIVIA_ANSWERS1[1712] = "L'eggs pantyhose";
NORMAL_TRIVIA_ANSWERS2[1712] = "l'eggs";

NORMAL_TRIVIA_QUESTIONS[1713] = "(People&Places): What physicist declined the presidency or a country saying he had no head for human problems?";
NORMAL_TRIVIA_ANSWERS1[1713] = "Albert Einstein";
NORMAL_TRIVIA_ANSWERS2[1713] = "einstein";

NORMAL_TRIVIA_QUESTIONS[1714] = "(Science&Nature): What part of the Venus Fly-trap plant is adapted to make an insect trap - the flower, leaf, stem or root?";
NORMAL_TRIVIA_ANSWERS1[1714] = "The leaf";
NORMAL_TRIVIA_ANSWERS2[1714] = "leaf";

NORMAL_TRIVIA_QUESTIONS[1715] = "(World): What three-word moniker did Elvis call \"the most childish expression I've ever heard\"?";
NORMAL_TRIVIA_ANSWERS1[1715] = "Elvis the Pelvis";

NORMAL_TRIVIA_QUESTIONS[1716] = "(History): Which council in the United Nations organization recommends appointees to the position of secretary general?";
NORMAL_TRIVIA_ANSWERS1[1716] = "The Security Council";
NORMAL_TRIVIA_ANSWERS2[1716] = "security";

NORMAL_TRIVIA_QUESTIONS[1717] = "(People&Places): What European country contains Transylvania, commonly considered to be the home of \"Count Dracula\"?";
NORMAL_TRIVIA_ANSWERS1[1717] = "Romania";

NORMAL_TRIVIA_QUESTIONS[1718] = "(Science&Nature): What company dominated the microprocessor field by the 1980s?";
NORMAL_TRIVIA_ANSWERS1[1718] = "Intel";

NORMAL_TRIVIA_QUESTIONS[1719] = "(Science&Nature): How many bones does a shark have?";
NORMAL_TRIVIA_ANSWERS1[1719] = "Zero";
NORMAL_TRIVIA_ANSWERS2[1719] = "None";
NORMAL_TRIVIA_ANSWERS3[1719] = "0";

NORMAL_TRIVIA_QUESTIONS[1720] = "(Arts&Entertainment): Who uttered zingers from the center square of the \"Hollywood Squares\" for 12 years?";
NORMAL_TRIVIA_ANSWERS1[1720] = "Paul Lynde";
NORMAL_TRIVIA_ANSWERS2[1720] = "lynde";

NORMAL_TRIVIA_QUESTIONS[1721] = "(History): What did the U.S. Post Office use as a symbol before adopting the bald eagle in 1970?";
NORMAL_TRIVIA_ANSWERS1[1721] = "A pony express rider";
NORMAL_TRIVIA_ANSWERS2[1721] = "pony express";

NORMAL_TRIVIA_QUESTIONS[1722] = "(Sports&Leisure): What did a well-known Dodgers' coach take to lose 40 pounds to win a bet with two of his players?";
NORMAL_TRIVIA_ANSWERS1[1722] = "Ultra Slim-Fast";
NORMAL_TRIVIA_ANSWERS2[1722] = "slim fast";
NORMAL_TRIVIA_ANSWERS3[1722] = "slimfast";

NORMAL_TRIVIA_QUESTIONS[1723] = "(History): According to one general, what was 'the first war ever fought without any censorship'?";
NORMAL_TRIVIA_ANSWERS1[1723] = "The Vietnam War";
NORMAL_TRIVIA_ANSWERS2[1723] = "vietnam";

NORMAL_TRIVIA_QUESTIONS[1724] = "(Arts&Entertainment): What eight-minute, 36-second hit by Don McLean did WABC call the most-played song of 1971?";
NORMAL_TRIVIA_ANSWERS1[1724] = "American Pie";

NORMAL_TRIVIA_QUESTIONS[1725] = "(Arts&Entertainment): What hit song helped the 1986 movie, \"Top Gun\", starring Tom Cruise soar?";
NORMAL_TRIVIA_ANSWERS1[1725] = "Take My Breath Away";

NORMAL_TRIVIA_QUESTIONS[1726] = "(Science&Nature): What does the male Emperor Penguine balance atop his feet for two months while its mate feeds?";
NORMAL_TRIVIA_ANSWERS1[1726] = "An egg";
NORMAL_TRIVIA_ANSWERS2[1726] = "egg";

NORMAL_TRIVIA_QUESTIONS[1727] = "(Science&Nature): What tracking device was the Stealth bomber designed to evade?";
NORMAL_TRIVIA_ANSWERS1[1727] = "Radar";

NORMAL_TRIVIA_QUESTIONS[1728] = "(World): What two-word phrase did a famous tuna receive repeatedly from Star-Kist fishermen?";
NORMAL_TRIVIA_ANSWERS1[1728] = "\"Sorry, Charlie\"";
NORMAL_TRIVIA_ANSWERS2[1728] = "sorry charlie";

NORMAL_TRIVIA_QUESTIONS[1729] = "(Science&Nature): What Frenchman developed a vaccine to combat rabies in 1885?";
NORMAL_TRIVIA_ANSWERS1[1729] = "Louis Pasteur";
NORMAL_TRIVIA_ANSWERS2[1729] = "pasteur";

NORMAL_TRIVIA_QUESTIONS[1730] = "(People&Places): What stands atop an 11-pointed fort in New York Harbor?";
NORMAL_TRIVIA_ANSWERS1[1730] = "The Statue of Liberty";
NORMAL_TRIVIA_ANSWERS2[1730] = "statue of liberty";

NORMAL_TRIVIA_QUESTIONS[1731] = "(Science&Nature): What nation's beachgoers have been munched on most by great white sharks?";
NORMAL_TRIVIA_ANSWERS1[1731] = "Australia's";
NORMAL_TRIVIA_ANSWERS2[1731] = "australia";

NORMAL_TRIVIA_QUESTIONS[1732] = "(Arts&Entertainment): What four-word line ended nine classic \"Honeymooners\" episodes?";
NORMAL_TRIVIA_ANSWERS1[1732] = "\"Baby, you're the greatest\"";
NORMAL_TRIVIA_ANSWERS2[1732] = "baby you're the greatest";

NORMAL_TRIVIA_QUESTIONS[1733] = "(Arts&Entertainment): Who's the most popular novelist putting vampires on the best-seller list?";
NORMAL_TRIVIA_ANSWERS1[1733] = "Anne Rice";
NORMAL_TRIVIA_ANSWERS2[1733] = "rice";

NORMAL_TRIVIA_QUESTIONS[1734] = "(People&Places): What malady made Napoleon uncomfortable in the saddle during the Battle of Waterloo?";
NORMAL_TRIVIA_ANSWERS1[1734] = "Hemorrhoids";
NORMAL_TRIVIA_ANSWERS2[1734] = "hemeroids";
NORMAL_TRIVIA_ANSWERS3[1734] = "hemaroids";

NORMAL_TRIVIA_QUESTIONS[1735] = "(History): Who found his crown to be a perfect fit when he was invested on July 1, 1969?";
NORMAL_TRIVIA_ANSWERS1[1735] = "Prince Charles";
NORMAL_TRIVIA_ANSWERS2[1735] = "charles";

NORMAL_TRIVIA_QUESTIONS[1736] = "(World): Whose verdict on her affair was: \"Honey, a dirt sandwich is better than Dwight Yoakam\"?";
NORMAL_TRIVIA_ANSWERS1[1736] = "Sharon Stone's";
NORMAL_TRIVIA_ANSWERS2[1736] = "stone";

NORMAL_TRIVIA_QUESTIONS[1737] = "(Science&Nature): What's the heaviest naturally-occurring element?";
NORMAL_TRIVIA_ANSWERS1[1737] = "Uranium";

NORMAL_TRIVIA_QUESTIONS[1738] = "(Science&Nature): Which of the 9 planets in our solar system is blue and white when seen from outer space?";
NORMAL_TRIVIA_ANSWERS1[1738] = "Earth";

NORMAL_TRIVIA_QUESTIONS[1739] = "(Arts&Entertainment): What is James Whistler's painting, \"Arrangement in Gray and Black\", best known as?";
NORMAL_TRIVIA_ANSWERS1[1739] = "Whistler's Mother";

NORMAL_TRIVIA_QUESTIONS[1740] = "(Arts&Entertainment): What 1986 movie earned Spike Lee his first taste of critical acclaim?";
NORMAL_TRIVIA_ANSWERS1[1740] = "She's Gotta Have It";
NORMAL_TRIVIA_ANSWERS2[1740] = "shes gotta have it";

NORMAL_TRIVIA_QUESTIONS[1741] = "(People&Places): Who raised $25 million on the Australian Stock Exchange to finance the film \"Lightning Jack\"?";
NORMAL_TRIVIA_ANSWERS1[1741] = "Paul Hogan";
NORMAL_TRIVIA_ANSWERS2[1741] = "hogan";

NORMAL_TRIVIA_QUESTIONS[1742] = "(Arts&Entertainment): What poet immortalized a famous silversmith's midnight ride to warn that the British were coming?";
NORMAL_TRIVIA_ANSWERS1[1742] = "Henry Wadsworth Longfellow";
NORMAL_TRIVIA_ANSWERS2[1742] = "longfellow";

NORMAL_TRIVIA_QUESTIONS[1743] = "(People&Places): Who was the first to take off solo in New York and land in Paris?";
NORMAL_TRIVIA_ANSWERS1[1743] = "Charles Lindbergh";
NORMAL_TRIVIA_ANSWERS2[1743] = "lindbergh";
NORMAL_TRIVIA_ANSWERS3[1743] = "lindberg";

NORMAL_TRIVIA_QUESTIONS[1744] = "(Arts&Entertainment): What expense-checker did this \"Twin Peaks\" agent intone messages to via a microcassette recorder?";
NORMAL_TRIVIA_ANSWERS1[1744] = "Diane";

NORMAL_TRIVIA_QUESTIONS[1745] = "(Arts&Entertainment): Who planted people in the audience to boo at the premiere of a Mozart opera?";
NORMAL_TRIVIA_ANSWERS1[1745] = "Antonio Salieri";
NORMAL_TRIVIA_ANSWERS2[1745] = "salieri";

NORMAL_TRIVIA_QUESTIONS[1746] = "(Arts&Entertainment): Who earned critical acclaim in 1980 for her suggestive ride on a mechanical bull?";
NORMAL_TRIVIA_ANSWERS1[1746] = "Debra Winger";
NORMAL_TRIVIA_ANSWERS2[1746] = "winger";

NORMAL_TRIVIA_QUESTIONS[1747] = "(Science&Nature): What did Plennie Wingo add to his glasses before walking backward from San Francisco to Santa Monica?";
NORMAL_TRIVIA_ANSWERS1[1747] = "Rearview mirrors";

NORMAL_TRIVIA_QUESTIONS[1748] = "(Science&Nature): What fabric is opposed by radical animal-rights activists because the host creature is boiled alive?";
NORMAL_TRIVIA_ANSWERS1[1748] = "Silk";

NORMAL_TRIVIA_QUESTIONS[1749] = "(Sports&Leisure): What two-word question did Nancy Kerrigan repeat after she got whacked in the knee?";
NORMAL_TRIVIA_ANSWERS1[1749] = "Why me?";
NORMAL_TRIVIA_ANSWERS2[1749] = "why me";

NORMAL_TRIVIA_QUESTIONS[1750] = "(Science&Nature): How many buffalo/bison roamed North America in 1492 - 600,000, 6 million or 60 million?";
NORMAL_TRIVIA_ANSWERS1[1750] = "60 million";
NORMAL_TRIVIA_ANSWERS2[1750] = "Sixty million";
NORMAL_TRIVIA_ANSWERS3[1750] = "60,000,000";

NORMAL_TRIVIA_QUESTIONS[1751] = "(History): Name 2 of the 4 U.S. presidents, other than Lincoln or Kennedy, that were assassinated while in office?";
NORMAL_TRIVIA_ANSWERS1[1751] = "James Garfield and William McKinley";
NORMAL_TRIVIA_ANSWERS2[1751] = "garfield and McKinley";
NORMAL_TRIVIA_ANSWERS3[1751] = "mckinley and garfield";

NORMAL_TRIVIA_QUESTIONS[1752] = "(People&Places): What did Russian hardliner Vladimir \"Mad Vlad\" Zhirinovsky threaten to take back from the U.S.?";
NORMAL_TRIVIA_ANSWERS1[1752] = "Alaska";

NORMAL_TRIVIA_QUESTIONS[1753] = "(People&Places): What screen lover's death inspired a 1926 mob scene outside a Manhattan funeral chapel?";
NORMAL_TRIVIA_ANSWERS1[1753] = "Rudolph Valentino's";
NORMAL_TRIVIA_ANSWERS2[1753] = "valentino";

NORMAL_TRIVIA_QUESTIONS[1754] = "(Science&Nature): Whose flight into space earned him some rib-crunching Russian bear hugs?";
NORMAL_TRIVIA_ANSWERS1[1754] = "Yuri Gagarin's";
NORMAL_TRIVIA_ANSWERS2[1754] = "gagarin";

NORMAL_TRIVIA_QUESTIONS[1755] = "(Arts&Entertainment): Who uttered the question: \"King Tut, how'd you get so funky? King Tut, did you do the Monkey?\"?";
NORMAL_TRIVIA_ANSWERS1[1755] = "Steve Martin";
NORMAL_TRIVIA_ANSWERS2[1755] = "martin";

NORMAL_TRIVIA_QUESTIONS[1756] = "(Science&Nature): What name did the first atomic submarine share with Robert Fulton's 1800 version?";
NORMAL_TRIVIA_ANSWERS1[1756] = "Nautilus";

NORMAL_TRIVIA_QUESTIONS[1757] = "(People&Places): What's the current term for a great oak log, burned at the festival of Thor?\"";
NORMAL_TRIVIA_ANSWERS1[1757] = "Yule log";

NORMAL_TRIVIA_QUESTIONS[1758] = "(Science&Nature): What's the name of the  \"self-sustaining\" edifice, home to eight men and women for two years?";
NORMAL_TRIVIA_ANSWERS1[1758] = "The Biosphere";
NORMAL_TRIVIA_ANSWERS2[1758] = "biosphere";

NORMAL_TRIVIA_QUESTIONS[1759] = "(People&Places): What memorial sparked controversy when unveiled by architect and sculptor Maya Lin?";
NORMAL_TRIVIA_ANSWERS1[1759] = "The Vietnam Veterans Memorial";
NORMAL_TRIVIA_ANSWERS2[1759] = "vietnam vet";

NORMAL_TRIVIA_QUESTIONS[1760] = "(People&Places): What Caribbean country still had jerry-rigged U.S. jeeps on its streets in the 1990s?";
NORMAL_TRIVIA_ANSWERS1[1760] = "Cuba";

NORMAL_TRIVIA_QUESTIONS[1761] = "(Arts&Entertainment): What fellow artist did Van Gogh threaten with a razor before taking a swipe at himself?";
NORMAL_TRIVIA_ANSWERS1[1761] = "Paul Gauguin";
NORMAL_TRIVIA_ANSWERS2[1761] = "Gauguin";

NORMAL_TRIVIA_QUESTIONS[1762] = "(History): Who changed his name from Vernon Wayne Howell for \"publicity and business purposes\"?";
NORMAL_TRIVIA_ANSWERS1[1762] = "David Koresh";
NORMAL_TRIVIA_ANSWERS2[1762] = "Koresh";

NORMAL_TRIVIA_QUESTIONS[1763] = "(People&Places): What city would you visit to see the contents of King Tut's tomb?";
NORMAL_TRIVIA_ANSWERS1[1763] = "Cairo";

NORMAL_TRIVIA_QUESTIONS[1764] = "(History): What's the most commonly used slang term to describe helicopters?";
NORMAL_TRIVIA_ANSWERS1[1764] = "Choppers";
NORMAL_TRIVIA_ANSWERS2[1764] = "chopper";

NORMAL_TRIVIA_QUESTIONS[1765] = "(World): What literary character tilted at windmills, mistaking them for giants?";
NORMAL_TRIVIA_ANSWERS1[1765] = "Don Quixote";
NORMAL_TRIVIA_ANSWERS2[1765] = "Quixote";

NORMAL_TRIVIA_QUESTIONS[1766] = "(Sports&Leisure): Who was the first man in 56 years to win both springboard and platform diving at the Olympics?";
NORMAL_TRIVIA_ANSWERS1[1766] = "Greg Louganis";
NORMAL_TRIVIA_ANSWERS2[1766] = "Louganis";

NORMAL_TRIVIA_QUESTIONS[1767] = "(Science&Nature): What independent movie studio shares it's name with a constellation? ";
NORMAL_TRIVIA_ANSWERS1[1767] = "Orion";

NORMAL_TRIVIA_QUESTIONS[1768] = "(World): In what movie Eddie Murphy insist his character's name be changed from Willie Biggs to Reggie Hammond?";
NORMAL_TRIVIA_ANSWERS1[1768] = "48 Hrs.";
NORMAL_TRIVIA_ANSWERS2[1768] = "48 Hours";

NORMAL_TRIVIA_QUESTIONS[1769] = "(Arts&Entertainment): Who was the second black star to be in a film grossing over $100 million?";
NORMAL_TRIVIA_ANSWERS1[1769] = "Whoopi Goldberg";
NORMAL_TRIVIA_ANSWERS2[1769] = "Goldberg";
NORMAL_TRIVIA_ANSWERS3[1769] = "Whoopi";

NORMAL_TRIVIA_QUESTIONS[1770] = "(Arts&Entertainment): Name one No.1 Michael Jackson hit this is a three-letter word beginning with the letter \"B\"";
NORMAL_TRIVIA_ANSWERS1[1770] = "'Ben' or 'Bad'";
NORMAL_TRIVIA_ANSWERS2[1770] = "Ben";
NORMAL_TRIVIA_ANSWERS3[1770] = "Bad";

NORMAL_TRIVIA_QUESTIONS[1771] = "(Sports&Leisure): What bowling pin is known as the widow?";
NORMAL_TRIVIA_ANSWERS1[1771] = "The ten pin";
NORMAL_TRIVIA_ANSWERS2[1771] = "10 pin";
NORMAL_TRIVIA_ANSWERS3[1771] = "tenpin";

NORMAL_TRIVIA_QUESTIONS[1772] = "(Sports&Leisure): How many thousand cows are needed to supply the NFL with enough footballs for a season?";
NORMAL_TRIVIA_ANSWERS1[1772] = "Three";
NORMAL_TRIVIA_ANSWERS2[1772] = "3";
NORMAL_TRIVIA_ANSWERS3[1772] = "3,000";

NORMAL_TRIVIA_QUESTIONS[1773] = "(People&Places): What was the only U.S. state in 1992 to lose more citizens to handguns than to car crashes?";
NORMAL_TRIVIA_ANSWERS1[1773] = "Texas";

NORMAL_TRIVIA_QUESTIONS[1774] = "(World): What Victor Hugo novel does \"The Simpsons\" pay tribute to by giving prisoners the number 24601?";
NORMAL_TRIVIA_ANSWERS1[1774] = "Les Miserables";
NORMAL_TRIVIA_ANSWERS2[1774] = "Miserables";

NORMAL_TRIVIA_QUESTIONS[1775] = "(World): What kind of tails did a gang of aborigines freeze, use to attack three police officers, and then eat?";
NORMAL_TRIVIA_ANSWERS1[1775] = "Kangaroo tails";
NORMAL_TRIVIA_ANSWERS2[1775] = "Kangaroo";

NORMAL_TRIVIA_QUESTIONS[1776] = "(History): What did Donald Trump rename the yacht \"Nabila\" that he bought for $29 million in 1987?";
NORMAL_TRIVIA_ANSWERS1[1776] = "The Trump Princess";
NORMAL_TRIVIA_ANSWERS2[1776] = "princess";

NORMAL_TRIVIA_QUESTIONS[1777] = "(Sports&Leisure): What Cincinnati Reds catcher could hold seven baseballs in his giant paw?";
NORMAL_TRIVIA_ANSWERS1[1777] = "Johnny Bench";
NORMAL_TRIVIA_ANSWERS2[1777] = "Bench";

NORMAL_TRIVIA_QUESTIONS[1778] = "(Science&Nature): What did Steven Hawking say could be formed by something other than the collapse of a star?";
NORMAL_TRIVIA_ANSWERS1[1778] = "Black holes";
NORMAL_TRIVIA_ANSWERS2[1778] = "black hole";

NORMAL_TRIVIA_QUESTIONS[1779] = "(Arts&Entertainment): What's the most famous five-word phrase uttered by Clint Eastwood in the movie \"Sudden Impact\"?";
NORMAL_TRIVIA_ANSWERS1[1779] = "Go ahead, make my day";
NORMAL_TRIVIA_ANSWERS2[1779] = "make my day";
NORMAL_TRIVIA_ANSWERS3[1779] = "go ahead";

NORMAL_TRIVIA_QUESTIONS[1780] = "(History): Who became South Dakota's first Democratic senator in 26 years by a margin of 597 votes in 1962?";
NORMAL_TRIVIA_ANSWERS1[1780] = "George McGovern";
NORMAL_TRIVIA_ANSWERS2[1780] = "McGovern";

NORMAL_TRIVIA_QUESTIONS[1781] = "(World): What hit saw the U.S. Navy bill moviemakers $1.1 million for \"technical services\"?";
NORMAL_TRIVIA_ANSWERS1[1781] = "Top Gun";
NORMAL_TRIVIA_ANSWERS2[1781] = "TopGun";

NORMAL_TRIVIA_QUESTIONS[1782] = "(Science&Nature): Who was the first president to wear false teeth?";
NORMAL_TRIVIA_ANSWERS1[1782] = "George Washington";
NORMAL_TRIVIA_ANSWERS2[1782] = "Washington";

NORMAL_TRIVIA_QUESTIONS[1783] = "(People&Places): What department store chain established it's headquarters in the Sears Tower?";
NORMAL_TRIVIA_ANSWERS1[1783] = "Sears, Roebuck and Co.";
NORMAL_TRIVIA_ANSWERS2[1783] = "Sears";

NORMAL_TRIVIA_QUESTIONS[1784] = "(Arts&Entertainment): What black star noted: \"I'm funny without drugs. I don't have to sniff cocaine to be funny\"?";
NORMAL_TRIVIA_ANSWERS1[1784] = "Eddie Murphy";
NORMAL_TRIVIA_ANSWERS2[1784] = "Murphy";

NORMAL_TRIVIA_QUESTIONS[1785] = "(Sports&Leisure): What player donned a Baltimore Orioles uniform for a major league record of 23 years?";
NORMAL_TRIVIA_ANSWERS1[1785] = "Brooks Robinson";
NORMAL_TRIVIA_ANSWERS2[1785] = "Robinson";
NORMAL_TRIVIA_ANSWERS3[1785] = "Robinsen";

NORMAL_TRIVIA_QUESTIONS[1786] = "(Sports&Leisure): What Olympic ice racer took a victory lap with a U.S. flag in one hand and his daughter Jane in the other?";
NORMAL_TRIVIA_ANSWERS1[1786] = "Dan Jansen";
NORMAL_TRIVIA_ANSWERS2[1786] = "Jansen";
NORMAL_TRIVIA_ANSWERS3[1786] = "Janson";

NORMAL_TRIVIA_QUESTIONS[1787] = "(History): What did George Armstrong Custer accidentally shoot and kill while hunting buffalo?";
NORMAL_TRIVIA_ANSWERS1[1787] = "His horse";
NORMAL_TRIVIA_ANSWERS2[1787] = "horse";

NORMAL_TRIVIA_QUESTIONS[1788] = "(World): What four-word farewell of the 1950s was inspired by a many-toothed reptile?";
NORMAL_TRIVIA_ANSWERS1[1788] = "See you later, alligator";
NORMAL_TRIVIA_ANSWERS2[1788] = "alligator";

NORMAL_TRIVIA_QUESTIONS[1789] = "(World): What subway vigilante took exception to being asked for $5 on January 25, 1985?";
NORMAL_TRIVIA_ANSWERS1[1789] = "Bernhard Goetz";
NORMAL_TRIVIA_ANSWERS2[1789] = "Bernard";
NORMAL_TRIVIA_ANSWERS3[1789] = "Bernhard";

NORMAL_TRIVIA_QUESTIONS[1790] = "(People&Places): What city did Michelangelo do \"David\" in?";
NORMAL_TRIVIA_ANSWERS1[1790] = "Florence";

NORMAL_TRIVIA_QUESTIONS[1791] = "(World): What well-known politician was a college roommate of Tommy Lee Jones?";
NORMAL_TRIVIA_ANSWERS1[1791] = "Al Gore";
NORMAL_TRIVIA_ANSWERS2[1791] = "Gore";

NORMAL_TRIVIA_QUESTIONS[1792] = "(Arts&Entertainment): What movie put Eddie Murphy on the cover of \"Newsweek\" as \"Mr. Box Office\" when he was 23?";
NORMAL_TRIVIA_ANSWERS1[1792] = "Beverly Hills Cop";

NORMAL_TRIVIA_QUESTIONS[1793] = "(Sports&Leisure): What city's vendors sell the most teddy bears made in one of their favorite baseballer's image?";
NORMAL_TRIVIA_ANSWERS1[1793] = "Minneapolis";

NORMAL_TRIVIA_QUESTIONS[1794] = "(History): What infamous six words came back to haunt George Bush in his 1992 presidential campaign?";
NORMAL_TRIVIA_ANSWERS1[1794] = "Read my lips, no new taxes";
NORMAL_TRIVIA_ANSWERS2[1794] = "read my lips";
NORMAL_TRIVIA_ANSWERS3[1794] = "no new taxes";

NORMAL_TRIVIA_QUESTIONS[1795] = "(World): What \"Married ... with Children\" star's bra was stolen from Frederick's of Hollywood in L.A. rioting?";
NORMAL_TRIVIA_ANSWERS1[1795] = "Katey Sagal's";
NORMAL_TRIVIA_ANSWERS2[1795] = "katey sagal";
NORMAL_TRIVIA_ANSWERS3[1795] = "katey";

NORMAL_TRIVIA_QUESTIONS[1796] = "(People&Places): What phrase did Abraham Lincoln use instead of \"87 years\" in his Gettysburg Address?";
NORMAL_TRIVIA_ANSWERS1[1796] = "Four score and seven years";
NORMAL_TRIVIA_ANSWERS2[1796] = "four score and seven";

NORMAL_TRIVIA_QUESTIONS[1797] = "(World): What TV and radio host never enters the studio without his suspenders?";
NORMAL_TRIVIA_ANSWERS1[1797] = "Larry King";
NORMAL_TRIVIA_ANSWERS2[1797] = "king";

NORMAL_TRIVIA_QUESTIONS[1798] = "(People&Places): What playwright did Muammar Qaddafi insist was \"of Arab origin\" in 1989?";
NORMAL_TRIVIA_ANSWERS1[1798] = "William Shakespeare";
NORMAL_TRIVIA_ANSWERS2[1798] = "shakespeare";
NORMAL_TRIVIA_ANSWERS3[1798] = "shakespear";

NORMAL_TRIVIA_QUESTIONS[1799] = "(History): What did the Soviets send up into space on the 40th anniversary of the day the communists seized power?";
NORMAL_TRIVIA_ANSWERS1[1799] = "Sputnik I";
NORMAL_TRIVIA_ANSWERS2[1799] = "sputnik";

NORMAL_TRIVIA_QUESTIONS[1800] = "(People&Places): What country cancelled its May Day parade in 1994 for the first time since 1959, due to lack of money?";
NORMAL_TRIVIA_ANSWERS1[1800] = "Cuba";

NORMAL_TRIVIA_QUESTIONS[1801] = "(Arts&Entertainment): What five words end Charles Dicken's most famous Christmas story?";
NORMAL_TRIVIA_ANSWERS1[1801] = "God bless us every one";

NORMAL_TRIVIA_QUESTIONS[1802] = "(People&Places): What 'state' boasts the largest church in Christendom?\"";
NORMAL_TRIVIA_ANSWERS1[1802] = "Vatican City";
NORMAL_TRIVIA_ANSWERS2[1802] = "Vatican";

NORMAL_TRIVIA_QUESTIONS[1803] = "(History): Which of Cleopatra's husbands killed himself by falling on his sword?";
NORMAL_TRIVIA_ANSWERS1[1803] = "Marc Antony";
NORMAL_TRIVIA_ANSWERS2[1803] = "Antony";

NORMAL_TRIVIA_QUESTIONS[1804] = "(World): Who said: \"I was the first woman to burn my bra. It took the fire department four days to put it out\"?";
NORMAL_TRIVIA_ANSWERS1[1804] = "Dolly Parton";
NORMAL_TRIVIA_ANSWERS2[1804] = "Parton";

NORMAL_TRIVIA_QUESTIONS[1805] = "(Science&Nature): Which finger of the throwing hand is subject to a painful syndrome called \"Frisbee finger\"?";
NORMAL_TRIVIA_ANSWERS1[1805] = "The middle finger";
NORMAL_TRIVIA_ANSWERS2[1805] = "middle";

NORMAL_TRIVIA_QUESTIONS[1806] = "(Science&Nature): What Michigan doctor lead the fight for medicide, or physician-assisted suicide?";
NORMAL_TRIVIA_ANSWERS1[1806] = "Jack Kevorkian";
NORMAL_TRIVIA_ANSWERS2[1806] = "kevorkian";

NORMAL_TRIVIA_QUESTIONS[1807] = "(Arts&Entertainment): What renowned reference work did Lon Chaney write an entry on makeup for?";
NORMAL_TRIVIA_ANSWERS1[1807] = "Encyclopaedia Britannica";
NORMAL_TRIVIA_ANSWERS2[1807] = "britannica";

NORMAL_TRIVIA_QUESTIONS[1808] = "(History): What White House aide's shredding machine jammed on November 21, 1986?";
NORMAL_TRIVIA_ANSWERS1[1808] = "Oliver North's";
NORMAL_TRIVIA_ANSWERS2[1808] = "oliver";
NORMAL_TRIVIA_ANSWERS3[1808] = "north";

NORMAL_TRIVIA_QUESTIONS[1809] = "(People&Places): Whose Atlantic City hotel-casino is three times the size of the Taj Mahal, it's East Indian namesake?";
NORMAL_TRIVIA_ANSWERS1[1809] = "Donald Trump's";
NORMAL_TRIVIA_ANSWERS2[1809] = "trump";

NORMAL_TRIVIA_QUESTIONS[1810] = "(Sports&Leisure): Who won the only two U.S. Open singles titles not won by Chris Evert from 1975 through 1982?";
NORMAL_TRIVIA_ANSWERS1[1810] = "Tracy Austin";
NORMAL_TRIVIA_ANSWERS2[1810] = "austin";

NORMAL_TRIVIA_QUESTIONS[1811] = "(Arts&Entertainment): What do most people call \"Waltz Number 314\" by Johann Strauss Jr.?";
NORMAL_TRIVIA_ANSWERS1[1811] = "Blue Danube";

NORMAL_TRIVIA_QUESTIONS[1812] = "(Sports&Leisure): Who batted .373 with 47 home runs and 175 RBI the year Babe Ruth hit 60 homers?";
NORMAL_TRIVIA_ANSWERS1[1812] = "Lou Gehrig";
NORMAL_TRIVIA_ANSWERS2[1812] = "gehrig";

NORMAL_TRIVIA_QUESTIONS[1813] = "(Sports&Leisure): What baseball owner was right in assuming midget Eddie Gaedel would walk as a pinch hitter in 1951?";
NORMAL_TRIVIA_ANSWERS1[1813] = "Bill Veeck";
NORMAL_TRIVIA_ANSWERS2[1813] = "Veeck";

NORMAL_TRIVIA_QUESTIONS[1814] = "(World): What 73-year-old trapeze artist fell to his death in 1978?";
NORMAL_TRIVIA_ANSWERS1[1814] = "Karl Wallenda";
NORMAL_TRIVIA_ANSWERS2[1814] = "Wallenda";

NORMAL_TRIVIA_QUESTIONS[1815] = "(History): What was the last hotel Robert Kennedy was in before riding to his final resting place?";
NORMAL_TRIVIA_ANSWERS1[1815] = "The Ambassador";
NORMAL_TRIVIA_ANSWERS2[1815] = "Ambassador";

NORMAL_TRIVIA_QUESTIONS[1816] = "(Sports&Leisure): What hockey star was ribbed as \"The Yellow One\" because of his aversion to flying?";
NORMAL_TRIVIA_ANSWERS1[1816] = "Wayne Gretzky";
NORMAL_TRIVIA_ANSWERS2[1816] = "Gretzky";

NORMAL_TRIVIA_QUESTIONS[1817] = "(Science&Nature): Where are two Russian vehicles, auctioned at Sotheby's in 1993 for $68,500, currently parked?";
NORMAL_TRIVIA_ANSWERS1[1817] = "On the moon";
NORMAL_TRIVIA_ANSWERS2[1817] = "Moon";

NORMAL_TRIVIA_QUESTIONS[1818] = "(Sports&Leisure): What Phillies first baseman correctly noted: \"I'm not an athlete, I'm a baseball player\"?";
NORMAL_TRIVIA_ANSWERS1[1818] = "John Kruk";
NORMAL_TRIVIA_ANSWERS2[1818] = "Kruk";

NORMAL_TRIVIA_QUESTIONS[1819] = "(Science&Nature): What whale was prized for the 15 barrels of high-quality oil found behind its forehead?";
NORMAL_TRIVIA_ANSWERS1[1819] = "The sperm whale";
NORMAL_TRIVIA_ANSWERS2[1819] = "sperm";

NORMAL_TRIVIA_QUESTIONS[1820] = "(People&Places): What Virginia county's courthouse was the site of Lee's surrender to Grant?";
NORMAL_TRIVIA_ANSWERS1[1820] = "Appomattox County's";
NORMAL_TRIVIA_ANSWERS2[1820] = "Appomattox";

NORMAL_TRIVIA_QUESTIONS[1821] = "(World): How many seasons did Johnny Carson host \"The Tonight Show\"?";
NORMAL_TRIVIA_ANSWERS1[1821] = "Thirty";
NORMAL_TRIVIA_ANSWERS2[1821] = "30";

NORMAL_TRIVIA_QUESTIONS[1822] = "(Sports&Leisure): Who's the only man to win the Masters, British Open, U.S. Open, PGA and U.S. Amateur at least twice?";
NORMAL_TRIVIA_ANSWERS1[1822] = "Jack Nicklaus";
NORMAL_TRIVIA_ANSWERS2[1822] = "Nicklaus";

NORMAL_TRIVIA_QUESTIONS[1823] = "(Arts&Entertainment): What blonde strutted as a Playboy Club waitress before singing lead vocals on four No. 1 hits?";
NORMAL_TRIVIA_ANSWERS1[1823] = "Deborah Harry";
NORMAL_TRIVIA_ANSWERS2[1823] = "Harry";

NORMAL_TRIVIA_QUESTIONS[1824] = "(History): USA President Jimmy Carter, brought together Anwar Sadat and who else at the Camp David peace negotiations?";
NORMAL_TRIVIA_ANSWERS1[1824] = "Menachem Begin";
NORMAL_TRIVIA_ANSWERS2[1824] = "Begin";

NORMAL_TRIVIA_QUESTIONS[1825] = "(History): What president nearly fell out of the Wright brothers' plane while waving to a crowd?";
NORMAL_TRIVIA_ANSWERS1[1825] = "Theodore Roosevelt";
NORMAL_TRIVIA_ANSWERS2[1825] = "Roosevelt";

NORMAL_TRIVIA_QUESTIONS[1826] = "(Science&Nature): What helpful aid did the mother of 'Monkee' Mike Nesmith invent for typists the world over?";
NORMAL_TRIVIA_ANSWERS1[1826] = "Liquid Paper Correction Fluid";
NORMAL_TRIVIA_ANSWERS2[1826] = "Liquid paper";

NORMAL_TRIVIA_QUESTIONS[1827] = "(Sports&Leisure): Who became the first black member of the Milwaukee Braves, in 1954?";
NORMAL_TRIVIA_ANSWERS1[1827] = "Hank Aaron";
NORMAL_TRIVIA_ANSWERS2[1827] = "Aaron";

NORMAL_TRIVIA_QUESTIONS[1828] = "(Sports&Leisure): Who broke baseball's color barrier, inking a contract and starting at first base in 1947?";
NORMAL_TRIVIA_ANSWERS1[1828] = "Jackie Robinson";
NORMAL_TRIVIA_ANSWERS2[1828] = "Robinson";

NORMAL_TRIVIA_QUESTIONS[1829] = "(People&Places): What mountain do Tibetans call Chomo-Lungma, or Mother Goddess of the Land?";
NORMAL_TRIVIA_ANSWERS1[1829] = "Mount Everest";
NORMAL_TRIVIA_ANSWERS2[1829] = "Everest";

NORMAL_TRIVIA_QUESTIONS[1830] = "(Arts&Entertainment): What children's book introduced the cat that wears a 'Cheshire grin'?";
NORMAL_TRIVIA_ANSWERS1[1830] = "Alice's Adventures in Wonderland";
NORMAL_TRIVIA_ANSWERS2[1830] = "Alice";
NORMAL_TRIVIA_ANSWERS3[1830] = "Wonderland";

NORMAL_TRIVIA_QUESTIONS[1831] = "(Sports&Leisure): What hand can a realistic poker player expect to be dealt once every 649,740 hands?";
NORMAL_TRIVIA_ANSWERS1[1831] = "A royal flush";
NORMAL_TRIVIA_ANSWERS2[1831] = "royal flush";

NORMAL_TRIVIA_QUESTIONS[1832] = "(People&Places): Who was the first woman ever to cross the Atlantic Ocean by airplane?";
NORMAL_TRIVIA_ANSWERS1[1832] = "Amellia Earhart";
NORMAL_TRIVIA_ANSWERS2[1832] = "Earhart";

NORMAL_TRIVIA_QUESTIONS[1833] = "(Arts&Entertainment): Who got laughs opposite Eddie Murphy in the role of Detective Billy Rosewood?";
NORMAL_TRIVIA_ANSWERS1[1833] = "Judge Reinhold";
NORMAL_TRIVIA_ANSWERS2[1833] = "Reinhold";
NORMAL_TRIVIA_ANSWERS3[1833] = "Judge";

NORMAL_TRIVIA_QUESTIONS[1834] = "(Sports&Leisure): What baseballer teamed with Babe Ruth to form \"the greatest 1-2 punch the sport has ever known\"?";
NORMAL_TRIVIA_ANSWERS1[1834] = "Lou Gehrig";
NORMAL_TRIVIA_ANSWERS2[1834] = "Gehrig";

NORMAL_TRIVIA_QUESTIONS[1835] = "(World): What book did King James authorize the first English publication of?";
NORMAL_TRIVIA_ANSWERS1[1835] = "The Bible";
NORMAL_TRIVIA_ANSWERS2[1835] = "Bible";

NORMAL_TRIVIA_QUESTIONS[1836] = "(History): Who's the only 20th-century USA president that had earned no undergraduate degree?";
NORMAL_TRIVIA_ANSWERS1[1836] = "Harry Truman";
NORMAL_TRIVIA_ANSWERS2[1836] = "Truman";

NORMAL_TRIVIA_QUESTIONS[1837] = "(People&Places): What hill in Athens boasts the Parthenon and other temples?";
NORMAL_TRIVIA_ANSWERS1[1837] = "The Acropolis";
NORMAL_TRIVIA_ANSWERS2[1837] = "Acropolis";

NORMAL_TRIVIA_QUESTIONS[1838] = "(Sports&Leisure): What pro figure skater did a Pittsburgh Steelers star marry in 1976?";
NORMAL_TRIVIA_ANSWERS1[1838] = "Jo Jo Starbuck";
NORMAL_TRIVIA_ANSWERS2[1838] = "Starbuck";
NORMAL_TRIVIA_ANSWERS3[1838] = "Jo Jo";

NORMAL_TRIVIA_QUESTIONS[1839] = "(World): What profession did former First Lady, Nancy Reagan, say was \"good training for the political life which lay ahead\"?";
NORMAL_TRIVIA_ANSWERS1[1839] = "Acting";

NORMAL_TRIVIA_QUESTIONS[1840] = "(World): What replacement did station KFBK rush to hire after letting Morton Downey Jr. go in 1984?";
NORMAL_TRIVIA_ANSWERS1[1840] = "Rush Limbaugh";
NORMAL_TRIVIA_ANSWERS2[1840] = "rush";
NORMAL_TRIVIA_ANSWERS3[1840] = "limbaugh";

NORMAL_TRIVIA_QUESTIONS[1841] = "(Sports&Leisure): What major league baseball team shares it's name with young bears?";
NORMAL_TRIVIA_ANSWERS1[1841] = "The Chicago Cubs";
NORMAL_TRIVIA_ANSWERS2[1841] = "chicago cubs";
NORMAL_TRIVIA_ANSWERS3[1841] = "the cubs";

NORMAL_TRIVIA_QUESTIONS[1842] = "(History): What three-word line of General MacArthur's appear on countless items dropped over the Philippines? ";
NORMAL_TRIVIA_ANSWERS1[1842] = "I shall return";

NORMAL_TRIVIA_QUESTIONS[1843] = "(World): What Hungarian name was given to 37 pet pooches registered in Los Angeles County by 1991?";
NORMAL_TRIVIA_ANSWERS1[1843] = "Zsa Zsa";

NORMAL_TRIVIA_QUESTIONS[1844] = "(History): What five-word plea by Rodney King made the cover of \"Time\" after the 1992 Los Angeles riots took place?";
NORMAL_TRIVIA_ANSWERS1[1844] = "Can't we all get along?";
NORMAL_TRIVIA_ANSWERS2[1844] = "can't we all get along";

NORMAL_TRIVIA_QUESTIONS[1845] = "(History): What U.S. general died in a Heidelberg hospital of lung congestion after a freak car accident?";
NORMAL_TRIVIA_ANSWERS1[1845] = "George Patton";
NORMAL_TRIVIA_ANSWERS2[1845] = "patton";

NORMAL_TRIVIA_QUESTIONS[1846] = "(World): What Hindu god is said to have appeared on Earth as Rama, Krishna and Buddha?";
NORMAL_TRIVIA_ANSWERS1[1846] = "Vishnu";

NORMAL_TRIVIA_QUESTIONS[1847] = "(World): What president adorns the double sawbuck?";
NORMAL_TRIVIA_ANSWERS1[1847] = "Andrew Jackson";
NORMAL_TRIVIA_ANSWERS2[1847] = "jackson";

NORMAL_TRIVIA_QUESTIONS[1848] = "(Arts&Entertainment): What 1987 movie earned Cher her first best actress Oscar?";
NORMAL_TRIVIA_ANSWERS1[1848] = "Moonstruck";
NORMAL_TRIVIA_ANSWERS2[1848] = "Moon struck";

NORMAL_TRIVIA_QUESTIONS[1849] = "(Sports&Leisure): What metal is an Olympic gold medal mostly made of?";
NORMAL_TRIVIA_ANSWERS1[1849] = "Silver";

NORMAL_TRIVIA_QUESTIONS[1850] = "(People&Places): Who flew the Concord to sing in both the London and Philadelphia parts of Live Aid on the same day?";
NORMAL_TRIVIA_ANSWERS1[1850] = "Phil Collins";
NORMAL_TRIVIA_ANSWERS2[1850] = "collins";

NORMAL_TRIVIA_QUESTIONS[1851] = "(Sports&Leisure): Whose bare feet did 3,000-meter runner Mary Decker trip over at the 1984 Olympics?";
NORMAL_TRIVIA_ANSWERS1[1851] = "Zola Budd's";
NORMAL_TRIVIA_ANSWERS2[1851] = "zola budd";

NORMAL_TRIVIA_QUESTIONS[1852] = "(Science&Nature): What comet was named for the man who predicted it would return in 1758?";
NORMAL_TRIVIA_ANSWERS1[1852] = "Halley's comet";
NORMAL_TRIVIA_ANSWERS2[1852] = "halley";
NORMAL_TRIVIA_ANSWERS3[1852] = "halleys";

NORMAL_TRIVIA_QUESTIONS[1853] = "(People&Places): What modern-day city was renamed Leningrad when a famous Bolshevik died?";
NORMAL_TRIVIA_ANSWERS1[1853] = "St. Petersburg";
NORMAL_TRIVIA_ANSWERS2[1853] = "petersburg";

NORMAL_TRIVIA_QUESTIONS[1854] = "(History): What memorable line did John Paul Jones allegedly utter during a sea battle with the British?";
NORMAL_TRIVIA_ANSWERS1[1854] = "I have not yet begun to fight";

NORMAL_TRIVIA_QUESTIONS[1855] = "(People&Places): Who left his heart in San Francisco in a 1962 classic song?";
NORMAL_TRIVIA_ANSWERS1[1855] = "Tony Bennett";
NORMAL_TRIVIA_ANSWERS2[1855] = "Bennett";

NORMAL_TRIVIA_QUESTIONS[1856] = "(Sports&Leisure): Who became golf's first career $5 million winner in 1988?";
NORMAL_TRIVIA_ANSWERS1[1856] = "Jack Nicklaus";
NORMAL_TRIVIA_ANSWERS2[1856] = "Nicklaus";

NORMAL_TRIVIA_QUESTIONS[1857] = "(Sports&Leisure): Whose World Series heroics prompted George Steinbrenner to dub him \"Mr. October\"?";
NORMAL_TRIVIA_ANSWERS1[1857] = "Reggie Jackson's";
NORMAL_TRIVIA_ANSWERS2[1857] = "jackson";

NORMAL_TRIVIA_QUESTIONS[1858] = "(Science&Nature): What fruit is grown by 94 percent of backyard gardeners?";
NORMAL_TRIVIA_ANSWERS1[1858] = "The tomato";
NORMAL_TRIVIA_ANSWERS2[1858] = "tomato";

NORMAL_TRIVIA_QUESTIONS[1859] = "(World): Whose fans wore lapel buttons bearing saxophones on January 20, 1993?";
NORMAL_TRIVIA_ANSWERS1[1859] = "Bill Clinton's";
NORMAL_TRIVIA_ANSWERS2[1859] = "clinton";

NORMAL_TRIVIA_QUESTIONS[1860] = "(History): What Supreme Court justice hosted and officiated at the 1994 marriage of Rush Limbaugh?";
NORMAL_TRIVIA_ANSWERS1[1860] = "Clarence Thomas";
NORMAL_TRIVIA_ANSWERS2[1860] = "clarence";
NORMAL_TRIVIA_ANSWERS3[1860] = "thomas";

NORMAL_TRIVIA_QUESTIONS[1861] = "(Music): Title Mania: Supertramp - Give _ ______ ___.";
NORMAL_TRIVIA_ANSWERS1[1861] = "a little bit";

NORMAL_TRIVIA_QUESTIONS[1862] = "(Music): \"Crying in the Rain\" by the Everly's was covered in the 90's. By which Swedish band?";
NORMAL_TRIVIA_ANSWERS1[1862] = "A-ha";

NORMAL_TRIVIA_QUESTIONS[1863] = "(Music): \"Big in Japan\" was a hit for which German band?";
NORMAL_TRIVIA_ANSWERS1[1863] = "Alphaville";

NORMAL_TRIVIA_QUESTIONS[1864] = "(Music): Which song made Freddy Aguilar famous?";
NORMAL_TRIVIA_ANSWERS1[1864] = "Anak";

NORMAL_TRIVIA_QUESTIONS[1865] = "(Music): Which Swedish band did a gig during the 2001 Eurovision Songcontest break?";
NORMAL_TRIVIA_ANSWERS1[1865] = "Aqua";

NORMAL_TRIVIA_QUESTIONS[1866] = "(Music): Title Mania: The Rubettes - Sugar ____ ____.";
NORMAL_TRIVIA_ANSWERS1[1866] = "Baby Love";

NORMAL_TRIVIA_QUESTIONS[1867] = "(Music): Who is the Golden Earring's lead singer?";
NORMAL_TRIVIA_ANSWERS1[1867] = "Barry Hay";

NORMAL_TRIVIA_QUESTIONS[1868] = "(Music): First soundtrack by Peter Gabriel?";
NORMAL_TRIVIA_ANSWERS1[1868] = "Birdy";

NORMAL_TRIVIA_QUESTIONS[1869] = "(Music): Rolling Stones Lyrics: Too much _____.";
NORMAL_TRIVIA_ANSWERS1[1869] = "Blood";

NORMAL_TRIVIA_QUESTIONS[1870] = "(Music): Who was the main actor in Pink Floyd's \"The Wall\"?";
NORMAL_TRIVIA_ANSWERS1[1870] = "Bob Geldof";

NORMAL_TRIVIA_QUESTIONS[1871] = "(Music): What's the name of U2's lead singer?";
NORMAL_TRIVIA_ANSWERS1[1871] = "Bono Vox";
NORMAL_TRIVIA_ANSWERS2[1871] = "Bono";

NORMAL_TRIVIA_QUESTIONS[1872] = "(Music): Bob Geldof was lead singer in which band?";
NORMAL_TRIVIA_ANSWERS1[1872] = "Boomtown Rats";
NORMAL_TRIVIA_ANSWERS2[1872] = "The Boomtown Rats";

NORMAL_TRIVIA_QUESTIONS[1873] = "(Music): Who plays lead guitar in Queen?";
NORMAL_TRIVIA_ANSWERS1[1873] = "Brian May";

NORMAL_TRIVIA_QUESTIONS[1874] = "(Music): Who is also called 'The Boss'?";
NORMAL_TRIVIA_ANSWERS1[1874] = "Bruce Springsteen";

NORMAL_TRIVIA_QUESTIONS[1875] = "(Music): Andy Latimer, song writer and guitar player in which band?";
NORMAL_TRIVIA_ANSWERS1[1875] = "Camel";

NORMAL_TRIVIA_QUESTIONS[1876] = "(Music): Who takes over Phil Collins drums when performing live concerts?";
NORMAL_TRIVIA_ANSWERS1[1876] = "Chester Thompson";

NORMAL_TRIVIA_QUESTIONS[1877] = "(Music): Which band came out of Split Enz?";
NORMAL_TRIVIA_ANSWERS1[1877] = "Crowded House";

NORMAL_TRIVIA_QUESTIONS[1878] = "(Music): Justin Hayward was one of the main singers on Jeff Wayne's \"War of the Worlds\". Who was the other one?";
NORMAL_TRIVIA_ANSWERS1[1878] = "David Essex";

NORMAL_TRIVIA_QUESTIONS[1879] = "(Music): What is Blondie's real name?";
NORMAL_TRIVIA_ANSWERS1[1879] = "Deborah Harry";
NORMAL_TRIVIA_ANSWERS2[1879] = "Debbie Harry";

NORMAL_TRIVIA_QUESTIONS[1880] = "(Music): The hit single \"People are People\" is by which band.";
NORMAL_TRIVIA_ANSWERS1[1880] = "Depeche Mode";

NORMAL_TRIVIA_QUESTIONS[1881] = "(Music): The first Alan Parsons Project album was about this writer.";
NORMAL_TRIVIA_ANSWERS1[1881] = "Edgar Allan Poe";

NORMAL_TRIVIA_QUESTIONS[1882] = "(Music): Who is also known as 'The King'?";
NORMAL_TRIVIA_ANSWERS1[1882] = "Elvis Presley";

NORMAL_TRIVIA_QUESTIONS[1883] = "(Music): What Italian composed \"Once upon a time in the West\"?";
NORMAL_TRIVIA_ANSWERS1[1883] = "Ennio Morricone";

NORMAL_TRIVIA_QUESTIONS[1884] = "(Music): What Italian singer had hits with \"Musica �\" and \"Una terra Promessa\"?";
NORMAL_TRIVIA_ANSWERS1[1884] = "Eros Ramazotti";

NORMAL_TRIVIA_QUESTIONS[1885] = "(Music): Who was a singer in Marillion and made an album called \"Suits\"?";
NORMAL_TRIVIA_ANSWERS1[1885] = "Fish";

NORMAL_TRIVIA_QUESTIONS[1886] = "(Music): Title Mania: Genesis - Follow you, ______ __.";
NORMAL_TRIVIA_ANSWERS1[1886] = "follow me";

NORMAL_TRIVIA_QUESTIONS[1887] = "(Music): Who is also known as 'The Voice'?";
NORMAL_TRIVIA_ANSWERS1[1887] = "Frank Sinatra";

NORMAL_TRIVIA_QUESTIONS[1888] = "(Music): By who was the hit \"Dancing Fool\"?";
NORMAL_TRIVIA_ANSWERS1[1888] = "Frank Zappa";

NORMAL_TRIVIA_QUESTIONS[1889] = "(Music): Who was Queen's lead singer?";
NORMAL_TRIVIA_ANSWERS1[1889] = "Freddie Mercury";

NORMAL_TRIVIA_QUESTIONS[1890] = "(Music): Title Mania: Deep Purple - Woman ____ _____.";
NORMAL_TRIVIA_ANSWERS1[1890] = "from Tokyo";

NORMAL_TRIVIA_QUESTIONS[1891] = "(Music): Who plays bass guitars in Kiss";
NORMAL_TRIVIA_ANSWERS1[1891] = "Gene Simmons";

NORMAL_TRIVIA_QUESTIONS[1892] = "(Music): Mike Rutherford plays guitars in which band?";
NORMAL_TRIVIA_ANSWERS1[1892] = "Genesis";

NORMAL_TRIVIA_QUESTIONS[1893] = "(Music): Tony Banks plays keyboards in which band?";
NORMAL_TRIVIA_ANSWERS1[1893] = "Genesis";

NORMAL_TRIVIA_QUESTIONS[1894] = "(Music): \"Eat the Rich\" is on which Aerosmith album?";
NORMAL_TRIVIA_ANSWERS1[1894] = "Get A Grip";

NORMAL_TRIVIA_QUESTIONS[1895] = "(Music): By which band is the 70's hit \"Radar Love\"?";
NORMAL_TRIVIA_ANSWERS1[1895] = "Golden Earring";
NORMAL_TRIVIA_ANSWERS2[1895] = "The Golden Earring";

NORMAL_TRIVIA_QUESTIONS[1896] = "(Music): The band's name before they were called Golden Earring?";
NORMAL_TRIVIA_ANSWERS1[1896] = "Golden Earrings";
NORMAL_TRIVIA_ANSWERS2[1896] = "The Golden Earrings";

NORMAL_TRIVIA_QUESTIONS[1897] = "(Music): Who plays the bass guitar in Emerson, Lake and Palmer?";
NORMAL_TRIVIA_ANSWERS1[1897] = "Greg Lake";
NORMAL_TRIVIA_ANSWERS2[1897] = "Lake";

NORMAL_TRIVIA_QUESTIONS[1898] = "(Music): Which Joy Division singer committed suicide in 1982?";
NORMAL_TRIVIA_ANSWERS1[1898] = "Ian Curtis";

NORMAL_TRIVIA_QUESTIONS[1899] = "(Music): Title Mania: The Moody Blues - Nights __ _____ _____.";
NORMAL_TRIVIA_ANSWERS1[1899] = "in white satin";

NORMAL_TRIVIA_QUESTIONS[1900] = "(Music): \"Calypso\" by John Denver was about a ship, owned by who?";
NORMAL_TRIVIA_ANSWERS1[1900] = "Jacques Cousteau";

NORMAL_TRIVIA_QUESTIONS[1901] = "(Music): Who plays bass guitars in Queen?";
NORMAL_TRIVIA_ANSWERS1[1901] = "John Deacon";

NORMAL_TRIVIA_QUESTIONS[1902] = "(Music): \"Music was my First Love\" was a hit by who?";
NORMAL_TRIVIA_ANSWERS1[1902] = "John Miles";

NORMAL_TRIVIA_QUESTIONS[1903] = "(Music): Which band made the albums \"Unknown Pleasures\", \"Closer\" and \"Still\"?";
NORMAL_TRIVIA_ANSWERS1[1903] = "Joy Division";

NORMAL_TRIVIA_QUESTIONS[1904] = "(Music): By who is the song \"Victim of Changes\"?";
NORMAL_TRIVIA_ANSWERS1[1904] = "Judas Priest";

NORMAL_TRIVIA_QUESTIONS[1905] = "(Music): Who did \"Don't cry for me Argentina\" on the original Evita musical?";
NORMAL_TRIVIA_ANSWERS1[1905] = "Julie Covington";

NORMAL_TRIVIA_QUESTIONS[1906] = "(Music): Who was the female voice on Jeff Wayne's \"War of the Worlds\"?";
NORMAL_TRIVIA_ANSWERS1[1906] = "Julie Covington";

NORMAL_TRIVIA_QUESTIONS[1907] = "(Music): Who is the singer of The Moody Blues?";
NORMAL_TRIVIA_ANSWERS1[1907] = "Justin Hayward";

NORMAL_TRIVIA_QUESTIONS[1908] = "(Music): \"Don't give up\" was done by Peter Gabriel and who?";
NORMAL_TRIVIA_ANSWERS1[1908] = "Kate Bush";

NORMAL_TRIVIA_QUESTIONS[1909] = "(Music): \"Shiny Happy People\" was done by R.E.M. and who?";
NORMAL_TRIVIA_ANSWERS1[1909] = "Kate Pierson";

NORMAL_TRIVIA_QUESTIONS[1910] = "(Music): By which band is the song \"God of Thunder\"?";
NORMAL_TRIVIA_ANSWERS1[1910] = "Kiss";

NORMAL_TRIVIA_QUESTIONS[1911] = "(Music): What band made the albums \"Destroyer\", \"Double Platinum\" and \"Hotter than Hell\"?";
NORMAL_TRIVIA_ANSWERS1[1911] = "Kiss";

NORMAL_TRIVIA_QUESTIONS[1912] = "(Music): Which country singer did \"It's so easy\"?";
NORMAL_TRIVIA_ANSWERS1[1912] = "Linda Ronstadt";

NORMAL_TRIVIA_QUESTIONS[1913] = "(Music): Who took a walk on the wildside in the early 70's?";
NORMAL_TRIVIA_ANSWERS1[1913] = "Lou Reed";

NORMAL_TRIVIA_QUESTIONS[1914] = "(Music): \"The Unforgiven\" and \"Enter Sandman\", hit singles by which band?";
NORMAL_TRIVIA_ANSWERS1[1914] = "Metallica";

NORMAL_TRIVIA_QUESTIONS[1915] = "(Music): Which band did \"Silent Running\" and \"Living Years\"?";
NORMAL_TRIVIA_ANSWERS1[1915] = "Mike and the Mechanics";

NORMAL_TRIVIA_QUESTIONS[1916] = "(Music): There are 2 different versions of the album \"Tubular Bells\". Who made both of them?";
NORMAL_TRIVIA_ANSWERS1[1916] = "Mike Oldfield";

NORMAL_TRIVIA_QUESTIONS[1917] = "(Music): Which UK band was formed after Joy Division singer Ian Curtis died?";
NORMAL_TRIVIA_ANSWERS1[1917] = "New Order";

NORMAL_TRIVIA_QUESTIONS[1918] = "(Music): On which ship was Madness in the early 80's?";
NORMAL_TRIVIA_ANSWERS1[1918] = "Night Boat to Cairo";

NORMAL_TRIVIA_QUESTIONS[1919] = "(Music): On which Paul Young album was his hit single \"Where ever I lay my hat\"?";
NORMAL_TRIVIA_ANSWERS1[1919] = "No Parles";

NORMAL_TRIVIA_QUESTIONS[1920] = "(Music): On which Paul Young album was his hit single \"Come back and stay\"?";
NORMAL_TRIVIA_ANSWERS1[1920] = "No Parlez";

NORMAL_TRIVIA_QUESTIONS[1921] = "(Music): Title Mania: Deep Purple - Smoke __ ___ _____.";
NORMAL_TRIVIA_ANSWERS1[1921] = "on the water";

NORMAL_TRIVIA_QUESTIONS[1922] = "(Music): The 70's disco hit \"Born to be Alive\" was performed by?";
NORMAL_TRIVIA_ANSWERS1[1922] = "Patrick Hernandez";

NORMAL_TRIVIA_QUESTIONS[1923] = "(Music): Who sings \"Living Years\" in Mike and the Mechanics?";
NORMAL_TRIVIA_ANSWERS1[1923] = "Paul Carrack";

NORMAL_TRIVIA_QUESTIONS[1924] = "(Music): What's the name of Genesis' former lead singer?";
NORMAL_TRIVIA_ANSWERS1[1924] = "Peter Gabriel";

NORMAL_TRIVIA_QUESTIONS[1925] = "(Music): What's the name of Genesis' lead singer?";
NORMAL_TRIVIA_ANSWERS1[1925] = "Phil Collins";

NORMAL_TRIVIA_QUESTIONS[1926] = "(Music): Where is Freddy Aguilar from?";
NORMAL_TRIVIA_ANSWERS1[1926] = "Philippines";
NORMAL_TRIVIA_ANSWERS2[1926] = "The Philippines";

NORMAL_TRIVIA_QUESTIONS[1927] = "(Music): David Gilmour, guitars and vocals in which band?";
NORMAL_TRIVIA_ANSWERS1[1927] = "Pink Floyd";

NORMAL_TRIVIA_QUESTIONS[1928] = "(Music): Which band recorded \"A Momentary Lapse of Reasons\" in 1989?";
NORMAL_TRIVIA_ANSWERS1[1928] = "Pink Floyd";

NORMAL_TRIVIA_QUESTIONS[1929] = "(Music): What is Peter Gabriel's first live album called?";
NORMAL_TRIVIA_ANSWERS1[1929] = "Plays Live";
NORMAL_TRIVIA_ANSWERS2[1929] = "Peter Gabriel Plays Live";

NORMAL_TRIVIA_QUESTIONS[1930] = "(Music): \"What it Takes\" is on which Aerosmith album?";
NORMAL_TRIVIA_ANSWERS1[1930] = "Pump";

NORMAL_TRIVIA_QUESTIONS[1931] = "(Music): Finish: George, Paul, John & _____.";
NORMAL_TRIVIA_ANSWERS1[1931] = "Ringo";

NORMAL_TRIVIA_QUESTIONS[1932] = "(Music): The mega hit \"Love is All\" was not really by a singing frog, by who was it?";
NORMAL_TRIVIA_ANSWERS1[1932] = "Roger Glover and Guests";
NORMAL_TRIVIA_ANSWERS2[1932] = "Roger Glover";

NORMAL_TRIVIA_QUESTIONS[1933] = "(Music): Which Supertramp member made a solo album called \"In the Eye of the Storm\"?";
NORMAL_TRIVIA_ANSWERS1[1933] = "Roger Hodson";

NORMAL_TRIVIA_QUESTIONS[1934] = "(Music): Who plays drums in Queen?";
NORMAL_TRIVIA_ANSWERS1[1934] = "Roger Taylor";

NORMAL_TRIVIA_QUESTIONS[1935] = "(Music): Who wrote Pink Floyd's \"The Wall\"?";
NORMAL_TRIVIA_ANSWERS1[1935] = "Roger Waters";

NORMAL_TRIVIA_QUESTIONS[1936] = "(Music): Title Mania: The Bay City Rollers - ________ night.";
NORMAL_TRIVIA_ANSWERS1[1936] = "Saturday";

NORMAL_TRIVIA_QUESTIONS[1937] = "(Music): Sid Vicious played lead guitars in which band?";
NORMAL_TRIVIA_ANSWERS1[1937] = "Sex Pistols";

NORMAL_TRIVIA_QUESTIONS[1938] = "(Music): Who was singer in The Police?";
NORMAL_TRIVIA_ANSWERS1[1938] = "Sting";

NORMAL_TRIVIA_QUESTIONS[1939] = "(Music): Who is Jesus in Andrew Lloyd Webber's \"Jesus Christ Superstar\"?";
NORMAL_TRIVIA_ANSWERS1[1939] = "Ted Neeley";

NORMAL_TRIVIA_QUESTIONS[1940] = "(Music): Kate Pierson is a singer in which band?";
NORMAL_TRIVIA_ANSWERS1[1940] = "The B52's";
NORMAL_TRIVIA_ANSWERS2[1940] = "B52's";

NORMAL_TRIVIA_QUESTIONS[1941] = "(Music): Title Mania: Simple Minds - Upon ___ _______.";
NORMAL_TRIVIA_ANSWERS1[1941] = "The Catwalk";

NORMAL_TRIVIA_QUESTIONS[1942] = "(Music): Robert Smith is the lead singer of which band?";
NORMAL_TRIVIA_ANSWERS1[1942] = "The Cure";
NORMAL_TRIVIA_ANSWERS2[1942] = "Cure";

NORMAL_TRIVIA_QUESTIONS[1943] = "(Music): The 80's album \"Seventeen Seconds\" was by which UK New Wave band?";
NORMAL_TRIVIA_ANSWERS1[1943] = "The Cure";
NORMAL_TRIVIA_ANSWERS2[1943] = "Cure";

NORMAL_TRIVIA_QUESTIONS[1944] = "(Music): \"Money\" is on which Pink Floyd album?";
NORMAL_TRIVIA_ANSWERS1[1944] = "The Dark Side of the Moon";
NORMAL_TRIVIA_ANSWERS2[1944] = "Dark Side of the Moon";

NORMAL_TRIVIA_QUESTIONS[1945] = "(Music): Pink Floyd says, this is the best album they ever made.";
NORMAL_TRIVIA_ANSWERS1[1945] = "The Division Bell";
NORMAL_TRIVIA_ANSWERS2[1945] = "Division Bell";

NORMAL_TRIVIA_QUESTIONS[1946] = "(Music): Phil Oakey is the lead singer of which band?";
NORMAL_TRIVIA_ANSWERS1[1946] = "The Human League";
NORMAL_TRIVIA_ANSWERS2[1946] = "Human League";

NORMAL_TRIVIA_QUESTIONS[1947] = "(Music): Where is Golden Earring from?";
NORMAL_TRIVIA_ANSWERS1[1947] = "The Netherlands";
NORMAL_TRIVIA_ANSWERS2[1947] = "Netherlands";
NORMAL_TRIVIA_ANSWERS3[1947] = "Holland";

NORMAL_TRIVIA_QUESTIONS[1948] = "(Music): \"Every little thing she does\" was a hit by which band?";
NORMAL_TRIVIA_ANSWERS1[1948] = "The Police";

NORMAL_TRIVIA_QUESTIONS[1949] = "(Music): To which band is Bill Wyman related?";
NORMAL_TRIVIA_ANSWERS1[1949] = "The Rolling Stones";
NORMAL_TRIVIA_ANSWERS2[1949] = "Rolling Stones";

NORMAL_TRIVIA_QUESTIONS[1950] = "(Music): To which band is Keith Richards related?";
NORMAL_TRIVIA_ANSWERS1[1950] = "The Rolling Stones";
NORMAL_TRIVIA_ANSWERS2[1950] = "Rolling Stones";

NORMAL_TRIVIA_QUESTIONS[1951] = "(Music): To which band is Mick Jagger related?";
NORMAL_TRIVIA_ANSWERS1[1951] = "The Rolling Stones";
NORMAL_TRIVIA_ANSWERS2[1951] = "Rolling Stones";

NORMAL_TRIVIA_QUESTIONS[1952] = "(Music): To which band is Ron Wood related?";
NORMAL_TRIVIA_ANSWERS1[1952] = "The Rolling Stones";
NORMAL_TRIVIA_ANSWERS2[1952] = "Rolling Stones";

NORMAL_TRIVIA_QUESTIONS[1953] = "(Music): \"Still Loving You\" was a big hit for which German band?";
NORMAL_TRIVIA_ANSWERS1[1953] = "The Scorpions";
NORMAL_TRIVIA_ANSWERS2[1953] = "Scorpions";

NORMAL_TRIVIA_QUESTIONS[1954] = "(Music): \"Heroes\" and \"Golden Brown\" were hits by which band?";
NORMAL_TRIVIA_ANSWERS1[1954] = "The Stranglers";
NORMAL_TRIVIA_ANSWERS2[1954] = "Stranglers";

NORMAL_TRIVIA_QUESTIONS[1955] = "(Music): Because of what is Kiss singer Gene Simmons famous?";
NORMAL_TRIVIA_ANSWERS1[1955] = "tongue";
NORMAL_TRIVIA_ANSWERS2[1955] = "his tongue";

NORMAL_TRIVIA_QUESTIONS[1956] = "(Music): Who made an album called \"Rattle and Hum\" in 1989?";
NORMAL_TRIVIA_ANSWERS1[1956] = "U2";

NORMAL_TRIVIA_QUESTIONS[1957] = "(Music): The album \"Innocent Victims\" is by which band?";
NORMAL_TRIVIA_ANSWERS1[1957] = "Uriah Heep";

NORMAL_TRIVIA_QUESTIONS[1958] = "(Music): Which band made a hit called \"Running with the Devil\"?";
NORMAL_TRIVIA_ANSWERS1[1958] = "Van Halen";

NORMAL_TRIVIA_QUESTIONS[1959] = "(Music): \"I wanna dance with somebody\", 1989 hit single by who?";
NORMAL_TRIVIA_ANSWERS1[1959] = "Whitney Houston";

NORMAL_TRIVIA_QUESTIONS[1960] = "(Music): \"Senza una Donna\" was a hit by Paul Young and?";
NORMAL_TRIVIA_ANSWERS1[1960] = "Zucchero";

NORMAL_TRIVIA_QUESTIONS[1961] = "(US Capitals): Alabama";
NORMAL_TRIVIA_ANSWERS1[1961] = "Montgomery";

NORMAL_TRIVIA_QUESTIONS[1962] = "(US Capitals): Alaska";
NORMAL_TRIVIA_ANSWERS1[1962] = "Juneau";

NORMAL_TRIVIA_QUESTIONS[1963] = "(US Capitals): Arizona";
NORMAL_TRIVIA_ANSWERS1[1963] = "Phoenix";

NORMAL_TRIVIA_QUESTIONS[1964] = "(US Capitals): Arkansas";
NORMAL_TRIVIA_ANSWERS1[1964] = "Little Rock";

NORMAL_TRIVIA_QUESTIONS[1965] = "(US Capitals): Califorina";
NORMAL_TRIVIA_ANSWERS1[1965] = "Sacramento";

NORMAL_TRIVIA_QUESTIONS[1966] = "(US Capitals): Colorado";
NORMAL_TRIVIA_ANSWERS1[1966] = "Denver";

NORMAL_TRIVIA_QUESTIONS[1967] = "(US Capitals): Connecticut";
NORMAL_TRIVIA_ANSWERS1[1967] = "Hartford";

NORMAL_TRIVIA_QUESTIONS[1968] = "(US Capitals): Delaware";
NORMAL_TRIVIA_ANSWERS1[1968] = "Dover";

NORMAL_TRIVIA_QUESTIONS[1969] = "(US Capitals): Florida";
NORMAL_TRIVIA_ANSWERS1[1969] = "Tallahassee";

NORMAL_TRIVIA_QUESTIONS[1970] = "(US Capitals): Georgia";
NORMAL_TRIVIA_ANSWERS1[1970] = "Atlanta";

NORMAL_TRIVIA_QUESTIONS[1971] = "(US Capitals): Hawaii";
NORMAL_TRIVIA_ANSWERS1[1971] = "Honolulu";

NORMAL_TRIVIA_QUESTIONS[1972] = "(US Capitals): Idaho";
NORMAL_TRIVIA_ANSWERS1[1972] = "Boise";

NORMAL_TRIVIA_QUESTIONS[1973] = "(US Capitals): Indiana";
NORMAL_TRIVIA_ANSWERS1[1973] = "Indianapolis";

NORMAL_TRIVIA_QUESTIONS[1974] = "(US Capitals): Illinois";
NORMAL_TRIVIA_ANSWERS1[1974] = "Springfield";

NORMAL_TRIVIA_QUESTIONS[1975] = "(US Capitals): Iowa";
NORMAL_TRIVIA_ANSWERS1[1975] = "Des Moines";

NORMAL_TRIVIA_QUESTIONS[1976] = "(US Capitals): Kansas";
NORMAL_TRIVIA_ANSWERS1[1976] = "Topeka";

NORMAL_TRIVIA_QUESTIONS[1977] = "(US Capitals): Kentucky";
NORMAL_TRIVIA_ANSWERS1[1977] = "Frankfort";

NORMAL_TRIVIA_QUESTIONS[1978] = "(US Capitals): Louisiana";
NORMAL_TRIVIA_ANSWERS1[1978] = "Baton Rouge";

NORMAL_TRIVIA_QUESTIONS[1979] = "(US Capitals): Maine";
NORMAL_TRIVIA_ANSWERS1[1979] = "Augusta";

NORMAL_TRIVIA_QUESTIONS[1980] = "(US Capitals): Maryland";
NORMAL_TRIVIA_ANSWERS1[1980] = "Annapolis";

NORMAL_TRIVIA_QUESTIONS[1981] = "(US Capitals): Massachusetts";
NORMAL_TRIVIA_ANSWERS1[1981] = "Boston";

NORMAL_TRIVIA_QUESTIONS[1982] = "(US Capitals): Michigan";
NORMAL_TRIVIA_ANSWERS1[1982] = "Lansing";

NORMAL_TRIVIA_QUESTIONS[1983] = "(US Capitals): Minnesota";
NORMAL_TRIVIA_ANSWERS1[1983] = "St. Paul";
NORMAL_TRIVIA_ANSWERS2[1983] = "St Paul";

NORMAL_TRIVIA_QUESTIONS[1984] = "(US Capitals): Mississippi";
NORMAL_TRIVIA_ANSWERS1[1984] = "Jackson";

NORMAL_TRIVIA_QUESTIONS[1985] = "(US Capitals): Missouri";
NORMAL_TRIVIA_ANSWERS1[1985] = "Jefferson City";

NORMAL_TRIVIA_QUESTIONS[1986] = "(US Capitals): Montana";
NORMAL_TRIVIA_ANSWERS1[1986] = "Helena";

NORMAL_TRIVIA_QUESTIONS[1987] = "(US Capitals): Nebraska";
NORMAL_TRIVIA_ANSWERS1[1987] = "Lincoln";

NORMAL_TRIVIA_QUESTIONS[1988] = "(US Capitals): Nevada";
NORMAL_TRIVIA_ANSWERS1[1988] = "Carson City";

NORMAL_TRIVIA_QUESTIONS[1989] = "(US Capitals): New Hampshire";
NORMAL_TRIVIA_ANSWERS1[1989] = "Concord";

NORMAL_TRIVIA_QUESTIONS[1990] = "(US Capitals): New Jersey";
NORMAL_TRIVIA_ANSWERS1[1990] = "Trenton";

NORMAL_TRIVIA_QUESTIONS[1991] = "(US Capitals): New Mexico";
NORMAL_TRIVIA_ANSWERS1[1991] = "Santa Fe";

NORMAL_TRIVIA_QUESTIONS[1992] = "(US Capitals): New York";
NORMAL_TRIVIA_ANSWERS1[1992] = "Albany";

NORMAL_TRIVIA_QUESTIONS[1993] = "(US Capitals): North Carolina";
NORMAL_TRIVIA_ANSWERS1[1993] = "Raleigh";

NORMAL_TRIVIA_QUESTIONS[1994] = "(US Capitals): North Dakota";
NORMAL_TRIVIA_ANSWERS1[1994] = "Bismarck";

NORMAL_TRIVIA_QUESTIONS[1995] = "(US Capitals): Ohio";
NORMAL_TRIVIA_ANSWERS1[1995] = "Columbus";

NORMAL_TRIVIA_QUESTIONS[1996] = "(US Capitals): Oklahoma";
NORMAL_TRIVIA_ANSWERS1[1996] = "Oklahoma City";

NORMAL_TRIVIA_QUESTIONS[1997] = "(US Capitals): Oregon";
NORMAL_TRIVIA_ANSWERS1[1997] = "Salem";

NORMAL_TRIVIA_QUESTIONS[1998] = "(US Capitals): Pennsylvania";
NORMAL_TRIVIA_ANSWERS1[1998] = "Harrisburg";

NORMAL_TRIVIA_QUESTIONS[1999] = "(US Capitals): Rhode Island";
NORMAL_TRIVIA_ANSWERS1[1999] = "Providence";

NORMAL_TRIVIA_QUESTIONS[2000] = "(US Capitals): South Carolina";
NORMAL_TRIVIA_ANSWERS1[2000] = "Columbia";

NORMAL_TRIVIA_QUESTIONS[2001] = "(US Capitals): South Dakota";
NORMAL_TRIVIA_ANSWERS1[2001] = "Pierre";

NORMAL_TRIVIA_QUESTIONS[2002] = "(US Capitals): Tennessee";
NORMAL_TRIVIA_ANSWERS1[2002] = "Nashville";

NORMAL_TRIVIA_QUESTIONS[2003] = "(Us Capitals): Texas";
NORMAL_TRIVIA_ANSWERS1[2003] = "Austin";

NORMAL_TRIVIA_QUESTIONS[2004] = "(US Capitals): Utah";
NORMAL_TRIVIA_ANSWERS1[2004] = "Salt Lake City";

NORMAL_TRIVIA_QUESTIONS[2005] = "(US Capitals): Vermont";
NORMAL_TRIVIA_ANSWERS1[2005] = "Montpelier";

NORMAL_TRIVIA_QUESTIONS[2006] = "(US Capitals): Virginia";
NORMAL_TRIVIA_ANSWERS1[2006] = "Richmond";

NORMAL_TRIVIA_QUESTIONS[2007] = "(US Capitals): Washington";
NORMAL_TRIVIA_ANSWERS1[2007] = "Olympia";

NORMAL_TRIVIA_QUESTIONS[2008] = "(US Capitals): West Virginia";
NORMAL_TRIVIA_ANSWERS1[2008] = "Charleston";

NORMAL_TRIVIA_QUESTIONS[2009] = "(US Capitals): Wisconsin";
NORMAL_TRIVIA_ANSWERS1[2009] = "Madison";

NORMAL_TRIVIA_QUESTIONS[2010] = "(US Capitals): Wyoming";
NORMAL_TRIVIA_ANSWERS1[2010] = "Cheyenne";

NORMAL_TRIVIA_QUESTIONS[2011] = "(Roman Emperors:): Who ruled in Rome in 31bc - 14ad?";
NORMAL_TRIVIA_ANSWERS1[2011] = "Augustus";

NORMAL_TRIVIA_QUESTIONS[2012] = "(Roman Emperors:): Who ruled in rome in 14ad - 37ad?";
NORMAL_TRIVIA_ANSWERS1[2012] = "Tiberius";

NORMAL_TRIVIA_QUESTIONS[2013] = "(Roman Emperors:): Who ruled in Rome in 37ad - 41ad?";
NORMAL_TRIVIA_ANSWERS1[2013] = "Caligula";

NORMAL_TRIVIA_QUESTIONS[2014] = "(Roman Emperors:): Who ruled in Rome in 41ad - 54ad?";
NORMAL_TRIVIA_ANSWERS1[2014] = "Claudius";

NORMAL_TRIVIA_QUESTIONS[2015] = "(Roman Emperors:): Who ruled in Rome in 54ad - 68ad?";
NORMAL_TRIVIA_ANSWERS1[2015] = "Nero";

NORMAL_TRIVIA_QUESTIONS[2016] = "(Roman Emperors:): Who ruled in Rome in 69ad?";
NORMAL_TRIVIA_ANSWERS1[2016] = "Vitellius";

NORMAL_TRIVIA_QUESTIONS[2017] = "(Roman Emperors:): Who ruled in Rome in 69ad - 79ad?";
NORMAL_TRIVIA_ANSWERS1[2017] = "Vespasianus";

NORMAL_TRIVIA_QUESTIONS[2018] = "(Roman Emperors:): Who ruled in Rome in 79ad - 81ad?";
NORMAL_TRIVIA_ANSWERS1[2018] = "Titus";

NORMAL_TRIVIA_QUESTIONS[2019] = "(Roman Emperors:): Who ruled in Rome in 81ad - 96ad?";
NORMAL_TRIVIA_ANSWERS1[2019] = "Domitianus";

NORMAL_TRIVIA_QUESTIONS[2020] = "(Roman Emperors:): Who ruled in Rome in 96ad - 98ad?";
NORMAL_TRIVIA_ANSWERS1[2020] = "Nerva";

NORMAL_TRIVIA_QUESTIONS[2021] = "(Roman Emperors:): Who ruled in Rome in 98ad - 117ad?";
NORMAL_TRIVIA_ANSWERS1[2021] = "Trajanus";

NORMAL_TRIVIA_QUESTIONS[2022] = "(Roman Emperors:): Who ruled in Rome in 117ad - 138ad?";
NORMAL_TRIVIA_ANSWERS1[2022] = "Hadrianus";

NORMAL_TRIVIA_QUESTIONS[2023] = "(Roman Emperors:): Who ruled in Rome in 138ad - 161ad?";
NORMAL_TRIVIA_ANSWERS1[2023] = "Antonius Pius";

NORMAL_TRIVIA_QUESTIONS[2024] = "(Roman Emperors:): Who ruled in Rome in 161ad - 180ad?";
NORMAL_TRIVIA_ANSWERS1[2024] = "Marcus Aurelius";

NORMAL_TRIVIA_QUESTIONS[2025] = "(Roman Emperors:): Who ruled in Rome in 180ad - 192ad?";
NORMAL_TRIVIA_ANSWERS1[2025] = "Commodus";

NORMAL_TRIVIA_QUESTIONS[2026] = "(Roman Emperors:): Who ruled in Rome in 193ad?";
NORMAL_TRIVIA_ANSWERS1[2026] = "Didius Julianus";

NORMAL_TRIVIA_QUESTIONS[2027] = "(Roman Emperors:): Who ruled in Rome in 193ad - 211ad?";
NORMAL_TRIVIA_ANSWERS1[2027] = "Septimus Severus";

NORMAL_TRIVIA_QUESTIONS[2028] = "(Roman Emperors:): Who ruled in Rome in 211ad - 217ad?";
NORMAL_TRIVIA_ANSWERS1[2028] = "Caracalla";

NORMAL_TRIVIA_QUESTIONS[2029] = "(Roman Emperors:): Who ruled in Rome in 217ad - 218ad?";
NORMAL_TRIVIA_ANSWERS1[2029] = "Macrinus";

NORMAL_TRIVIA_QUESTIONS[2030] = "(Roman Emperors:): Who ruled in Rome in 218ad - 222ad?";
NORMAL_TRIVIA_ANSWERS1[2030] = "Heliogabalus";

NORMAL_TRIVIA_QUESTIONS[2031] = "(Roman Emperors:): Who ruled in Rome in 222ad - 235ad?";
NORMAL_TRIVIA_ANSWERS1[2031] = "Alexander Severus";

NORMAL_TRIVIA_QUESTIONS[2032] = "(Roman Emperors:): Who ruled in Rome in 235ad - 238ad?";
NORMAL_TRIVIA_ANSWERS1[2032] = "Maximinus";

NORMAL_TRIVIA_QUESTIONS[2033] = "(Roman Emperors:): Who ruled in Rome in 238ad?";
NORMAL_TRIVIA_ANSWERS1[2033] = "Balbinus";

NORMAL_TRIVIA_QUESTIONS[2034] = "(Roman Emperors:): Who ruled in Rome in 238ad - 244ad?";
NORMAL_TRIVIA_ANSWERS1[2034] = "Gordianus III";

NORMAL_TRIVIA_QUESTIONS[2035] = "(Roman Emperors:): Who ruled in Rome in 244ad - 249ad?";
NORMAL_TRIVIA_ANSWERS1[2035] = "Philippus";

NORMAL_TRIVIA_QUESTIONS[2036] = "(Roman Emperors:): Who ruled in Rome in 249ad - 251ad?";
NORMAL_TRIVIA_ANSWERS1[2036] = "Decius";

NORMAL_TRIVIA_QUESTIONS[2037] = "(Roman Emperors:): Who ruled in Rome in 251ad - 254ad?";
NORMAL_TRIVIA_ANSWERS1[2037] = "Gallus";

NORMAL_TRIVIA_QUESTIONS[2038] = "(Roman Emperors:): Who ruled in Rome in 254ad?";
NORMAL_TRIVIA_ANSWERS1[2038] = "Aemilianus";

NORMAL_TRIVIA_QUESTIONS[2039] = "(Roman Emperors:): Who ruled in Rome in 254ad - 260ad?";
NORMAL_TRIVIA_ANSWERS1[2039] = "Valerianus";

NORMAL_TRIVIA_QUESTIONS[2040] = "(Roman Emperors:): Who ruled in Rome in 254ad - 268ad?";
NORMAL_TRIVIA_ANSWERS1[2040] = "Galienus";

NORMAL_TRIVIA_QUESTIONS[2041] = "(Roman Emperors:): Who ruled in Rome in 268ad - 270ad?";
NORMAL_TRIVIA_ANSWERS1[2041] = "Claudius II";

NORMAL_TRIVIA_QUESTIONS[2042] = "(Roman Emperors:): Who ruled in Rome in 270ad - 275ad?";
NORMAL_TRIVIA_ANSWERS1[2042] = "Aerelianus";

NORMAL_TRIVIA_QUESTIONS[2043] = "(Roman Emperors:): Who ruled in Rome in 275ad - 276ad?";
NORMAL_TRIVIA_ANSWERS1[2043] = "Tacitus";

NORMAL_TRIVIA_QUESTIONS[2044] = "(Roman Emperors:): Who ruled in Rome in 276ad - 282ad?";
NORMAL_TRIVIA_ANSWERS1[2044] = "Prubus";

NORMAL_TRIVIA_QUESTIONS[2045] = "(Roman Emperors:): Who ruled in Rome in 282ad - 283ad?";
NORMAL_TRIVIA_ANSWERS1[2045] = "Carus";

NORMAL_TRIVIA_QUESTIONS[2046] = "(Roman Emperors:): Who ruled in Rome in 283ad - 284ad?";
NORMAL_TRIVIA_ANSWERS1[2046] = "Numerianus";

NORMAL_TRIVIA_QUESTIONS[2047] = "(Roman Emperors:): Who ruled in Rome in 283ad - 285ad?";
NORMAL_TRIVIA_ANSWERS1[2047] = "Carinus";

NORMAL_TRIVIA_QUESTIONS[2048] = "(Roman Emperors:): Who ruled in Rome in 284ad - 305ad?";
NORMAL_TRIVIA_ANSWERS1[2048] = "Diocletianus";

NORMAL_TRIVIA_QUESTIONS[2049] = "(Roman Emperors:): Who ruled in Rome in 305ad - 306ad?";
NORMAL_TRIVIA_ANSWERS1[2049] = "Galerius";

NORMAL_TRIVIA_QUESTIONS[2050] = "(Roman Emperors:): Who ruled in Rome in 306ad - 324ad?";
NORMAL_TRIVIA_ANSWERS1[2050] = "Maxentius";

NORMAL_TRIVIA_QUESTIONS[2051] = "(Roman Emperors:): Who ruled in Rome in 324ad - 337ad?";
NORMAL_TRIVIA_ANSWERS1[2051] = "Constantinus the Great";

NORMAL_TRIVIA_QUESTIONS[2052] = "(Roman Emperors:): Who ruled in Rome in 337ad - 361ad?";
NORMAL_TRIVIA_ANSWERS1[2052] = "Constantinus II";

NORMAL_TRIVIA_QUESTIONS[2053] = "(Roman Emperors:):  Who ruled in Rome in 337ad - 350ad?";
NORMAL_TRIVIA_ANSWERS1[2053] = "Constans";

NORMAL_TRIVIA_QUESTIONS[2054] = "(Roman Emperors:): Who ruled in Rome in 361ad - 363ad?";
NORMAL_TRIVIA_ANSWERS1[2054] = "Julianus Apostata";

NORMAL_TRIVIA_QUESTIONS[2055] = "(Roman Emperors:): Who ruled in Rome in 363ad - 364ad?";
NORMAL_TRIVIA_ANSWERS1[2055] = "Jovianus";

NORMAL_TRIVIA_QUESTIONS[2056] = "(Roman Emperors:): Who ruled in Rome in 364ad - 375ad?";
NORMAL_TRIVIA_ANSWERS1[2056] = "Valentinianus";

NORMAL_TRIVIA_QUESTIONS[2057] = "(Roman Emperors:): Who ruled in Rome in 364ad - 378ad?";
NORMAL_TRIVIA_ANSWERS1[2057] = "Valens";

NORMAL_TRIVIA_QUESTIONS[2058] = "(Roman Emperors:): Who ruled in Rome in 375ad - 383ad?";
NORMAL_TRIVIA_ANSWERS1[2058] = "Gratianus";

NORMAL_TRIVIA_QUESTIONS[2059] = "(Roman Emperors:): Who ruled in Rome in 375ad - 392ad?";
NORMAL_TRIVIA_ANSWERS1[2059] = "Valentinianus";

NORMAL_TRIVIA_QUESTIONS[2060] = "(Roman Emperors:): Who ruled in Rome in 378ad - 395ad?";
NORMAL_TRIVIA_ANSWERS1[2060] = "Theodosius the Great";

NORMAL_TRIVIA_QUESTIONS[2061] = "(World Leaders:): From which country was Muhammad Zahir Shah king?";
NORMAL_TRIVIA_ANSWERS1[2061] = "Afghanistan";

NORMAL_TRIVIA_QUESTIONS[2062] = "(World Leaders:): From which country was General Juan D. Peron president?";
NORMAL_TRIVIA_ANSWERS1[2062] = "Argentina";

NORMAL_TRIVIA_QUESTIONS[2063] = "(World Leaders:): From which country was Leopold III king?";
NORMAL_TRIVIA_ANSWERS1[2063] = "Belgium";

NORMAL_TRIVIA_QUESTIONS[2064] = "(World Leaders:): From which country was Yigme Wangchuk de maharadja?";
NORMAL_TRIVIA_ANSWERS1[2064] = "Bhutan";

NORMAL_TRIVIA_QUESTIONS[2065] = "(World Leaders:): From which country was Sao Sjwe Thaik president?";
NORMAL_TRIVIA_ANSWERS1[2065] = "Burma";

NORMAL_TRIVIA_QUESTIONS[2066] = "(World Leaders:): From which country was Enriquez Hertzog president?";
NORMAL_TRIVIA_ANSWERS1[2066] = "Bolivia";

NORMAL_TRIVIA_QUESTIONS[2067] = "(World Leaders:): From which country was Generaal Enrique Gaspar Dutra president?";
NORMAL_TRIVIA_ANSWERS1[2067] = "Brazil";

NORMAL_TRIVIA_QUESTIONS[2068] = "(World Leaders:): From which country was Gabriel Gonzalez Videla president?";
NORMAL_TRIVIA_ANSWERS1[2068] = "Chile";

NORMAL_TRIVIA_QUESTIONS[2069] = "(World Leaders:): From which country was Li Tsuang Jen president?";
NORMAL_TRIVIA_ANSWERS1[2069] = "China";

NORMAL_TRIVIA_QUESTIONS[2070] = "(World Leaders:): From which country was Mariano Ospina Perez president?";
NORMAL_TRIVIA_ANSWERS1[2070] = "Colombia";

NORMAL_TRIVIA_QUESTIONS[2071] = "(World Leaders:): From which country was Jose Figuerez president?";
NORMAL_TRIVIA_ANSWERS1[2071] = "Costa Rica";

NORMAL_TRIVIA_QUESTIONS[2072] = "(World Leaders:): From which country was Carlos Prio Socarras president?";
NORMAL_TRIVIA_ANSWERS1[2072] = "Cuba";

NORMAL_TRIVIA_QUESTIONS[2073] = "(World Leaders:): From which country was Frederick IX king?";
NORMAL_TRIVIA_ANSWERS1[2073] = "Denmark";

NORMAL_TRIVIA_QUESTIONS[2074] = "(World Leaders:): From which country was Galo Plaza Lasso president?";
NORMAL_TRIVIA_ANSWERS1[2074] = "Ecuador";

NORMAL_TRIVIA_QUESTIONS[2075] = "(World Leaders:): Which country had king Farouk?";
NORMAL_TRIVIA_ANSWERS1[2075] = "Egypt";

NORMAL_TRIVIA_QUESTIONS[2076] = "(World Leaders:): From which country was Jubo Paasikivi president?";
NORMAL_TRIVIA_ANSWERS1[2076] = "Finland";

NORMAL_TRIVIA_QUESTIONS[2077] = "(World Leaders:): From which country was Vincent Auriol president?";
NORMAL_TRIVIA_ANSWERS1[2077] = "France";

NORMAL_TRIVIA_QUESTIONS[2078] = "(World Leaders:): Born in Greece in 1901, who was king in 1947?";
NORMAL_TRIVIA_ANSWERS1[2078] = "Paul I";

NORMAL_TRIVIA_QUESTIONS[2079] = "(World Leaders:): From which country was George VI king?";
NORMAL_TRIVIA_ANSWERS1[2079] = "Geat Britain";

NORMAL_TRIVIA_QUESTIONS[2080] = "(World Leaders:): From which country was Juan Jose Arevalo president?";
NORMAL_TRIVIA_ANSWERS1[2080] = "Guatemala";

NORMAL_TRIVIA_QUESTIONS[2081] = "(World Leaders:): From which country was Dumarsais Estime president?";
NORMAL_TRIVIA_ANSWERS1[2081] = "Haiti";

NORMAL_TRIVIA_QUESTIONS[2082] = "(World Leaders:): From which country was Juan Manuel Galves president?";
NORMAL_TRIVIA_ANSWERS1[2082] = "Honduras";

NORMAL_TRIVIA_QUESTIONS[2083] = "(World Leaders:): From which country was Arpad Szakasits president?";
NORMAL_TRIVIA_ANSWERS1[2083] = "Hungary";

NORMAL_TRIVIA_QUESTIONS[2084] = "(World Leaders:): From which country was Sean T. O'Kelly president?";
NORMAL_TRIVIA_ANSWERS1[2084] = "Ireland";

NORMAL_TRIVIA_QUESTIONS[2085] = "(World Leaders:): From which country was Faisal II king?";
NORMAL_TRIVIA_ANSWERS1[2085] = "Iraq";

NORMAL_TRIVIA_QUESTIONS[2086] = "(World Leaders:): From which country was Shahpoor Muhammad Reza Pahlevi shah?";
NORMAL_TRIVIA_ANSWERS1[2086] = "Iran";

NORMAL_TRIVIA_QUESTIONS[2087] = "(World Leaders:): From which country was Chaim Weizmann president?";
NORMAL_TRIVIA_ANSWERS1[2087] = "Israel";

NORMAL_TRIVIA_QUESTIONS[2088] = "(World Leaders:): From which country was Luigi Einaudi president?";
NORMAL_TRIVIA_ANSWERS1[2088] = "Italy";

NORMAL_TRIVIA_QUESTIONS[2089] = "(World Leaders:): From which country was Hirohito emperor?";
NORMAL_TRIVIA_ANSWERS1[2089] = "Japan";

NORMAL_TRIVIA_QUESTIONS[2090] = "(World Leaders:): From which country was Bechara el Khoury president?";
NORMAL_TRIVIA_ANSWERS1[2090] = "Lebanon";

NORMAL_TRIVIA_QUESTIONS[2091] = "(World Leaders:): From which country was William V.S. Tubman president?";
NORMAL_TRIVIA_ANSWERS1[2091] = "Liberya";

NORMAL_TRIVIA_QUESTIONS[2092] = "(World Leaders:): From which country was Sidi Muhammad sultan?";
NORMAL_TRIVIA_ANSWERS1[2092] = "Morocco";

NORMAL_TRIVIA_QUESTIONS[2093] = "(World Leaders:): From which country was Miguel Aleman president?";
NORMAL_TRIVIA_ANSWERS1[2093] = "Mexico";

NORMAL_TRIVIA_QUESTIONS[2094] = "(World Leaders:): From which country was Juliana queen?";
NORMAL_TRIVIA_ANSWERS1[2094] = "Netherlands";

NORMAL_TRIVIA_QUESTIONS[2095] = "(World Leaders:): From which country was Victor M. Roman y Reyes president?";
NORMAL_TRIVIA_ANSWERS1[2095] = "Nicaragua";

NORMAL_TRIVIA_QUESTIONS[2096] = "(World Leaders:): From which country was Haakon VII king?";
NORMAL_TRIVIA_ANSWERS1[2096] = "Norway";

NORMAL_TRIVIA_QUESTIONS[2097] = "(World Leaders:): From which country was Karl Renner president?";
NORMAL_TRIVIA_ANSWERS1[2097] = "Austria";

NORMAL_TRIVIA_QUESTIONS[2098] = "(World Leaders:): From which country was Domingo Diaz president?";
NORMAL_TRIVIA_ANSWERS1[2098] = "Panama";

NORMAL_TRIVIA_QUESTIONS[2099] = "(World Leaders:): From which country was F. Molas Lopes president?";
NORMAL_TRIVIA_ANSWERS1[2099] = "Paraguay";

NORMAL_TRIVIA_QUESTIONS[2100] = "(World Leaders:): From which country was Manuel A. Odira president?";
NORMAL_TRIVIA_ANSWERS1[2100] = "Peru";

NORMAL_TRIVIA_QUESTIONS[2101] = "(World Leaders:):  From which country was Elpidio Quirino president?";
NORMAL_TRIVIA_ANSWERS1[2101] = "Philippines";
NORMAL_TRIVIA_ANSWERS2[2101] = "The Philippines";

NORMAL_TRIVIA_QUESTIONS[2102] = "(World Leaders:): From which country was Boleslav Bierut president?";
NORMAL_TRIVIA_ANSWERS1[2102] = "Poland";

NORMAL_TRIVIA_QUESTIONS[2103] = "(World Leaders:): From which country was Antonio de Fragoso Carmona president?";
NORMAL_TRIVIA_ANSWERS1[2103] = "Portugal";

NORMAL_TRIVIA_QUESTIONS[2104] = "(World Leaders:): From which country was Abdul Aziz al Faisal al Saud king?";
NORMAL_TRIVIA_ANSWERS1[2104] = "Saudi Arabia";

NORMAL_TRIVIA_QUESTIONS[2105] = "(World Leaders:): From which country was Hoesni Zaim president?";
NORMAL_TRIVIA_ANSWERS1[2105] = "Syria";

NORMAL_TRIVIA_QUESTIONS[2106] = "(World Leaders:): From which country was Phumibol Aduldet king?";
NORMAL_TRIVIA_ANSWERS1[2106] = "Thailand";

NORMAL_TRIVIA_QUESTIONS[2107] = "(World Leaders:): From which country was Ismet Inonu president?";
NORMAL_TRIVIA_ANSWERS1[2107] = "Turkey";

NORMAL_TRIVIA_QUESTIONS[2108] = "(World Leaders:): From which country was Battle Berres president?";
NORMAL_TRIVIA_ANSWERS1[2108] = "Uruguay";

NORMAL_TRIVIA_QUESTIONS[2109] = "(World Leaders:): From which country was Gustav V king?";
NORMAL_TRIVIA_ANSWERS1[2109] = "Sweden";

NORMAL_TRIVIA_QUESTIONS[2110] = "(WWI:): Who in Austria was killed on June 28 1914?";
NORMAL_TRIVIA_ANSWERS1[2110] = "Franz Ferdinand";

NORMAL_TRIVIA_QUESTIONS[2111] = "(WWI:): Who was killed in Paris on July 31 1914?";
NORMAL_TRIVIA_ANSWERS1[2111] = "Jean Jaures";

NORMAL_TRIVIA_QUESTIONS[2112] = "(WWI:): Who said 'Not kennt kein Gebot' on August 4 1914?";
NORMAL_TRIVIA_ANSWERS1[2112] = "Von Bethmann Hollweg";

NORMAL_TRIVIA_QUESTIONS[2113] = "(WWI:): Which Belgian city was taken by the Germans on August 4-17 1914?";
NORMAL_TRIVIA_ANSWERS1[2113] = "Liege";
NORMAL_TRIVIA_ANSWERS2[2113] = "Luik";

NORMAL_TRIVIA_QUESTIONS[2114] = "(WWI:): August 19 1914: Ultimatum from Japan to which country?";
NORMAL_TRIVIA_ANSWERS1[2114] = "Germany";

NORMAL_TRIVIA_QUESTIONS[2115] = "(WWI:): What's the name of the pope who died on August 20 1914?";
NORMAL_TRIVIA_ANSWERS1[2115] = "Pius X";

NORMAL_TRIVIA_QUESTIONS[2116] = "(WWI:): Which Belgian city was occupied on August 20 1914?";
NORMAL_TRIVIA_ANSWERS1[2116] = "Brussels";
NORMAL_TRIVIA_ANSWERS2[2116] = "Bruxelles";

NORMAL_TRIVIA_QUESTIONS[2117] = "(WWI:): August 23-31 1914: The Battle of?";
NORMAL_TRIVIA_ANSWERS1[2117] = "Tannenberg";

NORMAL_TRIVIA_QUESTIONS[2118] = "(WWI:): On September 3 1914, Reims was occupied by?";
NORMAL_TRIVIA_ANSWERS1[2118] = "The Germans";
NORMAL_TRIVIA_ANSWERS2[2118] = "Germany";

NORMAL_TRIVIA_QUESTIONS[2119] = "(WWI:): September 5 1914: Battle at?";
NORMAL_TRIVIA_ANSWERS1[2119] = "The Marne";
NORMAL_TRIVIA_ANSWERS2[2119] = "Marne";

NORMAL_TRIVIA_QUESTIONS[2120] = "(WWI:): September 8 1914: The fall of?";
NORMAL_TRIVIA_ANSWERS1[2120] = "Maubeuge";

NORMAL_TRIVIA_QUESTIONS[2121] = "(WWI:): Which English ship was destroyed by the German submarine U9 September 22 1914?";
NORMAL_TRIVIA_ANSWERS1[2121] = "Aboekir";
NORMAL_TRIVIA_ANSWERS2[2121] = "Hogue";
NORMAL_TRIVIA_ANSWERS3[2121] = "Cressy";

NORMAL_TRIVIA_QUESTIONS[2122] = "(WWI:): Which Belgian city was taken on October 9 1914?";
NORMAL_TRIVIA_ANSWERS1[2122] = "Antwerp";
NORMAL_TRIVIA_ANSWERS2[2122] = "Antwerpen";

NORMAL_TRIVIA_QUESTIONS[2123] = "(WWI:): Which Belgian city was taken on October 14 1914?";
NORMAL_TRIVIA_ANSWERS1[2123] = "Brugge";

NORMAL_TRIVIA_QUESTIONS[2124] = "(WWI:): Which Belgian city was taken on October 15 1914?";
NORMAL_TRIVIA_ANSWERS1[2124] = "Oostende";

NORMAL_TRIVIA_QUESTIONS[2125] = "(WWI:): Which Belgian city was taken on October 16 1914?";
NORMAL_TRIVIA_ANSWERS1[2125] = "Zeebrugge";

NORMAL_TRIVIA_QUESTIONS[2126] = "(WWI:): On November 7 1914, Tsingtau was taken by which country?";
NORMAL_TRIVIA_ANSWERS1[2126] = "Japan";

NORMAL_TRIVIA_QUESTIONS[2127] = "(WWI:): Which country's east coast was attacked by the Germans on January 19-20 1915?";
NORMAL_TRIVIA_ANSWERS1[2127] = "England";

NORMAL_TRIVIA_QUESTIONS[2128] = "(WWI:): German defeats who on February 4-22 1915?";
NORMAL_TRIVIA_ANSWERS1[2128] = "Russia";
NORMAL_TRIVIA_ANSWERS2[2128] = "The Russians";
NORMAL_TRIVIA_ANSWERS3[2128] = "Russians";

NORMAL_TRIVIA_QUESTIONS[2129] = "(WWI:): On April 25 1915, allied troups land where?";
NORMAL_TRIVIA_ANSWERS1[2129] = "Gallipolli";

NORMAL_TRIVIA_QUESTIONS[2130] = "(WWI:): Which city in Poland was taken on August 3 1915?";
NORMAL_TRIVIA_ANSWERS1[2130] = "Warsaw";

NORMAL_TRIVIA_QUESTIONS[2131] = "(WWI:): Which battle lasted from February 16 - December 16 1916?";
NORMAL_TRIVIA_ANSWERS1[2131] = "Verdun";
NORMAL_TRIVIA_ANSWERS2[2131] = "The Battle of Verdun";
NORMAL_TRIVIA_ANSWERS3[2131] = "Battle of Verdun";

NORMAL_TRIVIA_QUESTIONS[2132] = "(WWI:): Intervention by the US on March 15 1916 in which country?";
NORMAL_TRIVIA_ANSWERS1[2132] = "Mexico";

NORMAL_TRIVIA_QUESTIONS[2133] = "(WWI:): Which east european country enters /WWI on August 27 1916?";
NORMAL_TRIVIA_ANSWERS1[2133] = "Romania";

NORMAL_TRIVIA_QUESTIONS[2134] = "(WWI:): Who becomes president of the US on November 7 1916?";
NORMAL_TRIVIA_ANSWERS1[2134] = "Wilson";

NORMAL_TRIVIA_QUESTIONS[2135] = "(WWI:): Which city was occupied by the English on March 11 1917?";
NORMAL_TRIVIA_ANSWERS1[2135] = "Baghdad";

NORMAL_TRIVIA_QUESTIONS[2136] = "(WWI:): On March 16 1917, which country becomes a republic?";
NORMAL_TRIVIA_ANSWERS1[2136] = "Russia";

NORMAL_TRIVIA_QUESTIONS[2137] = "(WWI:): Which tsar was arrested on March 21 1916?";
NORMAL_TRIVIA_ANSWERS1[2137] = "Tsar Nicholas II";
NORMAL_TRIVIA_ANSWERS2[2137] = "Nicholas II";

NORMAL_TRIVIA_QUESTIONS[2138] = "(WWI:): Which north european city was occupied on September 3 1917?";
NORMAL_TRIVIA_ANSWERS1[2138] = "Riga";

NORMAL_TRIVIA_QUESTIONS[2139] = "(WWI:): The second 'October Revolution' on November 6-7 1917 was where?";
NORMAL_TRIVIA_ANSWERS1[2139] = "Russia";

NORMAL_TRIVIA_QUESTIONS[2140] = "(WWI:): Which Russian city was taken on March 1-3 1918?";
NORMAL_TRIVIA_ANSWERS1[2140] = "Kiev";

NORMAL_TRIVIA_QUESTIONS[2141] = "(WWI:): March 7 1918, peace between Germany and which other country?";
NORMAL_TRIVIA_ANSWERS1[2141] = "Finland";

NORMAL_TRIVIA_QUESTIONS[2142] = "(WWI:): On October 3 1918, Boris III became the king of which country?";
NORMAL_TRIVIA_ANSWERS1[2142] = "Bulgaria";

NORMAL_TRIVIA_QUESTIONS[2143] = "(WWI:): Who was killed on October 31 1917?";
NORMAL_TRIVIA_ANSWERS1[2143] = "Tisza";

NORMAL_TRIVIA_QUESTIONS[2144] = "(WWI:): In which German city started a revolution on November 9 1917?";
NORMAL_TRIVIA_ANSWERS1[2144] = "Berlin";

NORMAL_TRIVIA_QUESTIONS[2145] = "(Acronyms-Hardware): What does HDD stand for?";
NORMAL_TRIVIA_ANSWERS1[2145] = "Hard Disk Drive";

NORMAL_TRIVIA_QUESTIONS[2146] = "(Acronyms-Hardware): What does CPU stand for?";
NORMAL_TRIVIA_ANSWERS1[2146] = "Central Processing Unit";

NORMAL_TRIVIA_QUESTIONS[2147] = "(Acronyms-Networks): What does TCP stand for?";
NORMAL_TRIVIA_ANSWERS1[2147] = "Transmission Control Protocol";

NORMAL_TRIVIA_QUESTIONS[2148] = "(Acronyms-Hardware): What does ROM stand for?";
NORMAL_TRIVIA_ANSWERS1[2148] = "Read Only Memory";
NORMAL_TRIVIA_ANSWERS2[2148] = "Read-Only Memory";

NORMAL_TRIVIA_QUESTIONS[2149] = "(Acronyms-Networks): What does FTP stand for?";
NORMAL_TRIVIA_ANSWERS1[2149] = "File Transfer Protocol";

NORMAL_TRIVIA_QUESTIONS[2150] = "(Acronyms-Networks): What does USB stand for?";
NORMAL_TRIVIA_ANSWERS1[2150] = "Universal Serial Bus";

NORMAL_TRIVIA_QUESTIONS[2151] = "(Acronyms-Software): What does DLL stand for?";
NORMAL_TRIVIA_ANSWERS1[2151] = "Dynamic Link Library";

NORMAL_TRIVIA_QUESTIONS[2152] = "(Acronyms-Networks): What does LAN stand for?";
NORMAL_TRIVIA_ANSWERS1[2152] = "Local Area Network";
NORMAL_TRIVIA_ANSWERS2[2152] = "Local Access Network";

NORMAL_TRIVIA_QUESTIONS[2153] = "(Acronyms-Networks): What does WAN stand for?";
NORMAL_TRIVIA_ANSWERS1[2153] = "Wide Area Network";

NORMAL_TRIVIA_QUESTIONS[2154] = "(Acronyms-Networks): What does OC stand for?";
NORMAL_TRIVIA_ANSWERS1[2154] = "Optical Carrier";

NORMAL_TRIVIA_QUESTIONS[2155] = "(Acronyms-Networks): What does HTTP stand for?";
NORMAL_TRIVIA_ANSWERS1[2155] = "HyperText Transfer Protocol";

NORMAL_TRIVIA_QUESTIONS[2156] = "(Acronyms-Networks): What does IP stand for?";
NORMAL_TRIVIA_ANSWERS1[2156] = "Internet Protocol";

NORMAL_TRIVIA_QUESTIONS[2157] = "(Acronyms-Hardware): What does PnP stand for?";
NORMAL_TRIVIA_ANSWERS1[2157] = "Plug-and-Play";
NORMAL_TRIVIA_ANSWERS2[2157] = "plug and play";

NORMAL_TRIVIA_QUESTIONS[2158] = "(Acronyms-Hardware): What does DMA stand for?";
NORMAL_TRIVIA_ANSWERS1[2158] = "Direct Memory Access";

NORMAL_TRIVIA_QUESTIONS[2159] = "(Acronyms-Networks): What does WWW stand for?";
NORMAL_TRIVIA_ANSWERS1[2159] = "World Wide Web";

NORMAL_TRIVIA_QUESTIONS[2160] = "(Acronyms-Networks): What does URL stand for?";
NORMAL_TRIVIA_ANSWERS1[2160] = "Uniform Resource Locator";

NORMAL_TRIVIA_QUESTIONS[2161] = "(Acronyms-Software): COBOL stands for _____ Business Oriented Language";
NORMAL_TRIVIA_ANSWERS1[2161] = "Common";

NORMAL_TRIVIA_QUESTIONS[2162] = "(Acronums-Software): BASIC stands for _____ All purpose Symbolic Instruction Code";
NORMAL_TRIVIA_ANSWERS1[2162] = "Beginner's";
NORMAL_TRIVIA_ANSWERS2[2162] = "Beginner";

NORMAL_TRIVIA_QUESTIONS[2163] = "(History-Internet): Who invented the TCP/IP standard?";
NORMAL_TRIVIA_ANSWERS1[2163] = "Vint Cerf";
NORMAL_TRIVIA_ANSWERS2[2163] = "Cerf";
NORMAL_TRIVIA_ANSWERS3[2163] = "Vincent Cerf";

NORMAL_TRIVIA_QUESTIONS[2164] = "(History-Computers): What year was the Digital Millennium Act passed by Congress?";
NORMAL_TRIVIA_ANSWERS1[2164] = "1998";

NORMAL_TRIVIA_QUESTIONS[2165] = "(History-Internet): What year did Sun Microsystems release Java?";
NORMAL_TRIVIA_ANSWERS1[2165] = "1995";

NORMAL_TRIVIA_QUESTIONS[2166] = "(History-Internet): What was the first registered domain?";
NORMAL_TRIVIA_ANSWERS1[2166] = "Symbolic.com";
NORMAL_TRIVIA_ANSWERS2[2166] = "Symbolic";

NORMAL_TRIVIA_QUESTIONS[2167] = "(History-Internet): What year was the @ symbol set as a standard for e-mail?";
NORMAL_TRIVIA_ANSWERS1[2167] = "1972";

NORMAL_TRIVIA_QUESTIONS[2168] = "(History-Computers): What year did Intel release the 8080 microprocessor?";
NORMAL_TRIVIA_ANSWERS1[2168] = "1974";

NORMAL_TRIVIA_QUESTIONS[2169] = "(History-Computers): One year after the 8080, what first personal computer was released based upon it?";
NORMAL_TRIVIA_ANSWERS1[2169] = "Altair 8800";
NORMAL_TRIVIA_ANSWERS2[2169] = "Altair";

NORMAL_TRIVIA_QUESTIONS[2170] = "(History-Computers): What US District Judge declared Microsoft a monopoly in 1999?";
NORMAL_TRIVIA_ANSWERS1[2170] = "Thomas Penfield Jackson";
NORMAL_TRIVIA_ANSWERS2[2170] = "Jackson";

NORMAL_TRIVIA_QUESTIONS[2171] = "(History-Computers): In 1981 what operating system became available to the PC market?";
NORMAL_TRIVIA_ANSWERS1[2171] = "MS-DOS";
NORMAL_TRIVIA_ANSWERS2[2171] = "MSDos";
NORMAL_TRIVIA_ANSWERS3[2171] = "MS Dos";

NORMAL_TRIVIA_QUESTIONS[2172] = "(History-Computers): Who first coined the term 'cyberspace'?";
NORMAL_TRIVIA_ANSWERS1[2172] = "William Gibson";
NORMAL_TRIVIA_ANSWERS2[2172] = "Gibson";

NORMAL_TRIVIA_QUESTIONS[2173] = "(History-Internet): What was the name of the first wide-scale peer-to-peer music sharing application?";
NORMAL_TRIVIA_ANSWERS1[2173] = "Napster";

NORMAL_TRIVIA_QUESTIONS[2174] = "(History-Internet): What major browser company did America Online buy in 1999?";
NORMAL_TRIVIA_ANSWERS1[2174] = "Netscape";

NORMAL_TRIVIA_QUESTIONS[2175] = "(History-Internet): What domain did CNET buy for $15,000 in 1996?";
NORMAL_TRIVIA_ANSWERS1[2175] = "tv.com";
NORMAL_TRIVIA_ANSWERS2[2175] = "tv";

NORMAL_TRIVIA_QUESTIONS[2176] = "(History-Internet): business.com sold for $150,000 in what year?";
NORMAL_TRIVIA_ANSWERS1[2176] = "1997";

NORMAL_TRIVIA_QUESTIONS[2177] = "(History-Computers): Who is the regarded as the father of supercomputing?";
NORMAL_TRIVIA_ANSWERS1[2177] = "Seymour Cray";
NORMAL_TRIVIA_ANSWERS2[2177] = "Cray";

NORMAL_TRIVIA_QUESTIONS[2178] = "(History-Computers): What law says that the number of transistors doubles every 18 months?";
NORMAL_TRIVIA_ANSWERS1[2178] = "Moore's Law";
NORMAL_TRIVIA_ANSWERS2[2178] = "Moore";

NORMAL_TRIVIA_QUESTIONS[2179] = "(History-Computers): Who wrote the core of the Linux operating system in 1991?";
NORMAL_TRIVIA_ANSWERS1[2179] = "Linus Torvalds";
NORMAL_TRIVIA_ANSWERS2[2179] = "Torvalds";

NORMAL_TRIVIA_QUESTIONS[2180] = "(History-Computers): Bell Labs released what operating system in 1969?";
NORMAL_TRIVIA_ANSWERS1[2180] = "UNIX";

NORMAL_TRIVIA_QUESTIONS[2181] = "(History-Computers): What company first invented the modern mouse?";
NORMAL_TRIVIA_ANSWERS1[2181] = "Xerox";

NORMAL_TRIVIA_QUESTIONS[2182] = "(History-Computers): What Macintosh computer was first introduced by Apple in 1998?";
NORMAL_TRIVIA_ANSWERS1[2182] = "iMac";

NORMAL_TRIVIA_QUESTIONS[2183] = "(History-Computers): Who is current chairman of Microsoft Corporation?";
NORMAL_TRIVIA_ANSWERS1[2183] = "Bill Gates";
NORMAL_TRIVIA_ANSWERS2[2183] = "Gates";

NORMAL_TRIVIA_QUESTIONS[2184] = "(History-Computers): What modem standard was passed to replace X2 and K56flex in 1998?";
NORMAL_TRIVIA_ANSWERS1[2184] = "v.90";
NORMAL_TRIVIA_ANSWERS2[2184] = "v90";

NORMAL_TRIVIA_QUESTIONS[2185] = "(History-Computers): UNIX was the first operating system written in what programming language?";
NORMAL_TRIVIA_ANSWERS1[2185] = "C";

NORMAL_TRIVIA_QUESTIONS[2186] = "(Technical-Hardware): What is the common bit-bus for PCI components?";
NORMAL_TRIVIA_ANSWERS1[2186] = "32-bit";
NORMAL_TRIVIA_ANSWERS2[2186] = "32-bits";
NORMAL_TRIVIA_ANSWERS3[2186] = "32";

NORMAL_TRIVIA_QUESTIONS[2187] = "(Technical-Hardware): What is the common bit-bus for ISA components?";
NORMAL_TRIVIA_ANSWERS1[2187] = "16-bit";
NORMAL_TRIVIA_ANSWERS2[2187] = "16-bits";
NORMAL_TRIVIA_ANSWERS3[2187] = "16";

NORMAL_TRIVIA_QUESTIONS[2188] = "(Technical-Hardware): Most non-SCSI CD-ROMs conform to what EIDE standard?";
NORMAL_TRIVIA_ANSWERS1[2188] = "ATAPI";

NORMAL_TRIVIA_QUESTIONS[2189] = "(Technical-Hardware): What interface do most new graphics card conform to?";
NORMAL_TRIVIA_ANSWERS1[2189] = "AGP";

NORMAL_TRIVIA_QUESTIONS[2190] = "(Technical-Hardware): What multimedia instruction set were built into Intel's processors after 1997?";
NORMAL_TRIVIA_ANSWERS1[2190] = "MMX";

NORMAL_TRIVIA_QUESTIONS[2191] = "(Technical-Networks): What common network protoctol can utilize a bus or star topology?";
NORMAL_TRIVIA_ANSWERS1[2191] = "Ethernet";

NORMAL_TRIVIA_QUESTIONS[2192] = "(Technical-Networks): What proprietary network protocol did Apple develop?";
NORMAL_TRIVIA_ANSWERS1[2192] = "AppleTalk";

NORMAL_TRIVIA_QUESTIONS[2193] = "(Technical-Networks): How many bits are in a byte?";
NORMAL_TRIVIA_ANSWERS1[2193] = "eight";
NORMAL_TRIVIA_ANSWERS2[2193] = "8";
NORMAL_TRIVIA_ANSWERS3[2193] = "8-bits";

NORMAL_TRIVIA_QUESTIONS[2194] = "(Technical-Networks): What common broadband technology utilizes standard POTS?";
NORMAL_TRIVIA_ANSWERS1[2194] = "DSL";

NORMAL_TRIVIA_QUESTIONS[2195] = "(Technical-Networks): What common broadband technology utilizes coxial cables?";
NORMAL_TRIVIA_ANSWERS1[2195] = "Cable Modem";
NORMAL_TRIVIA_ANSWERS2[2195] = "cable";

NORMAL_TRIVIA_QUESTIONS[2196] = "(Technical-Hardware): What is the maximum speed USB 1.1 can transfer at?";
NORMAL_TRIVIA_ANSWERS1[2196] = "12 mbps";
NORMAL_TRIVIA_ANSWERS2[2196] = "12mbps";

NORMAL_TRIVIA_QUESTIONS[2197] = "(Technical-Hardware): What is the maximum speed USB 2.0 can transfer at?";
NORMAL_TRIVIA_ANSWERS1[2197] = "480 mbps";
NORMAL_TRIVIA_ANSWERS2[2197] = "480mbps";

NORMAL_TRIVIA_QUESTIONS[2198] = "(Technical-Hardware): What is the maximum speed FireWire can transfer at?";
NORMAL_TRIVIA_ANSWERS1[2198] = "400 mbps";
NORMAL_TRIVIA_ANSWERS2[2198] = "400mbps";

NORMAL_TRIVIA_QUESTIONS[2199] = "(Technical-Hardware): How many devices can USB support on a single chain?";
NORMAL_TRIVIA_ANSWERS1[2199] = "127";

NORMAL_TRIVIA_QUESTIONS[2200] = "(Technical-Networks): How fast is a standard 10BaseT network?";
NORMAL_TRIVIA_ANSWERS1[2200] = "10 mbps";
NORMAL_TRIVIA_ANSWERS2[2200] = "10mbps";

NORMAL_TRIVIA_QUESTIONS[2201] = "(Technical-Networks): What kind of jack does standard twisted-pair cable use?";
NORMAL_TRIVIA_ANSWERS1[2201] = "RJ-45";
NORMAL_TRIVIA_ANSWERS2[2201] = "RJ 45";

NORMAL_TRIVIA_QUESTIONS[2202] = "(Technical-Networks): How fast can a single ISDN B-channel transfer at?";
NORMAL_TRIVIA_ANSWERS1[2202] = "64kbps";
NORMAL_TRIVIA_ANSWERS2[2202] = "64k";

NORMAL_TRIVIA_QUESTIONS[2203] = "(Technical-Networks): 1.544 Mbps is the transfer rate of which common broadband technology?";
NORMAL_TRIVIA_ANSWERS1[2203] = "Tier-1 (T1)";
NORMAL_TRIVIA_ANSWERS2[2203] = "Tier-1";
NORMAL_TRIVIA_ANSWERS3[2203] = "T-1";

NORMAL_TRIVIA_QUESTIONS[2204] = "(Technical-Networks): 51.84 Mbps is the transfer rate of which common broadband technology?";
NORMAL_TRIVIA_ANSWERS1[2204] = "OC-1";
NORMAL_TRIVIA_ANSWERS2[2204] = "OC1";

NORMAL_TRIVIA_QUESTIONS[2205] = "(Product Knowledge): What is one of the 3 pillars of Siemens strength?";
NORMAL_TRIVIA_ANSWERS1[2205] = "Infinite Modularity, Ultimate Portability, Complete Information Access";
NORMAL_TRIVIA_ANSWERS2[2205] = "Modularity";
NORMAL_TRIVIA_ANSWERS3[2205] = "Portability";

NORMAL_TRIVIA_QUESTIONS[2206] = "(Product Knowledge): What modular monitors come standard with four channels?";
NORMAL_TRIVIA_ANSWERS1[2206] = "SC 7000 and SC 8000 monitors";
NORMAL_TRIVIA_ANSWERS2[2206] = "SC 7000";
NORMAL_TRIVIA_ANSWERS3[2206] = "SC7000";

NORMAL_TRIVIA_QUESTIONS[2207] = "(Product Knowledge): What modular monitor comes standard with six channels?";
NORMAL_TRIVIA_ANSWERS1[2207] = "SC 9000XL";

NORMAL_TRIVIA_QUESTIONS[2208] = "(Product Knowledge): What is the name of the INFINITY noninvasive cable management solution?";
NORMAL_TRIVIA_ANSWERS1[2208] = "MultiMed Pods (-5, -6, NeoMed)";
NORMAL_TRIVIA_ANSWERS2[2208] = "Multimed";
NORMAL_TRIVIA_ANSWERS3[2208] = "NeoMed";

NORMAL_TRIVIA_QUESTIONS[2209] = "(Product Knowledge): What is the name of the INFINITY invasive pressure cable management solution?";
NORMAL_TRIVIA_ANSWERS1[2209] = "HemoMed Pods (-2, -4, HemoMed)";
NORMAL_TRIVIA_ANSWERS2[2209] = "Hemomed";
NORMAL_TRIVIA_ANSWERS3[2209] = "Hemo-2";

NORMAL_TRIVIA_QUESTIONS[2210] = "(Product Knowledge): Can I use the HemoMed with the SC6002XL?";
NORMAL_TRIVIA_ANSWERS1[2210] = "No";

NORMAL_TRIVIA_QUESTIONS[2211] = "(Product Knowledge): What part of the etCO2&Respiratory Mechanics pod be used with the SC6002XL?";
NORMAL_TRIVIA_ANSWERS1[2211] = "etCO2 function";
NORMAL_TRIVIA_ANSWERS2[2211] = "etCO2";

NORMAL_TRIVIA_QUESTIONS[2212] = "(Product Knowledge): What cable would I order to connect a balloon pump to an INFINITY modular monitor?";
NORMAL_TRIVIA_ANSWERS1[2212] = "Analog output cable";
NORMAL_TRIVIA_ANSWERS2[2212] = "Analog";

NORMAL_TRIVIA_QUESTIONS[2213] = "(Anatomy&Physiology): What waves are seen on a normal ECG?";
NORMAL_TRIVIA_ANSWERS1[2213] = "In order: P wave, QRS complex, ST segment, T wave";
NORMAL_TRIVIA_ANSWERS2[2213] = "P wave";
NORMAL_TRIVIA_ANSWERS3[2213] = "QRS complex";

NORMAL_TRIVIA_QUESTIONS[2214] = "(Anatomy&Physiology): What is the normal pacemaker of the heart?";
NORMAL_TRIVIA_ANSWERS1[2214] = "SA node";

NORMAL_TRIVIA_QUESTIONS[2215] = "(Anatomy&Physiology): What are the four chambers of the heart?";
NORMAL_TRIVIA_ANSWERS1[2215] = "right atrium, right ventricle, left atrium, left ventricle";
NORMAL_TRIVIA_ANSWERS2[2215] = "left atrium";
NORMAL_TRIVIA_ANSWERS3[2215] = "right atrium";

NORMAL_TRIVIA_QUESTIONS[2216] = "(Anatomy&Physiology): What are the two most important factors in obtaining accurate noninvasive blood pressure readings?";
NORMAL_TRIVIA_ANSWERS1[2216] = "Correct cuff size and position";
NORMAL_TRIVIA_ANSWERS2[2216] = "cuff size";
NORMAL_TRIVIA_ANSWERS3[2216] = "position";

NORMAL_TRIVIA_QUESTIONS[2217] = "(Anatomy&Physiology): What do we call the pressure measurement from the right atrium?";
NORMAL_TRIVIA_ANSWERS1[2217] = "Central venous pressure";
NORMAL_TRIVIA_ANSWERS2[2217] = "cvp";
NORMAL_TRIVIA_ANSWERS3[2217] = "right atrial pressure";

NORMAL_TRIVIA_QUESTIONS[2218] = "(Anatomy&Physiology): What pressure do we measure when we inflate the balloon on the Swan-Ganz catheter?";
NORMAL_TRIVIA_ANSWERS1[2218] = "wedge pressure";
NORMAL_TRIVIA_ANSWERS2[2218] = "pulmonary wedge pressure";
NORMAL_TRIVIA_ANSWERS3[2218] = "wedge";

NORMAL_TRIVIA_QUESTIONS[2219] = "(Anatomy&Physiology): What is the process of measuring respirations with ECG leads called?";
NORMAL_TRIVIA_ANSWERS1[2219] = "Impedence";

NORMAL_TRIVIA_QUESTIONS[2220] = "(Trivia): What color reflects light from all parts of the visible spectrum?";
NORMAL_TRIVIA_ANSWERS1[2220] = "white";

NORMAL_TRIVIA_QUESTIONS[2221] = "(Trivia): Triceratops' tail was longer than its body? True or false?";
NORMAL_TRIVIA_ANSWERS1[2221] = "false";

NORMAL_TRIVIA_QUESTIONS[2222] = "(Trivia): Air bubbles in the center of a hair shaft cause hair to turn gray. True or false?";
NORMAL_TRIVIA_ANSWERS1[2222] = "false";

NORMAL_TRIVIA_QUESTIONS[2223] = "(Trivia): Cyan is what color?";
NORMAL_TRIVIA_ANSWERS1[2223] = "blue";

NORMAL_TRIVIA_QUESTIONS[2224] = "(Trivia): Tongue prints are as unique as fingerprints? True or false?";
NORMAL_TRIVIA_ANSWERS1[2224] = "true";

NORMAL_TRIVIA_QUESTIONS[2225] = "(Trivia): What day of the month is New Year's Day in the United States?";
NORMAL_TRIVIA_ANSWERS1[2225] = "1";
NORMAL_TRIVIA_ANSWERS2[2225] = "1st";
NORMAL_TRIVIA_ANSWERS3[2225] = "first";

NORMAL_TRIVIA_QUESTIONS[2226] = "(Trivia): How many states begin with the letter \"A\"?";
NORMAL_TRIVIA_ANSWERS1[2226] = "4";
NORMAL_TRIVIA_ANSWERS2[2226] = "four";

NORMAL_TRIVIA_QUESTIONS[2227] = "(Trivia): The right lung takes in more air than the left? True or false?";
NORMAL_TRIVIA_ANSWERS1[2227] = "true";

NORMAL_TRIVIA_QUESTIONS[2228] = "(Trivia): How many continents are there?";
NORMAL_TRIVIA_ANSWERS1[2228] = "7";
NORMAL_TRIVIA_ANSWERS2[2228] = "seven";

NORMAL_TRIVIA_QUESTIONS[2229] = "(Trivia): How many times did Dorothy click her heels together?";
NORMAL_TRIVIA_ANSWERS1[2229] = "3";
NORMAL_TRIVIA_ANSWERS2[2229] = "three";

NORMAL_TRIVIA_QUESTIONS[2230] = "(Trivia): In 1995 what color M&M was substituted for tan?";
NORMAL_TRIVIA_ANSWERS1[2230] = "blue";

NORMAL_TRIVIA_QUESTIONS[2231] = "(Trivia): How many wonders of the ancient world were there?";
NORMAL_TRIVIA_ANSWERS1[2231] = "7";
NORMAL_TRIVIA_ANSWERS2[2231] = "seven";

NORMAL_TRIVIA_QUESTIONS[2232] = "(Trivia): The human body has 45 miles of nerves. True or false?";
NORMAL_TRIVIA_ANSWERS1[2232] = "true";

NORMAL_TRIVIA_QUESTIONS[2233] = "(Trivia): Besides red and white, what other color is on the flag of Thailand?";
NORMAL_TRIVIA_ANSWERS1[2233] = "blue";

NORMAL_TRIVIA_QUESTIONS[2234] = "(Trivia): What color is Lisa's necklace on The Simpsons?";
NORMAL_TRIVIA_ANSWERS1[2234] = "white";

NORMAL_TRIVIA_QUESTIONS[2235] = "(Trivia): The Pacific Ocean encloses an area larger than all the land surfaces of the earth put together. True or false?";
NORMAL_TRIVIA_ANSWERS1[2235] = "true";

NORMAL_TRIVIA_QUESTIONS[2236] = "(Trivia): How many outs are in a double play?";
NORMAL_TRIVIA_ANSWERS1[2236] = "2";
NORMAL_TRIVIA_ANSWERS2[2236] = "two";

NORMAL_TRIVIA_QUESTIONS[2237] = "(Trivia): How many races are run each year at the Indianapolis Speedway?";
NORMAL_TRIVIA_ANSWERS1[2237] = "1";
NORMAL_TRIVIA_ANSWERS2[2237] = "one";

NORMAL_TRIVIA_QUESTIONS[2238] = "(Trivia): Robert Todd Lincoln, son of Abraham Lincoln, was present at the assassinations of three presidents. True or false?";
NORMAL_TRIVIA_ANSWERS1[2238] = "true";

NORMAL_TRIVIA_QUESTIONS[2239] = "(Trivia): How many months does the average worker ant live?";
NORMAL_TRIVIA_ANSWERS1[2239] = "3";
NORMAL_TRIVIA_ANSWERS2[2239] = "three";

NORMAL_TRIVIA_QUESTIONS[2240] = "(Trivia): What color is a giraffe's tongue?";
NORMAL_TRIVIA_ANSWERS1[2240] = "black";

NORMAL_TRIVIA_QUESTIONS[2241] = "(Trivia): Curious George's friend was The Man in the what color hat?";
NORMAL_TRIVIA_ANSWERS1[2241] = "yellow";

NORMAL_TRIVIA_QUESTIONS[2242] = "(Trivia): There are more insects in one square mile of rural land than there are human beings on the entire earth. True or false?";
NORMAL_TRIVIA_ANSWERS1[2242] = "true";

NORMAL_TRIVIA_QUESTIONS[2243] = "(Trivia): What is the greatest number of regulation baseballs a person has ever held in one hand?";
NORMAL_TRIVIA_ANSWERS1[2243] = "9";
NORMAL_TRIVIA_ANSWERS2[2243] = "nine";

NORMAL_TRIVIA_QUESTIONS[2244] = "(Trivia): What color blood does Mr. Spock have?";
NORMAL_TRIVIA_ANSWERS1[2244] = "green";

NORMAL_TRIVIA_QUESTIONS[2245] = "(Trivia): How many countries are there in Central America?";
NORMAL_TRIVIA_ANSWERS1[2245] = "7";
NORMAL_TRIVIA_ANSWERS2[2245] = "seven";

NORMAL_TRIVIA_QUESTIONS[2246] = "(Trivia): What two colors make up the flag of Japan?";
NORMAL_TRIVIA_ANSWERS1[2246] = "red and white";
NORMAL_TRIVIA_ANSWERS2[2246] = "white and red";
NORMAL_TRIVIA_ANSWERS3[2246] = "red,white";

NORMAL_TRIVIA_QUESTIONS[2247] = "(Trivia): How many countries in South America border the Pacific Ocean?";
NORMAL_TRIVIA_ANSWERS1[2247] = "4";
NORMAL_TRIVIA_ANSWERS2[2247] = "four";

NORMAL_TRIVIA_QUESTIONS[2248] = "(Trivia): Spiders never spin webs in structures made of chestnut wood. True or false?";
NORMAL_TRIVIA_ANSWERS1[2248] = "true";

NORMAL_TRIVIA_QUESTIONS[2249] = "(Trivia): The card game Twenty-one is also known as what?";
NORMAL_TRIVIA_ANSWERS1[2249] = "blackjack";
NORMAL_TRIVIA_ANSWERS2[2249] = "black jack";

NORMAL_TRIVIA_QUESTIONS[2250] = "(Trivia): How many feet tall is the average giraffe at birth?";
NORMAL_TRIVIA_ANSWERS1[2250] = "6";
NORMAL_TRIVIA_ANSWERS2[2250] = "six";

NORMAL_TRIVIA_QUESTIONS[2251] = "(Trivia): More people are killed each year by honeybees than by poisonous snakes. True or false?";
NORMAL_TRIVIA_ANSWERS1[2251] = "true";

NORMAL_TRIVIA_QUESTIONS[2252] = "(Trivia): How many books in the Torah?";
NORMAL_TRIVIA_ANSWERS1[2252] = "5";
NORMAL_TRIVIA_ANSWERS2[2252] = "five";

NORMAL_TRIVIA_QUESTIONS[2253] = "(Trivia): How many pounds of milk does it take to make a pound of natural cheese?";
NORMAL_TRIVIA_ANSWERS1[2253] = "10";
NORMAL_TRIVIA_ANSWERS2[2253] = "ten";

NORMAL_TRIVIA_QUESTIONS[2254] = "(Trivia): The deer botfly can fly faster than a jet plane. True or false?";
NORMAL_TRIVIA_ANSWERS1[2254] = "true";

NORMAL_TRIVIA_QUESTIONS[2255] = "(Trivia): On Sesame Street, what color is Elmo's nose?";
NORMAL_TRIVIA_ANSWERS1[2255] = "orange";

NORMAL_TRIVIA_QUESTIONS[2256] = "(Trivia): How many pints of saliva does the average human mouth produce daily?";
NORMAL_TRIVIA_ANSWERS1[2256] = "2";
NORMAL_TRIVIA_ANSWERS2[2256] = "two";

NORMAL_TRIVIA_QUESTIONS[2257] = "(Trivia): \"Smoke on the Water\" was recorded by which group?";
NORMAL_TRIVIA_ANSWERS1[2257] = "Deep Purple";

NORMAL_TRIVIA_QUESTIONS[2258] = "(Trivia): How many eyelids do birds have on each eye?";
NORMAL_TRIVIA_ANSWERS1[2258] = "3";
NORMAL_TRIVIA_ANSWERS2[2258] = "three";

NORMAL_TRIVIA_QUESTIONS[2259] = "(Trivia): What color is the outside of a primary rainbow?";
NORMAL_TRIVIA_ANSWERS1[2259] = "red";

NORMAL_TRIVIA_QUESTIONS[2260] = "(Trivia): What is the closest foreign country to Alaska?";
NORMAL_TRIVIA_ANSWERS1[2260] = "Canada";

NORMAL_TRIVIA_QUESTIONS[2261] = "(Trivia): What year did World War I (WWI) start in?";
NORMAL_TRIVIA_ANSWERS1[2261] = "1914";

NORMAL_TRIVIA_QUESTIONS[2262] = "(Trivia): How many rows of pins are there in tenpin bowling?";
NORMAL_TRIVIA_ANSWERS1[2262] = "4";
NORMAL_TRIVIA_ANSWERS2[2262] = "four";

NORMAL_TRIVIA_QUESTIONS[2263] = "(Trivia): Who composed \"Twinke, Twinkle, Little Star\" at the age of five?";
NORMAL_TRIVIA_ANSWERS1[2263] = "Wolfgang Mozart";
NORMAL_TRIVIA_ANSWERS2[2263] = "Mozart";
NORMAL_TRIVIA_ANSWERS3[2263] = "Amadeus";

NORMAL_TRIVIA_QUESTIONS[2264] = "(Trivia): What's the motto of the Boy Scouts?";
NORMAL_TRIVIA_ANSWERS1[2264] = "Be prepared";

NORMAL_TRIVIA_QUESTIONS[2265] = "(Trivia): What was Paul Bunyan's ox's name?";
NORMAL_TRIVIA_ANSWERS1[2265] = "Babe";

NORMAL_TRIVIA_QUESTIONS[2266] = "(Trivia): What state is Mount McKinley in?";
NORMAL_TRIVIA_ANSWERS1[2266] = "Alaska";

NORMAL_TRIVIA_QUESTIONS[2267] = "(Trivia): What nationality was Aladdin?";
NORMAL_TRIVIA_ANSWERS1[2267] = "Chinese";

NORMAL_TRIVIA_QUESTIONS[2268] = "(Trivia): What's the world's largest coral reef?";
NORMAL_TRIVIA_ANSWERS1[2268] = "The Great Barrier Reef";
NORMAL_TRIVIA_ANSWERS2[2268] = "Great Barrier Reef";
NORMAL_TRIVIA_ANSWERS3[2268] = "Great Barrier";

NORMAL_TRIVIA_QUESTIONS[2269] = "(Trivia): Who did Lurch work for?";
NORMAL_TRIVIA_ANSWERS1[2269] = "The Addams family";
NORMAL_TRIVIA_ANSWERS2[2269] = "Addams";
NORMAL_TRIVIA_ANSWERS3[2269] = "Adams";

NORMAL_TRIVIA_QUESTIONS[2270] = "(Trivia): How many US states border California?";
NORMAL_TRIVIA_ANSWERS1[2270] = "3";
NORMAL_TRIVIA_ANSWERS2[2270] = "three";

NORMAL_TRIVIA_QUESTIONS[2271] = "(Trivia): What's the capital of the Netherlands?";
NORMAL_TRIVIA_ANSWERS1[2271] = "Amsterdam";

NORMAL_TRIVIA_QUESTIONS[2272] = "(Trivia): What phrase does Dorothy repeat as she clicks her ruby shoes to return to Kansas?";
NORMAL_TRIVIA_ANSWERS1[2272] = "There's no place like home";

NORMAL_TRIVIA_QUESTIONS[2273] = "(Trivia): Do mosquitoes have teeth?";
NORMAL_TRIVIA_ANSWERS1[2273] = "Yes";

NORMAL_TRIVIA_QUESTIONS[2274] = "(Trivia): What's the second-largest continent?";
NORMAL_TRIVIA_ANSWERS1[2274] = "Africa";

NORMAL_TRIVIA_QUESTIONS[2275] = "(Trivia): Who does Alice follow down the hole?";
NORMAL_TRIVIA_ANSWERS1[2275] = "The White Rabbit";
NORMAL_TRIVIA_ANSWERS2[2275] = "Rabbit";

NORMAL_TRIVIA_QUESTIONS[2276] = "(Trivia): How many sides does a hexagon have?";
NORMAL_TRIVIA_ANSWERS1[2276] = "6";
NORMAL_TRIVIA_ANSWERS2[2276] = "six";

NORMAL_TRIVIA_QUESTIONS[2277] = "(Trivia): What was the motto of the Three Musketeers?";
NORMAL_TRIVIA_ANSWERS1[2277] = "All for one, one for all";
NORMAL_TRIVIA_ANSWERS2[2277] = "all for one";
NORMAL_TRIVIA_ANSWERS3[2277] = "one for all";

NORMAL_TRIVIA_QUESTIONS[2278] = "(Trivia): What are the clay targets in trap shooting called?";
NORMAL_TRIVIA_ANSWERS1[2278] = "Pigeons";
NORMAL_TRIVIA_ANSWERS2[2278] = "pigons";
NORMAL_TRIVIA_ANSWERS3[2278] = "pidgeons";

NORMAL_TRIVIA_QUESTIONS[2279] = "(Trivia): What has 1,792 steps?";
NORMAL_TRIVIA_ANSWERS1[2279] = "The Eiffel Tower";
NORMAL_TRIVIA_ANSWERS2[2279] = "Eiffel";
NORMAL_TRIVIA_ANSWERS3[2279] = "Eifel";

NORMAL_TRIVIA_QUESTIONS[2280] = "(Trivia): What do you take Dramamine for?";
NORMAL_TRIVIA_ANSWERS1[2280] = "Motion sickness";

NORMAL_TRIVIA_QUESTIONS[2281] = "(Trivia): What did the Seven Dwarfs do for a living?";
NORMAL_TRIVIA_ANSWERS1[2281] = "They were miners";
NORMAL_TRIVIA_ANSWERS2[2281] = "mined";
NORMAL_TRIVIA_ANSWERS3[2281] = "miner";

NORMAL_TRIVIA_QUESTIONS[2282] = "(Trivia): What did the three little kittens lose?";
NORMAL_TRIVIA_ANSWERS1[2282] = "Their mittens";
NORMAL_TRIVIA_ANSWERS2[2282] = "mittens";

NORMAL_TRIVIA_QUESTIONS[2283] = "(Trivia): What zone varies from batter to batter in baseball?";
NORMAL_TRIVIA_ANSWERS1[2283] = "The strike zone";
NORMAL_TRIVIA_ANSWERS2[2283] = "strike";

NORMAL_TRIVIA_QUESTIONS[2284] = "(Trivia): What US State includes the San Juan Islands?";
NORMAL_TRIVIA_ANSWERS1[2284] = "Washington";

NORMAL_TRIVIA_QUESTIONS[2285] = "(Trivia): What is the most commonly-used punctuation mark?";
NORMAL_TRIVIA_ANSWERS1[2285] = "The comma";
NORMAL_TRIVIA_ANSWERS2[2285] = "comma";

NORMAL_TRIVIA_QUESTIONS[2286] = "(Trivia): What term describes an animal with a constant blood temperature?";
NORMAL_TRIVIA_ANSWERS1[2286] = "Warm blooded";

NORMAL_TRIVIA_QUESTIONS[2287] = "(Trivia): What is the largest artery in the human body?";
NORMAL_TRIVIA_ANSWERS1[2287] = "The aorta";
NORMAL_TRIVIA_ANSWERS2[2287] = "aorta";

NORMAL_TRIVIA_QUESTIONS[2288] = "(Trivia): How many bones are there in the human body?";
NORMAL_TRIVIA_ANSWERS1[2288] = "206";

NORMAL_TRIVIA_QUESTIONS[2289] = "(Trivia): What desert embraces the sunniest spot on the Earth?";
NORMAL_TRIVIA_ANSWERS1[2289] = "The Sahara";
NORMAL_TRIVIA_ANSWERS2[2289] = "Sahara";

NORMAL_TRIVIA_QUESTIONS[2290] = "(Trivia): What musical group did the Wilson brothers form in 1961?";
NORMAL_TRIVIA_ANSWERS1[2290] = "The Beach Boys";
NORMAL_TRIVIA_ANSWERS2[2290] = "beach boys";

NORMAL_TRIVIA_QUESTIONS[2291] = "(Trivia): What Dr. Seuss character steals Christmas?";
NORMAL_TRIVIA_ANSWERS1[2291] = "The Grinch";
NORMAL_TRIVIA_ANSWERS2[2291] = "grinch";

NORMAL_TRIVIA_QUESTIONS[2292] = "(Trivia): What's removed in a splenectomy?";
NORMAL_TRIVIA_ANSWERS1[2292] = "The spleen";
NORMAL_TRIVIA_ANSWERS2[2292] = "spleen";

NORMAL_TRIVIA_QUESTIONS[2293] = "(Trivia): What's the world's largest and heaviest animal?";
NORMAL_TRIVIA_ANSWERS1[2293] = "The blue whale";
NORMAL_TRIVIA_ANSWERS2[2293] = "blue whale";

NORMAL_TRIVIA_QUESTIONS[2294] = "(Trivia): What's the only bird that gives us leather?";
NORMAL_TRIVIA_ANSWERS1[2294] = "The ostrich";
NORMAL_TRIVIA_ANSWERS2[2294] = "ostrich";

NORMAL_TRIVIA_QUESTIONS[2295] = "(Trivia): What's the primary color with the shortest name?";
NORMAL_TRIVIA_ANSWERS1[2295] = "Red";

NORMAL_TRIVIA_QUESTIONS[2296] = "(Trivia): What's the Roman Numeral for 64?";
NORMAL_TRIVIA_ANSWERS1[2296] = "LXIV";

NORMAL_TRIVIA_QUESTIONS[2297] = "(Trivia): Where is the human skin the thickest?";
NORMAL_TRIVIA_ANSWERS1[2297] = "The back";
NORMAL_TRIVIA_ANSWERS2[2297] = "back";

NORMAL_TRIVIA_QUESTIONS[2298] = "(Trivia): Where does Yogi Bear live?";
NORMAL_TRIVIA_ANSWERS1[2298] = "Jellystone National park";
NORMAL_TRIVIA_ANSWERS2[2298] = "Jellystone";

NORMAL_TRIVIA_QUESTIONS[2299] = "(Trivia): Who lived at 221B Baker Street?";
NORMAL_TRIVIA_ANSWERS1[2299] = "Sherlock Holmes";
NORMAL_TRIVIA_ANSWERS2[2299] = "Sherlock";

NORMAL_TRIVIA_QUESTIONS[2300] = "(Trivia): How many holes are there in a tenpin bowling ball?";
NORMAL_TRIVIA_ANSWERS1[2300] = "3";
NORMAL_TRIVIA_ANSWERS2[2300] = "three";

NORMAL_TRIVIA_QUESTIONS[2301] = "(Trivia): What bird's a symbol of peace?";
NORMAL_TRIVIA_ANSWERS1[2301] = "The dove";
NORMAL_TRIVIA_ANSWERS2[2301] = "dove";

NORMAL_TRIVIA_QUESTIONS[2302] = "(Trivia): When Sherlock Holmes is stumped, who does he turn to?";
NORMAL_TRIVIA_ANSWERS1[2302] = "his brother, Mycroft Holmes";
NORMAL_TRIVIA_ANSWERS2[2302] = "Mycroft";

NORMAL_TRIVIA_QUESTIONS[2303] = "(Trivia): You PING a computer on a network - what are the letters PING an acronym for?";
NORMAL_TRIVIA_ANSWERS1[2303] = "Packet INternet Groper";
NORMAL_TRIVIA_ANSWERS2[2303] = "Groper";

NORMAL_TRIVIA_QUESTIONS[2304] = "(Trivia): Who, along with Bill Gates, started Microsoft?";
NORMAL_TRIVIA_ANSWERS1[2304] = "Paul Allen";
NORMAL_TRIVIA_ANSWERS2[2304] = "Allen";

NORMAL_TRIVIA_QUESTIONS[2305] = "(Trivia): In \"The Emperor's New Groove\", who did the voice for Pacha, the villager?";
NORMAL_TRIVIA_ANSWERS1[2305] = "John Goodman";
NORMAL_TRIVIA_ANSWERS2[2305] = "Goodman";

NORMAL_TRIVIA_QUESTIONS[2306] = "(Trivia): What do you call the smiley face and other symbols you type on the computer?";
NORMAL_TRIVIA_ANSWERS1[2306] = "Emoticons";

NORMAL_TRIVIA_QUESTIONS[2307] = "(Trivia): How many bytes are in one kilobyte (KB)?";
NORMAL_TRIVIA_ANSWERS1[2307] = "1024";

NORMAL_TRIVIA_QUESTIONS[2308] = "(Trivia): What would you use a Self Contained Underwater Breathing Apparatus for?";
NORMAL_TRIVIA_ANSWERS1[2308] = "Scuba diving";
NORMAL_TRIVIA_ANSWERS2[2308] = "Scuba";

NORMAL_TRIVIA_QUESTIONS[2309] = "(Trivia): What frequency, used by phone hackers to make free calls, is the name of a hacker magazine?";
NORMAL_TRIVIA_ANSWERS1[2309] = "2600";

NORMAL_TRIVIA_QUESTIONS[2310] = "(Trivia): What dial-up service was used by the characters in \"You've Got Mail\"?";
NORMAL_TRIVIA_ANSWERS1[2310] = "America Online";
NORMAL_TRIVIA_ANSWERS2[2310] = "America";
NORMAL_TRIVIA_ANSWERS3[2310] = "AOL";

NORMAL_TRIVIA_QUESTIONS[2311] = "(Trivia): What is the altitude of Mount Everest?";
NORMAL_TRIVIA_ANSWERS1[2311] = "29,028 feet or 8848 meters";
NORMAL_TRIVIA_ANSWERS2[2311] = "29028";
NORMAL_TRIVIA_ANSWERS3[2311] = "8848";

NORMAL_TRIVIA_QUESTIONS[2312] = "(Dance): Who invented a close fitting garment worn by dancers?";
NORMAL_TRIVIA_ANSWERS1[2312] = "Jules Leotard";
NORMAL_TRIVIA_ANSWERS2[2312] = "Leotard";

NORMAL_TRIVIA_QUESTIONS[2313] = "(Literature): Who wrote \"The Sun Also Rises\" ?";
NORMAL_TRIVIA_ANSWERS1[2313] = "Ernest Hemingway";
NORMAL_TRIVIA_ANSWERS2[2313] = "Hemingway";

NORMAL_TRIVIA_QUESTIONS[2314] = "(History): TRUE OR FALSE: The star in the upper left corner of a United States flag symbolizes the State of Delaware which was the first state to ratify the Constitution.";
NORMAL_TRIVIA_ANSWERS1[2314] = "false";

NORMAL_TRIVIA_QUESTIONS[2315] = "(Entertainment): TRUE OR FALSE: Gene Wilder and Richard Pryor co-starred in Mel Brooks' classic comedy Young Frankenstein. ";
NORMAL_TRIVIA_ANSWERS1[2315] = "false";

NORMAL_TRIVIA_QUESTIONS[2316] = "(People): What is Lee J. Cobb's middle name?";
NORMAL_TRIVIA_ANSWERS1[2316] = "Jacoby";

NORMAL_TRIVIA_QUESTIONS[2317] = "(Magazines): TRUE OR FALSE: Better Homes magazine provides \"A limited warranty to consumers: Replacement or refund if defective.\"";
NORMAL_TRIVIA_ANSWERS1[2317] = "false";

NORMAL_TRIVIA_QUESTIONS[2318] = "(Science): TRUE OR FALSE: Sound travels faster through the air than underwater.";
NORMAL_TRIVIA_ANSWERS1[2318] = "false";

NORMAL_TRIVIA_QUESTIONS[2319] = "(Magazines): TRUE OR FALSE: The biweekly publication Life is the only People knockoff to have survived.";
NORMAL_TRIVIA_ANSWERS1[2319] = "false";

NORMAL_TRIVIA_QUESTIONS[2320] = "(Art): Dominican Frairs of Santa Maria, Milan could dine in the shadow of what masterpiece.";
NORMAL_TRIVIA_ANSWERS1[2320] = "The Last Supper";
NORMAL_TRIVIA_ANSWERS2[2320] = "Last Supper";

NORMAL_TRIVIA_QUESTIONS[2321] = "(Entertainment): In what state is Andy Griffith's Mayberry located?";
NORMAL_TRIVIA_ANSWERS1[2321] = "North Carolina";
NORMAL_TRIVIA_ANSWERS2[2321] = "NC";

NORMAL_TRIVIA_QUESTIONS[2322] = "(History): In 1969, Neil Armstrong and Edwin (Buzz) Aldrin became the first men to walk on the moon. What was the name of their space craft?";
NORMAL_TRIVIA_ANSWERS1[2322] = "Apollo 11";
NORMAL_TRIVIA_ANSWERS2[2322] = "Apollo XI";

NORMAL_TRIVIA_QUESTIONS[2323] = "(History): How many stones did David carry into battle with Goliath?";
NORMAL_TRIVIA_ANSWERS1[2323] = "five";
NORMAL_TRIVIA_ANSWERS2[2323] = "5";

NORMAL_TRIVIA_QUESTIONS[2324] = "(Nature): What produces the substance known as royal jelly?";
NORMAL_TRIVIA_ANSWERS1[2324] = "Honey Bees";
NORMAL_TRIVIA_ANSWERS2[2324] = "Bees";
NORMAL_TRIVIA_ANSWERS3[2324] = "Bee";

NORMAL_TRIVIA_QUESTIONS[2325] = "(Sports): Where would you have found the famed Murderer's Row?";
NORMAL_TRIVIA_ANSWERS1[2325] = "Yankee Stadium";
NORMAL_TRIVIA_ANSWERS2[2325] = "Yankee";

NORMAL_TRIVIA_QUESTIONS[2326] = "(Architecture): Which of these buildings is the shortest: Toronto Tower, Empire State Building, Eiffel Tower, Washington Monument.";
NORMAL_TRIVIA_ANSWERS1[2326] = "Washington Monument";
NORMAL_TRIVIA_ANSWERS2[2326] = "Washington";

NORMAL_TRIVIA_QUESTIONS[2327] = "(Geography): TRUE OR FALSE: Wales is a county in the United Kingdom.";
NORMAL_TRIVIA_ANSWERS1[2327] = "false";

NORMAL_TRIVIA_QUESTIONS[2328] = "(Geography): TRUE OR FALSE: Mexico City is slowly sinking into the ground.";
NORMAL_TRIVIA_ANSWERS1[2328] = "true";

NORMAL_TRIVIA_QUESTIONS[2329] = "(Geography): Mount Lofty Range and the Grampian Mountains are located in what Southern Hemisphere country?";
NORMAL_TRIVIA_ANSWERS1[2329] = "Australia";

NORMAL_TRIVIA_QUESTIONS[2330] = "(Geography): Maine is the only state in the U.S. that borders exactly one other state. What is the state it borders?";
NORMAL_TRIVIA_ANSWERS1[2330] = "New Hampshire";
NORMAL_TRIVIA_ANSWERS2[2330] = "Hampshire";

NORMAL_TRIVIA_QUESTIONS[2331] = "(Geography): Where can the Grand Canyon be found?";
NORMAL_TRIVIA_ANSWERS1[2331] = "Arizona";

NORMAL_TRIVIA_QUESTIONS[2332] = "(Geography): Stone mountain is the only mountain in the world that is actually growing in size because it is made out of granite.  In what United States capital is this mountain located?";
NORMAL_TRIVIA_ANSWERS1[2332] = "Atlanta";

NORMAL_TRIVIA_QUESTIONS[2333] = "(Geography): What country was formerly known as New Holland?";
NORMAL_TRIVIA_ANSWERS1[2333] = "Australia";

NORMAL_TRIVIA_QUESTIONS[2334] = "(History): Who was the oldest king to succeed to the British throne?";
NORMAL_TRIVIA_ANSWERS1[2334] = "William IV";
NORMAL_TRIVIA_ANSWERS2[2334] = "William 4";

NORMAL_TRIVIA_QUESTIONS[2335] = "(History): King Henry the VIII of England had how many wives?";
NORMAL_TRIVIA_ANSWERS1[2335] = "six";
NORMAL_TRIVIA_ANSWERS2[2335] = "6";

NORMAL_TRIVIA_QUESTIONS[2336] = "(History): What was the first state to be readmitted to the union after the civil war?";
NORMAL_TRIVIA_ANSWERS1[2336] = "Tennessee";

NORMAL_TRIVIA_QUESTIONS[2337] = "(History): Howard Carter made the startling discovery of King Tut's tomb in what year?";
NORMAL_TRIVIA_ANSWERS1[2337] = "1922";

NORMAL_TRIVIA_QUESTIONS[2338] = "(Movie Quotes): What movie is this quote from: \"They may take our lives, but they will never take OUR FREEDOM!!\"";
NORMAL_TRIVIA_ANSWERS1[2338] = "Braveheart";

NORMAL_TRIVIA_QUESTIONS[2339] = "(Movie Quotes): \"I soiled my armor I was so scared!\" is from which movie?";
NORMAL_TRIVIA_ANSWERS1[2339] = "Monty Python and the Holy Grail";
NORMAL_TRIVIA_ANSWERS2[2339] = "Grail";
NORMAL_TRIVIA_ANSWERS3[2339] = "Monty";

NORMAL_TRIVIA_QUESTIONS[2340] = "(Movie Quotes): \"The garbage chute was a wonderful idea. What an incredible smell you're discovered.\" is from which movie?";
NORMAL_TRIVIA_ANSWERS1[2340] = "Star Wars";

NORMAL_TRIVIA_QUESTIONS[2341] = "(Movie Quotes): \"I've been dead once, already. It's very liberating.\" is from which movie?";
NORMAL_TRIVIA_ANSWERS1[2341] = "Batman";

NORMAL_TRIVIA_QUESTIONS[2342] = "(Movie Quotes): \"Just the facts, ma'am.\" is from which movie?";
NORMAL_TRIVIA_ANSWERS1[2342] = "Dragnet";

NORMAL_TRIVIA_QUESTIONS[2343] = "(Geography): The first completely automated, robotic cow milking machine was invented by which country?";
NORMAL_TRIVIA_ANSWERS1[2343] = "Denmark";

NORMAL_TRIVIA_QUESTIONS[2344] = "(Halloween): What is the original name for Halloween?";
NORMAL_TRIVIA_ANSWERS1[2344] = "All Hallows Eve";

NORMAL_TRIVIA_QUESTIONS[2345] = "(Halloween): What is the name for a male witch?";
NORMAL_TRIVIA_ANSWERS1[2345] = "Warlock";

NORMAL_TRIVIA_QUESTIONS[2346] = "(Halloween): In Casper, the movie starring Christina Ricci, Casper's uncles' names were: Fatso, Stinky, and What ______?";
NORMAL_TRIVIA_ANSWERS1[2346] = "Stretch";

NORMAL_TRIVIA_QUESTIONS[2347] = "(Halloween): What is the correct spelling for a lit and carved pumkin?";
NORMAL_TRIVIA_ANSWERS1[2347] = "Jack-o-Lantern";

NORMAL_TRIVIA_QUESTIONS[2348] = "(Halloween): When a black cat crosses your path, what does it usually mean (in the USA)?";
NORMAL_TRIVIA_ANSWERS1[2348] = "Bad Luck";

NORMAL_TRIVIA_QUESTIONS[2349] = "(Halloween): Ghosts are known to haunt what?";
NORMAL_TRIVIA_ANSWERS1[2349] = "Houses";

NORMAL_TRIVIA_QUESTIONS[2350] = "(Halloween): What do children usually get in return when 'Trick or Treat' is expressed?";
NORMAL_TRIVIA_ANSWERS1[2350] = "Candy";

NORMAL_TRIVIA_QUESTIONS[2351] = "(Halloween): What type of monster dies from a silver bullet?";
NORMAL_TRIVIA_ANSWERS1[2351] = "Werewolf";

NORMAL_TRIVIA_QUESTIONS[2352] = "(Halloween): In the old days, what was the purpose of dressing up in costumes?";
NORMAL_TRIVIA_ANSWERS1[2352] = "To scare off ghosts";

NORMAL_TRIVIA_QUESTIONS[2353] = "(History): On what day did Martin Luther post his 95 Theses on several church doors, officialy starting his unofficial break from the Roman Catholic Church?";
NORMAL_TRIVIA_ANSWERS1[2353] = "October 31";
NORMAL_TRIVIA_ANSWERS2[2353] = "October 31st";
NORMAL_TRIVIA_ANSWERS3[2353] = "Halloween";

NORMAL_TRIVIA_QUESTIONS[2354] = "(Halloween): What animal other than a cat is associated with the witch?";
NORMAL_TRIVIA_ANSWERS1[2354] = "bat";

NORMAL_TRIVIA_QUESTIONS[2355] = "(History): In what post-renaissance century did the European witch trials begin in?";
NORMAL_TRIVIA_ANSWERS1[2355] = "1700";
NORMAL_TRIVIA_ANSWERS2[2355] = "17th Century";

NORMAL_TRIVIA_QUESTIONS[2356] = "(Halloween): Fill in the blank: Revenge upon whoever opens the _________ of a mummy?";
NORMAL_TRIVIA_ANSWERS1[2356] = "coffin";
NORMAL_TRIVIA_ANSWERS2[2356] = "tomb";

NORMAL_TRIVIA_QUESTIONS[2357] = "(Halloween): When can werewolves come out?";
NORMAL_TRIVIA_ANSWERS1[2357] = "Full moon";

NORMAL_TRIVIA_QUESTIONS[2358] = "(Halloween): Where did the myth about zombies begin?";
NORMAL_TRIVIA_ANSWERS1[2358] = "Africa";

NORMAL_TRIVIA_QUESTIONS[2359] = "(Halloween): Why do zombies often wear chains?";
NORMAL_TRIVIA_ANSWERS1[2359] = "they are slaves";

NORMAL_TRIVIA_QUESTIONS[2360] = "(Halloween): Where did the stories of vampires originate?";
NORMAL_TRIVIA_ANSWERS1[2360] = "Europe";

NORMAL_TRIVIA_QUESTIONS[2361] = "(Halloween): Fill in the blank: Casper the friendly ________ .";
NORMAL_TRIVIA_ANSWERS1[2361] = "ghost";

NORMAL_TRIVIA_QUESTIONS[2362] = "(Halloween): Fill in the blank: Put a light in the _______ to light up its face.";
NORMAL_TRIVIA_ANSWERS1[2362] = "pumpkin";

NORMAL_TRIVIA_QUESTIONS[2363] = "(Halloween): You can dress up like a ______ on Halloween and wear red horns and a tail.";
NORMAL_TRIVIA_ANSWERS1[2363] = "devil";

NORMAL_TRIVIA_QUESTIONS[2364] = "(Halloween): 'Hell is for Children' is a song from which '80's rocker?";
NORMAL_TRIVIA_ANSWERS1[2364] = "Pat Benetar";

NORMAL_TRIVIA_QUESTIONS[2365] = "(Harry): What is the name of Harry Potter's owl?";
NORMAL_TRIVIA_ANSWERS1[2365] = "Hedwig";

NORMAL_TRIVIA_QUESTIONS[2366] = "(Halloween): Loch Ness is located in what country?";
NORMAL_TRIVIA_ANSWERS1[2366] = "Scotland";

NORMAL_TRIVIA_QUESTIONS[2367] = "(Halloween): 'Laughing' by Vincent Price ends this 'M.J.' song";
NORMAL_TRIVIA_ANSWERS1[2367] = "Thriller";

NORMAL_TRIVIA_QUESTIONS[2368] = "(Halloween): New Mexico supposedly has a crashed UFO and aliens kept at this city's army air-field.";
NORMAL_TRIVIA_ANSWERS1[2368] = "Roswell";

NORMAL_TRIVIA_QUESTIONS[2369] = "(Halloween): Fill in the blank: Area 5_.";
NORMAL_TRIVIA_ANSWERS1[2369] = "1";

NORMAL_TRIVIA_QUESTIONS[2370] = "(Halloween): Bats, when leaving a cave, will always exit in this direction.";
NORMAL_TRIVIA_ANSWERS1[2370] = "left";

NORMAL_TRIVIA_QUESTIONS[2371] = "(The Great Pumpkin Charlie Brown): What does Linus tell Charlie Brown to never jump into a pile of leaves with?";
NORMAL_TRIVIA_ANSWERS1[2371] = "wet sucker";

NORMAL_TRIVIA_QUESTIONS[2372] = "(The Great Pumpkin Charlie Brown): When writing his letter to The Great Pumpkin, whom does Linus say gets more publicity than he?";
NORMAL_TRIVIA_ANSWERS1[2372] = "Santa Claus";

NORMAL_TRIVIA_QUESTIONS[2373] = "(The Great Pumpkin Charlie Brown): Who sits in the pumpkin patch with Linus on Halloween night waiting for the Great Pumpkin?";
NORMAL_TRIVIA_ANSWERS1[2373] = "Sally";

NORMAL_TRIVIA_QUESTIONS[2374] = "(The Great Pumpkin Charlie Brown): What did Charlie Brown receive while Trick or Treating?";
NORMAL_TRIVIA_ANSWERS1[2374] = "rocks";

NORMAL_TRIVIA_QUESTIONS[2375] = "(The Great Pumpkin Charlie Brown): When the Great Pumpkin finally raises out of the pumpkin patch, who is it really?";
NORMAL_TRIVIA_ANSWERS1[2375] = "Snoopy";

NORMAL_TRIVIA_QUESTIONS[2376] = "(The Great Pumpkin Charlie Brown): Whom does the gang use as a model when making the pumpkin at the Halloween party?";
NORMAL_TRIVIA_ANSWERS1[2376] = "Charlie Brown";

NORMAL_TRIVIA_QUESTIONS[2377] = "(World History): What was the greatest epic of the Sumerian empire?";
NORMAL_TRIVIA_ANSWERS1[2377] = "Gilgamesh";

NORMAL_TRIVIA_QUESTIONS[2378] = "(World History): What is the name of the greatest work attributed to Confucius (known as Lun-yu in Chinese)?";
NORMAL_TRIVIA_ANSWERS1[2378] = "The Analects";
NORMAL_TRIVIA_ANSWERS2[2378] = "Analects";

NORMAL_TRIVIA_QUESTIONS[2379] = "(World History): What Germanic tribe destroyed Rome in the year A.D. 455?";
NORMAL_TRIVIA_ANSWERS1[2379] = "The Vandals";
NORMAL_TRIVIA_ANSWERS2[2379] = "Vandals";

NORMAL_TRIVIA_QUESTIONS[2380] = "(World History): The Eastern and Western Roman empires were restored for a time under a great Byzantine emperor who lived from 483-562 A.D. What was his name?";
NORMAL_TRIVIA_ANSWERS1[2380] = "Justinian";

NORMAL_TRIVIA_QUESTIONS[2381] = "(World History): Muhammed fled from Mecca to what town in 622, in order to escape religious persecution?";
NORMAL_TRIVIA_ANSWERS1[2381] = "Medina";

NORMAL_TRIVIA_QUESTIONS[2382] = "(World History): The Mongols finally withdrew from Europe in the year 1241. This was as a result of the death of what Mongol leader?";
NORMAL_TRIVIA_ANSWERS1[2382] = "Ogedai";

NORMAL_TRIVIA_QUESTIONS[2383] = "(World History): In 1532, the leader of the Incan empire, Atahualpa, was killed. Who was the leader of the Spanish expedition that marched on the Incan empire and caused Atahualpa's death?";
NORMAL_TRIVIA_ANSWERS1[2383] = "Pizarro";

NORMAL_TRIVIA_QUESTIONS[2384] = "(World History): The end of the 30 years war in Europe occurred in 1648. What was the peace that ensued called?";
NORMAL_TRIVIA_ANSWERS1[2384] = "Peace of Westphalia";
NORMAL_TRIVIA_ANSWERS2[2384] = "Westphalia";

NORMAL_TRIVIA_QUESTIONS[2385] = "(World History): In 1803, the United States negotiated what purchase from France?";
NORMAL_TRIVIA_ANSWERS1[2385] = "Louisiana Purchase";
NORMAL_TRIVIA_ANSWERS2[2385] = "Louisiana";

NORMAL_TRIVIA_QUESTIONS[2386] = "(World History): What country of the Western hemisphere declared its independence, becoming the first black nation to gain freedom from European colonial rule?";
NORMAL_TRIVIA_ANSWERS1[2386] = "Haiti";

NORMAL_TRIVIA_QUESTIONS[2387] = "(World History): Which Norman defeated King Harold at the Battle of Hastings in 1066?";
NORMAL_TRIVIA_ANSWERS1[2387] = "William the Conqueror";
NORMAL_TRIVIA_ANSWERS2[2387] = "William";
NORMAL_TRIVIA_ANSWERS3[2387] = "Conqueror";

NORMAL_TRIVIA_QUESTIONS[2388] = "(World History): In which Australian city did MacArthur base his Pacific operations during World War II?";
NORMAL_TRIVIA_ANSWERS1[2388] = "Brisbane";

NORMAL_TRIVIA_QUESTIONS[2389] = "(World History): Which two countries did contoversial Historian A.J.P. Taylor blame for starting World War II with their 'Policy of Appeasement'?";
NORMAL_TRIVIA_ANSWERS1[2389] = "Britain and France";
NORMAL_TRIVIA_ANSWERS2[2389] = "France and Britain";

NORMAL_TRIVIA_QUESTIONS[2390] = "(World History): In Norse mythology, which term describes the pre-ordained doom of the gods?";
NORMAL_TRIVIA_ANSWERS1[2390] = "Ragnarok";

NORMAL_TRIVIA_QUESTIONS[2391] = "(World History): What was the name of the settlement which was defended by the British forces as depicted in the film 'Zulu'?";
NORMAL_TRIVIA_ANSWERS1[2391] = "Rorke's Drift";
NORMAL_TRIVIA_ANSWERS2[2391] = "Rorkes Drift";

NORMAL_TRIVIA_QUESTIONS[2392] = "(World History): What name did Marshall Blucher want to use as the name for the Battle of Waterloo, reflecting the name of the inn where he and the Duke of Wellington met after the battle?";
NORMAL_TRIVIA_ANSWERS1[2392] = "La Belle Alliance";

NORMAL_TRIVIA_QUESTIONS[2393] = "(World History): In Heraldry, what color is referred to as 'Gules'?";
NORMAL_TRIVIA_ANSWERS1[2393] = "Red";

NORMAL_TRIVIA_QUESTIONS[2394] = "(World History): Who was quoted as saying 'In war, whichever side may call itself the victor, there are no winners, but all are losers.'?";
NORMAL_TRIVIA_ANSWERS1[2394] = "Chamberlain";
NORMAL_TRIVIA_ANSWERS2[2394] = "Neville Chamberlain";

NORMAL_TRIVIA_QUESTIONS[2395] = "(World History): Who wrote 'The Declaration of the Rights of Women' in France in 1791? ";
NORMAL_TRIVIA_ANSWERS1[2395] = "Olympe de Gouge";

NORMAL_TRIVIA_QUESTIONS[2396] = "(World History): Which famous document opens with the sentence 'A spectre is haunting Europe - the spectre of Communism'?";
NORMAL_TRIVIA_ANSWERS1[2396] = "The Communist Manifesto";
NORMAL_TRIVIA_ANSWERS2[2396] = "Manifesto";

NORMAL_TRIVIA_QUESTIONS[2397] = "(World History): What was the nickname of Australian poet A.B. Patterson?";
NORMAL_TRIVIA_ANSWERS1[2397] = "Banjo";

NORMAL_TRIVIA_QUESTIONS[2398] = "(World History): The Navy of which country was responsible for the initial retrieval of three 'enigma' machine rotors from a sinking U-boat in 1940, allowing for the succesful decryption of the main 'enigma' keys by that country's cryptographers.";
NORMAL_TRIVIA_ANSWERS1[2398] = "Britain";

NORMAL_TRIVIA_QUESTIONS[2399] = "(World History): Which World War II leader was quoted as saying in 1935 'The Pope! How many divisions has he got'?";
NORMAL_TRIVIA_ANSWERS1[2399] = "Josef Stalin";
NORMAL_TRIVIA_ANSWERS2[2399] = "Stalin";

NORMAL_TRIVIA_QUESTIONS[2400] = "(World History): Which war saw the birth of the Balaclava as a form of head wear?";
NORMAL_TRIVIA_ANSWERS1[2400] = "Crimean";

NORMAL_TRIVIA_QUESTIONS[2401] = "(World History): What name was taken by a political group from the controversial document which was presented to the Czechoslovakian Government in 1977, leading to the arrest of the three individuals who presented it?";
NORMAL_TRIVIA_ANSWERS1[2401] = "Charter '77";
NORMAL_TRIVIA_ANSWERS2[2401] = "Charter 77";

NORMAL_TRIVIA_QUESTIONS[2402] = "(World History): What Japanese city was hit by the atomic bomb first?";
NORMAL_TRIVIA_ANSWERS1[2402] = "Hiroshima";

NORMAL_TRIVIA_QUESTIONS[2403] = "(World History): True or False, The United States has dropped nuclear bombs on Spain.";
NORMAL_TRIVIA_ANSWERS1[2403] = "true";

NORMAL_TRIVIA_QUESTIONS[2404] = "(World History): Who was the first Prime Minister of Australia?";
NORMAL_TRIVIA_ANSWERS1[2404] = "Edmund Barton";
NORMAL_TRIVIA_ANSWERS2[2404] = "Barton";

NORMAL_TRIVIA_QUESTIONS[2405] = "(World History): From 1904 to 1905 Japan was at war. Which country did Japan defeat?";
NORMAL_TRIVIA_ANSWERS1[2405] = "Russia";

NORMAL_TRIVIA_QUESTIONS[2406] = "(World History): What Portuguese explorer became the first European to reach the area now occupied by Brazil in 1500 A.D.?";
NORMAL_TRIVIA_ANSWERS1[2406] = "Pedro Cabral";
NORMAL_TRIVIA_ANSWERS2[2406] = "Cabral";

NORMAL_TRIVIA_QUESTIONS[2407] = "(World History): After Muhammad's death in 632 A.D., his father-in-law became the first caliph of Islam. What was this man's name?";
NORMAL_TRIVIA_ANSWERS1[2407] = "Abu Bakr";
NORMAL_TRIVIA_ANSWERS2[2407] = "Bakr";

NORMAL_TRIVIA_QUESTIONS[2408] = "(World History): Which pope not only bestowed the title 'defender of the faith' on Henry VIII but also subsequently excommunicated him?";
NORMAL_TRIVIA_ANSWERS1[2408] = "Leo X";
NORMAL_TRIVIA_ANSWERS2[2408] = "Leo 10";

NORMAL_TRIVIA_QUESTIONS[2409] = "(World History): The Mogul empire in India was established in 1526, when the army of the emperor of Delhi was defeated. What was the title given to Zahir ud-din Mohammed, the conqueror and first great Mogul of India?";
NORMAL_TRIVIA_ANSWERS1[2409] = "Babar";

NORMAL_TRIVIA_QUESTIONS[2410] = "(World History): The battle of Balaclava was an inconclusive battle fought during which war?";
NORMAL_TRIVIA_ANSWERS1[2410] = "Crimean";

NORMAL_TRIVIA_QUESTIONS[2411] = "(World History): Who was the French revolutionist and member of the Convention who was murdered in 1793 by Charlotte Corday?";
NORMAL_TRIVIA_ANSWERS1[2411] = "Jean Paul Marat";
NORMAL_TRIVIA_ANSWERS2[2411] = "Marat";

NORMAL_TRIVIA_QUESTIONS[2412] = "(World History): What was the name of the only English pope?";
NORMAL_TRIVIA_ANSWERS1[2412] = "Adrian IV";
NORMAL_TRIVIA_ANSWERS2[2412] = "Adrian 4";

NORMAL_TRIVIA_QUESTIONS[2413] = "(World History): In the 7th century A.D., what religion spread across much of North Africa?";
NORMAL_TRIVIA_ANSWERS1[2413] = "Islam";

NORMAL_TRIVIA_QUESTIONS[2414] = "(World History): During his reign (1398-1353 B.C.), an Egyptian pharoah denied the numerous gods of Egypt and became the first monotheistic Egyptian king. What was this pharoah's name?";
NORMAL_TRIVIA_ANSWERS1[2414] = "Ahknaten";

NORMAL_TRIVIA_QUESTIONS[2415] = "(World History): During the Chinese Sui dynasty, a canal system was constructed that linked the Yellow river with the Yangtze river. What was this canal system called?";
NORMAL_TRIVIA_ANSWERS1[2415] = "Grand Canal";

NORMAL_TRIVIA_QUESTIONS[2416] = "(World History): Who was the 'great liberator' of South American history?";
NORMAL_TRIVIA_ANSWERS1[2416] = "Simon Bolviar";
NORMAL_TRIVIA_ANSWERS2[2416] = "Bolviar";

NORMAL_TRIVIA_QUESTIONS[2417] = "(World History): What is the name of the first landing place on the east coast of Australia (in 1770) of Captain James Cook?";
NORMAL_TRIVIA_ANSWERS1[2417] = "Botany Bay";

NORMAL_TRIVIA_QUESTIONS[2418] = "(World History): The word 'Anschluss' refers to Hitler's union of Germany with what other European nation?";
NORMAL_TRIVIA_ANSWERS1[2418] = "Austria";

NORMAL_TRIVIA_QUESTIONS[2419] = "(World History): Alexander the Great was forced to return back to his capital after his troops mutinied following a battle near the Indus river in India. What was the name of this battle that occurred in 326 B.C.?";
NORMAL_TRIVIA_ANSWERS1[2419] = "Hydaspes";

NORMAL_TRIVIA_QUESTIONS[2420] = "(World History): What city was the site of the peace and treaty that ended the American Revolution in 1783?";
NORMAL_TRIVIA_ANSWERS1[2420] = "Paris";

NORMAL_TRIVIA_QUESTIONS[2421] = "(World History): True or False, Great Britain, United States, and Canada invaded Normandy on D-Day.";
NORMAL_TRIVIA_ANSWERS1[2421] = "true";

NORMAL_TRIVIA_QUESTIONS[2422] = "(World History): Who was assassinated in Sarajevo, and was one of the main reasons that World War I started?";
NORMAL_TRIVIA_ANSWERS1[2422] = "Franz Ferdinand";
NORMAL_TRIVIA_ANSWERS2[2422] = "Ferdinand";

NORMAL_TRIVIA_QUESTIONS[2423] = "(World History): How many times was Franklin D. Roosevelt elected as the President of the United States of America?";
NORMAL_TRIVIA_ANSWERS1[2423] = "Four";
NORMAL_TRIVIA_ANSWERS2[2423] = "4";

NORMAL_TRIVIA_QUESTIONS[2424] = "(World History): Whay year did Hitler become Chancellor of Germany?";
NORMAL_TRIVIA_ANSWERS1[2424] = "1933";

NORMAL_TRIVIA_QUESTIONS[2425] = "(World History): What 20th century British Prime Minister coined the phrase 'Iron Curtain'?";
NORMAL_TRIVIA_ANSWERS1[2425] = "Winston Churchill";
NORMAL_TRIVIA_ANSWERS2[2425] = "Churchill";

NORMAL_TRIVIA_QUESTIONS[2426] = "(World History): What group won victories during the American Revolution at Bennington and Fort Ticonderoga under the leadership of Ethan Allen?";
NORMAL_TRIVIA_ANSWERS1[2426] = "Green Mountain Boys";

NORMAL_TRIVIA_QUESTIONS[2427] = "(World History): What man was the Mayor of New York City from 1933 until 1945?";
NORMAL_TRIVIA_ANSWERS1[2427] = "Fiorello La Gaurdia";
NORMAL_TRIVIA_ANSWERS2[2427] = "La Gaurdia";

NORMAL_TRIVIA_QUESTIONS[2428] = "(World History): In what year did the Glorious Revolution in which William and Mary were put on the throne of England occur?";
NORMAL_TRIVIA_ANSWERS1[2428] = "1688";

NORMAL_TRIVIA_QUESTIONS[2429] = "(World History): What amendment to the U.S. Constitution permits the Federal Income Tax?";
NORMAL_TRIVIA_ANSWERS1[2429] = "Sixteenth";
NORMAL_TRIVIA_ANSWERS2[2429] = "16th";
NORMAL_TRIVIA_ANSWERS3[2429] = "16";

NORMAL_TRIVIA_QUESTIONS[2430] = "(World History): Who served as Dwight Eisenhower's Vice-President?";
NORMAL_TRIVIA_ANSWERS1[2430] = "Richard Nixon";
NORMAL_TRIVIA_ANSWERS2[2430] = "Nixon";

NORMAL_TRIVIA_QUESTIONS[2431] = "(World History): Who was the leader of the Mexicans during the 1836 invasion of the Alamo?";
NORMAL_TRIVIA_ANSWERS1[2431] = "Santa Anna";
NORMAL_TRIVIA_ANSWERS2[2431] = "Anna";

NORMAL_TRIVIA_QUESTIONS[2432] = "(World History): In what southern State was Former-President Jimmy Carter born (phalaphe's home state)?";
NORMAL_TRIVIA_ANSWERS1[2432] = "Georgia";

NORMAL_TRIVIA_QUESTIONS[2433] = "(World History): Who founded the colony of Rhode Island?";
NORMAL_TRIVIA_ANSWERS1[2433] = "Roger Williams";
NORMAL_TRIVIA_ANSWERS2[2433] = "Williams";

NORMAL_TRIVIA_QUESTIONS[2434] = "(World History): What President removed General Douglas MacArthur from command in the Korean War?";
NORMAL_TRIVIA_ANSWERS1[2434] = "Harry S. Truman";
NORMAL_TRIVIA_ANSWERS2[2434] = "Truman";

NORMAL_TRIVIA_QUESTIONS[2435] = "(World History): Who shot New York Senator Robert Kennedy in 1968?";
NORMAL_TRIVIA_ANSWERS1[2435] = "Sirhan Sirhan";
NORMAL_TRIVIA_ANSWERS2[2435] = "Sirhan";

NORMAL_TRIVIA_QUESTIONS[2436] = "(World History): What French King was overthrown in the July Revolution of 1830?";
NORMAL_TRIVIA_ANSWERS1[2436] = "Charles X";
NORMAL_TRIVIA_ANSWERS2[2436] = "Charles 10";

NORMAL_TRIVIA_QUESTIONS[2437] = "(World History): What German military leader was nicknamed 'Desert Fox'?";
NORMAL_TRIVIA_ANSWERS1[2437] = "Erwin Rommel";
NORMAL_TRIVIA_ANSWERS2[2437] = "Rommel";

NORMAL_TRIVIA_QUESTIONS[2438] = "(World History): What President was in office during the Alien and Sedition Acts of 1798?";
NORMAL_TRIVIA_ANSWERS1[2438] = "John Adams";
NORMAL_TRIVIA_ANSWERS2[2438] = "Adams";

NORMAL_TRIVIA_QUESTIONS[2439] = "(World History): 'These are the times that try men's souls' is a quote from what Thomsas Paine pamphlet?";
NORMAL_TRIVIA_ANSWERS1[2439] = "The Crisis";
NORMAL_TRIVIA_ANSWERS2[2439] = "crisis";

NORMAL_TRIVIA_QUESTIONS[2440] = "(World History): What British award was bestowed on the island country of Malta in 1942? ";
NORMAL_TRIVIA_ANSWERS1[2440] = "The George Cross";
NORMAL_TRIVIA_ANSWERS2[2440] = "george";

NORMAL_TRIVIA_QUESTIONS[2441] = "(World History): Which European country became a republic in 1792?";
NORMAL_TRIVIA_ANSWERS1[2441] = "France";

NORMAL_TRIVIA_QUESTIONS[2442] = "(World History): What country boasted World War Two's two biggest battleships?";
NORMAL_TRIVIA_ANSWERS1[2442] = "Japan";

NORMAL_TRIVIA_QUESTIONS[2443] = "(World History): What nation has the oldest monarchy?";
NORMAL_TRIVIA_ANSWERS1[2443] = "Japan";

NORMAL_TRIVIA_QUESTIONS[2444] = "(World History): What European country had Kings nicknamed 'The Lazy', 'The Fat' and 'The Quarrelsome'?";
NORMAL_TRIVIA_ANSWERS1[2444] = "France";

NORMAL_TRIVIA_QUESTIONS[2445] = "(World History): What European city lost 4,000 people to a 'killer fog' of carbon dioxide in 1952?";
NORMAL_TRIVIA_ANSWERS1[2445] = "London";

NORMAL_TRIVIA_QUESTIONS[2446] = "(World History): Which continent is the only one without an active volcano?";
NORMAL_TRIVIA_ANSWERS1[2446] = "Australia";

NORMAL_TRIVIA_QUESTIONS[2447] = "(World History): A subject of English literature, which Scottish king killed Duncan I to seized the throne in 1040?";
NORMAL_TRIVIA_ANSWERS1[2447] = "Macbeth";

NORMAL_TRIVIA_QUESTIONS[2448] = "(World History): What group conquered the Russians, Ukrainians, and Siberians in the 13th century and established the Empire of the Golden Horde?";
NORMAL_TRIVIA_ANSWERS1[2448] = "Tartars";

NORMAL_TRIVIA_QUESTIONS[2449] = "(World History): During the Black Death, or Bubonic Plague, in mid 1300's Europe (approx.), what percentage of the population perished?";
NORMAL_TRIVIA_ANSWERS1[2449] = "33%";
NORMAL_TRIVIA_ANSWERS2[2449] = "33";
NORMAL_TRIVIA_ANSWERS3[2449] = "third";

NORMAL_TRIVIA_QUESTIONS[2450] = "(World History): The Hundred Years War was fought between what two European countries?";
NORMAL_TRIVIA_ANSWERS1[2450] = "England and France";
NORMAL_TRIVIA_ANSWERS2[2450] = "France and England";

NORMAL_TRIVIA_QUESTIONS[2451] = "(World History): Vasco de Gama, who discovered a sea route in the 15th century to India around the continent of Africa, was from what European country?";
NORMAL_TRIVIA_ANSWERS1[2451] = "Portugal";

NORMAL_TRIVIA_QUESTIONS[2452] = "(World History): What group used the agricultural method of terracing in the Andes Mountains during the 15th century?";
NORMAL_TRIVIA_ANSWERS1[2452] = "Incas";

NORMAL_TRIVIA_QUESTIONS[2453] = "(World History): The beginning of the Renaissance in Italy began in what century?";
NORMAL_TRIVIA_ANSWERS1[2453] = "14th Century";
NORMAL_TRIVIA_ANSWERS2[2453] = "14th";
NORMAL_TRIVIA_ANSWERS3[2453] = "14";

NORMAL_TRIVIA_QUESTIONS[2454] = "(World History): Who defeated the English at the Battle of Hastings in 1066?";
NORMAL_TRIVIA_ANSWERS1[2454] = "Normans";

NORMAL_TRIVIA_QUESTIONS[2455] = "(World History): Built in 1407 in Genoa, Casa di San Giorgio, one of the first of its kind, was a what?";
NORMAL_TRIVIA_ANSWERS1[2455] = "Bank";

NORMAL_TRIVIA_QUESTIONS[2456] = "(World History): Which was constructed first, The Cathedral or The Tower, in Pisa, Italy?";
NORMAL_TRIVIA_ANSWERS1[2456] = "The Cathedral";
NORMAL_TRIVIA_ANSWERS2[2456] = "Cathedral";

NORMAL_TRIVIA_QUESTIONS[2457] = "(World History): When Christopher Columbus landed in the Caribbean Islands in 1492, what present day nation did he land on first?";
NORMAL_TRIVIA_ANSWERS1[2457] = "Bahamas";

NORMAL_TRIVIA_QUESTIONS[2458] = "(World History): In 1260, the Mongols led by Kublai Khan overtook China and ruled until 1368. What dynasty was this?";
NORMAL_TRIVIA_ANSWERS1[2458] = "Yuan";

NORMAL_TRIVIA_QUESTIONS[2459] = "(World History): The Aztec capital was founded around 1325 in central Mexico and was called what?";
NORMAL_TRIVIA_ANSWERS1[2459] = "Tenochtitlan";

NORMAL_TRIVIA_QUESTIONS[2460] = "(World History): Which English King issued the Magna Carta in 1215?";
NORMAL_TRIVIA_ANSWERS1[2460] = "King John";
NORMAL_TRIVIA_ANSWERS2[2460] = "John";

NORMAL_TRIVIA_QUESTIONS[2461] = "(World History): Joan of Arc was a heroine during what war?";
NORMAL_TRIVIA_ANSWERS1[2461] = "Hundred Year's War";
NORMAL_TRIVIA_ANSWERS2[2461] = "100 Year's War";
NORMAL_TRIVIA_ANSWERS3[2461] = "Hundred Years War";

NORMAL_TRIVIA_QUESTIONS[2462] = "(World History): What Venetian traveler and explorer landed in China and reached Kublai Khan's court in 1275?";
NORMAL_TRIVIA_ANSWERS1[2462] = "Marco Polo";
NORMAL_TRIVIA_ANSWERS2[2462] = "Polo";

NORMAL_TRIVIA_QUESTIONS[2463] = "(World History): Constantinople fell to the Ottoman Turks in what year?";
NORMAL_TRIVIA_ANSWERS1[2463] = "1453";

NORMAL_TRIVIA_QUESTIONS[2464] = "(World History): What empire ruled by Mansa Musa reached its height in Africa from 1312-1337?";
NORMAL_TRIVIA_ANSWERS1[2464] = "Mali Kingdom";
NORMAL_TRIVIA_ANSWERS2[2464] = "Mali";

NORMAL_TRIVIA_QUESTIONS[2465] = "(World History): The legend of this 12th century English bandit-hero was mostly made known through the ballads and songs of wandering minstrels who weaved a patchwork of fact and fiction into the contemporary culture of the time. Who was he?";
NORMAL_TRIVIA_ANSWERS1[2465] = "Robin Hood";

NORMAL_TRIVIA_QUESTIONS[2466] = "(World History): What year is the single most important year in U.S. history (the defeat of the Spanish armada)?";
NORMAL_TRIVIA_ANSWERS1[2466] = "1588";

NORMAL_TRIVIA_QUESTIONS[2467] = "(Arithmetic): 3+7= ?";
NORMAL_TRIVIA_ANSWERS1[2467] = "10";

NORMAL_TRIVIA_QUESTIONS[2468] = "(Arithmetic): 14x20= ?";
NORMAL_TRIVIA_ANSWERS1[2468] = "280";

NORMAL_TRIVIA_QUESTIONS[2469] = "(Arithmetic): 21+44= ?";
NORMAL_TRIVIA_ANSWERS1[2469] = "65";

NORMAL_TRIVIA_QUESTIONS[2470] = "(Arithmetic): 31(4+9)= ?";
NORMAL_TRIVIA_ANSWERS1[2470] = "403";

NORMAL_TRIVIA_QUESTIONS[2471] = "(Arithmetic): 21+9= ?";
NORMAL_TRIVIA_ANSWERS1[2471] = "30";

NORMAL_TRIVIA_QUESTIONS[2472] = "(Arithmetic): 86+180= ?";
NORMAL_TRIVIA_ANSWERS1[2472] = "266";

NORMAL_TRIVIA_QUESTIONS[2473] = "(Arithmetic): 5(5)+41-44= ?";
NORMAL_TRIVIA_ANSWERS1[2473] = "22";

NORMAL_TRIVIA_QUESTIONS[2474] = "(Word Problem): There were 4 apples on the table. Johnny ate 3 of them, and then the dog took another one. How many apples were left on the table?";
NORMAL_TRIVIA_ANSWERS1[2474] = "0";
NORMAL_TRIVIA_ANSWERS2[2474] = "none";

NORMAL_TRIVIA_QUESTIONS[2475] = "(Word Problem): A farmer had 18 sheep, all but 9 died. How may sheep did he have after that?";
NORMAL_TRIVIA_ANSWERS1[2475] = "9";

NORMAL_TRIVIA_QUESTIONS[2476] = "(Word Problem): If Hamfon has 6 apples, and at the end of the day he has 6 apples, assuming nothing happens to the apples by tomorrow morning, how many apples will he have tomorrow morning.";
NORMAL_TRIVIA_ANSWERS1[2476] = "6";

NORMAL_TRIVIA_QUESTIONS[2477] = "(Algebra I): If this is true, say the answer, if it is false say false: 2(3x4) = (2x3)4";
NORMAL_TRIVIA_ANSWERS1[2477] = "24";

NORMAL_TRIVIA_QUESTIONS[2478] = "(Algebra I): If this is true, say the answer, if it is false say false: 5(4+1)= (20+5)";
NORMAL_TRIVIA_ANSWERS1[2478] = "25";

NORMAL_TRIVIA_QUESTIONS[2479] = "(Algebra I): If this is true, say the answer, if it is false say false: 2+1x3 = (2+1)x3";
NORMAL_TRIVIA_ANSWERS1[2479] = "false";

NORMAL_TRIVIA_QUESTIONS[2480] = "(Roman Numerals): Divide the Roman numeral DXXII by III. In Roman numerals, what would be your answer.";
NORMAL_TRIVIA_ANSWERS1[2480] = "CLXXIV";

NORMAL_TRIVIA_QUESTIONS[2481] = "(Algebra I): Solve for X: 5x+4=24";
NORMAL_TRIVIA_ANSWERS1[2481] = "4";

NORMAL_TRIVIA_QUESTIONS[2482] = "(Roman Numerals): Multiply XLIV by II. What is your answer in Roman numerals?";
NORMAL_TRIVIA_ANSWERS1[2482] = "LXXXVIII";

NORMAL_TRIVIA_QUESTIONS[2483] = "(Roman Numerals): Add MCMXLIV and D. What is your answer in Roman numerals?";
NORMAL_TRIVIA_ANSWERS1[2483] = "MMCDXLIV";

NORMAL_TRIVIA_QUESTIONS[2484] = "(Roman Numerals): A real easy one. Subtract II from IV in Roman numerals.";
NORMAL_TRIVIA_ANSWERS1[2484] = "II";

NORMAL_TRIVIA_QUESTIONS[2485] = "(Roman Numerals): If the numerator is XXI and your denominator is III, what's the answer in Roman numerals?";
NORMAL_TRIVIA_ANSWERS1[2485] = "VII";

NORMAL_TRIVIA_QUESTIONS[2486] = "(Terminology): What is the meaning of 'crore'?";
NORMAL_TRIVIA_ANSWERS1[2486] = "10,000,000";
NORMAL_TRIVIA_ANSWERS2[2486] = "10000000";
NORMAL_TRIVIA_ANSWERS3[2486] = "10 Million";

NORMAL_TRIVIA_QUESTIONS[2487] = "(Geometry): How many sides does a 'icosohedron' have?";
NORMAL_TRIVIA_ANSWERS1[2487] = "20";

NORMAL_TRIVIA_QUESTIONS[2488] = "(Terminology): 'Lakh' is a term meaning what?";
NORMAL_TRIVIA_ANSWERS1[2488] = "100,000";
NORMAL_TRIVIA_ANSWERS2[2488] = "100000";

NORMAL_TRIVIA_QUESTIONS[2489] = "(Geometry): What is the name of the 'x' coordinate in geometry?";
NORMAL_TRIVIA_ANSWERS1[2489] = "Abscissa";

NORMAL_TRIVIA_QUESTIONS[2490] = "(Terminology): What was the original meaning of the word 'Myriad'?";
NORMAL_TRIVIA_ANSWERS1[2490] = "10,000";
NORMAL_TRIVIA_ANSWERS2[2490] = "10000";

NORMAL_TRIVIA_QUESTIONS[2491] = "(Geometry): In assuming (X,Y,Z) what does Y = in (52,5,2)";
NORMAL_TRIVIA_ANSWERS1[2491] = "5";

NORMAL_TRIVIA_QUESTIONS[2492] = "(Algebra II): Matrices are fun!! I mean everyone liked the Matrix soo...add Matrix a [1 2 3 4] to Matrix b [4 3 2 1] and say the answer.";
NORMAL_TRIVIA_ANSWERS1[2492] = "[5 5 5 5]";

NORMAL_TRIVIA_QUESTIONS[2493] = "(Algebra II): Assuming these three matrices are three rows of one matrix, ordered from top to bottom, what type of matrix is this an example of: [1 0 0 3] [0 1 0 4] [0 0 1 2] ?";
NORMAL_TRIVIA_ANSWERS1[2493] = "Augmented Matrix";

NORMAL_TRIVIA_QUESTIONS[2494] = "(Geometry): .5 x Base x Height is the formula to find the area of what geometric figure?";
NORMAL_TRIVIA_ANSWERS1[2494] = "Triangle";

NORMAL_TRIVIA_QUESTIONS[2495] = "(Algebra): A set of all X such that {X=1,2,3,4...} is the definition for what classification of numbers?";
NORMAL_TRIVIA_ANSWERS1[2495] = "Natural";

NORMAL_TRIVIA_QUESTIONS[2496] = "(Algebra): A set of all X such that {X=0,1,2,3,4...} is the definition for what classification of numbers?";
NORMAL_TRIVIA_ANSWERS1[2496] = "Whole";

NORMAL_TRIVIA_QUESTIONS[2497] = "(Algebra):  A set of all X such that {X=...-3,-2,-1,0,1,2,3...} is the definition for what classification of numbers?";
NORMAL_TRIVIA_ANSWERS1[2497] = "Integers";

NORMAL_TRIVIA_QUESTIONS[2498] = "(Politics): We all know that the United Kingdom has a Queen. However, what is the true definition of their governmental system?";
NORMAL_TRIVIA_ANSWERS1[2498] = "Parliamentary Monarchy";

NORMAL_TRIVIA_QUESTIONS[2499] = "(Politics): The United States formed a government like none other in history. What is the proper term to describe our system of government?";
NORMAL_TRIVIA_ANSWERS1[2499] = "Federal Republic";

NORMAL_TRIVIA_QUESTIONS[2500] = "(Politics): We all know of the troubles the U.S. had in Somalia in the early 1990s. What type of government has been established in that war-torn African nation?";
NORMAL_TRIVIA_ANSWERS1[2500] = "None";

NORMAL_TRIVIA_QUESTIONS[2501] = "(Politics): What nation gained their independence from Great Britain in 1947 and now functions as a federal republic?";
NORMAL_TRIVIA_ANSWERS1[2501] = "India";

NORMAL_TRIVIA_QUESTIONS[2502] = "(Politics): What nation occupies the northern half of the island nation of Cyprus?";
NORMAL_TRIVIA_ANSWERS1[2502] = "Turkey";

NORMAL_TRIVIA_QUESTIONS[2503] = "(Politics): Libya's government is headed by Muammar Qadaffi. What rank does he hold in the Libyan military?";
NORMAL_TRIVIA_ANSWERS1[2503] = "Colonel";

NORMAL_TRIVIA_QUESTIONS[2504] = "(Politics): Is the Vatican a country?";
NORMAL_TRIVIA_ANSWERS1[2504] = "True";
NORMAL_TRIVIA_ANSWERS2[2504] = "yes";

NORMAL_TRIVIA_QUESTIONS[2505] = "(Politics): The government of Israel is based where?";
NORMAL_TRIVIA_ANSWERS1[2505] = "Jerusalem";

NORMAL_TRIVIA_QUESTIONS[2506] = "(Politics): According to most world governments (including the U.S), the government of Israel is based where?";
NORMAL_TRIVIA_ANSWERS1[2506] = "Tel Aviv";

NORMAL_TRIVIA_QUESTIONS[2507] = "(Politics): During the British Raj in India, what city originally served as its capital?";
NORMAL_TRIVIA_ANSWERS1[2507] = "Calcutta";

NORMAL_TRIVIA_QUESTIONS[2508] = "(Politics): Fujimori is president of what country?";
NORMAL_TRIVIA_ANSWERS1[2508] = "Peru";

NORMAL_TRIVIA_QUESTIONS[2509] = "(Politics): Who is president of Russia?";
NORMAL_TRIVIA_ANSWERS1[2509] = "Putin";

NORMAL_TRIVIA_QUESTIONS[2510] = "(Politics): Who is the Prime Minister of Israel?";
NORMAL_TRIVIA_ANSWERS1[2510] = "Barak";
NORMAL_TRIVIA_ANSWERS2[2510] = "Ehud Barak";

NORMAL_TRIVIA_QUESTIONS[2511] = "(Politics): Who burned down the German parliamentary building, the Reichstag, on 27 Februari 1933?";
NORMAL_TRIVIA_ANSWERS1[2511] = "Marinus van der Lubbe";
NORMAL_TRIVIA_ANSWERS2[2511] = "Lubbe";
NORMAL_TRIVIA_ANSWERS3[2511] = "Marinus";

NORMAL_TRIVIA_QUESTIONS[2512] = "(Politics): What is the parliament of Israel called?";
NORMAL_TRIVIA_ANSWERS1[2512] = "Knesset";

NORMAL_TRIVIA_QUESTIONS[2513] = "(Politics): The Japanese parliament, the Diet, is composed of a House of Representatives and a ...";
NORMAL_TRIVIA_ANSWERS1[2513] = "House of Councillors";

NORMAL_TRIVIA_QUESTIONS[2514] = "(Politics): Which country has the Folketing as parliament?";
NORMAL_TRIVIA_ANSWERS1[2514] = "Denmark";
NORMAL_TRIVIA_ANSWERS2[2514] = "Holland";

NORMAL_TRIVIA_QUESTIONS[2515] = "(Politics): What is the general assembly of Russia known as.";
NORMAL_TRIVIA_ANSWERS1[2515] = "Duma";

NORMAL_TRIVIA_QUESTIONS[2516] = "(Politics): The French parliament consists of two chambers, the Senat and the ...";
NORMAL_TRIVIA_ANSWERS1[2516] = "Assemblee Nationale";

NORMAL_TRIVIA_QUESTIONS[2517] = "(Politics): In which city is the South African parliament?";
NORMAL_TRIVIA_ANSWERS1[2517] = "Cape Town";

NORMAL_TRIVIA_QUESTIONS[2518] = "(Politics): At what age are Japanese citizens eligible to vote?";
NORMAL_TRIVIA_ANSWERS1[2518] = "20";

NORMAL_TRIVIA_QUESTIONS[2519] = "(Politics): What is the Chinese parliament called?";
NORMAL_TRIVIA_ANSWERS1[2519] = "National People's Congress";
NORMAL_TRIVIA_ANSWERS2[2519] = "National Peoples Congress";

NORMAL_TRIVIA_QUESTIONS[2520] = "(Politics): Where does the European Parliament have its seat?";
NORMAL_TRIVIA_ANSWERS1[2520] = "Strasbourg";

NORMAL_TRIVIA_QUESTIONS[2521] = "(Politics): In which city is the Dutch parliament?";
NORMAL_TRIVIA_ANSWERS1[2521] = "The Hague";

NORMAL_TRIVIA_QUESTIONS[2522] = "(Politics): In which year was the landmark Brown vs Topeka (Board of Education) case, which argued that racially separate facilities in education were inherently unequal, passed by the Supreme Court?";
NORMAL_TRIVIA_ANSWERS1[2522] = "1954";

NORMAL_TRIVIA_QUESTIONS[2523] = "(Politics): Which institution makes up the legislative branch of the government of the United States?";
NORMAL_TRIVIA_ANSWERS1[2523] = "Congress";

NORMAL_TRIVIA_QUESTIONS[2524] = "(Politics): What did the 1973 Roe vs Wade Supreme Court case deal with (and this is why everyone is confused about pro-life/pro-choice people)?";
NORMAL_TRIVIA_ANSWERS1[2524] = "Abortion";

NORMAL_TRIVIA_QUESTIONS[2525] = "(Politics): Which US President started his career as a film actor?";
NORMAL_TRIVIA_ANSWERS1[2525] = "Reagan";
NORMAL_TRIVIA_ANSWERS2[2525] = "Ronald Reagan";

NORMAL_TRIVIA_QUESTIONS[2526] = "(Politics): Who is the Vice President of the United States of America.";
NORMAL_TRIVIA_ANSWERS1[2526] = "Cheney";
NORMAL_TRIVIA_ANSWERS2[2526] = "Dick Cheney";

NORMAL_TRIVIA_QUESTIONS[2527] = "(Politics): Who is the Prime Minister of Great Britain.";
NORMAL_TRIVIA_ANSWERS1[2527] = "Blair";
NORMAL_TRIVIA_ANSWERS2[2527] = "Tony Blair";

NORMAL_TRIVIA_QUESTIONS[2528] = "(Politics): How are the first ten Amendments to the U.S Constitution commonly known?";
NORMAL_TRIVIA_ANSWERS1[2528] = "Bill of Rights";

NORMAL_TRIVIA_QUESTIONS[2529] = "(Politics): The network that helped slaves in the South escape to freedom in the North was known as the_______ _________.";
NORMAL_TRIVIA_ANSWERS1[2529] = "Underground Railroad";

NORMAL_TRIVIA_QUESTIONS[2530] = "(Politics): According to Popular Vote, who is the President of the United States of American (hmmm...can we say: phal is liberal?)";
NORMAL_TRIVIA_ANSWERS1[2530] = "Al Gore";

NORMAL_TRIVIA_QUESTIONS[2531] = "(Politics): In the 1876 Presidential election, Samuel J. Tilden won the popular vote, but initially there was a tie in the electoral votes for the two leading candidates in the Electoral College vote. This tie was decided by a commission established by Congress. Who finally became President?";
NORMAL_TRIVIA_ANSWERS1[2531] = "Hayes";
NORMAL_TRIVIA_ANSWERS2[2531] = "Rutherford B. Hayes";

NORMAL_TRIVIA_QUESTIONS[2532] = "(Politics): In 1998, what country turned 50?";
NORMAL_TRIVIA_ANSWERS1[2532] = "Israel";

NORMAL_TRIVIA_QUESTIONS[2533] = "(Arts&Entertainment): What fellow artist did Van Gogh threaten with a razor before taking a swipe at himself?";
NORMAL_TRIVIA_ANSWERS1[2533] = "Paul Gauguin";
NORMAL_TRIVIA_ANSWERS2[2533] = "Gauguin";

NORMAL_TRIVIA_QUESTIONS[2534] = "(History): Who changed his name from Vernon Wayne Howell for \"publicity and business purposes\"?";
NORMAL_TRIVIA_ANSWERS1[2534] = "David Koresh";
NORMAL_TRIVIA_ANSWERS2[2534] = "Koresh";

NORMAL_TRIVIA_QUESTIONS[2535] = "(People&Places): What city would you visit to see the contents of King Tut's tomb?";
NORMAL_TRIVIA_ANSWERS1[2535] = "Cairo";

NORMAL_TRIVIA_QUESTIONS[2536] = "(History): What's the most commonly used slang term to describe helicopters?";
NORMAL_TRIVIA_ANSWERS1[2536] = "Choppers";
NORMAL_TRIVIA_ANSWERS2[2536] = "chopper";

NORMAL_TRIVIA_QUESTIONS[2537] = "(World): What literary character tilted at windmills, mistaking them for giants?";
NORMAL_TRIVIA_ANSWERS1[2537] = "Don Quixote";
NORMAL_TRIVIA_ANSWERS2[2537] = "Quixote";

NORMAL_TRIVIA_QUESTIONS[2538] = "(Sports&Leisure): Who was the first man in 56 years to win both springboard and platform diving at the Olympics?";
NORMAL_TRIVIA_ANSWERS1[2538] = "Greg Louganis";
NORMAL_TRIVIA_ANSWERS2[2538] = "Louganis";

NORMAL_TRIVIA_QUESTIONS[2539] = "(Science&Nature): What independent movie studio shares it's name with a constellation? ";
NORMAL_TRIVIA_ANSWERS1[2539] = "Orion";

NORMAL_TRIVIA_QUESTIONS[2540] = "(World): In what movie Eddie Murphy insist his character's name be changed from Willie Biggs to Reggie Hammond?";
NORMAL_TRIVIA_ANSWERS1[2540] = "48 Hrs.";
NORMAL_TRIVIA_ANSWERS2[2540] = "48 Hours";

NORMAL_TRIVIA_QUESTIONS[2541] = "(Arts&Entertainment): Who was the second black star to be in a film grossing over $100 million?";
NORMAL_TRIVIA_ANSWERS1[2541] = "Whoopi Goldberg";
NORMAL_TRIVIA_ANSWERS2[2541] = "Goldberg";
NORMAL_TRIVIA_ANSWERS3[2541] = "Whoopi";

NORMAL_TRIVIA_QUESTIONS[2542] = "(Arts&Entertainment): Name one No.1 Michael Jackson hit this is a three-letter word beginning with the letter \"B\"";
NORMAL_TRIVIA_ANSWERS1[2542] = "'Ben' or 'Bad'";
NORMAL_TRIVIA_ANSWERS2[2542] = "Ben";
NORMAL_TRIVIA_ANSWERS3[2542] = "Bad";

NORMAL_TRIVIA_QUESTIONS[2543] = "(Sports&Leisure): What bowling pin is known as the widow?";
NORMAL_TRIVIA_ANSWERS1[2543] = "The ten pin";
NORMAL_TRIVIA_ANSWERS2[2543] = "10 pin";
NORMAL_TRIVIA_ANSWERS3[2543] = "tenpin";

NORMAL_TRIVIA_QUESTIONS[2544] = "(Sports&Leisure): How many thousand cows are needed to supply the NFL with enough footballs for a season?";
NORMAL_TRIVIA_ANSWERS1[2544] = "Three";
NORMAL_TRIVIA_ANSWERS2[2544] = "3";
NORMAL_TRIVIA_ANSWERS3[2544] = "3,000";

NORMAL_TRIVIA_QUESTIONS[2545] = "(People&Places): What was the only U.S. state in 1992 to lose more citizens to handguns than to car crashes?";
NORMAL_TRIVIA_ANSWERS1[2545] = "Texas";

NORMAL_TRIVIA_QUESTIONS[2546] = "(World): What Victor Hugo novel does \"The Simpsons\" pay tribute to by giving prisoners the number 24601?";
NORMAL_TRIVIA_ANSWERS1[2546] = "Les Miserables";
NORMAL_TRIVIA_ANSWERS2[2546] = "Miserables";

NORMAL_TRIVIA_QUESTIONS[2547] = "(World): What kind of tails did a gang of aborigines freeze, use to attack three police officers, and then eat?";
NORMAL_TRIVIA_ANSWERS1[2547] = "Kangaroo tails";
NORMAL_TRIVIA_ANSWERS2[2547] = "Kangaroo";

NORMAL_TRIVIA_QUESTIONS[2548] = "(History): What did Donald Trump rename the yacht \"Nabila\" that he bought for $29 million in 1987?";
NORMAL_TRIVIA_ANSWERS1[2548] = "The Trump Princess";
NORMAL_TRIVIA_ANSWERS2[2548] = "princess";

NORMAL_TRIVIA_QUESTIONS[2549] = "(Sports&Leisure): What Cincinnati Reds catcher could hold seven baseballs in his giant paw?";
NORMAL_TRIVIA_ANSWERS1[2549] = "Johnny Bench";
NORMAL_TRIVIA_ANSWERS2[2549] = "Bench";

NORMAL_TRIVIA_QUESTIONS[2550] = "(Science&Nature): What did Steven Hawking say could be formed by something other than the collapse of a star?";
NORMAL_TRIVIA_ANSWERS1[2550] = "Black holes";
NORMAL_TRIVIA_ANSWERS2[2550] = "black hole";

NORMAL_TRIVIA_QUESTIONS[2551] = "(Arts&Entertainment): What's the most famous five-word phrase uttered by Clint Eastwood in the movie \"Sudden Impact\"?";
NORMAL_TRIVIA_ANSWERS1[2551] = "Go ahead, make my day";
NORMAL_TRIVIA_ANSWERS2[2551] = "make my day";
NORMAL_TRIVIA_ANSWERS3[2551] = "go ahead";

NORMAL_TRIVIA_QUESTIONS[2552] = "(History): Who became South Dakota's first Democratic senator in 26 years by a margin of 597 votes in 1962?";
NORMAL_TRIVIA_ANSWERS1[2552] = "George McGovern";
NORMAL_TRIVIA_ANSWERS2[2552] = "McGovern";

NORMAL_TRIVIA_QUESTIONS[2553] = "(World): What hit saw the U.S. Navy bill moviemakers $1.1 million for \"technical services\"?";
NORMAL_TRIVIA_ANSWERS1[2553] = "Top Gun";
NORMAL_TRIVIA_ANSWERS2[2553] = "TopGun";

NORMAL_TRIVIA_QUESTIONS[2554] = "(Science&Nature): Who was the first president to wear false teeth?";
NORMAL_TRIVIA_ANSWERS1[2554] = "George Washington";
NORMAL_TRIVIA_ANSWERS2[2554] = "Washington";

NORMAL_TRIVIA_QUESTIONS[2555] = "(People&Places): What department store chain established it's headquarters in the Sears Tower?";
NORMAL_TRIVIA_ANSWERS1[2555] = "Sears, Roebuck and Co.";
NORMAL_TRIVIA_ANSWERS2[2555] = "Sears";

NORMAL_TRIVIA_QUESTIONS[2556] = "(Arts&Entertainment): What black star noted: \"I'm funny without drugs. I don't have to sniff cocaine to be funny\"?";
NORMAL_TRIVIA_ANSWERS1[2556] = "Eddie Murphy";
NORMAL_TRIVIA_ANSWERS2[2556] = "Murphy";

NORMAL_TRIVIA_QUESTIONS[2557] = "(Sports&Leisure): What player donned a Baltimore Orioles uniform for a major league record of 23 years?";
NORMAL_TRIVIA_ANSWERS1[2557] = "Brooks Robinson";
NORMAL_TRIVIA_ANSWERS2[2557] = "Robinson";
NORMAL_TRIVIA_ANSWERS3[2557] = "Robinsen";

NORMAL_TRIVIA_QUESTIONS[2558] = "(Sports&Leisure): What Olympic ice racer took a victory lap with a U.S. flag in one hand and his daughter Jane in the other?";
NORMAL_TRIVIA_ANSWERS1[2558] = "Dan Jansen";
NORMAL_TRIVIA_ANSWERS2[2558] = "Jansen";
NORMAL_TRIVIA_ANSWERS3[2558] = "Janson";

NORMAL_TRIVIA_QUESTIONS[2559] = "(History): What did George Armstrong Custer accidentally shoot and kill while hunting buffalo?";
NORMAL_TRIVIA_ANSWERS1[2559] = "His horse";
NORMAL_TRIVIA_ANSWERS2[2559] = "horse";

NORMAL_TRIVIA_QUESTIONS[2560] = "(World): What four-word farewell of the 1950s was inspired by a many-toothed reptile?";
NORMAL_TRIVIA_ANSWERS1[2560] = "See you later, alligator";
NORMAL_TRIVIA_ANSWERS2[2560] = "alligator";

NORMAL_TRIVIA_QUESTIONS[2561] = "(World): What subway vigilante took exception to being asked for $5 on January 25, 1985?";
NORMAL_TRIVIA_ANSWERS1[2561] = "Bernhard Goetz";
NORMAL_TRIVIA_ANSWERS2[2561] = "Bernard";
NORMAL_TRIVIA_ANSWERS3[2561] = "Bernhard";

NORMAL_TRIVIA_QUESTIONS[2562] = "(People&Places): What city did Michelangelo do \"David\" in?";
NORMAL_TRIVIA_ANSWERS1[2562] = "Florence";

NORMAL_TRIVIA_QUESTIONS[2563] = "(World): What well-known politician was a college roommate of Tommy Lee Jones?";
NORMAL_TRIVIA_ANSWERS1[2563] = "Al Gore";
NORMAL_TRIVIA_ANSWERS2[2563] = "Gore";

NORMAL_TRIVIA_QUESTIONS[2564] = "(Arts&Entertainment): What movie put Eddie Murphy on the cover of \"Newsweek\" as \"Mr. Box Office\" when he was 23?";
NORMAL_TRIVIA_ANSWERS1[2564] = "Beverly Hills Cop";
NORMAL_TRIVIA_ANSWERS2[2564] = "Beverly";

NORMAL_TRIVIA_QUESTIONS[2565] = "(Sports&Leisure): What city's vendors sell the most teddy bears made in one of their favorite baseballer's image?";
NORMAL_TRIVIA_ANSWERS1[2565] = "Minneapolis";

NORMAL_TRIVIA_QUESTIONS[2566] = "(History): What infamous six words came back to haunt George Bush in his 1992 presidential campaign?";
NORMAL_TRIVIA_ANSWERS1[2566] = "Read my lips, no new taxes";
NORMAL_TRIVIA_ANSWERS2[2566] = "read my lips";
NORMAL_TRIVIA_ANSWERS3[2566] = "no new taxes";

NORMAL_TRIVIA_QUESTIONS[2567] = "(World): What \"Married ... with Children\" star's bra was stolen from Frederick's of Hollywood in L.A. rioting?";
NORMAL_TRIVIA_ANSWERS1[2567] = "Katey Sagal's";
NORMAL_TRIVIA_ANSWERS2[2567] = "katey sagal";
NORMAL_TRIVIA_ANSWERS3[2567] = "katey";

NORMAL_TRIVIA_QUESTIONS[2568] = "(People&Places): What phrase did Abraham Lincoln use instead of \"87 years\" in his Gettysburg Address?";
NORMAL_TRIVIA_ANSWERS1[2568] = "Four score and seven years";
NORMAL_TRIVIA_ANSWERS2[2568] = "four score";

NORMAL_TRIVIA_QUESTIONS[2569] = "(World): What TV and radio host never enters the studio without his suspenders?";
NORMAL_TRIVIA_ANSWERS1[2569] = "Larry King";
NORMAL_TRIVIA_ANSWERS2[2569] = "king";

NORMAL_TRIVIA_QUESTIONS[2570] = "(People&Places): What playwright did Muammar Qaddafi insist was \"of Arab origin\" in 1989?";
NORMAL_TRIVIA_ANSWERS1[2570] = "William Shakespeare";
NORMAL_TRIVIA_ANSWERS2[2570] = "shakespeare";
NORMAL_TRIVIA_ANSWERS3[2570] = "shakespear";

NORMAL_TRIVIA_QUESTIONS[2571] = "(History): What did the Soviets send up into space on the 40th anniversary of the day the communists seized power?";
NORMAL_TRIVIA_ANSWERS1[2571] = "Sputnik I";
NORMAL_TRIVIA_ANSWERS2[2571] = "sputnik";

NORMAL_TRIVIA_QUESTIONS[2572] = "(People&Places): What country cancelled its May Day parade in 1994 for the first time since 1959, due to lack of money?";
NORMAL_TRIVIA_ANSWERS1[2572] = "Cuba";

NORMAL_TRIVIA_QUESTIONS[2573] = "(Arts&Entertainment): What five words end Charles Dicken's most famous Christmas story?";
NORMAL_TRIVIA_ANSWERS1[2573] = "God bless us every one";

NORMAL_TRIVIA_QUESTIONS[2574] = "(People&Places): What 'state' boasts the largest church in Christendom?\"";
NORMAL_TRIVIA_ANSWERS1[2574] = "Vatican City";
NORMAL_TRIVIA_ANSWERS2[2574] = "Vatican";

NORMAL_TRIVIA_QUESTIONS[2575] = "(History): Which of Cleopatra's husbands killed himself by falling on his sword?";
NORMAL_TRIVIA_ANSWERS1[2575] = "Marc Antony";
NORMAL_TRIVIA_ANSWERS2[2575] = "Antony";

NORMAL_TRIVIA_QUESTIONS[2576] = "(World): Who said: \"I was the first woman to burn my bra. It took the fire department four days to put it out\"?";
NORMAL_TRIVIA_ANSWERS1[2576] = "Dolly Parton";
NORMAL_TRIVIA_ANSWERS2[2576] = "Parton";

NORMAL_TRIVIA_QUESTIONS[2577] = "(Science&Nature): Which finger of the throwing hand is subject to a painful syndrome called \"Frisbee finger\"?";
NORMAL_TRIVIA_ANSWERS1[2577] = "The middle finger";
NORMAL_TRIVIA_ANSWERS2[2577] = "middle";

NORMAL_TRIVIA_QUESTIONS[2578] = "(Science&Nature): What Michigan doctor lead the fight for medicide, or physician-assisted suicide?";
NORMAL_TRIVIA_ANSWERS1[2578] = "Jack Kevorkian";
NORMAL_TRIVIA_ANSWERS2[2578] = "kevorkian";

NORMAL_TRIVIA_QUESTIONS[2579] = "(Arts&Entertainment): What renowned reference work did Lon Chaney write an entry on makeup for?";
NORMAL_TRIVIA_ANSWERS1[2579] = "Encyclopaedia Britannica";
NORMAL_TRIVIA_ANSWERS2[2579] = "britannica";

NORMAL_TRIVIA_QUESTIONS[2580] = "(History): What White House aide's shredding machine jammed on November 21, 1986?";
NORMAL_TRIVIA_ANSWERS1[2580] = "Oliver North's";
NORMAL_TRIVIA_ANSWERS2[2580] = "oliver";
NORMAL_TRIVIA_ANSWERS3[2580] = "north";

NORMAL_TRIVIA_QUESTIONS[2581] = "(People&Places): Whose Atlantic City hotel-casino is three times the size of the Taj Mahal, it's East Indian namesake?";
NORMAL_TRIVIA_ANSWERS1[2581] = "Donald Trump's";
NORMAL_TRIVIA_ANSWERS2[2581] = "trump";

NORMAL_TRIVIA_QUESTIONS[2582] = "(Sports&Leisure): Who won the only two U.S. Open singles titles not won by Chris Evert from 1975 through 1982?";
NORMAL_TRIVIA_ANSWERS1[2582] = "Tracy Austin";
NORMAL_TRIVIA_ANSWERS2[2582] = "austin";

NORMAL_TRIVIA_QUESTIONS[2583] = "(Arts&Entertainment): What do most people call \"Waltz Number 314\" by Johann Strauss Jr.?";
NORMAL_TRIVIA_ANSWERS1[2583] = "Blue Danube";

NORMAL_TRIVIA_QUESTIONS[2584] = "(Sports&Leisure): Who batted .373 with 47 home runs and 175 RBI the year Babe Ruth hit 60 homers?";
NORMAL_TRIVIA_ANSWERS1[2584] = "Lou Gehrig";
NORMAL_TRIVIA_ANSWERS2[2584] = "gehrig";

NORMAL_TRIVIA_QUESTIONS[2585] = "(Sports&Leisure): What baseball owner was right in assuming midget Eddie Gaedel would walk as a pinch hitter in 1951?";
NORMAL_TRIVIA_ANSWERS1[2585] = "Bill Veeck";
NORMAL_TRIVIA_ANSWERS2[2585] = "Veeck";

NORMAL_TRIVIA_QUESTIONS[2586] = "(World): What 73-year-old trapeze artist fell to his death in 1978?";
NORMAL_TRIVIA_ANSWERS1[2586] = "Karl Wallenda";
NORMAL_TRIVIA_ANSWERS2[2586] = "Wallenda";

NORMAL_TRIVIA_QUESTIONS[2587] = "(History): What was the last hotel Robert Kennedy was in before riding to his final resting place?";
NORMAL_TRIVIA_ANSWERS1[2587] = "The Ambassador";
NORMAL_TRIVIA_ANSWERS2[2587] = "Ambassador";

NORMAL_TRIVIA_QUESTIONS[2588] = "(Sports&Leisure): What hockey star was ribbed as \"The Yellow One\" because of his aversion to flying?";
NORMAL_TRIVIA_ANSWERS1[2588] = "Wayne Gretzky";
NORMAL_TRIVIA_ANSWERS2[2588] = "Gretzky";

NORMAL_TRIVIA_QUESTIONS[2589] = "(Science&Nature): Where are two Russian vehicles, auctioned at Sotheby's in 1993 for $68,500, currently parked?";
NORMAL_TRIVIA_ANSWERS1[2589] = "On the moon";
NORMAL_TRIVIA_ANSWERS2[2589] = "Moon";

NORMAL_TRIVIA_QUESTIONS[2590] = "(Sports&Leisure): What Phillies first baseman correctly noted: \"I'm not an athlete, I'm a baseball player\"?";
NORMAL_TRIVIA_ANSWERS1[2590] = "John Kruk";
NORMAL_TRIVIA_ANSWERS2[2590] = "Kruk";

NORMAL_TRIVIA_QUESTIONS[2591] = "(Science&Nature): What whale was prized for the 15 barrels of high-quality oil found behind its forehead?";
NORMAL_TRIVIA_ANSWERS1[2591] = "The sperm whale";
NORMAL_TRIVIA_ANSWERS2[2591] = "sperm";

NORMAL_TRIVIA_QUESTIONS[2592] = "(People&Places): What Virginia county's courthouse was the site of Lee's surrender to Grant?";
NORMAL_TRIVIA_ANSWERS1[2592] = "Appomattox County's";
NORMAL_TRIVIA_ANSWERS2[2592] = "Appomattox";

NORMAL_TRIVIA_QUESTIONS[2593] = "(World): How many seasons did Johnny Carson host \"The Tonight Show\"?";
NORMAL_TRIVIA_ANSWERS1[2593] = "Thirty";
NORMAL_TRIVIA_ANSWERS2[2593] = "30";

NORMAL_TRIVIA_QUESTIONS[2594] = "(Sports&Leisure): Who's the only man to win the Masters, British Open, U.S. Open, PGA and U.S. Amateur at least twice?";
NORMAL_TRIVIA_ANSWERS1[2594] = "Jack Nicklaus";
NORMAL_TRIVIA_ANSWERS2[2594] = "Nicklaus";

NORMAL_TRIVIA_QUESTIONS[2595] = "(Arts&Entertainment): What blonde strutted as a Playboy Club waitress before singing lead vocals on four No. 1 hits?";
NORMAL_TRIVIA_ANSWERS1[2595] = "Deborah Harry";
NORMAL_TRIVIA_ANSWERS2[2595] = "Harry";

NORMAL_TRIVIA_QUESTIONS[2596] = "(History): USA President Jimmy Carter, brought together Anwar Sadat and who else at the Camp David peace negotiations?";
NORMAL_TRIVIA_ANSWERS1[2596] = "Menachem Begin";
NORMAL_TRIVIA_ANSWERS2[2596] = "Begin";

NORMAL_TRIVIA_QUESTIONS[2597] = "(History): What president nearly fell out of the Wright brothers' plane while waving to a crowd?";
NORMAL_TRIVIA_ANSWERS1[2597] = "Theodore Roosevelt";
NORMAL_TRIVIA_ANSWERS2[2597] = "Roosevelt";

NORMAL_TRIVIA_QUESTIONS[2598] = "(Science&Nature): What helpful aid did the mother of Monkee Mike Nesmith invent for typists the world over?";
NORMAL_TRIVIA_ANSWERS1[2598] = "Liquid Paper Correction Fluid";
NORMAL_TRIVIA_ANSWERS2[2598] = "Liquid paper";

NORMAL_TRIVIA_QUESTIONS[2599] = "(Sports&Leisure): Who became the first black member of the Milwaukee Braves, in 1954?";
NORMAL_TRIVIA_ANSWERS1[2599] = "Hank Aaron";
NORMAL_TRIVIA_ANSWERS2[2599] = "Aaron";

NORMAL_TRIVIA_QUESTIONS[2600] = "(Sports&Leisure): Who broke baseball's color barrier, inking a contract and starting at first base in 1947?";
NORMAL_TRIVIA_ANSWERS1[2600] = "Jackie Robinson";
NORMAL_TRIVIA_ANSWERS2[2600] = "Robinson";

NORMAL_TRIVIA_QUESTIONS[2601] = "(People&Places): What mountain do Tibetans call Chomo-Lungma, or Mother Goddess of the Land?";
NORMAL_TRIVIA_ANSWERS1[2601] = "Mount Everest";
NORMAL_TRIVIA_ANSWERS2[2601] = "Everest";

NORMAL_TRIVIA_QUESTIONS[2602] = "(Arts&Entertainment): What children's book introduced the cat behind it's Cheshire grin?";
NORMAL_TRIVIA_ANSWERS1[2602] = "Alice's Adventures in Wonderland";
NORMAL_TRIVIA_ANSWERS2[2602] = "Alice";
NORMAL_TRIVIA_ANSWERS3[2602] = "Wonderland";

NORMAL_TRIVIA_QUESTIONS[2603] = "(Sports&Leisure): What hand can a realistic poker player expect to be dealt once every 649,740 hands?";
NORMAL_TRIVIA_ANSWERS1[2603] = "A royal flush";
NORMAL_TRIVIA_ANSWERS2[2603] = "royal flush";

NORMAL_TRIVIA_QUESTIONS[2604] = "(People&Places): Who was the first woman ever to cross the Atlantic Ocean by airplane?";
NORMAL_TRIVIA_ANSWERS1[2604] = "Amellia Earhart";
NORMAL_TRIVIA_ANSWERS2[2604] = "Earhart";

NORMAL_TRIVIA_QUESTIONS[2605] = "(Arts&Entertainment): Who got laughs opposite Eddie Murphy in the role of Detective Billy Rosewood?";
NORMAL_TRIVIA_ANSWERS1[2605] = "Judge Reinhold";
NORMAL_TRIVIA_ANSWERS2[2605] = "Reinhold";
NORMAL_TRIVIA_ANSWERS3[2605] = "Judge";

NORMAL_TRIVIA_QUESTIONS[2606] = "(Sports&Leisure): What baseballer teamed with Babe Ruth to form \"the greatest 1-2 punch the sport has ever known\"?";
NORMAL_TRIVIA_ANSWERS1[2606] = "Lou Gehrig";
NORMAL_TRIVIA_ANSWERS2[2606] = "Gehrig";

NORMAL_TRIVIA_QUESTIONS[2607] = "(World): What book did King James authorize the first English publication of?";
NORMAL_TRIVIA_ANSWERS1[2607] = "The Bible";
NORMAL_TRIVIA_ANSWERS2[2607] = "Bible";

NORMAL_TRIVIA_QUESTIONS[2608] = "(History): Who's the only 20th-century USA president that had earned no undergraduate degree?";
NORMAL_TRIVIA_ANSWERS1[2608] = "Harry Truman";
NORMAL_TRIVIA_ANSWERS2[2608] = "Truman";

NORMAL_TRIVIA_QUESTIONS[2609] = "(People&Places): What hill in Athens boasts the Parthenon and other temples?";
NORMAL_TRIVIA_ANSWERS1[2609] = "The Acropolis";
NORMAL_TRIVIA_ANSWERS2[2609] = "Acropolis";

NORMAL_TRIVIA_QUESTIONS[2610] = "(Sports&Leisure): What pro figure skater did a Pittsburgh Steelers star marry in 1976?";
NORMAL_TRIVIA_ANSWERS1[2610] = "Jo Jo Starbuck";
NORMAL_TRIVIA_ANSWERS2[2610] = "Starbuck";
NORMAL_TRIVIA_ANSWERS3[2610] = "Jo Jo";

NORMAL_TRIVIA_QUESTIONS[2611] = "(World): What profession did one First Lady say was \"good training for the political life which lay ahead\"?";
NORMAL_TRIVIA_ANSWERS1[2611] = "Acting";

NORMAL_TRIVIA_QUESTIONS[2612] = "(World): What replacement did station KFBK rush to hire after letting Morton Downey Jr. go in 1984?";
NORMAL_TRIVIA_ANSWERS1[2612] = "Rush Limbaugh";
NORMAL_TRIVIA_ANSWERS2[2612] = "rush";
NORMAL_TRIVIA_ANSWERS3[2612] = "limbaugh";

NORMAL_TRIVIA_QUESTIONS[2613] = "(Sports&Leisure): What major league baseball team shares it's name with young bears?";
NORMAL_TRIVIA_ANSWERS1[2613] = "The Chicago Cubs";
NORMAL_TRIVIA_ANSWERS2[2613] = "chicago cubs";

NORMAL_TRIVIA_QUESTIONS[2614] = "(History): What three-word line of General MacArthur's appear on countless items dropped over the Philippines? ";
NORMAL_TRIVIA_ANSWERS1[2614] = "I shall return";

NORMAL_TRIVIA_QUESTIONS[2615] = "(World): What Hungarian name was given to 37 pet pooches registered in Los Angeles County by 1991?";
NORMAL_TRIVIA_ANSWERS1[2615] = "Zsa Zsa";

NORMAL_TRIVIA_QUESTIONS[2616] = "(History): What five-word plea by Rodney King made the cover of \"Time\" after the 1992 Los Angeles riots took place?";
NORMAL_TRIVIA_ANSWERS1[2616] = "Can't we all get along?";
NORMAL_TRIVIA_ANSWERS2[2616] = "get along";

NORMAL_TRIVIA_QUESTIONS[2617] = "(History): What U.S. general died in a Heidelberg hospital of lung congestion after a freak car accident?";
NORMAL_TRIVIA_ANSWERS1[2617] = "George Patton";
NORMAL_TRIVIA_ANSWERS2[2617] = "patton";

NORMAL_TRIVIA_QUESTIONS[2618] = "(World): What Hindu god is said to have appeared on Earth as Rama, Krishna and Buddha?";
NORMAL_TRIVIA_ANSWERS1[2618] = "Vishnu";

NORMAL_TRIVIA_QUESTIONS[2619] = "(World): What president adorns the double sawbuck?";
NORMAL_TRIVIA_ANSWERS1[2619] = "Andrew Jackson";
NORMAL_TRIVIA_ANSWERS2[2619] = "jackson";

NORMAL_TRIVIA_QUESTIONS[2620] = "(Arts&Entertainment): What 1987 movie earned Cher her first best actress Oscar?";
NORMAL_TRIVIA_ANSWERS1[2620] = "Moonstruck";
NORMAL_TRIVIA_ANSWERS2[2620] = "Moon struck";

NORMAL_TRIVIA_QUESTIONS[2621] = "(Sports&Leisure): What metal is an Olympic gold medal mostly made of?";
NORMAL_TRIVIA_ANSWERS1[2621] = "Silver";

NORMAL_TRIVIA_QUESTIONS[2622] = "(People&Places): Who flew the Concord to sing in both the London and Philadelphia parts of Live Aid on the same day?";
NORMAL_TRIVIA_ANSWERS1[2622] = "Phil Collins";
NORMAL_TRIVIA_ANSWERS2[2622] = "collins";

NORMAL_TRIVIA_QUESTIONS[2623] = "(Sports&Leisure): Whose bare feet did 3,000-meter runner Mary Decker trip over at the 1984 Olympics?";
NORMAL_TRIVIA_ANSWERS1[2623] = "Zola Budd's";
NORMAL_TRIVIA_ANSWERS2[2623] = "zola budd";

NORMAL_TRIVIA_QUESTIONS[2624] = "(Science&Nature): What comet was named for the man who predicted it would return in 1758?";
NORMAL_TRIVIA_ANSWERS1[2624] = "Halley's comet";
NORMAL_TRIVIA_ANSWERS2[2624] = "halley";

NORMAL_TRIVIA_QUESTIONS[2625] = "(People&Places): What modern-day city was renamed Leningrad when this Bolshevik died?";
NORMAL_TRIVIA_ANSWERS1[2625] = "St. Petersburg";
NORMAL_TRIVIA_ANSWERS2[2625] = "petersburg";

NORMAL_TRIVIA_QUESTIONS[2626] = "(History): What memorable line did John Paul Jones allegedly utter during a sea battle with the British?";
NORMAL_TRIVIA_ANSWERS1[2626] = "I have not yet begun to fight";

NORMAL_TRIVIA_QUESTIONS[2627] = "(People&Places): Who left his heart in San Francisco in a 1962 classic song?";
NORMAL_TRIVIA_ANSWERS1[2627] = "Tony Bennett";
NORMAL_TRIVIA_ANSWERS2[2627] = "Bennett";

NORMAL_TRIVIA_QUESTIONS[2628] = "(Sports&Leisure): Who became golf's first career $5 million winner in 1988?";
NORMAL_TRIVIA_ANSWERS1[2628] = "Jack Nicklaus";
NORMAL_TRIVIA_ANSWERS2[2628] = "Nicklaus";

NORMAL_TRIVIA_QUESTIONS[2629] = "(Sports&Leisure): Whose World Series heroics prompted George Steinbrenner to dub him \"Mr. October\"?";
NORMAL_TRIVIA_ANSWERS1[2629] = "Reggie Jackson's";
NORMAL_TRIVIA_ANSWERS2[2629] = "jackson";

NORMAL_TRIVIA_QUESTIONS[2630] = "(Science&Nature): What fruit is grown by 94 percent of backyard gardeners?";
NORMAL_TRIVIA_ANSWERS1[2630] = "The tomato";
NORMAL_TRIVIA_ANSWERS2[2630] = "tomato";

NORMAL_TRIVIA_QUESTIONS[2631] = "(World): Whose fans wore lapel buttons bearing saxophones on January 20, 1993?";
NORMAL_TRIVIA_ANSWERS1[2631] = "Bill Clinton's";
NORMAL_TRIVIA_ANSWERS2[2631] = "clinton";

NORMAL_TRIVIA_QUESTIONS[2632] = "(History): What Supreme Court justice hosted and officiated at the 1994 marriage of Rush Limbaugh?";
NORMAL_TRIVIA_ANSWERS1[2632] = "Clarence Thomas";
NORMAL_TRIVIA_ANSWERS2[2632] = "clarence";
NORMAL_TRIVIA_ANSWERS3[2632] = "thomas";
